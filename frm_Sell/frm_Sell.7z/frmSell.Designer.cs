﻿namespace MLM_Program
{
    partial class frmSell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_Us = new System.Windows.Forms.TextBox();
            this.butt_Excel = new System.Windows.Forms.Button();
            this.tab_Sell = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chart_Item = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.chart_edu = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart_Leave = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart_Mem = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Save = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            this.txtCenter = new System.Windows.Forms.TextBox();
            this.txtCenter_Code = new System.Windows.Forms.TextBox();
            this.mtxtSn = new System.Windows.Forms.MaskedTextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.dGridView_Base = new System.Windows.Forms.DataGridView();
            this.txt_ETC1 = new System.Windows.Forms.TextBox();
            this.txtCenter2_Code = new System.Windows.Forms.TextBox();
            this.txtCenter2 = new System.Windows.Forms.TextBox();
            this.txtSellCode_Code = new System.Windows.Forms.TextBox();
            this.txtSellCode = new System.Windows.Forms.TextBox();
            this.DTP_SellDate = new System.Windows.Forms.DateTimePicker();
            this.butt_Ord_Clear = new System.Windows.Forms.Button();
            this.txt_Ins_Number = new System.Windows.Forms.TextBox();
            this.txt_TotalPv = new System.Windows.Forms.TextBox();
            this.txt_UnaccMoney = new System.Windows.Forms.TextBox();
            this.txt_TotalInputPrice = new System.Windows.Forms.TextBox();
            this.txt_TotalPrice = new System.Windows.Forms.TextBox();
            this.txt_OrderNumber = new System.Windows.Forms.TextBox();
            this.dGridView_Base_Item = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.txt_Item_Etc = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txt_ItemCount = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txt_ItemCode = new System.Windows.Forms.TextBox();
            this.txt_ItemName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_SalesItemIndex = new System.Windows.Forms.TextBox();
            this.butt_Item_Del = new System.Windows.Forms.Button();
            this.butt_Item_Clear = new System.Windows.Forms.Button();
            this.butt_Item_Save = new System.Windows.Forms.Button();
            this.txt_SumCnt = new System.Windows.Forms.TextBox();
            this.txt_SumPV = new System.Windows.Forms.TextBox();
            this.txt_SumPr = new System.Windows.Forms.TextBox();
            this.panel_Cacu = new System.Windows.Forms.Panel();
            this.dGridView_Base_Cacu = new System.Windows.Forms.DataGridView();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.txt_C_Etc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_C_index = new System.Windows.Forms.TextBox();
            this.butt_Cacu_Del = new System.Windows.Forms.Button();
            this.butt_Cacu_Save = new System.Windows.Forms.Button();
            this.butt_Cacu_Clear = new System.Windows.Forms.Button();
            this.tab_Cacu = new System.Windows.Forms.TabControl();
            this.tab_Card = new System.Windows.Forms.TabPage();
            this.button_Ok = new System.Windows.Forms.Button();
            this.tableLayoutPanel59 = new System.Windows.Forms.TableLayoutPanel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.txt_C_B_Number = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.tableLayoutPanel72 = new System.Windows.Forms.TableLayoutPanel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.txt_C_P_Number = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.txt_C_Card_Month = new System.Windows.Forms.TextBox();
            this.txt_C_Card_Year = new System.Windows.Forms.TextBox();
            this.combo_C_Card_Year = new System.Windows.Forms.ComboBox();
            this.combo_C_Card_Month = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.tableLayoutPanel55 = new System.Windows.Forms.TableLayoutPanel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.txt_Price_3_2 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tableLayoutPanel57 = new System.Windows.Forms.TableLayoutPanel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.combo_C_Card_Per = new System.Windows.Forms.ComboBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.txt_Price_3 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tableLayoutPanel50 = new System.Windows.Forms.TableLayoutPanel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.mtxtPriceDate3 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate3 = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.tableLayoutPanel54 = new System.Windows.Forms.TableLayoutPanel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.txt_C_Card_Ap_Num = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.txt_C_Card = new System.Windows.Forms.TextBox();
            this.txt_C_Card_Code = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel53 = new System.Windows.Forms.TableLayoutPanel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.txt_C_Name_3 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.txt_C_Card_Number = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tableL_CD = new System.Windows.Forms.TableLayoutPanel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.txt_Price_CC = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.tab_Cash = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel74 = new System.Windows.Forms.TableLayoutPanel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.label83 = new System.Windows.Forms.Label();
            this.check_Cash_Pre = new System.Windows.Forms.CheckBox();
            this.label84 = new System.Windows.Forms.Label();
            this.txt_C_Cash_Number2 = new System.Windows.Forms.TextBox();
            this.check_Not_Cash = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel48 = new System.Windows.Forms.TableLayoutPanel();
            this.panel77 = new System.Windows.Forms.Panel();
            this.label62 = new System.Windows.Forms.Label();
            this.txt_C_Cash_Number2_2 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txt_C_Cash_Send_Nu = new System.Windows.Forms.TextBox();
            this.radioB_C_Cash_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_C_Cash_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.check_Cash = new System.Windows.Forms.CheckBox();
            this.label60 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_Price_1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.mtxtPriceDate1 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate1 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.tab_Bank = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel76 = new System.Windows.Forms.TableLayoutPanel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.label87 = new System.Windows.Forms.Label();
            this.txt_C_Bank_Number2_2 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.txt_C_Bank_Send_Nu = new System.Windows.Forms.TextBox();
            this.radioB_C_Bank_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_C_Bank_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.label89 = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.txt_C_Bank_Code_3 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.txt_C_Bank_Code_2 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.txt_C_Bank_Code = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.txt_C_Bank = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txt_C_Name_2 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_Price_2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.mtxtPriceDate2 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate2 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.tab_VA_Bank = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel75 = new System.Windows.Forms.Panel();
            this.txtBank = new System.Windows.Forms.TextBox();
            this.txtBank_Code = new System.Windows.Forms.TextBox();
            this.txt_AV_C_Number3 = new System.Windows.Forms.TextBox();
            this.buttonV_Cancel = new System.Windows.Forms.Button();
            this.buttonV_Ok = new System.Windows.Forms.Button();
            this.tableLayoutPanel60 = new System.Windows.Forms.TableLayoutPanel();
            this.panel82 = new System.Windows.Forms.Panel();
            this.txt_AV_C_Number1 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.tableLayoutPanel70 = new System.Windows.Forms.TableLayoutPanel();
            this.panel84 = new System.Windows.Forms.Panel();
            this.txt_AV_C_Code = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.tableLayoutPanel71 = new System.Windows.Forms.TableLayoutPanel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.txt_Price_5 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.tableLayoutPanel69 = new System.Windows.Forms.TableLayoutPanel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.txt_AV_C_AppDate1 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.tableLayoutPanel73 = new System.Windows.Forms.TableLayoutPanel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.txt_Price_5_2 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.check_Not_AVCash = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.label63 = new System.Windows.Forms.Label();
            this.txt_AVC_Cash_Number2 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txt_AVC_Cash_Send_Nu = new System.Windows.Forms.TextBox();
            this.radioB_AVC_Cash_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_AVC_Cash_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.check_AVCash = new System.Windows.Forms.CheckBox();
            this.label78 = new System.Windows.Forms.Label();
            this.tab_Mile = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.txt_Price_4_2 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.txt_Price_4 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.mtxtPriceDate4 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate4 = new System.Windows.Forms.DateTimePicker();
            this.label40 = new System.Windows.Forms.Label();
            this.butt_Mile_Search = new System.Windows.Forms.Button();
            this.panel42 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.chk_app = new System.Windows.Forms.CheckBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.txt_SumMile = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_Sugi_TF = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.txt_SumBank = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.txt_SumCash = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.txt_SumCard = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_RecIndex = new System.Windows.Forms.TextBox();
            this.butt_Rec_Del = new System.Windows.Forms.Button();
            this.butt_Rec_Clear = new System.Windows.Forms.Button();
            this.butt_Rec_Save = new System.Windows.Forms.Button();
            this.butt_Rec_Add = new System.Windows.Forms.Button();
            this.opt_Rec_Add3 = new System.Windows.Forms.RadioButton();
            this.opt_Rec_Add2 = new System.Windows.Forms.RadioButton();
            this.opt_Rec_Add1 = new System.Windows.Forms.RadioButton();
            this.label26 = new System.Windows.Forms.Label();
            this.txt_Base_Rec_Code = new System.Windows.Forms.TextBox();
            this.txt_Base_Rec = new System.Windows.Forms.TextBox();
            this.txt_Pass_Number = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtGetDate1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.butt_AddCode = new System.Windows.Forms.Button();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txt_Get_Etc1 = new System.Windows.Forms.TextBox();
            this.txt_Get_Name1 = new System.Windows.Forms.TextBox();
            this.DTP_GetDate1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Receive_Method_Code = new System.Windows.Forms.TextBox();
            this.txt_Receive_Method = new System.Windows.Forms.TextBox();
            this.dGridView_Base_Rece_Item = new System.Windows.Forms.DataGridView();
            this.dGridView_Base_Rece_Add = new System.Windows.Forms.DataGridView();
            this.txt_SOrd = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.txt_SumCV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dGridView_Base_Rece = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel77 = new System.Windows.Forms.TableLayoutPanel();
            this.label90 = new System.Windows.Forms.Label();
            this.panel92 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.mtxtZip1 = new System.Windows.Forms.MaskedTextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.mtxtTel2 = new System.Windows.Forms.MaskedTextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.mtxtTel1 = new System.Windows.Forms.MaskedTextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.pan_Rec_Item = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.chk_Total = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel75 = new System.Windows.Forms.TableLayoutPanel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.txt_Tel = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.tableLayoutPanel61 = new System.Windows.Forms.TableLayoutPanel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label64 = new System.Windows.Forms.Label();
            this.tableLayoutPanel62 = new System.Windows.Forms.TableLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label65 = new System.Windows.Forms.Label();
            this.tableLayoutPanel64 = new System.Windows.Forms.TableLayoutPanel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label67 = new System.Windows.Forms.Label();
            this.tableLayoutPanel63 = new System.Windows.Forms.TableLayoutPanel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label66 = new System.Windows.Forms.Label();
            this.tableLayoutPanel65 = new System.Windows.Forms.TableLayoutPanel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label68 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel58 = new System.Windows.Forms.TableLayoutPanel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.radioB_CALL = new System.Windows.Forms.RadioButton();
            this.radioB_DESK = new System.Windows.Forms.RadioButton();
            this.label79 = new System.Windows.Forms.Label();
            this.tableLayoutPanel47 = new System.Windows.Forms.TableLayoutPanel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.txt_InputPass_Pay = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txt_TotalCV = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.tableLayoutPanel68 = new System.Windows.Forms.TableLayoutPanel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label71 = new System.Windows.Forms.Label();
            this.tableLayoutPanel67 = new System.Windows.Forms.TableLayoutPanel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label70 = new System.Windows.Forms.Label();
            this.tableLayoutPanel66 = new System.Windows.Forms.TableLayoutPanel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label69 = new System.Windows.Forms.Label();
            this.tableLayoutPanel56 = new System.Windows.Forms.TableLayoutPanel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.mtxtSellDate2 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_SellDate2 = new System.Windows.Forms.DateTimePicker();
            this.label37 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.lblSellCode_Code = new System.Windows.Forms.Label();
            this.lblSellCode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.mtxtSellDate = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.butt_Print = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label55 = new System.Windows.Forms.Label();
            this.txt_ETC2 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pane_Cash = new System.Windows.Forms.Panel();
            this.pane_Card = new System.Windows.Forms.Panel();
            this.pane_Bank = new System.Windows.Forms.Panel();
            this.dGridView_Base_Mile = new System.Windows.Forms.DataGridView();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.tab_Sell.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Item)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart_edu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Leave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Mem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Item)).BeginInit();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.panel37.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel_Cacu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Cacu)).BeginInit();
            this.panel66.SuspendLayout();
            this.panel18.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel48.SuspendLayout();
            this.tab_Cacu.SuspendLayout();
            this.tab_Card.SuspendLayout();
            this.tableLayoutPanel59.SuspendLayout();
            this.panel80.SuspendLayout();
            this.tableLayoutPanel72.SuspendLayout();
            this.panel81.SuspendLayout();
            this.tableLayoutPanel52.SuspendLayout();
            this.panel53.SuspendLayout();
            this.tableLayoutPanel55.SuspendLayout();
            this.panel56.SuspendLayout();
            this.tableLayoutPanel57.SuspendLayout();
            this.panel57.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.panel50.SuspendLayout();
            this.tableLayoutPanel50.SuspendLayout();
            this.panel51.SuspendLayout();
            this.tableLayoutPanel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.panel49.SuspendLayout();
            this.tableLayoutPanel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.tableLayoutPanel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.tableL_CD.SuspendLayout();
            this.panel88.SuspendLayout();
            this.tab_Cash.SuspendLayout();
            this.tableLayoutPanel74.SuspendLayout();
            this.panel86.SuspendLayout();
            this.tableLayoutPanel48.SuspendLayout();
            this.panel77.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tab_Bank.SuspendLayout();
            this.tableLayoutPanel76.SuspendLayout();
            this.panel91.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.panel62.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.panel60.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.panel61.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.panel59.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.panel58.SuspendLayout();
            this.tab_VA_Bank.SuspendLayout();
            this.tableLayoutPanel46.SuspendLayout();
            this.panel75.SuspendLayout();
            this.tableLayoutPanel60.SuspendLayout();
            this.panel82.SuspendLayout();
            this.tableLayoutPanel70.SuspendLayout();
            this.panel84.SuspendLayout();
            this.tableLayoutPanel71.SuspendLayout();
            this.panel85.SuspendLayout();
            this.tableLayoutPanel69.SuspendLayout();
            this.panel83.SuspendLayout();
            this.tableLayoutPanel73.SuspendLayout();
            this.panel87.SuspendLayout();
            this.tableLayoutPanel49.SuspendLayout();
            this.panel78.SuspendLayout();
            this.tab_Mile.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.panel65.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.panel63.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel42.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            this.panel74.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.panel47.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.panel46.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.panel45.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.panel44.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel43.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Item)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Add)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.panel38.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.panel41.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.panel39.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.panel40.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel77.SuspendLayout();
            this.panel92.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.panel68.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.panel73.SuspendLayout();
            this.tableLayoutPanel40.SuspendLayout();
            this.panel72.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            this.panel71.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.panel69.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.panel70.SuspendLayout();
            this.pan_Rec_Item.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel29.SuspendLayout();
            this.tableLayoutPanel75.SuspendLayout();
            this.panel89.SuspendLayout();
            this.tableLayoutPanel61.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tableLayoutPanel62.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tableLayoutPanel64.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tableLayoutPanel63.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel65.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel58.SuspendLayout();
            this.panel79.SuspendLayout();
            this.tableLayoutPanel47.SuspendLayout();
            this.panel76.SuspendLayout();
            this.tableLayoutPanel44.SuspendLayout();
            this.panel23.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel68.SuspendLayout();
            this.panel36.SuspendLayout();
            this.tableLayoutPanel67.SuspendLayout();
            this.panel35.SuspendLayout();
            this.tableLayoutPanel66.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tableLayoutPanel56.SuspendLayout();
            this.panel33.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel32.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel31.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Mile)).BeginInit();
            this.panel67.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txt_Us);
            this.panel1.Controls.Add(this.butt_Excel);
            this.panel1.Controls.Add(this.tab_Sell);
            this.panel1.Controls.Add(this.butt_Delete);
            this.panel1.Controls.Add(this.butt_Clear);
            this.panel1.Controls.Add(this.butt_Save);
            this.panel1.Controls.Add(this.butt_Exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1806, 28);
            this.panel1.TabIndex = 200;
            // 
            // txt_Us
            // 
            this.txt_Us.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Us.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Us.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_Us.ForeColor = System.Drawing.Color.Blue;
            this.txt_Us.Location = new System.Drawing.Point(933, 5);
            this.txt_Us.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Us.MaxLength = 30;
            this.txt_Us.Name = "txt_Us";
            this.txt_Us.ReadOnly = true;
            this.txt_Us.Size = new System.Drawing.Size(61, 21);
            this.txt_Us.TabIndex = 174;
            this.txt_Us.TabStop = false;
            this.txt_Us.Visible = false;
            // 
            // butt_Excel
            // 
            this.butt_Excel.BackColor = System.Drawing.Color.White;
            this.butt_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel.Location = new System.Drawing.Point(528, 29);
            this.butt_Excel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel.Name = "butt_Excel";
            this.butt_Excel.Size = new System.Drawing.Size(111, 26);
            this.butt_Excel.TabIndex = 4;
            this.butt_Excel.TabStop = false;
            this.butt_Excel.Text = "Kicc_등록";
            this.butt_Excel.UseVisualStyleBackColor = false;
            this.butt_Excel.Click += new System.EventHandler(this.butt_Excel_Click);
            // 
            // tab_Sell
            // 
            this.tab_Sell.Controls.Add(this.tabPage1);
            this.tab_Sell.Controls.Add(this.tabPage2);
            this.tab_Sell.Controls.Add(this.tabPage3);
            this.tab_Sell.Location = new System.Drawing.Point(1032, 4);
            this.tab_Sell.Name = "tab_Sell";
            this.tab_Sell.SelectedIndex = 0;
            this.tab_Sell.Size = new System.Drawing.Size(180, 24);
            this.tab_Sell.TabIndex = 151;
            this.tab_Sell.TabStop = false;
            this.tab_Sell.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(172, 0);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "판매_내역";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chart_Item);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(172, 0);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "판매_집계";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chart_Item
            // 
            this.chart_Item.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            this.chart_Item.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            chartArea5.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea5.Name = "ChartArea1";
            this.chart_Item.ChartAreas.Add(chartArea5);
            this.chart_Item.Dock = System.Windows.Forms.DockStyle.Fill;
            legend5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            legend5.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            legend5.Name = "Legend1";
            this.chart_Item.Legends.Add(legend5);
            this.chart_Item.Location = new System.Drawing.Point(3, 3);
            this.chart_Item.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chart_Item.Name = "chart_Item";
            this.chart_Item.Size = new System.Drawing.Size(166, 0);
            this.chart_Item.TabIndex = 31;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            this.tabPage3.Controls.Add(this.chart_edu);
            this.tabPage3.Controls.Add(this.chart_Leave);
            this.tabPage3.Controls.Add(this.chart_Mem);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(172, 0);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "판매_집계II";
            // 
            // chart_edu
            // 
            this.chart_edu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            this.chart_edu.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            chartArea6.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea6.Name = "ChartArea1";
            this.chart_edu.ChartAreas.Add(chartArea6);
            legend6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            legend6.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            legend6.Name = "Legend1";
            this.chart_edu.Legends.Add(legend6);
            this.chart_edu.Location = new System.Drawing.Point(452, 3);
            this.chart_edu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chart_edu.Name = "chart_edu";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chart_edu.Series.Add(series4);
            this.chart_edu.Size = new System.Drawing.Size(223, 220);
            this.chart_edu.TabIndex = 4;
            this.chart_edu.Text = "chart2";
            // 
            // chart_Leave
            // 
            this.chart_Leave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            this.chart_Leave.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            chartArea7.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea7.Name = "ChartArea1";
            this.chart_Leave.ChartAreas.Add(chartArea7);
            legend7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            legend7.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            legend7.Name = "Legend1";
            this.chart_Leave.Legends.Add(legend7);
            this.chart_Leave.Location = new System.Drawing.Point(226, 4);
            this.chart_Leave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chart_Leave.Name = "chart_Leave";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chart_Leave.Series.Add(series5);
            this.chart_Leave.Size = new System.Drawing.Size(223, 220);
            this.chart_Leave.TabIndex = 3;
            this.chart_Leave.Text = "chart2";
            // 
            // chart_Mem
            // 
            this.chart_Mem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            this.chart_Mem.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.chart_Mem.BorderSkin.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dash;
            chartArea8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(241)))), ((int)(((byte)(220)))));
            chartArea8.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea8.Name = "ChartArea1";
            this.chart_Mem.ChartAreas.Add(chartArea8);
            legend8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            legend8.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            legend8.Name = "Legend1";
            this.chart_Mem.Legends.Add(legend8);
            this.chart_Mem.Location = new System.Drawing.Point(3, 4);
            this.chart_Mem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chart_Mem.Name = "chart_Mem";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chart_Mem.Series.Add(series6);
            this.chart_Mem.Size = new System.Drawing.Size(223, 220);
            this.chart_Mem.TabIndex = 2;
            this.chart_Mem.Text = "chart1";
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(125, 1);
            this.butt_Delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(111, 26);
            this.butt_Delete.TabIndex = 3;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "구매_취소";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Visible = false;
            this.butt_Delete.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.Location = new System.Drawing.Point(266, 1);
            this.butt_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(111, 26);
            this.butt_Clear.TabIndex = 2;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            this.butt_Clear.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.White;
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.Location = new System.Drawing.Point(411, 1);
            this.butt_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(111, 26);
            this.butt_Save.TabIndex = 3;
            this.butt_Save.Text = "저장";
            this.butt_Save.UseVisualStyleBackColor = false;
            this.butt_Save.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(658, 1);
            this.butt_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(111, 26);
            this.butt_Exit.TabIndex = 0;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            this.butt_Exit.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // txtCenter
            // 
            this.txtCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCenter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCenter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCenter.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter.Location = new System.Drawing.Point(3, 3);
            this.txtCenter.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtCenter.MaxLength = 30;
            this.txtCenter.Name = "txtCenter";
            this.txtCenter.ReadOnly = true;
            this.txtCenter.Size = new System.Drawing.Size(117, 22);
            this.txtCenter.TabIndex = 158;
            this.txtCenter.TabStop = false;
            this.txtCenter.Tag = "ncode";
            // 
            // txtCenter_Code
            // 
            this.txtCenter_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtCenter_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter_Code.Location = new System.Drawing.Point(120, 3);
            this.txtCenter_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter_Code.MaxLength = 30;
            this.txtCenter_Code.Name = "txtCenter_Code";
            this.txtCenter_Code.Size = new System.Drawing.Size(47, 22);
            this.txtCenter_Code.TabIndex = 159;
            this.txtCenter_Code.TabStop = false;
            // 
            // mtxtSn
            // 
            this.mtxtSn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtSn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.mtxtSn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtSn.Location = new System.Drawing.Point(3, 3);
            this.mtxtSn.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSn.Name = "mtxtSn";
            this.mtxtSn.ReadOnly = true;
            this.mtxtSn.Size = new System.Drawing.Size(164, 21);
            this.mtxtSn.TabIndex = 151;
            this.mtxtSn.TabStop = false;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName.Location = new System.Drawing.Point(3, 3);
            this.txtName.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(164, 22);
            this.txtName.TabIndex = 1;
            this.txtName.TabStop = false;
            this.txtName.Tag = "name";
            this.txtName.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtName.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtMbid.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.mtxtMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtMbid.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.Size = new System.Drawing.Size(164, 21);
            this.mtxtMbid.TabIndex = 0;
            this.mtxtMbid.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtxtMbid_MaskInputRejected);
            this.mtxtMbid.Click += new System.EventHandler(this.mtxtMbid_Click);
            this.mtxtMbid.TextChanged += new System.EventHandler(this.mtxtMbid_TextChanged);
            this.mtxtMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_KeyPress);
            this.mtxtMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // dGridView_Base
            // 
            this.dGridView_Base.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dGridView_Base.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base.DefaultCellStyle = dataGridViewCellStyle16;
            this.dGridView_Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base.Location = new System.Drawing.Point(306, 0);
            this.dGridView_Base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base.Name = "dGridView_Base";
            this.dGridView_Base.RowTemplate.Height = 23;
            this.dGridView_Base.Size = new System.Drawing.Size(1498, 182);
            this.dGridView_Base.TabIndex = 150;
            this.dGridView_Base.TabStop = false;
            this.dGridView_Base.DoubleClick += new System.EventHandler(this.dGridView_Base_DoubleClick);
            // 
            // txt_ETC1
            // 
            this.txt_ETC1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC1.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ETC1.MaxLength = 100;
            this.txt_ETC1.Multiline = true;
            this.txt_ETC1.Name = "txt_ETC1";
            this.txt_ETC1.Size = new System.Drawing.Size(134, 81);
            this.txt_ETC1.TabIndex = 3;
            this.txt_ETC1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_ETC1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_ETC1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_ETC1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtCenter2_Code
            // 
            this.txtCenter2_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtCenter2_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter2_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter2_Code.Location = new System.Drawing.Point(96, 3);
            this.txtCenter2_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter2_Code.MaxLength = 30;
            this.txtCenter2_Code.Name = "txtCenter2_Code";
            this.txtCenter2_Code.Size = new System.Drawing.Size(42, 22);
            this.txtCenter2_Code.TabIndex = 106;
            this.txtCenter2_Code.TabStop = false;
            // 
            // txtCenter2
            // 
            this.txtCenter2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter2.Location = new System.Drawing.Point(3, 3);
            this.txtCenter2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter2.MaxLength = 30;
            this.txtCenter2.Name = "txtCenter2";
            this.txtCenter2.Size = new System.Drawing.Size(93, 22);
            this.txtCenter2.TabIndex = 2;
            this.txtCenter2.Tag = "ncode";
            this.txtCenter2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtCenter2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtCenter2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtCenter2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtSellCode_Code
            // 
            this.txtSellCode_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtSellCode_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode_Code.ForeColor = System.Drawing.Color.Lime;
            this.txtSellCode_Code.Location = new System.Drawing.Point(96, 3);
            this.txtSellCode_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode_Code.MaxLength = 30;
            this.txtSellCode_Code.Name = "txtSellCode_Code";
            this.txtSellCode_Code.Size = new System.Drawing.Size(42, 22);
            this.txtSellCode_Code.TabIndex = 103;
            this.txtSellCode_Code.TabStop = false;
            this.txtSellCode_Code.Leave += new System.EventHandler(this.txtSellCode_Code_Leave);
            // 
            // txtSellCode
            // 
            this.txtSellCode.BackColor = System.Drawing.Color.White;
            this.txtSellCode.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode.Location = new System.Drawing.Point(3, 3);
            this.txtSellCode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode.MaxLength = 30;
            this.txtSellCode.Name = "txtSellCode";
            this.txtSellCode.Size = new System.Drawing.Size(93, 22);
            this.txtSellCode.TabIndex = 1;
            this.txtSellCode.Tag = "ncode";
            this.txtSellCode.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtSellCode.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtSellCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtSellCode.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_SellDate
            // 
            this.DTP_SellDate.Location = new System.Drawing.Point(116, 4);
            this.DTP_SellDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate.Name = "DTP_SellDate";
            this.DTP_SellDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate.TabIndex = 105;
            this.DTP_SellDate.TabStop = false;
            this.DTP_SellDate.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // butt_Ord_Clear
            // 
            this.butt_Ord_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Ord_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Ord_Clear.Location = new System.Drawing.Point(2, 1);
            this.butt_Ord_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Ord_Clear.Name = "butt_Ord_Clear";
            this.butt_Ord_Clear.Size = new System.Drawing.Size(269, 29);
            this.butt_Ord_Clear.TabIndex = 167;
            this.butt_Ord_Clear.TabStop = false;
            this.butt_Ord_Clear.Text = "새구매_등록";
            this.butt_Ord_Clear.UseVisualStyleBackColor = false;
            this.butt_Ord_Clear.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // txt_Ins_Number
            // 
            this.txt_Ins_Number.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Ins_Number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Ins_Number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Ins_Number.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_Ins_Number.ForeColor = System.Drawing.Color.IndianRed;
            this.txt_Ins_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_Ins_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Ins_Number.MaxLength = 30;
            this.txt_Ins_Number.Name = "txt_Ins_Number";
            this.txt_Ins_Number.ReadOnly = true;
            this.txt_Ins_Number.Size = new System.Drawing.Size(134, 21);
            this.txt_Ins_Number.TabIndex = 167;
            this.txt_Ins_Number.TabStop = false;
            // 
            // txt_TotalPv
            // 
            this.txt_TotalPv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_TotalPv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_TotalPv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TotalPv.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_TotalPv.Location = new System.Drawing.Point(3, 4);
            this.txt_TotalPv.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_TotalPv.MaxLength = 30;
            this.txt_TotalPv.Name = "txt_TotalPv";
            this.txt_TotalPv.ReadOnly = true;
            this.txt_TotalPv.Size = new System.Drawing.Size(164, 21);
            this.txt_TotalPv.TabIndex = 166;
            this.txt_TotalPv.TabStop = false;
            // 
            // txt_UnaccMoney
            // 
            this.txt_UnaccMoney.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_UnaccMoney.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_UnaccMoney.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_UnaccMoney.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_UnaccMoney.ForeColor = System.Drawing.Color.Red;
            this.txt_UnaccMoney.Location = new System.Drawing.Point(3, 3);
            this.txt_UnaccMoney.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_UnaccMoney.MaxLength = 30;
            this.txt_UnaccMoney.Name = "txt_UnaccMoney";
            this.txt_UnaccMoney.ReadOnly = true;
            this.txt_UnaccMoney.Size = new System.Drawing.Size(81, 21);
            this.txt_UnaccMoney.TabIndex = 175;
            this.txt_UnaccMoney.TabStop = false;
            // 
            // txt_TotalInputPrice
            // 
            this.txt_TotalInputPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_TotalInputPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_TotalInputPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TotalInputPrice.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_TotalInputPrice.ForeColor = System.Drawing.Color.Blue;
            this.txt_TotalInputPrice.Location = new System.Drawing.Point(3, 3);
            this.txt_TotalInputPrice.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_TotalInputPrice.MaxLength = 30;
            this.txt_TotalInputPrice.Name = "txt_TotalInputPrice";
            this.txt_TotalInputPrice.ReadOnly = true;
            this.txt_TotalInputPrice.Size = new System.Drawing.Size(81, 21);
            this.txt_TotalInputPrice.TabIndex = 173;
            this.txt_TotalInputPrice.TabStop = false;
            // 
            // txt_TotalPrice
            // 
            this.txt_TotalPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_TotalPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_TotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TotalPrice.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_TotalPrice.ForeColor = System.Drawing.Color.Blue;
            this.txt_TotalPrice.Location = new System.Drawing.Point(3, 4);
            this.txt_TotalPrice.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_TotalPrice.MaxLength = 30;
            this.txt_TotalPrice.Name = "txt_TotalPrice";
            this.txt_TotalPrice.ReadOnly = true;
            this.txt_TotalPrice.Size = new System.Drawing.Size(164, 21);
            this.txt_TotalPrice.TabIndex = 165;
            this.txt_TotalPrice.TabStop = false;
            // 
            // txt_OrderNumber
            // 
            this.txt_OrderNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_OrderNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_OrderNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_OrderNumber.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_OrderNumber.ForeColor = System.Drawing.Color.IndianRed;
            this.txt_OrderNumber.Location = new System.Drawing.Point(3, 3);
            this.txt_OrderNumber.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_OrderNumber.MaxLength = 30;
            this.txt_OrderNumber.Name = "txt_OrderNumber";
            this.txt_OrderNumber.ReadOnly = true;
            this.txt_OrderNumber.Size = new System.Drawing.Size(134, 21);
            this.txt_OrderNumber.TabIndex = 164;
            this.txt_OrderNumber.TabStop = false;
            // 
            // dGridView_Base_Item
            // 
            this.dGridView_Base_Item.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Item.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Item.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dGridView_Base_Item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Item.DefaultCellStyle = dataGridViewCellStyle18;
            this.dGridView_Base_Item.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base_Item.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Item.Location = new System.Drawing.Point(3, 92);
            this.dGridView_Base_Item.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Item.Name = "dGridView_Base_Item";
            this.dGridView_Base_Item.RowTemplate.Height = 23;
            this.dGridView_Base_Item.Size = new System.Drawing.Size(417, 281);
            this.dGridView_Base_Item.TabIndex = 151;
            this.dGridView_Base_Item.TabStop = false;
            this.dGridView_Base_Item.DoubleClick += new System.EventHandler(this.dGridView_Base_Sub_DoubleClick);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel12);
            this.panel3.Controls.Add(this.tableLayoutPanel9);
            this.panel3.Controls.Add(this.tableLayoutPanel8);
            this.panel3.Controls.Add(this.txt_SalesItemIndex);
            this.panel3.Controls.Add(this.butt_Item_Del);
            this.panel3.Controls.Add(this.butt_Item_Clear);
            this.panel3.Controls.Add(this.butt_Item_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 17);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(417, 75);
            this.panel3.TabIndex = 0;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.panel37, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(2, 113);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(186, 36);
            this.tableLayoutPanel12.TabIndex = 195;
            this.tableLayoutPanel12.Visible = false;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.White;
            this.panel37.Controls.Add(this.txt_Item_Etc);
            this.panel37.Location = new System.Drawing.Point(126, 4);
            this.panel37.Margin = new System.Windows.Forms.Padding(2);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(56, 28);
            this.panel37.TabIndex = 15;
            // 
            // txt_Item_Etc
            // 
            this.txt_Item_Etc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Item_Etc.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Item_Etc.Location = new System.Drawing.Point(0, 2);
            this.txt_Item_Etc.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Item_Etc.MaxLength = 100;
            this.txt_Item_Etc.Name = "txt_Item_Etc";
            this.txt_Item_Etc.Size = new System.Drawing.Size(56, 22);
            this.txt_Item_Etc.TabIndex = 2;
            this.txt_Item_Etc.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Item_Etc.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Item_Etc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Item_Etc.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(2, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 32);
            this.label16.TabIndex = 0;
            this.label16.Text = "비고";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.panel11, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(2, 39);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(174, 36);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.txt_ItemCount);
            this.panel11.Location = new System.Drawing.Point(126, 4);
            this.panel11.Margin = new System.Windows.Forms.Padding(2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(44, 28);
            this.panel11.TabIndex = 15;
            // 
            // txt_ItemCount
            // 
            this.txt_ItemCount.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ItemCount.Location = new System.Drawing.Point(3, 3);
            this.txt_ItemCount.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ItemCount.MaxLength = 8;
            this.txt_ItemCount.Name = "txt_ItemCount";
            this.txt_ItemCount.Size = new System.Drawing.Size(38, 22);
            this.txt_ItemCount.TabIndex = 1;
            this.txt_ItemCount.Tag = "1";
            this.txt_ItemCount.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_ItemCount.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_ItemCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_ItemCount.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(2, 2);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 32);
            this.label14.TabIndex = 0;
            this.label14.Text = "수량";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.panel10, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(414, 36);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.txt_ItemCode);
            this.panel10.Controls.Add(this.txt_ItemName);
            this.panel10.Location = new System.Drawing.Point(126, 4);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(284, 28);
            this.panel10.TabIndex = 15;
            // 
            // txt_ItemCode
            // 
            this.txt_ItemCode.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ItemCode.Location = new System.Drawing.Point(3, 3);
            this.txt_ItemCode.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ItemCode.MaxLength = 8;
            this.txt_ItemCode.Name = "txt_ItemCode";
            this.txt_ItemCode.Size = new System.Drawing.Size(155, 22);
            this.txt_ItemCode.TabIndex = 0;
            this.txt_ItemCode.Tag = "ncode";
            this.txt_ItemCode.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_ItemCode.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_ItemCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_ItemCode.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txt_ItemName
            // 
            this.txt_ItemName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txt_ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ItemName.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_ItemName.ForeColor = System.Drawing.Color.White;
            this.txt_ItemName.Location = new System.Drawing.Point(159, 3);
            this.txt_ItemName.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ItemName.MaxLength = 30;
            this.txt_ItemName.Name = "txt_ItemName";
            this.txt_ItemName.ReadOnly = true;
            this.txt_ItemName.Size = new System.Drawing.Size(122, 21);
            this.txt_ItemName.TabIndex = 166;
            this.txt_ItemName.TabStop = false;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(2, 2);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 32);
            this.label7.TabIndex = 0;
            this.label7.Text = "상품코드/상품명";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_SalesItemIndex
            // 
            this.txt_SalesItemIndex.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_SalesItemIndex.Location = new System.Drawing.Point(462, 39);
            this.txt_SalesItemIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_SalesItemIndex.MaxLength = 8;
            this.txt_SalesItemIndex.Name = "txt_SalesItemIndex";
            this.txt_SalesItemIndex.ReadOnly = true;
            this.txt_SalesItemIndex.Size = new System.Drawing.Size(51, 22);
            this.txt_SalesItemIndex.TabIndex = 175;
            this.txt_SalesItemIndex.TabStop = false;
            this.txt_SalesItemIndex.Visible = false;
            // 
            // butt_Item_Del
            // 
            this.butt_Item_Del.BackColor = System.Drawing.Color.White;
            this.butt_Item_Del.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Item_Del.Location = new System.Drawing.Point(176, 45);
            this.butt_Item_Del.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Item_Del.Name = "butt_Item_Del";
            this.butt_Item_Del.Size = new System.Drawing.Size(95, 28);
            this.butt_Item_Del.TabIndex = 174;
            this.butt_Item_Del.TabStop = false;
            this.butt_Item_Del.Text = "지우기";
            this.butt_Item_Del.UseVisualStyleBackColor = false;
            this.butt_Item_Del.Visible = false;
            this.butt_Item_Del.Click += new System.EventHandler(this.Base_Small_Item_Button_Click);
            // 
            // butt_Item_Clear
            // 
            this.butt_Item_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Item_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Item_Clear.Location = new System.Drawing.Point(344, 45);
            this.butt_Item_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Item_Clear.Name = "butt_Item_Clear";
            this.butt_Item_Clear.Size = new System.Drawing.Size(71, 28);
            this.butt_Item_Clear.TabIndex = 173;
            this.butt_Item_Clear.TabStop = false;
            this.butt_Item_Clear.Text = "취소";
            this.butt_Item_Clear.UseVisualStyleBackColor = false;
            this.butt_Item_Clear.Click += new System.EventHandler(this.Base_Small_Item_Button_Click);
            // 
            // butt_Item_Save
            // 
            this.butt_Item_Save.BackColor = System.Drawing.Color.White;
            this.butt_Item_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Item_Save.Location = new System.Drawing.Point(272, 45);
            this.butt_Item_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Item_Save.Name = "butt_Item_Save";
            this.butt_Item_Save.Size = new System.Drawing.Size(71, 28);
            this.butt_Item_Save.TabIndex = 2;
            this.butt_Item_Save.Text = "추가";
            this.butt_Item_Save.UseVisualStyleBackColor = false;
            this.butt_Item_Save.Click += new System.EventHandler(this.Base_Small_Item_Button_Click);
            // 
            // txt_SumCnt
            // 
            this.txt_SumCnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumCnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumCnt.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumCnt.Location = new System.Drawing.Point(3, 4);
            this.txt_SumCnt.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumCnt.MaxLength = 30;
            this.txt_SumCnt.Name = "txt_SumCnt";
            this.txt_SumCnt.ReadOnly = true;
            this.txt_SumCnt.Size = new System.Drawing.Size(70, 21);
            this.txt_SumCnt.TabIndex = 165;
            this.txt_SumCnt.TabStop = false;
            // 
            // txt_SumPV
            // 
            this.txt_SumPV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumPV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumPV.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumPV.ForeColor = System.Drawing.Color.Red;
            this.txt_SumPV.Location = new System.Drawing.Point(3, 3);
            this.txt_SumPV.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumPV.MaxLength = 30;
            this.txt_SumPV.Name = "txt_SumPV";
            this.txt_SumPV.ReadOnly = true;
            this.txt_SumPV.Size = new System.Drawing.Size(58, 21);
            this.txt_SumPV.TabIndex = 175;
            this.txt_SumPV.TabStop = false;
            // 
            // txt_SumPr
            // 
            this.txt_SumPr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumPr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumPr.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumPr.ForeColor = System.Drawing.Color.Blue;
            this.txt_SumPr.Location = new System.Drawing.Point(3, 3);
            this.txt_SumPr.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumPr.MaxLength = 30;
            this.txt_SumPr.Name = "txt_SumPr";
            this.txt_SumPr.ReadOnly = true;
            this.txt_SumPr.Size = new System.Drawing.Size(70, 21);
            this.txt_SumPr.TabIndex = 173;
            this.txt_SumPr.TabStop = false;
            // 
            // panel_Cacu
            // 
            this.panel_Cacu.Controls.Add(this.dGridView_Base_Cacu);
            this.panel_Cacu.Controls.Add(this.panel66);
            this.panel_Cacu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Cacu.Location = new System.Drawing.Point(3, 17);
            this.panel_Cacu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel_Cacu.Name = "panel_Cacu";
            this.panel_Cacu.Size = new System.Drawing.Size(889, 394);
            this.panel_Cacu.TabIndex = 0;
            // 
            // dGridView_Base_Cacu
            // 
            this.dGridView_Base_Cacu.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Cacu.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Cacu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dGridView_Base_Cacu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Cacu.DefaultCellStyle = dataGridViewCellStyle20;
            this.dGridView_Base_Cacu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base_Cacu.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Cacu.Location = new System.Drawing.Point(0, 305);
            this.dGridView_Base_Cacu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Cacu.Name = "dGridView_Base_Cacu";
            this.dGridView_Base_Cacu.RowTemplate.Height = 23;
            this.dGridView_Base_Cacu.Size = new System.Drawing.Size(889, 89);
            this.dGridView_Base_Cacu.TabIndex = 155;
            this.dGridView_Base_Cacu.TabStop = false;
            this.dGridView_Base_Cacu.DoubleClick += new System.EventHandler(this.dGridView_Base_Sub_DoubleClick);
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.panel18);
            this.panel66.Controls.Add(this.tab_Cacu);
            this.panel66.Controls.Add(this.panel42);
            this.panel66.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel66.Location = new System.Drawing.Point(0, 0);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(889, 305);
            this.panel66.TabIndex = 200;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.tableLayoutPanel13);
            this.panel18.Controls.Add(this.txt_C_index);
            this.panel18.Controls.Add(this.butt_Cacu_Del);
            this.panel18.Controls.Add(this.butt_Cacu_Save);
            this.panel18.Controls.Add(this.butt_Cacu_Clear);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 260);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(668, 30);
            this.panel18.TabIndex = 199;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.panel48, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(355, 24);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel13.TabIndex = 198;
            this.tableLayoutPanel13.Visible = false;
            // 
            // panel48
            // 
            this.panel48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.txt_C_Etc);
            this.panel48.Location = new System.Drawing.Point(126, 4);
            this.panel48.Margin = new System.Windows.Forms.Padding(2);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(87, 28);
            this.panel48.TabIndex = 15;
            // 
            // txt_C_Etc
            // 
            this.txt_C_Etc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txt_C_Etc.BackColor = System.Drawing.Color.White;
            this.txt_C_Etc.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Etc.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Etc.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Etc.MaxLength = 100;
            this.txt_C_Etc.Name = "txt_C_Etc";
            this.txt_C_Etc.Size = new System.Drawing.Size(82, 22);
            this.txt_C_Etc.TabIndex = 0;
            this.txt_C_Etc.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Etc.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Etc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Etc.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(2, 2);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 32);
            this.label8.TabIndex = 0;
            this.label8.Text = "비고";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_C_index
            // 
            this.txt_C_index.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_index.Location = new System.Drawing.Point(280, 16);
            this.txt_C_index.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_C_index.MaxLength = 8;
            this.txt_C_index.Name = "txt_C_index";
            this.txt_C_index.ReadOnly = true;
            this.txt_C_index.Size = new System.Drawing.Size(51, 22);
            this.txt_C_index.TabIndex = 197;
            this.txt_C_index.TabStop = false;
            this.txt_C_index.Visible = false;
            // 
            // butt_Cacu_Del
            // 
            this.butt_Cacu_Del.BackColor = System.Drawing.Color.White;
            this.butt_Cacu_Del.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Cacu_Del.Location = new System.Drawing.Point(0, 1);
            this.butt_Cacu_Del.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Cacu_Del.Name = "butt_Cacu_Del";
            this.butt_Cacu_Del.Size = new System.Drawing.Size(89, 28);
            this.butt_Cacu_Del.TabIndex = 196;
            this.butt_Cacu_Del.TabStop = false;
            this.butt_Cacu_Del.Text = "지우기";
            this.butt_Cacu_Del.UseVisualStyleBackColor = false;
            this.butt_Cacu_Del.Visible = false;
            this.butt_Cacu_Del.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // butt_Cacu_Save
            // 
            this.butt_Cacu_Save.BackColor = System.Drawing.Color.White;
            this.butt_Cacu_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Cacu_Save.Location = new System.Drawing.Point(90, 1);
            this.butt_Cacu_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Cacu_Save.Name = "butt_Cacu_Save";
            this.butt_Cacu_Save.Size = new System.Drawing.Size(89, 28);
            this.butt_Cacu_Save.TabIndex = 10;
            this.butt_Cacu_Save.Text = "추가";
            this.butt_Cacu_Save.UseVisualStyleBackColor = false;
            this.butt_Cacu_Save.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // butt_Cacu_Clear
            // 
            this.butt_Cacu_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Cacu_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Cacu_Clear.Location = new System.Drawing.Point(180, 1);
            this.butt_Cacu_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Cacu_Clear.Name = "butt_Cacu_Clear";
            this.butt_Cacu_Clear.Size = new System.Drawing.Size(89, 28);
            this.butt_Cacu_Clear.TabIndex = 195;
            this.butt_Cacu_Clear.TabStop = false;
            this.butt_Cacu_Clear.Text = "취소";
            this.butt_Cacu_Clear.UseVisualStyleBackColor = false;
            this.butt_Cacu_Clear.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // tab_Cacu
            // 
            this.tab_Cacu.Controls.Add(this.tab_Card);
            this.tab_Cacu.Controls.Add(this.tab_Cash);
            this.tab_Cacu.Controls.Add(this.tab_Bank);
            this.tab_Cacu.Controls.Add(this.tab_VA_Bank);
            this.tab_Cacu.Controls.Add(this.tab_Mile);
            this.tab_Cacu.Dock = System.Windows.Forms.DockStyle.Top;
            this.tab_Cacu.Location = new System.Drawing.Point(0, 0);
            this.tab_Cacu.Name = "tab_Cacu";
            this.tab_Cacu.SelectedIndex = 0;
            this.tab_Cacu.Size = new System.Drawing.Size(668, 260);
            this.tab_Cacu.TabIndex = 1;
            this.tab_Cacu.SelectedIndexChanged += new System.EventHandler(this.tab_Cacu_SelectedIndexChanged);
            // 
            // tab_Card
            // 
            this.tab_Card.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Card.Controls.Add(this.button_Ok);
            this.tab_Card.Controls.Add(this.tableLayoutPanel59);
            this.tab_Card.Controls.Add(this.tableLayoutPanel72);
            this.tab_Card.Controls.Add(this.tableLayoutPanel52);
            this.tab_Card.Controls.Add(this.button_Cancel);
            this.tab_Card.Controls.Add(this.tableLayoutPanel55);
            this.tab_Card.Controls.Add(this.tableLayoutPanel57);
            this.tab_Card.Controls.Add(this.tableLayoutPanel33);
            this.tab_Card.Controls.Add(this.tableLayoutPanel50);
            this.tab_Card.Controls.Add(this.tableLayoutPanel54);
            this.tab_Card.Controls.Add(this.tableLayoutPanel30);
            this.tab_Card.Controls.Add(this.tableLayoutPanel53);
            this.tab_Card.Controls.Add(this.tableLayoutPanel51);
            this.tab_Card.Controls.Add(this.tableL_CD);
            this.tab_Card.Location = new System.Drawing.Point(4, 22);
            this.tab_Card.Name = "tab_Card";
            this.tab_Card.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Card.Size = new System.Drawing.Size(660, 234);
            this.tab_Card.TabIndex = 0;
            this.tab_Card.Text = "카드";
            // 
            // button_Ok
            // 
            this.button_Ok.BackColor = System.Drawing.Color.White;
            this.button_Ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Ok.Location = new System.Drawing.Point(2, 188);
            this.button_Ok.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_Ok.Name = "button_Ok";
            this.button_Ok.Size = new System.Drawing.Size(84, 28);
            this.button_Ok.TabIndex = 199;
            this.button_Ok.TabStop = false;
            this.button_Ok.Text = "카드_승인";
            this.button_Ok.UseVisualStyleBackColor = false;
            this.button_Ok.Click += new System.EventHandler(this.button_Ok_Click);
            // 
            // tableLayoutPanel59
            // 
            this.tableLayoutPanel59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel59.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel59.ColumnCount = 2;
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel59.Controls.Add(this.panel80, 1, 0);
            this.tableLayoutPanel59.Controls.Add(this.label80, 0, 0);
            this.tableLayoutPanel59.Location = new System.Drawing.Point(240, 149);
            this.tableLayoutPanel59.Name = "tableLayoutPanel59";
            this.tableLayoutPanel59.RowCount = 1;
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel59.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel59.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel59.TabIndex = 10;
            // 
            // panel80
            // 
            this.panel80.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel80.BackColor = System.Drawing.Color.White;
            this.panel80.Controls.Add(this.txt_C_B_Number);
            this.panel80.Location = new System.Drawing.Point(126, 4);
            this.panel80.Margin = new System.Windows.Forms.Padding(2);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(108, 28);
            this.panel80.TabIndex = 15;
            // 
            // txt_C_B_Number
            // 
            this.txt_C_B_Number.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_B_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_C_B_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_B_Number.MaxLength = 10;
            this.txt_C_B_Number.Name = "txt_C_B_Number";
            this.txt_C_B_Number.Size = new System.Drawing.Size(102, 22);
            this.txt_C_B_Number.TabIndex = 6;
            this.txt_C_B_Number.Tag = "1";
            this.txt_C_B_Number.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_B_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_B_Number.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label80
            // 
            this.label80.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label80.ForeColor = System.Drawing.Color.White;
            this.label80.Location = new System.Drawing.Point(2, 2);
            this.label80.Margin = new System.Windows.Forms.Padding(0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(120, 32);
            this.label80.TabIndex = 0;
            this.label80.Text = "생년월일(EX:790301)";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel72
            // 
            this.tableLayoutPanel72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel72.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel72.ColumnCount = 2;
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel72.Controls.Add(this.panel81, 1, 0);
            this.tableLayoutPanel72.Controls.Add(this.label81, 0, 0);
            this.tableLayoutPanel72.Location = new System.Drawing.Point(1, 149);
            this.tableLayoutPanel72.Name = "tableLayoutPanel72";
            this.tableLayoutPanel72.RowCount = 1;
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel72.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel72.TabIndex = 9;
            // 
            // panel81
            // 
            this.panel81.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel81.BackColor = System.Drawing.Color.White;
            this.panel81.Controls.Add(this.txt_C_P_Number);
            this.panel81.Location = new System.Drawing.Point(126, 4);
            this.panel81.Margin = new System.Windows.Forms.Padding(2);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(108, 28);
            this.panel81.TabIndex = 15;
            // 
            // txt_C_P_Number
            // 
            this.txt_C_P_Number.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_P_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_C_P_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_P_Number.MaxLength = 2;
            this.txt_C_P_Number.Name = "txt_C_P_Number";
            this.txt_C_P_Number.Size = new System.Drawing.Size(102, 22);
            this.txt_C_P_Number.TabIndex = 6;
            this.txt_C_P_Number.Tag = "1";
            this.txt_C_P_Number.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_P_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_P_Number.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label81
            // 
            this.label81.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label81.ForeColor = System.Drawing.Color.White;
            this.label81.Location = new System.Drawing.Point(2, 2);
            this.label81.Margin = new System.Windows.Forms.Padding(0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(120, 32);
            this.label81.TabIndex = 0;
            this.label81.Text = "앞_2자리";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel52.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel52.ColumnCount = 2;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.Controls.Add(this.panel53, 1, 0);
            this.tableLayoutPanel52.Controls.Add(this.label46, 0, 0);
            this.tableLayoutPanel52.Location = new System.Drawing.Point(1, 76);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 1;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel52.TabIndex = 5;
            // 
            // panel53
            // 
            this.panel53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel53.BackColor = System.Drawing.Color.White;
            this.panel53.Controls.Add(this.txt_C_Card_Month);
            this.panel53.Controls.Add(this.txt_C_Card_Year);
            this.panel53.Controls.Add(this.combo_C_Card_Year);
            this.panel53.Controls.Add(this.combo_C_Card_Month);
            this.panel53.Location = new System.Drawing.Point(126, 4);
            this.panel53.Margin = new System.Windows.Forms.Padding(2);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(108, 28);
            this.panel53.TabIndex = 15;
            // 
            // txt_C_Card_Month
            // 
            this.txt_C_Card_Month.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Month.Location = new System.Drawing.Point(65, 3);
            this.txt_C_Card_Month.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Month.MaxLength = 2;
            this.txt_C_Card_Month.Name = "txt_C_Card_Month";
            this.txt_C_Card_Month.Size = new System.Drawing.Size(40, 22);
            this.txt_C_Card_Month.TabIndex = 10;
            this.txt_C_Card_Month.Tag = "1";
            this.txt_C_Card_Month.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card_Month.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card_Month.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txt_C_Card_Year
            // 
            this.txt_C_Card_Year.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Year.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Card_Year.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Year.MaxLength = 2;
            this.txt_C_Card_Year.Name = "txt_C_Card_Year";
            this.txt_C_Card_Year.Size = new System.Drawing.Size(59, 22);
            this.txt_C_Card_Year.TabIndex = 9;
            this.txt_C_Card_Year.Tag = "1";
            this.txt_C_Card_Year.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card_Year.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card_Year.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // combo_C_Card_Year
            // 
            this.combo_C_Card_Year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Year.FormattingEnabled = true;
            this.combo_C_Card_Year.Location = new System.Drawing.Point(3, 38);
            this.combo_C_Card_Year.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Year.Name = "combo_C_Card_Year";
            this.combo_C_Card_Year.Size = new System.Drawing.Size(59, 20);
            this.combo_C_Card_Year.TabIndex = 7;
            this.combo_C_Card_Year.TabStop = false;
            // 
            // combo_C_Card_Month
            // 
            this.combo_C_Card_Month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Month.FormattingEnabled = true;
            this.combo_C_Card_Month.Location = new System.Drawing.Point(65, 38);
            this.combo_C_Card_Month.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Month.Name = "combo_C_Card_Month";
            this.combo_C_Card_Month.Size = new System.Drawing.Size(40, 20);
            this.combo_C_Card_Month.TabIndex = 8;
            this.combo_C_Card_Month.TabStop = false;
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(2, 2);
            this.label46.Margin = new System.Windows.Forms.Padding(0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(120, 32);
            this.label46.TabIndex = 0;
            this.label46.Text = "유효기간(년_월)";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button_Cancel
            // 
            this.button_Cancel.BackColor = System.Drawing.Color.White;
            this.button_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Cancel.Location = new System.Drawing.Point(93, 187);
            this.button_Cancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(87, 28);
            this.button_Cancel.TabIndex = 200;
            this.button_Cancel.TabStop = false;
            this.button_Cancel.Text = "승인_취소";
            this.button_Cancel.UseVisualStyleBackColor = false;
            this.button_Cancel.Visible = false;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // tableLayoutPanel55
            // 
            this.tableLayoutPanel55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel55.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel55.ColumnCount = 2;
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel55.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel55.Controls.Add(this.panel56, 1, 0);
            this.tableLayoutPanel55.Controls.Add(this.label54, 0, 0);
            this.tableLayoutPanel55.Location = new System.Drawing.Point(239, 3);
            this.tableLayoutPanel55.Name = "tableLayoutPanel55";
            this.tableLayoutPanel55.RowCount = 1;
            this.tableLayoutPanel55.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel55.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel55.Size = new System.Drawing.Size(239, 36);
            this.tableLayoutPanel55.TabIndex = 8;
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.Color.White;
            this.panel56.Controls.Add(this.txt_Price_3_2);
            this.panel56.Location = new System.Drawing.Point(126, 4);
            this.panel56.Margin = new System.Windows.Forms.Padding(2);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(108, 28);
            this.panel56.TabIndex = 15;
            // 
            // txt_Price_3_2
            // 
            this.txt_Price_3_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_3_2.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_3_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_3_2.MaxLength = 8;
            this.txt_Price_3_2.Name = "txt_Price_3_2";
            this.txt_Price_3_2.Size = new System.Drawing.Size(102, 22);
            this.txt_Price_3_2.TabIndex = 7;
            this.txt_Price_3_2.Tag = "2";
            this.txt_Price_3_2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Price_3_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_3_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_3_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label54
            // 
            this.label54.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(2, 2);
            this.label54.Margin = new System.Windows.Forms.Padding(0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(120, 32);
            this.label54.TabIndex = 0;
            this.label54.Text = "승인_금액";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel57
            // 
            this.tableLayoutPanel57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel57.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel57.ColumnCount = 2;
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel57.Controls.Add(this.panel57, 1, 0);
            this.tableLayoutPanel57.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel57.Location = new System.Drawing.Point(240, 76);
            this.tableLayoutPanel57.Name = "tableLayoutPanel57";
            this.tableLayoutPanel57.RowCount = 1;
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel57.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel57.TabIndex = 6;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.White;
            this.panel57.Controls.Add(this.combo_C_Card_Per);
            this.panel57.Location = new System.Drawing.Point(126, 4);
            this.panel57.Margin = new System.Windows.Forms.Padding(2);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(108, 28);
            this.panel57.TabIndex = 15;
            // 
            // combo_C_Card_Per
            // 
            this.combo_C_Card_Per.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Per.FormattingEnabled = true;
            this.combo_C_Card_Per.Location = new System.Drawing.Point(3, 3);
            this.combo_C_Card_Per.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.combo_C_Card_Per.Name = "combo_C_Card_Per";
            this.combo_C_Card_Per.Size = new System.Drawing.Size(102, 20);
            this.combo_C_Card_Per.TabIndex = 9;
            // 
            // label56
            // 
            this.label56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(2, 2);
            this.label56.Margin = new System.Windows.Forms.Padding(0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(120, 32);
            this.label56.TabIndex = 0;
            this.label56.Text = "할부_기간";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.panel50, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.label23, 0, 0);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(1, 2);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel33.TabIndex = 0;
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.White;
            this.panel50.Controls.Add(this.txt_Price_3);
            this.panel50.Location = new System.Drawing.Point(126, 4);
            this.panel50.Margin = new System.Windows.Forms.Padding(2);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(108, 28);
            this.panel50.TabIndex = 15;
            // 
            // txt_Price_3
            // 
            this.txt_Price_3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_3.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_3.MaxLength = 8;
            this.txt_Price_3.Name = "txt_Price_3";
            this.txt_Price_3.Size = new System.Drawing.Size(102, 22);
            this.txt_Price_3.TabIndex = 0;
            this.txt_Price_3.Tag = "2";
            this.txt_Price_3.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Price_3.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_3.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(2, 2);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(120, 32);
            this.label23.TabIndex = 0;
            this.label23.Text = "결제액";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel50
            // 
            this.tableLayoutPanel50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel50.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel50.ColumnCount = 2;
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 109F));
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel50.Controls.Add(this.panel51, 1, 0);
            this.tableLayoutPanel50.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel50.Location = new System.Drawing.Point(240, 113);
            this.tableLayoutPanel50.Name = "tableLayoutPanel50";
            this.tableLayoutPanel50.RowCount = 1;
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel50.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel50.TabIndex = 1;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.White;
            this.panel51.Controls.Add(this.mtxtPriceDate3);
            this.panel51.Controls.Add(this.DTP_PriceDate3);
            this.panel51.Location = new System.Drawing.Point(115, 4);
            this.panel51.Margin = new System.Windows.Forms.Padding(2);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(118, 28);
            this.panel51.TabIndex = 15;
            // 
            // mtxtPriceDate3
            // 
            this.mtxtPriceDate3.Location = new System.Drawing.Point(3, 3);
            this.mtxtPriceDate3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate3.Name = "mtxtPriceDate3";
            this.mtxtPriceDate3.Size = new System.Drawing.Size(92, 21);
            this.mtxtPriceDate3.TabIndex = 107;
            this.mtxtPriceDate3.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPriceDate3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPriceDate3.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_PriceDate3
            // 
            this.DTP_PriceDate3.Location = new System.Drawing.Point(94, 3);
            this.DTP_PriceDate3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate3.Name = "DTP_PriceDate3";
            this.DTP_PriceDate3.Size = new System.Drawing.Size(21, 21);
            this.DTP_PriceDate3.TabIndex = 173;
            this.DTP_PriceDate3.TabStop = false;
            this.DTP_PriceDate3.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(2, 2);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(109, 32);
            this.label24.TabIndex = 0;
            this.label24.Text = "결제일";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel54
            // 
            this.tableLayoutPanel54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel54.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel54.ColumnCount = 2;
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel54.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel54.Controls.Add(this.panel55, 1, 0);
            this.tableLayoutPanel54.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel54.Location = new System.Drawing.Point(1, 113);
            this.tableLayoutPanel54.Name = "tableLayoutPanel54";
            this.tableLayoutPanel54.RowCount = 1;
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel54.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel54.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel54.TabIndex = 7;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.White;
            this.panel55.Controls.Add(this.txt_C_Card_Ap_Num);
            this.panel55.Location = new System.Drawing.Point(126, 4);
            this.panel55.Margin = new System.Windows.Forms.Padding(2);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(108, 28);
            this.panel55.TabIndex = 15;
            // 
            // txt_C_Card_Ap_Num
            // 
            this.txt_C_Card_Ap_Num.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Ap_Num.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Card_Ap_Num.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Ap_Num.MaxLength = 8;
            this.txt_C_Card_Ap_Num.Name = "txt_C_Card_Ap_Num";
            this.txt_C_Card_Ap_Num.ReadOnly = true;
            this.txt_C_Card_Ap_Num.Size = new System.Drawing.Size(102, 22);
            this.txt_C_Card_Ap_Num.TabIndex = 6;
            this.txt_C_Card_Ap_Num.Tag = "1";
            this.txt_C_Card_Ap_Num.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Card_Ap_Num.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card_Ap_Num.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card_Ap_Num.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label50
            // 
            this.label50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(2, 2);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(120, 32);
            this.label50.TabIndex = 0;
            this.label50.Text = "승인_번호";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel30.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.panel49, 1, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(278, 39);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(200, 36);
            this.tableLayoutPanel30.TabIndex = 2;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(2, 2);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 32);
            this.label22.TabIndex = 0;
            this.label22.Text = "카드";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.White;
            this.panel49.Controls.Add(this.txt_C_Card);
            this.panel49.Controls.Add(this.txt_C_Card_Code);
            this.panel49.Location = new System.Drawing.Point(76, 4);
            this.panel49.Margin = new System.Windows.Forms.Padding(2);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(119, 28);
            this.panel49.TabIndex = 15;
            // 
            // txt_C_Card
            // 
            this.txt_C_Card.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Card.Margin = new System.Windows.Forms.Padding(0);
            this.txt_C_Card.MaxLength = 30;
            this.txt_C_Card.Name = "txt_C_Card";
            this.txt_C_Card.Size = new System.Drawing.Size(70, 22);
            this.txt_C_Card.TabIndex = 14;
            this.txt_C_Card.Tag = "ncode";
            this.txt_C_Card.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Card.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txt_C_Card_Code
            // 
            this.txt_C_Card_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txt_C_Card_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Card_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Code.ForeColor = System.Drawing.Color.White;
            this.txt_C_Card_Code.Location = new System.Drawing.Point(74, 3);
            this.txt_C_Card_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Code.MaxLength = 30;
            this.txt_C_Card_Code.Name = "txt_C_Card_Code";
            this.txt_C_Card_Code.ReadOnly = true;
            this.txt_C_Card_Code.Size = new System.Drawing.Size(42, 22);
            this.txt_C_Card_Code.TabIndex = 4;
            this.txt_C_Card_Code.TabStop = false;
            // 
            // tableLayoutPanel53
            // 
            this.tableLayoutPanel53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel53.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel53.ColumnCount = 2;
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.Controls.Add(this.panel54, 1, 0);
            this.tableLayoutPanel53.Controls.Add(this.label48, 0, 0);
            this.tableLayoutPanel53.Location = new System.Drawing.Point(126, 195);
            this.tableLayoutPanel53.Name = "tableLayoutPanel53";
            this.tableLayoutPanel53.RowCount = 1;
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel53.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel53.TabIndex = 3;
            this.tableLayoutPanel53.Visible = false;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.White;
            this.panel54.Controls.Add(this.txt_C_Name_3);
            this.panel54.Location = new System.Drawing.Point(126, 4);
            this.panel54.Margin = new System.Windows.Forms.Padding(2);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(98, 28);
            this.panel54.TabIndex = 15;
            // 
            // txt_C_Name_3
            // 
            this.txt_C_Name_3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Name_3.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Name_3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Name_3.MaxLength = 100;
            this.txt_C_Name_3.Name = "txt_C_Name_3";
            this.txt_C_Name_3.Size = new System.Drawing.Size(92, 22);
            this.txt_C_Name_3.TabIndex = 2;
            this.txt_C_Name_3.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Name_3.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Name_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Name_3.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label48
            // 
            this.label48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(2, 2);
            this.label48.Margin = new System.Windows.Forms.Padding(0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(120, 32);
            this.label48.TabIndex = 0;
            this.label48.Text = "소유자명";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel51.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel51.ColumnCount = 2;
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.Controls.Add(this.panel52, 1, 0);
            this.tableLayoutPanel51.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel51.Location = new System.Drawing.Point(1, 39);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 1;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(277, 36);
            this.tableLayoutPanel51.TabIndex = 4;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.White;
            this.panel52.Controls.Add(this.txt_C_Card_Number);
            this.panel52.Location = new System.Drawing.Point(126, 4);
            this.panel52.Margin = new System.Windows.Forms.Padding(2);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(147, 28);
            this.panel52.TabIndex = 15;
            // 
            // txt_C_Card_Number
            // 
            this.txt_C_Card_Number.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Number.Location = new System.Drawing.Point(4, 3);
            this.txt_C_Card_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Number.MaxLength = 30;
            this.txt_C_Card_Number.Name = "txt_C_Card_Number";
            this.txt_C_Card_Number.Size = new System.Drawing.Size(138, 22);
            this.txt_C_Card_Number.TabIndex = 5;
            this.txt_C_Card_Number.Tag = "-";
            this.txt_C_Card_Number.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Card_Number.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card_Number.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(2, 2);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 32);
            this.label28.TabIndex = 0;
            this.label28.Text = "카드번호";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableL_CD
            // 
            this.tableL_CD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableL_CD.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableL_CD.ColumnCount = 2;
            this.tableL_CD.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableL_CD.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_CD.Controls.Add(this.panel88, 1, 0);
            this.tableL_CD.Controls.Add(this.label82, 0, 0);
            this.tableL_CD.Location = new System.Drawing.Point(1, 204);
            this.tableL_CD.Name = "tableL_CD";
            this.tableL_CD.RowCount = 1;
            this.tableL_CD.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_CD.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableL_CD.Size = new System.Drawing.Size(228, 36);
            this.tableL_CD.TabIndex = 202;
            this.tableL_CD.Visible = false;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.White;
            this.panel88.Controls.Add(this.txt_Price_CC);
            this.panel88.Location = new System.Drawing.Point(126, 4);
            this.panel88.Margin = new System.Windows.Forms.Padding(2);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(98, 28);
            this.panel88.TabIndex = 15;
            // 
            // txt_Price_CC
            // 
            this.txt_Price_CC.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_CC.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_CC.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_CC.MaxLength = 8;
            this.txt_Price_CC.Name = "txt_Price_CC";
            this.txt_Price_CC.Size = new System.Drawing.Size(92, 22);
            this.txt_Price_CC.TabIndex = 0;
            this.txt_Price_CC.Tag = "2";
            this.txt_Price_CC.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_CC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_CC.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label82
            // 
            this.label82.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label82.ForeColor = System.Drawing.Color.White;
            this.label82.Location = new System.Drawing.Point(2, 2);
            this.label82.Margin = new System.Windows.Forms.Padding(0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(120, 32);
            this.label82.TabIndex = 0;
            this.label82.Text = "부분_취소금액";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Cash
            // 
            this.tab_Cash.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Cash.Controls.Add(this.tableLayoutPanel74);
            this.tab_Cash.Controls.Add(this.txt_C_Cash_Number2);
            this.tab_Cash.Controls.Add(this.check_Not_Cash);
            this.tab_Cash.Controls.Add(this.tableLayoutPanel48);
            this.tab_Cash.Controls.Add(this.tableLayoutPanel2);
            this.tab_Cash.Controls.Add(this.tableLayoutPanel23);
            this.tab_Cash.Location = new System.Drawing.Point(4, 22);
            this.tab_Cash.Name = "tab_Cash";
            this.tab_Cash.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Cash.Size = new System.Drawing.Size(660, 234);
            this.tab_Cash.TabIndex = 1;
            this.tab_Cash.Text = "현금";
            // 
            // tableLayoutPanel74
            // 
            this.tableLayoutPanel74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel74.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel74.ColumnCount = 2;
            this.tableLayoutPanel74.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel74.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel74.Controls.Add(this.panel86, 1, 0);
            this.tableLayoutPanel74.Controls.Add(this.label84, 0, 0);
            this.tableLayoutPanel74.Location = new System.Drawing.Point(416, 90);
            this.tableLayoutPanel74.Name = "tableLayoutPanel74";
            this.tableLayoutPanel74.RowCount = 1;
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel74.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel74.Size = new System.Drawing.Size(386, 59);
            this.tableLayoutPanel74.TabIndex = 234;
            this.tableLayoutPanel74.Visible = false;
            // 
            // panel86
            // 
            this.panel86.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel86.BackColor = System.Drawing.Color.White;
            this.panel86.Controls.Add(this.label83);
            this.panel86.Controls.Add(this.check_Cash_Pre);
            this.panel86.Location = new System.Drawing.Point(126, 4);
            this.panel86.Margin = new System.Windows.Forms.Padding(2);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(256, 51);
            this.panel86.TabIndex = 15;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(4, 29);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(119, 12);
            this.label83.TabIndex = 57;
            this.label83.Text = "현금영수증_승인번호";
            // 
            // check_Cash_Pre
            // 
            this.check_Cash_Pre.AutoSize = true;
            this.check_Cash_Pre.ForeColor = System.Drawing.Color.Red;
            this.check_Cash_Pre.Location = new System.Drawing.Point(6, 5);
            this.check_Cash_Pre.Name = "check_Cash_Pre";
            this.check_Cash_Pre.Size = new System.Drawing.Size(120, 16);
            this.check_Cash_Pre.TabIndex = 0;
            this.check_Cash_Pre.Text = "단말기_신고_처리";
            this.check_Cash_Pre.UseVisualStyleBackColor = true;
            // 
            // label84
            // 
            this.label84.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label84.ForeColor = System.Drawing.Color.White;
            this.label84.Location = new System.Drawing.Point(2, 2);
            this.label84.Margin = new System.Windows.Forms.Padding(0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(120, 55);
            this.label84.TabIndex = 0;
            this.label84.Text = "카드_단말기_신고";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_C_Cash_Number2
            // 
            this.txt_C_Cash_Number2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Cash_Number2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Cash_Number2.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_C_Cash_Number2.ForeColor = System.Drawing.Color.Red;
            this.txt_C_Cash_Number2.Location = new System.Drawing.Point(332, 32);
            this.txt_C_Cash_Number2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Cash_Number2.MaxLength = 30;
            this.txt_C_Cash_Number2.Name = "txt_C_Cash_Number2";
            this.txt_C_Cash_Number2.ReadOnly = true;
            this.txt_C_Cash_Number2.Size = new System.Drawing.Size(128, 21);
            this.txt_C_Cash_Number2.TabIndex = 176;
            this.txt_C_Cash_Number2.TabStop = false;
            this.txt_C_Cash_Number2.Visible = false;
            // 
            // check_Not_Cash
            // 
            this.check_Not_Cash.AutoSize = true;
            this.check_Not_Cash.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.check_Not_Cash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.check_Not_Cash.Location = new System.Drawing.Point(265, 178);
            this.check_Not_Cash.Name = "check_Not_Cash";
            this.check_Not_Cash.Size = new System.Drawing.Size(253, 16);
            this.check_Not_Cash.TabIndex = 233;
            this.check_Not_Cash.Text = "현금영수증/세금계산서_미신고/미발행";
            this.check_Not_Cash.UseVisualStyleBackColor = true;
            this.check_Not_Cash.Visible = false;
            // 
            // tableLayoutPanel48
            // 
            this.tableLayoutPanel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel48.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel48.ColumnCount = 2;
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel48.Controls.Add(this.panel77, 1, 0);
            this.tableLayoutPanel48.Controls.Add(this.label60, 0, 0);
            this.tableLayoutPanel48.Location = new System.Drawing.Point(0, 76);
            this.tableLayoutPanel48.Name = "tableLayoutPanel48";
            this.tableLayoutPanel48.RowCount = 1;
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel48.Size = new System.Drawing.Size(386, 85);
            this.tableLayoutPanel48.TabIndex = 2;
            this.tableLayoutPanel48.Visible = false;
            // 
            // panel77
            // 
            this.panel77.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel77.BackColor = System.Drawing.Color.White;
            this.panel77.Controls.Add(this.label62);
            this.panel77.Controls.Add(this.txt_C_Cash_Number2_2);
            this.panel77.Controls.Add(this.label61);
            this.panel77.Controls.Add(this.txt_C_Cash_Send_Nu);
            this.panel77.Controls.Add(this.radioB_C_Cash_Send_TF2);
            this.panel77.Controls.Add(this.radioB_C_Cash_Send_TF1);
            this.panel77.Controls.Add(this.check_Cash);
            this.panel77.Location = new System.Drawing.Point(126, 4);
            this.panel77.Margin = new System.Windows.Forms.Padding(2);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(256, 77);
            this.panel77.TabIndex = 15;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(5, 57);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(117, 12);
            this.label62.TabIndex = 177;
            this.label62.Text = "현금영수증 인증번호";
            // 
            // txt_C_Cash_Number2_2
            // 
            this.txt_C_Cash_Number2_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Cash_Number2_2.Location = new System.Drawing.Point(123, 51);
            this.txt_C_Cash_Number2_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Cash_Number2_2.MaxLength = 20;
            this.txt_C_Cash_Number2_2.Name = "txt_C_Cash_Number2_2";
            this.txt_C_Cash_Number2_2.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Cash_Number2_2.TabIndex = 56;
            this.txt_C_Cash_Number2_2.Tag = "1";
            this.txt_C_Cash_Number2_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Cash_Number2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Cash_Number2_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(4, 29);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(117, 12);
            this.label61.TabIndex = 57;
            this.label61.Text = "현금영수증 신청번호";
            // 
            // txt_C_Cash_Send_Nu
            // 
            this.txt_C_Cash_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Cash_Send_Nu.Location = new System.Drawing.Point(123, 24);
            this.txt_C_Cash_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Cash_Send_Nu.MaxLength = 20;
            this.txt_C_Cash_Send_Nu.Name = "txt_C_Cash_Send_Nu";
            this.txt_C_Cash_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Cash_Send_Nu.TabIndex = 56;
            this.txt_C_Cash_Send_Nu.Tag = "1";
            this.txt_C_Cash_Send_Nu.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Cash_Send_Nu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Cash_Send_Nu.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // radioB_C_Cash_Send_TF2
            // 
            this.radioB_C_Cash_Send_TF2.AutoSize = true;
            this.radioB_C_Cash_Send_TF2.Location = new System.Drawing.Point(195, 4);
            this.radioB_C_Cash_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Cash_Send_TF2.Name = "radioB_C_Cash_Send_TF2";
            this.radioB_C_Cash_Send_TF2.Size = new System.Drawing.Size(59, 16);
            this.radioB_C_Cash_Send_TF2.TabIndex = 55;
            this.radioB_C_Cash_Send_TF2.Text = "사업자";
            this.radioB_C_Cash_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_C_Cash_Send_TF1
            // 
            this.radioB_C_Cash_Send_TF1.AutoSize = true;
            this.radioB_C_Cash_Send_TF1.Checked = true;
            this.radioB_C_Cash_Send_TF1.Location = new System.Drawing.Point(137, 4);
            this.radioB_C_Cash_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Cash_Send_TF1.Name = "radioB_C_Cash_Send_TF1";
            this.radioB_C_Cash_Send_TF1.Size = new System.Drawing.Size(47, 16);
            this.radioB_C_Cash_Send_TF1.TabIndex = 54;
            this.radioB_C_Cash_Send_TF1.TabStop = true;
            this.radioB_C_Cash_Send_TF1.Text = "개인";
            this.radioB_C_Cash_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // check_Cash
            // 
            this.check_Cash.AutoSize = true;
            this.check_Cash.ForeColor = System.Drawing.Color.Red;
            this.check_Cash.Location = new System.Drawing.Point(6, 5);
            this.check_Cash.Name = "check_Cash";
            this.check_Cash.Size = new System.Drawing.Size(114, 16);
            this.check_Cash.TabIndex = 0;
            this.check_Cash.Text = "현금영수증_신고";
            this.check_Cash.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label60.ForeColor = System.Drawing.Color.White;
            this.label60.Location = new System.Drawing.Point(2, 2);
            this.label60.Margin = new System.Windows.Forms.Padding(0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(120, 81);
            this.label60.TabIndex = 0;
            this.label60.Text = "현금영수증";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel13, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.txt_Price_1);
            this.panel13.Location = new System.Drawing.Point(126, 4);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(118, 28);
            this.panel13.TabIndex = 15;
            // 
            // txt_Price_1
            // 
            this.txt_Price_1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_1.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_1.MaxLength = 8;
            this.txt_Price_1.Name = "txt_Price_1";
            this.txt_Price_1.Size = new System.Drawing.Size(112, 22);
            this.txt_Price_1.TabIndex = 0;
            this.txt_Price_1.Tag = "2";
            this.txt_Price_1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Price_1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "결제액";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel23.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(2, 39);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel23.TabIndex = 1;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.mtxtPriceDate1);
            this.panel14.Controls.Add(this.DTP_PriceDate1);
            this.panel14.Location = new System.Drawing.Point(126, 4);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(118, 28);
            this.panel14.TabIndex = 15;
            // 
            // mtxtPriceDate1
            // 
            this.mtxtPriceDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtPriceDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate1.Name = "mtxtPriceDate1";
            this.mtxtPriceDate1.Size = new System.Drawing.Size(92, 21);
            this.mtxtPriceDate1.TabIndex = 107;
            this.mtxtPriceDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPriceDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPriceDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_PriceDate1
            // 
            this.DTP_PriceDate1.Location = new System.Drawing.Point(94, 3);
            this.DTP_PriceDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate1.Name = "DTP_PriceDate1";
            this.DTP_PriceDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_PriceDate1.TabIndex = 112;
            this.DTP_PriceDate1.TabStop = false;
            this.DTP_PriceDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 32);
            this.label13.TabIndex = 0;
            this.label13.Text = "결제일";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Bank
            // 
            this.tab_Bank.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Bank.Controls.Add(this.tableLayoutPanel76);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel28);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel26);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel27);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel25);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel24);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel21);
            this.tab_Bank.Controls.Add(this.tableLayoutPanel22);
            this.tab_Bank.Location = new System.Drawing.Point(4, 22);
            this.tab_Bank.Name = "tab_Bank";
            this.tab_Bank.Size = new System.Drawing.Size(660, 234);
            this.tab_Bank.TabIndex = 2;
            this.tab_Bank.Text = "무통장";
            // 
            // tableLayoutPanel76
            // 
            this.tableLayoutPanel76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel76.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel76.ColumnCount = 2;
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel76.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel76.Controls.Add(this.panel91, 1, 0);
            this.tableLayoutPanel76.Controls.Add(this.label89, 0, 0);
            this.tableLayoutPanel76.Location = new System.Drawing.Point(1, 149);
            this.tableLayoutPanel76.Name = "tableLayoutPanel76";
            this.tableLayoutPanel76.RowCount = 1;
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel76.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel76.Size = new System.Drawing.Size(386, 85);
            this.tableLayoutPanel76.TabIndex = 211;
            this.tableLayoutPanel76.Visible = false;
            // 
            // panel91
            // 
            this.panel91.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel91.BackColor = System.Drawing.Color.White;
            this.panel91.Controls.Add(this.label87);
            this.panel91.Controls.Add(this.txt_C_Bank_Number2_2);
            this.panel91.Controls.Add(this.label88);
            this.panel91.Controls.Add(this.txt_C_Bank_Send_Nu);
            this.panel91.Controls.Add(this.radioB_C_Bank_Send_TF2);
            this.panel91.Controls.Add(this.radioB_C_Bank_Send_TF1);
            this.panel91.Location = new System.Drawing.Point(126, 4);
            this.panel91.Margin = new System.Windows.Forms.Padding(2);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(256, 77);
            this.panel91.TabIndex = 15;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(5, 57);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(117, 12);
            this.label87.TabIndex = 177;
            this.label87.Text = "현금영수증 인증번호";
            // 
            // txt_C_Bank_Number2_2
            // 
            this.txt_C_Bank_Number2_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Number2_2.Location = new System.Drawing.Point(123, 51);
            this.txt_C_Bank_Number2_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Number2_2.MaxLength = 20;
            this.txt_C_Bank_Number2_2.Name = "txt_C_Bank_Number2_2";
            this.txt_C_Bank_Number2_2.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Bank_Number2_2.TabIndex = 56;
            this.txt_C_Bank_Number2_2.Tag = "1";
            this.txt_C_Bank_Number2_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Bank_Number2_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Bank_Number2_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(4, 29);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(117, 12);
            this.label88.TabIndex = 57;
            this.label88.Text = "현금영수증 신청번호";
            // 
            // txt_C_Bank_Send_Nu
            // 
            this.txt_C_Bank_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Send_Nu.Location = new System.Drawing.Point(123, 24);
            this.txt_C_Bank_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Send_Nu.MaxLength = 20;
            this.txt_C_Bank_Send_Nu.Name = "txt_C_Bank_Send_Nu";
            this.txt_C_Bank_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Bank_Send_Nu.TabIndex = 56;
            this.txt_C_Bank_Send_Nu.Tag = "1";
            this.txt_C_Bank_Send_Nu.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Bank_Send_Nu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Bank_Send_Nu.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // radioB_C_Bank_Send_TF2
            // 
            this.radioB_C_Bank_Send_TF2.AutoSize = true;
            this.radioB_C_Bank_Send_TF2.Location = new System.Drawing.Point(195, 4);
            this.radioB_C_Bank_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Bank_Send_TF2.Name = "radioB_C_Bank_Send_TF2";
            this.radioB_C_Bank_Send_TF2.Size = new System.Drawing.Size(59, 16);
            this.radioB_C_Bank_Send_TF2.TabIndex = 55;
            this.radioB_C_Bank_Send_TF2.Text = "사업자";
            this.radioB_C_Bank_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_C_Bank_Send_TF1
            // 
            this.radioB_C_Bank_Send_TF1.AutoSize = true;
            this.radioB_C_Bank_Send_TF1.Checked = true;
            this.radioB_C_Bank_Send_TF1.Location = new System.Drawing.Point(137, 4);
            this.radioB_C_Bank_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Bank_Send_TF1.Name = "radioB_C_Bank_Send_TF1";
            this.radioB_C_Bank_Send_TF1.Size = new System.Drawing.Size(47, 16);
            this.radioB_C_Bank_Send_TF1.TabIndex = 54;
            this.radioB_C_Bank_Send_TF1.TabStop = true;
            this.radioB_C_Bank_Send_TF1.Text = "개인";
            this.radioB_C_Bank_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // label89
            // 
            this.label89.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label89.ForeColor = System.Drawing.Color.White;
            this.label89.Location = new System.Drawing.Point(2, 2);
            this.label89.Margin = new System.Windows.Forms.Padding(0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(120, 81);
            this.label89.TabIndex = 0;
            this.label89.Text = "현금영수증";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Controls.Add(this.panel62, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1, 111);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(477, 36);
            this.tableLayoutPanel28.TabIndex = 210;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.White;
            this.panel62.Controls.Add(this.txt_C_Bank_Code_3);
            this.panel62.Location = new System.Drawing.Point(126, 4);
            this.panel62.Margin = new System.Windows.Forms.Padding(2);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(347, 28);
            this.panel62.TabIndex = 15;
            // 
            // txt_C_Bank_Code_3
            // 
            this.txt_C_Bank_Code_3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code_3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code_3.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Bank_Code_3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code_3.MaxLength = 30;
            this.txt_C_Bank_Code_3.Name = "txt_C_Bank_Code_3";
            this.txt_C_Bank_Code_3.ReadOnly = true;
            this.txt_C_Bank_Code_3.Size = new System.Drawing.Size(341, 22);
            this.txt_C_Bank_Code_3.TabIndex = 6;
            this.txt_C_Bank_Code_3.TabStop = false;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(2, 2);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(120, 32);
            this.label44.TabIndex = 0;
            this.label44.Text = "계좌_번호";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel26.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.panel60, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.label38, 0, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(230, 74);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel26.TabIndex = 209;
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.White;
            this.panel60.Controls.Add(this.txt_C_Bank_Code_2);
            this.panel60.Location = new System.Drawing.Point(126, 4);
            this.panel60.Margin = new System.Windows.Forms.Padding(2);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(118, 28);
            this.panel60.TabIndex = 15;
            // 
            // txt_C_Bank_Code_2
            // 
            this.txt_C_Bank_Code_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code_2.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Bank_Code_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code_2.MaxLength = 30;
            this.txt_C_Bank_Code_2.Name = "txt_C_Bank_Code_2";
            this.txt_C_Bank_Code_2.ReadOnly = true;
            this.txt_C_Bank_Code_2.Size = new System.Drawing.Size(112, 22);
            this.txt_C_Bank_Code_2.TabIndex = 5;
            this.txt_C_Bank_Code_2.TabStop = false;
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(2, 2);
            this.label38.Margin = new System.Windows.Forms.Padding(0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(120, 32);
            this.label38.TabIndex = 0;
            this.label38.Text = "회사_은행명";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel27.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.panel61, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.label42, 0, 0);
            this.tableLayoutPanel27.Location = new System.Drawing.Point(1, 74);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel27.TabIndex = 208;
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.Color.White;
            this.panel61.Controls.Add(this.txt_C_Bank_Code);
            this.panel61.Location = new System.Drawing.Point(126, 4);
            this.panel61.Margin = new System.Windows.Forms.Padding(2);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(98, 28);
            this.panel61.TabIndex = 15;
            // 
            // txt_C_Bank_Code
            // 
            this.txt_C_Bank_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Bank_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code.MaxLength = 30;
            this.txt_C_Bank_Code.Name = "txt_C_Bank_Code";
            this.txt_C_Bank_Code.ReadOnly = true;
            this.txt_C_Bank_Code.Size = new System.Drawing.Size(92, 22);
            this.txt_C_Bank_Code.TabIndex = 4;
            this.txt_C_Bank_Code.TabStop = false;
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(2, 2);
            this.label42.Margin = new System.Windows.Forms.Padding(0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(120, 32);
            this.label42.TabIndex = 0;
            this.label42.Text = "회사_은행_코드";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel25.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.panel59, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(230, 38);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel25.TabIndex = 3;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.White;
            this.panel59.Controls.Add(this.txt_C_Bank);
            this.panel59.Location = new System.Drawing.Point(126, 4);
            this.panel59.Margin = new System.Windows.Forms.Padding(2);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(118, 28);
            this.panel59.TabIndex = 15;
            // 
            // txt_C_Bank
            // 
            this.txt_C_Bank.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Bank.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank.MaxLength = 30;
            this.txt_C_Bank.Name = "txt_C_Bank";
            this.txt_C_Bank.Size = new System.Drawing.Size(112, 22);
            this.txt_C_Bank.TabIndex = 3;
            this.txt_C_Bank.Tag = "ncode";
            this.txt_C_Bank.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Bank.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Bank.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Bank.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(2, 2);
            this.label43.Margin = new System.Windows.Forms.Padding(0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 32);
            this.label43.TabIndex = 0;
            this.label43.Text = "계좌가명";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel24.Location = new System.Drawing.Point(2, 38);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel24.TabIndex = 2;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.txt_C_Name_2);
            this.panel16.Location = new System.Drawing.Point(126, 4);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(98, 28);
            this.panel16.TabIndex = 15;
            // 
            // txt_C_Name_2
            // 
            this.txt_C_Name_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Name_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Name_2.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Name_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Name_2.MaxLength = 100;
            this.txt_C_Name_2.Name = "txt_C_Name_2";
            this.txt_C_Name_2.Size = new System.Drawing.Size(92, 22);
            this.txt_C_Name_2.TabIndex = 2;
            this.txt_C_Name_2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Name_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Name_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Name_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(2, 2);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 32);
            this.label39.TabIndex = 0;
            this.label39.Text = "입금자명";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.panel12, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.txt_Price_2);
            this.panel12.Location = new System.Drawing.Point(126, 4);
            this.panel12.Margin = new System.Windows.Forms.Padding(2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(98, 28);
            this.panel12.TabIndex = 15;
            // 
            // txt_Price_2
            // 
            this.txt_Price_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_2.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_2.MaxLength = 8;
            this.txt_Price_2.Name = "txt_Price_2";
            this.txt_Price_2.Size = new System.Drawing.Size(92, 22);
            this.txt_Price_2.TabIndex = 0;
            this.txt_Price_2.Tag = "2";
            this.txt_Price_2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Price_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 32);
            this.label9.TabIndex = 0;
            this.label9.Text = "결제액";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel22.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.panel58, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel22.Location = new System.Drawing.Point(230, 2);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel22.TabIndex = 1;
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.Color.White;
            this.panel58.Controls.Add(this.mtxtPriceDate2);
            this.panel58.Controls.Add(this.DTP_PriceDate2);
            this.panel58.Location = new System.Drawing.Point(126, 4);
            this.panel58.Margin = new System.Windows.Forms.Padding(2);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(118, 28);
            this.panel58.TabIndex = 15;
            // 
            // mtxtPriceDate2
            // 
            this.mtxtPriceDate2.Location = new System.Drawing.Point(3, 3);
            this.mtxtPriceDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate2.Name = "mtxtPriceDate2";
            this.mtxtPriceDate2.Size = new System.Drawing.Size(92, 21);
            this.mtxtPriceDate2.TabIndex = 107;
            this.mtxtPriceDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPriceDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPriceDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_PriceDate2
            // 
            this.DTP_PriceDate2.Location = new System.Drawing.Point(94, 3);
            this.DTP_PriceDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate2.Name = "DTP_PriceDate2";
            this.DTP_PriceDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_PriceDate2.TabIndex = 173;
            this.DTP_PriceDate2.TabStop = false;
            this.DTP_PriceDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 32);
            this.label11.TabIndex = 0;
            this.label11.Text = "결제일";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_VA_Bank
            // 
            this.tab_VA_Bank.BackColor = System.Drawing.SystemColors.Control;
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel46);
            this.tab_VA_Bank.Controls.Add(this.txt_AV_C_Number3);
            this.tab_VA_Bank.Controls.Add(this.buttonV_Cancel);
            this.tab_VA_Bank.Controls.Add(this.buttonV_Ok);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel60);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel70);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel71);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel69);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel73);
            this.tab_VA_Bank.Controls.Add(this.check_Not_AVCash);
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel49);
            this.tab_VA_Bank.Location = new System.Drawing.Point(4, 22);
            this.tab_VA_Bank.Name = "tab_VA_Bank";
            this.tab_VA_Bank.Size = new System.Drawing.Size(660, 234);
            this.tab_VA_Bank.TabIndex = 4;
            this.tab_VA_Bank.Text = "가상계좌";
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel46.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel46.ColumnCount = 2;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel46.Controls.Add(this.panel75, 1, 0);
            this.tableLayoutPanel46.Location = new System.Drawing.Point(230, 3);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 1;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(249, 36);
            this.tableLayoutPanel46.TabIndex = 227;
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(2, 2);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(120, 32);
            this.label35.TabIndex = 0;
            this.label35.Text = "신청_은행";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.White;
            this.panel75.Controls.Add(this.txtBank);
            this.panel75.Controls.Add(this.txtBank_Code);
            this.panel75.Location = new System.Drawing.Point(126, 4);
            this.panel75.Margin = new System.Windows.Forms.Padding(2);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(119, 28);
            this.panel75.TabIndex = 15;
            // 
            // txtBank
            // 
            this.txtBank.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtBank.Location = new System.Drawing.Point(3, 3);
            this.txtBank.Margin = new System.Windows.Forms.Padding(0);
            this.txtBank.MaxLength = 30;
            this.txtBank.Name = "txtBank";
            this.txtBank.Size = new System.Drawing.Size(70, 22);
            this.txtBank.TabIndex = 14;
            this.txtBank.Tag = "ncode";
            this.txtBank.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtBank.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtBank.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtBank.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtBank_Code
            // 
            this.txtBank_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtBank_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBank_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtBank_Code.ForeColor = System.Drawing.Color.White;
            this.txtBank_Code.Location = new System.Drawing.Point(74, 3);
            this.txtBank_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtBank_Code.MaxLength = 30;
            this.txtBank_Code.Name = "txtBank_Code";
            this.txtBank_Code.ReadOnly = true;
            this.txtBank_Code.Size = new System.Drawing.Size(42, 22);
            this.txtBank_Code.TabIndex = 4;
            this.txtBank_Code.TabStop = false;
            // 
            // txt_AV_C_Number3
            // 
            this.txt_AV_C_Number3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_AV_C_Number3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AV_C_Number3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AV_C_Number3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AV_C_Number3.Location = new System.Drawing.Point(314, 118);
            this.txt_AV_C_Number3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AV_C_Number3.MaxLength = 30;
            this.txt_AV_C_Number3.Name = "txt_AV_C_Number3";
            this.txt_AV_C_Number3.ReadOnly = true;
            this.txt_AV_C_Number3.Size = new System.Drawing.Size(335, 22);
            this.txt_AV_C_Number3.TabIndex = 226;
            this.txt_AV_C_Number3.TabStop = false;
            this.txt_AV_C_Number3.Visible = false;
            // 
            // buttonV_Cancel
            // 
            this.buttonV_Cancel.BackColor = System.Drawing.Color.White;
            this.buttonV_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonV_Cancel.Location = new System.Drawing.Point(141, 114);
            this.buttonV_Cancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonV_Cancel.Name = "buttonV_Cancel";
            this.buttonV_Cancel.Size = new System.Drawing.Size(137, 26);
            this.buttonV_Cancel.TabIndex = 225;
            this.buttonV_Cancel.TabStop = false;
            this.buttonV_Cancel.Text = "가상계좌_취소";
            this.buttonV_Cancel.UseVisualStyleBackColor = false;
            this.buttonV_Cancel.Visible = false;
            this.buttonV_Cancel.Click += new System.EventHandler(this.buttonV_Cancel_Click);
            // 
            // buttonV_Ok
            // 
            this.buttonV_Ok.BackColor = System.Drawing.Color.White;
            this.buttonV_Ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonV_Ok.Location = new System.Drawing.Point(3, 114);
            this.buttonV_Ok.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonV_Ok.Name = "buttonV_Ok";
            this.buttonV_Ok.Size = new System.Drawing.Size(137, 26);
            this.buttonV_Ok.TabIndex = 224;
            this.buttonV_Ok.TabStop = false;
            this.buttonV_Ok.Text = "가상계좌_발생";
            this.buttonV_Ok.UseVisualStyleBackColor = false;
            this.buttonV_Ok.Click += new System.EventHandler(this.buttonV_Ok_Click);
            // 
            // tableLayoutPanel60
            // 
            this.tableLayoutPanel60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel60.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel60.ColumnCount = 2;
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel60.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel60.Controls.Add(this.panel82, 1, 0);
            this.tableLayoutPanel60.Controls.Add(this.label72, 0, 0);
            this.tableLayoutPanel60.Location = new System.Drawing.Point(188, 76);
            this.tableLayoutPanel60.Name = "tableLayoutPanel60";
            this.tableLayoutPanel60.RowCount = 1;
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel60.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel60.Size = new System.Drawing.Size(290, 36);
            this.tableLayoutPanel60.TabIndex = 223;
            // 
            // panel82
            // 
            this.panel82.BackColor = System.Drawing.Color.White;
            this.panel82.Controls.Add(this.txt_AV_C_Number1);
            this.panel82.Location = new System.Drawing.Point(126, 4);
            this.panel82.Margin = new System.Windows.Forms.Padding(2);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(160, 28);
            this.panel82.TabIndex = 15;
            // 
            // txt_AV_C_Number1
            // 
            this.txt_AV_C_Number1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_AV_C_Number1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AV_C_Number1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AV_C_Number1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AV_C_Number1.Location = new System.Drawing.Point(3, 3);
            this.txt_AV_C_Number1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AV_C_Number1.MaxLength = 30;
            this.txt_AV_C_Number1.Name = "txt_AV_C_Number1";
            this.txt_AV_C_Number1.ReadOnly = true;
            this.txt_AV_C_Number1.Size = new System.Drawing.Size(154, 22);
            this.txt_AV_C_Number1.TabIndex = 6;
            this.txt_AV_C_Number1.TabStop = false;
            // 
            // label72
            // 
            this.label72.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label72.ForeColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(2, 2);
            this.label72.Margin = new System.Windows.Forms.Padding(0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(120, 32);
            this.label72.TabIndex = 0;
            this.label72.Text = "계좌_번호";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel70
            // 
            this.tableLayoutPanel70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel70.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel70.ColumnCount = 2;
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel70.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel70.Controls.Add(this.panel84, 1, 0);
            this.tableLayoutPanel70.Controls.Add(this.label74, 0, 0);
            this.tableLayoutPanel70.Location = new System.Drawing.Point(2, 76);
            this.tableLayoutPanel70.Name = "tableLayoutPanel70";
            this.tableLayoutPanel70.RowCount = 1;
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel70.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel70.Size = new System.Drawing.Size(185, 36);
            this.tableLayoutPanel70.TabIndex = 222;
            // 
            // panel84
            // 
            this.panel84.BackColor = System.Drawing.Color.White;
            this.panel84.Controls.Add(this.txt_AV_C_Code);
            this.panel84.Location = new System.Drawing.Point(126, 4);
            this.panel84.Margin = new System.Windows.Forms.Padding(2);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(55, 28);
            this.panel84.TabIndex = 15;
            // 
            // txt_AV_C_Code
            // 
            this.txt_AV_C_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_AV_C_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AV_C_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AV_C_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AV_C_Code.Location = new System.Drawing.Point(3, 3);
            this.txt_AV_C_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AV_C_Code.MaxLength = 30;
            this.txt_AV_C_Code.Name = "txt_AV_C_Code";
            this.txt_AV_C_Code.ReadOnly = true;
            this.txt_AV_C_Code.Size = new System.Drawing.Size(49, 22);
            this.txt_AV_C_Code.TabIndex = 4;
            this.txt_AV_C_Code.TabStop = false;
            // 
            // label74
            // 
            this.label74.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label74.ForeColor = System.Drawing.Color.White;
            this.label74.Location = new System.Drawing.Point(2, 2);
            this.label74.Margin = new System.Windows.Forms.Padding(0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(120, 32);
            this.label74.TabIndex = 0;
            this.label74.Text = "가상계좌_은행_코드";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel71
            // 
            this.tableLayoutPanel71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel71.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel71.ColumnCount = 2;
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133F));
            this.tableLayoutPanel71.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel71.Controls.Add(this.panel85, 1, 0);
            this.tableLayoutPanel71.Controls.Add(this.label75, 0, 0);
            this.tableLayoutPanel71.Location = new System.Drawing.Point(2, 40);
            this.tableLayoutPanel71.Name = "tableLayoutPanel71";
            this.tableLayoutPanel71.RowCount = 1;
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel71.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel71.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel71.TabIndex = 221;
            // 
            // panel85
            // 
            this.panel85.BackColor = System.Drawing.Color.White;
            this.panel85.Controls.Add(this.txt_Price_5);
            this.panel85.Location = new System.Drawing.Point(139, 4);
            this.panel85.Margin = new System.Windows.Forms.Padding(2);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(85, 28);
            this.panel85.TabIndex = 15;
            // 
            // txt_Price_5
            // 
            this.txt_Price_5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Price_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Price_5.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_5.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_5.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_5.MaxLength = 30;
            this.txt_Price_5.Name = "txt_Price_5";
            this.txt_Price_5.ReadOnly = true;
            this.txt_Price_5.Size = new System.Drawing.Size(79, 22);
            this.txt_Price_5.TabIndex = 5;
            this.txt_Price_5.TabStop = false;
            // 
            // label75
            // 
            this.label75.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label75.ForeColor = System.Drawing.Color.White;
            this.label75.Location = new System.Drawing.Point(2, 2);
            this.label75.Margin = new System.Windows.Forms.Padding(0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(133, 32);
            this.label75.TabIndex = 0;
            this.label75.Text = "입금액";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel69
            // 
            this.tableLayoutPanel69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel69.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel69.ColumnCount = 2;
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133F));
            this.tableLayoutPanel69.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel69.Controls.Add(this.panel83, 1, 0);
            this.tableLayoutPanel69.Controls.Add(this.label73, 0, 0);
            this.tableLayoutPanel69.Location = new System.Drawing.Point(230, 40);
            this.tableLayoutPanel69.Name = "tableLayoutPanel69";
            this.tableLayoutPanel69.RowCount = 1;
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel69.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel69.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel69.TabIndex = 220;
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.Color.White;
            this.panel83.Controls.Add(this.txt_AV_C_AppDate1);
            this.panel83.Location = new System.Drawing.Point(139, 4);
            this.panel83.Margin = new System.Windows.Forms.Padding(2);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(105, 28);
            this.panel83.TabIndex = 15;
            // 
            // txt_AV_C_AppDate1
            // 
            this.txt_AV_C_AppDate1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_AV_C_AppDate1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AV_C_AppDate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AV_C_AppDate1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AV_C_AppDate1.Location = new System.Drawing.Point(3, 3);
            this.txt_AV_C_AppDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AV_C_AppDate1.MaxLength = 30;
            this.txt_AV_C_AppDate1.Name = "txt_AV_C_AppDate1";
            this.txt_AV_C_AppDate1.ReadOnly = true;
            this.txt_AV_C_AppDate1.Size = new System.Drawing.Size(99, 22);
            this.txt_AV_C_AppDate1.TabIndex = 5;
            this.txt_AV_C_AppDate1.TabStop = false;
            // 
            // label73
            // 
            this.label73.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label73.ForeColor = System.Drawing.Color.White;
            this.label73.Location = new System.Drawing.Point(2, 2);
            this.label73.Margin = new System.Windows.Forms.Padding(0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(133, 32);
            this.label73.TabIndex = 0;
            this.label73.Text = "가상_계좌요청/입금일";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel73
            // 
            this.tableLayoutPanel73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel73.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel73.ColumnCount = 2;
            this.tableLayoutPanel73.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel73.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel73.Controls.Add(this.panel87, 1, 0);
            this.tableLayoutPanel73.Controls.Add(this.label77, 0, 0);
            this.tableLayoutPanel73.Location = new System.Drawing.Point(2, 3);
            this.tableLayoutPanel73.Name = "tableLayoutPanel73";
            this.tableLayoutPanel73.RowCount = 1;
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel73.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel73.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel73.TabIndex = 219;
            // 
            // panel87
            // 
            this.panel87.BackColor = System.Drawing.Color.White;
            this.panel87.Controls.Add(this.txt_Price_5_2);
            this.panel87.Location = new System.Drawing.Point(126, 4);
            this.panel87.Margin = new System.Windows.Forms.Padding(2);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(98, 28);
            this.panel87.TabIndex = 15;
            // 
            // txt_Price_5_2
            // 
            this.txt_Price_5_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_5_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_5_2.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_5_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_5_2.MaxLength = 8;
            this.txt_Price_5_2.Name = "txt_Price_5_2";
            this.txt_Price_5_2.Size = new System.Drawing.Size(92, 22);
            this.txt_Price_5_2.TabIndex = 0;
            this.txt_Price_5_2.Tag = "2";
            this.txt_Price_5_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_5_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_5_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label77
            // 
            this.label77.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label77.ForeColor = System.Drawing.Color.White;
            this.label77.Location = new System.Drawing.Point(2, 2);
            this.label77.Margin = new System.Windows.Forms.Padding(0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(120, 32);
            this.label77.TabIndex = 0;
            this.label77.Text = "가상계좌_요청액";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // check_Not_AVCash
            // 
            this.check_Not_AVCash.AutoSize = true;
            this.check_Not_AVCash.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.check_Not_AVCash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.check_Not_AVCash.Location = new System.Drawing.Point(3, 142);
            this.check_Not_AVCash.Name = "check_Not_AVCash";
            this.check_Not_AVCash.Size = new System.Drawing.Size(253, 16);
            this.check_Not_AVCash.TabIndex = 234;
            this.check_Not_AVCash.Text = "현금영수증/세금계산서_미신고/미발행";
            this.check_Not_AVCash.UseVisualStyleBackColor = true;
            this.check_Not_AVCash.Visible = false;
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel49.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel49.ColumnCount = 2;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.Controls.Add(this.panel78, 1, 0);
            this.tableLayoutPanel49.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel49.Location = new System.Drawing.Point(2, 159);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 1;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(386, 80);
            this.tableLayoutPanel49.TabIndex = 228;
            this.tableLayoutPanel49.Visible = false;
            // 
            // panel78
            // 
            this.panel78.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel78.BackColor = System.Drawing.Color.White;
            this.panel78.Controls.Add(this.label63);
            this.panel78.Controls.Add(this.txt_AVC_Cash_Number2);
            this.panel78.Controls.Add(this.label76);
            this.panel78.Controls.Add(this.txt_AVC_Cash_Send_Nu);
            this.panel78.Controls.Add(this.radioB_AVC_Cash_Send_TF2);
            this.panel78.Controls.Add(this.radioB_AVC_Cash_Send_TF1);
            this.panel78.Controls.Add(this.check_AVCash);
            this.panel78.Location = new System.Drawing.Point(126, 4);
            this.panel78.Margin = new System.Windows.Forms.Padding(2);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(256, 72);
            this.panel78.TabIndex = 15;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(5, 54);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(117, 12);
            this.label63.TabIndex = 177;
            this.label63.Text = "현금영수증 인증번호";
            // 
            // txt_AVC_Cash_Number2
            // 
            this.txt_AVC_Cash_Number2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AVC_Cash_Number2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AVC_Cash_Number2.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_AVC_Cash_Number2.ForeColor = System.Drawing.Color.Red;
            this.txt_AVC_Cash_Number2.Location = new System.Drawing.Point(123, 49);
            this.txt_AVC_Cash_Number2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AVC_Cash_Number2.MaxLength = 30;
            this.txt_AVC_Cash_Number2.Name = "txt_AVC_Cash_Number2";
            this.txt_AVC_Cash_Number2.ReadOnly = true;
            this.txt_AVC_Cash_Number2.Size = new System.Drawing.Size(128, 21);
            this.txt_AVC_Cash_Number2.TabIndex = 176;
            this.txt_AVC_Cash_Number2.TabStop = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(4, 29);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(117, 12);
            this.label76.TabIndex = 57;
            this.label76.Text = "현금영수증 신청번호";
            // 
            // txt_AVC_Cash_Send_Nu
            // 
            this.txt_AVC_Cash_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AVC_Cash_Send_Nu.Location = new System.Drawing.Point(123, 24);
            this.txt_AVC_Cash_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AVC_Cash_Send_Nu.MaxLength = 20;
            this.txt_AVC_Cash_Send_Nu.Name = "txt_AVC_Cash_Send_Nu";
            this.txt_AVC_Cash_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_AVC_Cash_Send_Nu.TabIndex = 56;
            this.txt_AVC_Cash_Send_Nu.Tag = "1";
            // 
            // radioB_AVC_Cash_Send_TF2
            // 
            this.radioB_AVC_Cash_Send_TF2.AutoSize = true;
            this.radioB_AVC_Cash_Send_TF2.Location = new System.Drawing.Point(195, 4);
            this.radioB_AVC_Cash_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_AVC_Cash_Send_TF2.Name = "radioB_AVC_Cash_Send_TF2";
            this.radioB_AVC_Cash_Send_TF2.Size = new System.Drawing.Size(59, 16);
            this.radioB_AVC_Cash_Send_TF2.TabIndex = 55;
            this.radioB_AVC_Cash_Send_TF2.Text = "사업자";
            this.radioB_AVC_Cash_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_AVC_Cash_Send_TF1
            // 
            this.radioB_AVC_Cash_Send_TF1.AutoSize = true;
            this.radioB_AVC_Cash_Send_TF1.Checked = true;
            this.radioB_AVC_Cash_Send_TF1.Location = new System.Drawing.Point(137, 4);
            this.radioB_AVC_Cash_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_AVC_Cash_Send_TF1.Name = "radioB_AVC_Cash_Send_TF1";
            this.radioB_AVC_Cash_Send_TF1.Size = new System.Drawing.Size(47, 16);
            this.radioB_AVC_Cash_Send_TF1.TabIndex = 54;
            this.radioB_AVC_Cash_Send_TF1.TabStop = true;
            this.radioB_AVC_Cash_Send_TF1.Text = "개인";
            this.radioB_AVC_Cash_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // check_AVCash
            // 
            this.check_AVCash.AutoSize = true;
            this.check_AVCash.ForeColor = System.Drawing.Color.Red;
            this.check_AVCash.Location = new System.Drawing.Point(6, 5);
            this.check_AVCash.Name = "check_AVCash";
            this.check_AVCash.Size = new System.Drawing.Size(114, 16);
            this.check_AVCash.TabIndex = 0;
            this.check_AVCash.Text = "현금영수증_신고";
            this.check_AVCash.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            this.label78.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label78.ForeColor = System.Drawing.Color.White;
            this.label78.Location = new System.Drawing.Point(2, 2);
            this.label78.Margin = new System.Windows.Forms.Padding(0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(120, 76);
            this.label78.TabIndex = 0;
            this.label78.Text = "현금영수증";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Mile
            // 
            this.tab_Mile.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Mile.Controls.Add(this.tableLayoutPanel32);
            this.tab_Mile.Controls.Add(this.tableLayoutPanel29);
            this.tab_Mile.Controls.Add(this.tableLayoutPanel31);
            this.tab_Mile.Controls.Add(this.butt_Mile_Search);
            this.tab_Mile.Location = new System.Drawing.Point(4, 22);
            this.tab_Mile.Name = "tab_Mile";
            this.tab_Mile.Size = new System.Drawing.Size(660, 234);
            this.tab_Mile.TabIndex = 3;
            this.tab_Mile.Text = "마일리지";
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.panel65, 1, 0);
            this.tableLayoutPanel32.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel32.Location = new System.Drawing.Point(2, 76);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel32.TabIndex = 210;
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.White;
            this.panel65.Controls.Add(this.txt_Price_4_2);
            this.panel65.Location = new System.Drawing.Point(126, 4);
            this.panel65.Margin = new System.Windows.Forms.Padding(2);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(118, 28);
            this.panel65.TabIndex = 15;
            // 
            // txt_Price_4_2
            // 
            this.txt_Price_4_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_4_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Price_4_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Price_4_2.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_Price_4_2.ForeColor = System.Drawing.Color.Blue;
            this.txt_Price_4_2.Location = new System.Drawing.Point(3, 4);
            this.txt_Price_4_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_4_2.MaxLength = 30;
            this.txt_Price_4_2.Name = "txt_Price_4_2";
            this.txt_Price_4_2.ReadOnly = true;
            this.txt_Price_4_2.Size = new System.Drawing.Size(112, 21);
            this.txt_Price_4_2.TabIndex = 173;
            this.txt_Price_4_2.TabStop = false;
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(2, 2);
            this.label41.Margin = new System.Windows.Forms.Padding(0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(120, 32);
            this.label41.TabIndex = 0;
            this.label41.Text = "사용가능_마일리지";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel29.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Controls.Add(this.panel63, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel29.TabIndex = 0;
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.Color.White;
            this.panel63.Controls.Add(this.txt_Price_4);
            this.panel63.Location = new System.Drawing.Point(126, 4);
            this.panel63.Margin = new System.Windows.Forms.Padding(2);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(118, 28);
            this.panel63.TabIndex = 15;
            // 
            // txt_Price_4
            // 
            this.txt_Price_4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Price_4.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_4.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_4.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_4.MaxLength = 8;
            this.txt_Price_4.Name = "txt_Price_4";
            this.txt_Price_4.Size = new System.Drawing.Size(112, 22);
            this.txt_Price_4.TabIndex = 0;
            this.txt_Price_4.Tag = "2";
            this.txt_Price_4.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Price_4.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Price_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Price_4.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(2, 2);
            this.label30.Margin = new System.Windows.Forms.Padding(0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(120, 32);
            this.label30.TabIndex = 0;
            this.label30.Text = "결제액";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel31.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.panel64, 1, 0);
            this.tableLayoutPanel31.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel31.Location = new System.Drawing.Point(2, 39);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(248, 36);
            this.tableLayoutPanel31.TabIndex = 1;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.Color.White;
            this.panel64.Controls.Add(this.mtxtPriceDate4);
            this.panel64.Controls.Add(this.DTP_PriceDate4);
            this.panel64.Location = new System.Drawing.Point(126, 4);
            this.panel64.Margin = new System.Windows.Forms.Padding(2);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(118, 28);
            this.panel64.TabIndex = 15;
            // 
            // mtxtPriceDate4
            // 
            this.mtxtPriceDate4.Location = new System.Drawing.Point(3, 3);
            this.mtxtPriceDate4.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate4.Name = "mtxtPriceDate4";
            this.mtxtPriceDate4.Size = new System.Drawing.Size(92, 21);
            this.mtxtPriceDate4.TabIndex = 107;
            this.mtxtPriceDate4.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPriceDate4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPriceDate4.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_PriceDate4
            // 
            this.DTP_PriceDate4.Location = new System.Drawing.Point(94, 3);
            this.DTP_PriceDate4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate4.Name = "DTP_PriceDate4";
            this.DTP_PriceDate4.Size = new System.Drawing.Size(21, 21);
            this.DTP_PriceDate4.TabIndex = 112;
            this.DTP_PriceDate4.TabStop = false;
            this.DTP_PriceDate4.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(2, 2);
            this.label40.Margin = new System.Windows.Forms.Padding(0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(120, 32);
            this.label40.TabIndex = 0;
            this.label40.Text = "결제일";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Mile_Search
            // 
            this.butt_Mile_Search.BackColor = System.Drawing.Color.White;
            this.butt_Mile_Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Mile_Search.Location = new System.Drawing.Point(250, 76);
            this.butt_Mile_Search.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Mile_Search.Name = "butt_Mile_Search";
            this.butt_Mile_Search.Size = new System.Drawing.Size(68, 35);
            this.butt_Mile_Search.TabIndex = 2;
            this.butt_Mile_Search.TabStop = false;
            this.butt_Mile_Search.Text = "조회";
            this.butt_Mile_Search.UseVisualStyleBackColor = false;
            this.butt_Mile_Search.Click += new System.EventHandler(this.butt_Mile_Search_Click);
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.tableLayoutPanel45);
            this.panel42.Controls.Add(this.tableLayoutPanel20);
            this.panel42.Controls.Add(this.tableLayoutPanel7);
            this.panel42.Controls.Add(this.txt_Sugi_TF);
            this.panel42.Controls.Add(this.tableLayoutPanel19);
            this.panel42.Controls.Add(this.tableLayoutPanel18);
            this.panel42.Controls.Add(this.tableLayoutPanel17);
            this.panel42.Controls.Add(this.tableLayoutPanel16);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel42.Location = new System.Drawing.Point(668, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(221, 305);
            this.panel42.TabIndex = 156;
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel45.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.Controls.Add(this.panel74, 1, 0);
            this.tableLayoutPanel45.Controls.Add(this.label32, 0, 0);
            this.tableLayoutPanel45.Location = new System.Drawing.Point(16, 238);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 1;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(478, 36);
            this.tableLayoutPanel45.TabIndex = 9;
            this.tableLayoutPanel45.Visible = false;
            // 
            // panel74
            // 
            this.panel74.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel74.BackColor = System.Drawing.Color.White;
            this.panel74.Controls.Add(this.label34);
            this.panel74.Controls.Add(this.chk_app);
            this.panel74.Location = new System.Drawing.Point(126, 4);
            this.panel74.Margin = new System.Windows.Forms.Padding(2);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(348, 28);
            this.panel74.TabIndex = 15;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.Blue;
            this.label34.Location = new System.Drawing.Point(0, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(219, 12);
            this.label34.TabIndex = 1;
            this.label34.Text = "(필수사항:카드번호,유효기간,승인금액)";
            // 
            // chk_app
            // 
            this.chk_app.AutoSize = true;
            this.chk_app.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.chk_app.ForeColor = System.Drawing.Color.Red;
            this.chk_app.Location = new System.Drawing.Point(4, 0);
            this.chk_app.Name = "chk_app";
            this.chk_app.Size = new System.Drawing.Size(187, 16);
            this.chk_app.TabIndex = 0;
            this.chk_app.Text = "매출 저장시 카드 자동 승인";
            this.chk_app.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(2, 2);
            this.label32.Margin = new System.Windows.Forms.Padding(0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(120, 32);
            this.label32.TabIndex = 0;
            this.label32.Text = "자동승인";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.panel47, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label45, 0, 0);
            this.tableLayoutPanel20.Location = new System.Drawing.Point(2, 110);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel20.TabIndex = 199;
            this.tableLayoutPanel20.Visible = false;
            // 
            // panel47
            // 
            this.panel47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel47.BackColor = System.Drawing.Color.White;
            this.panel47.Controls.Add(this.txt_SumMile);
            this.panel47.Location = new System.Drawing.Point(126, 4);
            this.panel47.Margin = new System.Windows.Forms.Padding(2);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(87, 28);
            this.panel47.TabIndex = 15;
            // 
            // txt_SumMile
            // 
            this.txt_SumMile.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SumMile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumMile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumMile.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumMile.ForeColor = System.Drawing.Color.Black;
            this.txt_SumMile.Location = new System.Drawing.Point(3, 3);
            this.txt_SumMile.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumMile.MaxLength = 30;
            this.txt_SumMile.Name = "txt_SumMile";
            this.txt_SumMile.ReadOnly = true;
            this.txt_SumMile.Size = new System.Drawing.Size(81, 21);
            this.txt_SumMile.TabIndex = 173;
            this.txt_SumMile.TabStop = false;
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(2, 2);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 32);
            this.label45.TabIndex = 0;
            this.label45.Text = "마일리지";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.panel9, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(2, 182);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel7.TabIndex = 198;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.txt_UnaccMoney);
            this.panel9.Location = new System.Drawing.Point(126, 4);
            this.panel9.Margin = new System.Windows.Forms.Padding(2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(87, 28);
            this.panel9.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 2);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 32);
            this.label10.TabIndex = 0;
            this.label10.Text = "미결제";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_Sugi_TF
            // 
            this.txt_Sugi_TF.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Sugi_TF.Location = new System.Drawing.Point(6, 278);
            this.txt_Sugi_TF.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Sugi_TF.MaxLength = 8;
            this.txt_Sugi_TF.Name = "txt_Sugi_TF";
            this.txt_Sugi_TF.Size = new System.Drawing.Size(70, 22);
            this.txt_Sugi_TF.TabIndex = 201;
            this.txt_Sugi_TF.Tag = "2";
            this.txt_Sugi_TF.Visible = false;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.panel46, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.label27, 0, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(2, 146);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 1;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel19.TabIndex = 198;
            // 
            // panel46
            // 
            this.panel46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel46.BackColor = System.Drawing.Color.White;
            this.panel46.Controls.Add(this.txt_TotalInputPrice);
            this.panel46.Location = new System.Drawing.Point(126, 4);
            this.panel46.Margin = new System.Windows.Forms.Padding(2);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(87, 28);
            this.panel46.TabIndex = 15;
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(2, 2);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(120, 32);
            this.label27.TabIndex = 0;
            this.label27.Text = "결재액";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.panel45, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(2, 73);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel18.TabIndex = 197;
            // 
            // panel45
            // 
            this.panel45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel45.BackColor = System.Drawing.Color.White;
            this.panel45.Controls.Add(this.txt_SumBank);
            this.panel45.Location = new System.Drawing.Point(126, 4);
            this.panel45.Margin = new System.Windows.Forms.Padding(2);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(87, 28);
            this.panel45.TabIndex = 15;
            // 
            // txt_SumBank
            // 
            this.txt_SumBank.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SumBank.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumBank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumBank.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumBank.ForeColor = System.Drawing.Color.Black;
            this.txt_SumBank.Location = new System.Drawing.Point(3, 3);
            this.txt_SumBank.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumBank.MaxLength = 30;
            this.txt_SumBank.Name = "txt_SumBank";
            this.txt_SumBank.ReadOnly = true;
            this.txt_SumBank.Size = new System.Drawing.Size(81, 21);
            this.txt_SumBank.TabIndex = 173;
            this.txt_SumBank.TabStop = false;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(2, 2);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(120, 32);
            this.label21.TabIndex = 0;
            this.label21.Text = "무통장";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.panel44, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(2, 37);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel17.TabIndex = 196;
            // 
            // panel44
            // 
            this.panel44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel44.BackColor = System.Drawing.Color.White;
            this.panel44.Controls.Add(this.txt_SumCash);
            this.panel44.Location = new System.Drawing.Point(126, 4);
            this.panel44.Margin = new System.Windows.Forms.Padding(2);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(87, 28);
            this.panel44.TabIndex = 15;
            // 
            // txt_SumCash
            // 
            this.txt_SumCash.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SumCash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumCash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumCash.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumCash.ForeColor = System.Drawing.Color.Black;
            this.txt_SumCash.Location = new System.Drawing.Point(3, 3);
            this.txt_SumCash.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumCash.MaxLength = 30;
            this.txt_SumCash.Name = "txt_SumCash";
            this.txt_SumCash.ReadOnly = true;
            this.txt_SumCash.Size = new System.Drawing.Size(81, 21);
            this.txt_SumCash.TabIndex = 165;
            this.txt_SumCash.TabStop = false;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(2, 2);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 32);
            this.label20.TabIndex = 0;
            this.label20.Text = "현금";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.panel43, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(2, 1);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(217, 36);
            this.tableLayoutPanel16.TabIndex = 195;
            // 
            // panel43
            // 
            this.panel43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel43.BackColor = System.Drawing.Color.White;
            this.panel43.Controls.Add(this.txt_SumCard);
            this.panel43.Location = new System.Drawing.Point(126, 4);
            this.panel43.Margin = new System.Windows.Forms.Padding(2);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(87, 28);
            this.panel43.TabIndex = 15;
            // 
            // txt_SumCard
            // 
            this.txt_SumCard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SumCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumCard.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumCard.ForeColor = System.Drawing.Color.Black;
            this.txt_SumCard.Location = new System.Drawing.Point(3, 3);
            this.txt_SumCard.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumCard.MaxLength = 30;
            this.txt_SumCard.Name = "txt_SumCard";
            this.txt_SumCard.ReadOnly = true;
            this.txt_SumCard.Size = new System.Drawing.Size(81, 21);
            this.txt_SumCard.TabIndex = 175;
            this.txt_SumCard.TabStop = false;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 32);
            this.label19.TabIndex = 0;
            this.label19.Text = "카드";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_RecIndex
            // 
            this.txt_RecIndex.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_RecIndex.Location = new System.Drawing.Point(290, 223);
            this.txt_RecIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_RecIndex.MaxLength = 8;
            this.txt_RecIndex.Name = "txt_RecIndex";
            this.txt_RecIndex.ReadOnly = true;
            this.txt_RecIndex.Size = new System.Drawing.Size(51, 22);
            this.txt_RecIndex.TabIndex = 194;
            this.txt_RecIndex.TabStop = false;
            this.txt_RecIndex.Visible = false;
            // 
            // butt_Rec_Del
            // 
            this.butt_Rec_Del.BackColor = System.Drawing.Color.White;
            this.butt_Rec_Del.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Rec_Del.Location = new System.Drawing.Point(2, 223);
            this.butt_Rec_Del.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Rec_Del.Name = "butt_Rec_Del";
            this.butt_Rec_Del.Size = new System.Drawing.Size(89, 28);
            this.butt_Rec_Del.TabIndex = 193;
            this.butt_Rec_Del.TabStop = false;
            this.butt_Rec_Del.Text = "지우기";
            this.butt_Rec_Del.UseVisualStyleBackColor = false;
            this.butt_Rec_Del.Visible = false;
            this.butt_Rec_Del.Click += new System.EventHandler(this.Base_Small_Rece_Button_Click);
            // 
            // butt_Rec_Clear
            // 
            this.butt_Rec_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Rec_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Rec_Clear.Location = new System.Drawing.Point(182, 223);
            this.butt_Rec_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Rec_Clear.Name = "butt_Rec_Clear";
            this.butt_Rec_Clear.Size = new System.Drawing.Size(89, 28);
            this.butt_Rec_Clear.TabIndex = 192;
            this.butt_Rec_Clear.TabStop = false;
            this.butt_Rec_Clear.Text = "취소";
            this.butt_Rec_Clear.UseVisualStyleBackColor = false;
            this.butt_Rec_Clear.Click += new System.EventHandler(this.Base_Small_Rece_Button_Click);
            // 
            // butt_Rec_Save
            // 
            this.butt_Rec_Save.BackColor = System.Drawing.Color.White;
            this.butt_Rec_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Rec_Save.Location = new System.Drawing.Point(92, 223);
            this.butt_Rec_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Rec_Save.Name = "butt_Rec_Save";
            this.butt_Rec_Save.Size = new System.Drawing.Size(89, 28);
            this.butt_Rec_Save.TabIndex = 8;
            this.butt_Rec_Save.Text = "추가";
            this.butt_Rec_Save.UseVisualStyleBackColor = false;
            this.butt_Rec_Save.Click += new System.EventHandler(this.Base_Small_Rece_Button_Click);
            // 
            // butt_Rec_Add
            // 
            this.butt_Rec_Add.BackColor = System.Drawing.Color.White;
            this.butt_Rec_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Rec_Add.Location = new System.Drawing.Point(455, 74);
            this.butt_Rec_Add.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Rec_Add.Name = "butt_Rec_Add";
            this.butt_Rec_Add.Size = new System.Drawing.Size(162, 32);
            this.butt_Rec_Add.TabIndex = 1;
            this.butt_Rec_Add.TabStop = false;
            this.butt_Rec_Add.Text = "과거_배송지";
            this.butt_Rec_Add.UseVisualStyleBackColor = false;
            this.butt_Rec_Add.Click += new System.EventHandler(this.butt_Rec_Add_Click);
            // 
            // opt_Rec_Add3
            // 
            this.opt_Rec_Add3.AutoSize = true;
            this.opt_Rec_Add3.Location = new System.Drawing.Point(631, 242);
            this.opt_Rec_Add3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opt_Rec_Add3.Name = "opt_Rec_Add3";
            this.opt_Rec_Add3.Size = new System.Drawing.Size(71, 16);
            this.opt_Rec_Add3.TabIndex = 55;
            this.opt_Rec_Add3.Text = "새배송지";
            this.opt_Rec_Add3.UseVisualStyleBackColor = true;
            this.opt_Rec_Add3.Visible = false;
            this.opt_Rec_Add3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.opt_Rec_Add1_MouseUp);
            // 
            // opt_Rec_Add2
            // 
            this.opt_Rec_Add2.AutoSize = true;
            this.opt_Rec_Add2.Location = new System.Drawing.Point(4, 36);
            this.opt_Rec_Add2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opt_Rec_Add2.Name = "opt_Rec_Add2";
            this.opt_Rec_Add2.Size = new System.Drawing.Size(83, 16);
            this.opt_Rec_Add2.TabIndex = 54;
            this.opt_Rec_Add2.Text = "기본배송지";
            this.opt_Rec_Add2.UseVisualStyleBackColor = true;
            this.opt_Rec_Add2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.opt_Rec_Add1_MouseUp);
            // 
            // opt_Rec_Add1
            // 
            this.opt_Rec_Add1.AutoSize = true;
            this.opt_Rec_Add1.Location = new System.Drawing.Point(4, 6);
            this.opt_Rec_Add1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opt_Rec_Add1.Name = "opt_Rec_Add1";
            this.opt_Rec_Add1.Size = new System.Drawing.Size(71, 16);
            this.opt_Rec_Add1.TabIndex = 53;
            this.opt_Rec_Add1.Text = "회원주소";
            this.opt_Rec_Add1.UseVisualStyleBackColor = true;
            this.opt_Rec_Add1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.opt_Rec_Add1_MouseUp);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(361, 957);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 13);
            this.label26.TabIndex = 187;
            this.label26.Text = "배송사_선택";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label26.Visible = false;
            // 
            // txt_Base_Rec_Code
            // 
            this.txt_Base_Rec_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Base_Rec_Code.Location = new System.Drawing.Point(429, 951);
            this.txt_Base_Rec_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Base_Rec_Code.MaxLength = 30;
            this.txt_Base_Rec_Code.Name = "txt_Base_Rec_Code";
            this.txt_Base_Rec_Code.Size = new System.Drawing.Size(77, 22);
            this.txt_Base_Rec_Code.TabIndex = 188;
            this.txt_Base_Rec_Code.Visible = false;
            // 
            // txt_Base_Rec
            // 
            this.txt_Base_Rec.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Base_Rec.Location = new System.Drawing.Point(429, 951);
            this.txt_Base_Rec.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Base_Rec.MaxLength = 30;
            this.txt_Base_Rec.Name = "txt_Base_Rec";
            this.txt_Base_Rec.Size = new System.Drawing.Size(148, 22);
            this.txt_Base_Rec.TabIndex = 16;
            this.txt_Base_Rec.TabStop = false;
            this.txt_Base_Rec.Tag = "ncode";
            this.txt_Base_Rec.Visible = false;
            this.txt_Base_Rec.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Base_Rec.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Base_Rec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            // 
            // txt_Pass_Number
            // 
            this.txt_Pass_Number.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Pass_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_Pass_Number.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Pass_Number.MaxLength = 30;
            this.txt_Pass_Number.Name = "txt_Pass_Number";
            this.txt_Pass_Number.Size = new System.Drawing.Size(194, 22);
            this.txt_Pass_Number.TabIndex = 15;
            this.txt_Pass_Number.TabStop = false;
            this.txt_Pass_Number.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Pass_Number.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Pass_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(521, 925);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(28, 15);
            this.label25.TabIndex = 185;
            this.label25.Text = "운송장번호";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label25.Visible = false;
            // 
            // txtGetDate1
            // 
            this.txtGetDate1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtGetDate1.Location = new System.Drawing.Point(431, 926);
            this.txtGetDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGetDate1.MaxLength = 8;
            this.txtGetDate1.Name = "txtGetDate1";
            this.txtGetDate1.Size = new System.Drawing.Size(68, 22);
            this.txtGetDate1.TabIndex = 14;
            this.txtGetDate1.TabStop = false;
            this.txtGetDate1.Tag = "1";
            this.txtGetDate1.Visible = false;
            this.txtGetDate1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtGetDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtGetDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(367, 929);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 13);
            this.label17.TabIndex = 183;
            this.label17.Text = "배송_일자";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label17.Visible = false;
            // 
            // butt_AddCode
            // 
            this.butt_AddCode.BackColor = System.Drawing.Color.White;
            this.butt_AddCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_AddCode.Location = new System.Drawing.Point(94, 1);
            this.butt_AddCode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_AddCode.Name = "butt_AddCode";
            this.butt_AddCode.Size = new System.Drawing.Size(75, 26);
            this.butt_AddCode.TabIndex = 11;
            this.butt_AddCode.TabStop = false;
            this.butt_AddCode.Text = "우편_번호";
            this.butt_AddCode.UseVisualStyleBackColor = false;
            this.butt_AddCode.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtAddress2.Location = new System.Drawing.Point(3, 3);
            this.txtAddress2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtAddress2.MaxLength = 50;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(483, 22);
            this.txtAddress2.TabIndex = 13;
            this.txtAddress2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtAddress2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtAddress1
            // 
            this.txtAddress1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtAddress1.Location = new System.Drawing.Point(3, 3);
            this.txtAddress1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtAddress1.MaxLength = 50;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(348, 22);
            this.txtAddress1.TabIndex = 12;
            this.txtAddress1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtAddress1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txt_Get_Etc1
            // 
            this.txt_Get_Etc1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Get_Etc1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Get_Etc1.Location = new System.Drawing.Point(3, 3);
            this.txt_Get_Etc1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Get_Etc1.MaxLength = 100;
            this.txt_Get_Etc1.Name = "txt_Get_Etc1";
            this.txt_Get_Etc1.Size = new System.Drawing.Size(317, 22);
            this.txt_Get_Etc1.TabIndex = 17;
            this.txt_Get_Etc1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Get_Etc1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Get_Etc1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Get_Etc1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txt_Get_Name1
            // 
            this.txt_Get_Name1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Get_Name1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Get_Name1.Location = new System.Drawing.Point(3, 3);
            this.txt_Get_Name1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Get_Name1.MaxLength = 30;
            this.txt_Get_Name1.Name = "txt_Get_Name1";
            this.txt_Get_Name1.Size = new System.Drawing.Size(164, 22);
            this.txt_Get_Name1.TabIndex = 2;
            this.txt_Get_Name1.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Get_Name1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Get_Name1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Get_Name1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_GetDate1
            // 
            this.DTP_GetDate1.Location = new System.Drawing.Point(500, 928);
            this.DTP_GetDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_GetDate1.Name = "DTP_GetDate1";
            this.DTP_GetDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_GetDate1.TabIndex = 112;
            this.DTP_GetDate1.TabStop = false;
            this.DTP_GetDate1.Visible = false;
            this.DTP_GetDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // txt_Receive_Method_Code
            // 
            this.txt_Receive_Method_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txt_Receive_Method_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Receive_Method_Code.ForeColor = System.Drawing.Color.White;
            this.txt_Receive_Method_Code.Location = new System.Drawing.Point(130, 3);
            this.txt_Receive_Method_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Receive_Method_Code.MaxLength = 30;
            this.txt_Receive_Method_Code.Name = "txt_Receive_Method_Code";
            this.txt_Receive_Method_Code.Size = new System.Drawing.Size(37, 22);
            this.txt_Receive_Method_Code.TabIndex = 106;
            this.txt_Receive_Method_Code.TabStop = false;
            // 
            // txt_Receive_Method
            // 
            this.txt_Receive_Method.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Receive_Method.Location = new System.Drawing.Point(3, 3);
            this.txt_Receive_Method.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Receive_Method.MaxLength = 30;
            this.txt_Receive_Method.Name = "txt_Receive_Method";
            this.txt_Receive_Method.Size = new System.Drawing.Size(126, 22);
            this.txt_Receive_Method.TabIndex = 0;
            this.txt_Receive_Method.Tag = "ncode";
            this.txt_Receive_Method.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_Receive_Method.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Receive_Method.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Receive_Method.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // dGridView_Base_Rece_Item
            // 
            this.dGridView_Base_Rece_Item.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Rece_Item.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Rece_Item.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dGridView_Base_Rece_Item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Rece_Item.DefaultCellStyle = dataGridViewCellStyle22;
            this.dGridView_Base_Rece_Item.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Rece_Item.Location = new System.Drawing.Point(0, 27);
            this.dGridView_Base_Rece_Item.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Rece_Item.Name = "dGridView_Base_Rece_Item";
            this.dGridView_Base_Rece_Item.RowTemplate.Height = 23;
            this.dGridView_Base_Rece_Item.Size = new System.Drawing.Size(137, 121);
            this.dGridView_Base_Rece_Item.TabIndex = 153;
            this.dGridView_Base_Rece_Item.TabStop = false;
            this.dGridView_Base_Rece_Item.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGridView_Base_2_CellClick);
            // 
            // dGridView_Base_Rece_Add
            // 
            this.dGridView_Base_Rece_Add.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Rece_Add.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Rece_Add.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dGridView_Base_Rece_Add.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Rece_Add.DefaultCellStyle = dataGridViewCellStyle24;
            this.dGridView_Base_Rece_Add.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Rece_Add.Location = new System.Drawing.Point(511, 976);
            this.dGridView_Base_Rece_Add.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Rece_Add.Name = "dGridView_Base_Rece_Add";
            this.dGridView_Base_Rece_Add.RowTemplate.Height = 23;
            this.dGridView_Base_Rece_Add.Size = new System.Drawing.Size(169, 191);
            this.dGridView_Base_Rece_Add.TabIndex = 154;
            this.dGridView_Base_Rece_Add.Visible = false;
            this.dGridView_Base_Rece_Add.DoubleClick += new System.EventHandler(this.dGridView_Base_Rece_Add_DoubleClick);
            this.dGridView_Base_Rece_Add.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dGridView_KeyDown);
            // 
            // txt_SOrd
            // 
            this.txt_SOrd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_SOrd.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_SOrd.Location = new System.Drawing.Point(3, 3);
            this.txt_SOrd.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SOrd.MaxLength = 30;
            this.txt_SOrd.Name = "txt_SOrd";
            this.txt_SOrd.Size = new System.Drawing.Size(164, 22);
            this.txt_SOrd.TabIndex = 14;
            this.txt_SOrd.TabStop = false;
            this.txt_SOrd.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_SOrd.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_SOrd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_SOrd_KeyPress);
            this.txt_SOrd.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dGridView_Base_Item);
            this.groupBox7.Controls.Add(this.panel38);
            this.groupBox7.Controls.Add(this.panel3);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox7.Font = new System.Drawing.Font("굴림", 9F);
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(423, 418);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "상품_내역";
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.tableLayoutPanel15);
            this.panel38.Controls.Add(this.tableLayoutPanel11);
            this.panel38.Controls.Add(this.tableLayoutPanel14);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel38.Location = new System.Drawing.Point(3, 373);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(417, 42);
            this.panel38.TabIndex = 152;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.panel41, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(203, 40);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(206, 36);
            this.tableLayoutPanel15.TabIndex = 200;
            this.tableLayoutPanel15.Visible = false;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Controls.Add(this.txt_SumCnt);
            this.panel41.Location = new System.Drawing.Point(126, 4);
            this.panel41.Margin = new System.Windows.Forms.Padding(2);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(76, 28);
            this.panel41.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 32);
            this.label6.TabIndex = 0;
            this.label6.Text = "수량합";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.panel39, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(155, 36);
            this.tableLayoutPanel11.TabIndex = 198;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.White;
            this.panel39.Controls.Add(this.txt_SumPr);
            this.panel39.Location = new System.Drawing.Point(75, 4);
            this.panel39.Margin = new System.Windows.Forms.Padding(2);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(76, 28);
            this.panel39.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 32);
            this.label3.TabIndex = 0;
            this.label3.Text = "금액합";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.panel40, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(156, 3);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(258, 36);
            this.tableLayoutPanel14.TabIndex = 199;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.White;
            this.panel40.Controls.Add(this.txt_SumCV);
            this.panel40.Controls.Add(this.txt_SumPV);
            this.panel40.Location = new System.Drawing.Point(126, 4);
            this.panel40.Margin = new System.Windows.Forms.Padding(2);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(128, 28);
            this.panel40.TabIndex = 15;
            // 
            // txt_SumCV
            // 
            this.txt_SumCV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumCV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumCV.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumCV.ForeColor = System.Drawing.Color.Red;
            this.txt_SumCV.Location = new System.Drawing.Point(62, 3);
            this.txt_SumCV.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumCV.MaxLength = 30;
            this.txt_SumCV.Name = "txt_SumCV";
            this.txt_SumCV.ReadOnly = true;
            this.txt_SumCV.Size = new System.Drawing.Size(64, 21);
            this.txt_SumCV.TabIndex = 175;
            this.txt_SumCV.TabStop = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "PV / BV 합";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel_Cacu);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox3.Location = new System.Drawing.Point(423, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(895, 418);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "결제_내역";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dGridView_Base_Rece);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(274, 630);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1532, 360);
            this.groupBox1.TabIndex = 400;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "배송_내역";
            // 
            // dGridView_Base_Rece
            // 
            this.dGridView_Base_Rece.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Rece.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Rece.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dGridView_Base_Rece.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Rece.DefaultCellStyle = dataGridViewCellStyle26;
            this.dGridView_Base_Rece.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base_Rece.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Rece.Location = new System.Drawing.Point(3, 271);
            this.dGridView_Base_Rece.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Rece.Name = "dGridView_Base_Rece";
            this.dGridView_Base_Rece.RowTemplate.Height = 23;
            this.dGridView_Base_Rece.Size = new System.Drawing.Size(1526, 86);
            this.dGridView_Base_Rece.TabIndex = 185;
            this.dGridView_Base_Rece.TabStop = false;
            this.dGridView_Base_Rece.DoubleClick += new System.EventHandler(this.dGridView_Base_Sub_DoubleClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.pan_Rec_Item);
            this.panel2.Controls.Add(this.opt_Rec_Add3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1526, 254);
            this.panel2.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableLayoutPanel77);
            this.panel4.Controls.Add(this.tableLayoutPanel34);
            this.panel4.Controls.Add(this.tableLayoutPanel35);
            this.panel4.Controls.Add(this.butt_Rec_Save);
            this.panel4.Controls.Add(this.tableLayoutPanel37);
            this.panel4.Controls.Add(this.butt_Rec_Clear);
            this.panel4.Controls.Add(this.butt_Rec_Add);
            this.panel4.Controls.Add(this.tableLayoutPanel42);
            this.panel4.Controls.Add(this.butt_Rec_Del);
            this.panel4.Controls.Add(this.tableLayoutPanel41);
            this.panel4.Controls.Add(this.txt_RecIndex);
            this.panel4.Controls.Add(this.tableLayoutPanel40);
            this.panel4.Controls.Add(this.tableLayoutPanel39);
            this.panel4.Controls.Add(this.tableLayoutPanel36);
            this.panel4.Controls.Add(this.tableLayoutPanel38);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(203, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(853, 254);
            this.panel4.TabIndex = 197;
            // 
            // tableLayoutPanel77
            // 
            this.tableLayoutPanel77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel77.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel77.ColumnCount = 2;
            this.tableLayoutPanel77.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel77.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel77.Controls.Add(this.label90, 0, 0);
            this.tableLayoutPanel77.Controls.Add(this.panel92, 1, 0);
            this.tableLayoutPanel77.Location = new System.Drawing.Point(454, 185);
            this.tableLayoutPanel77.Name = "tableLayoutPanel77";
            this.tableLayoutPanel77.RowCount = 1;
            this.tableLayoutPanel77.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel77.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel77.Size = new System.Drawing.Size(330, 37);
            this.tableLayoutPanel77.TabIndex = 197;
            // 
            // label90
            // 
            this.label90.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label90.ForeColor = System.Drawing.Color.White;
            this.label90.Location = new System.Drawing.Point(2, 2);
            this.label90.Margin = new System.Windows.Forms.Padding(0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(120, 33);
            this.label90.TabIndex = 0;
            this.label90.Text = "운송장번호";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel92
            // 
            this.panel92.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel92.BackColor = System.Drawing.Color.White;
            this.panel92.Controls.Add(this.txt_Pass_Number);
            this.panel92.Location = new System.Drawing.Point(126, 4);
            this.panel92.Margin = new System.Windows.Forms.Padding(2);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(200, 29);
            this.panel92.TabIndex = 15;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel34.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Controls.Add(this.panel68, 1, 0);
            this.tableLayoutPanel34.Controls.Add(this.label47, 0, 0);
            this.tableLayoutPanel34.Location = new System.Drawing.Point(0, 2);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel34.TabIndex = 0;
            // 
            // panel68
            // 
            this.panel68.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel68.BackColor = System.Drawing.Color.White;
            this.panel68.Controls.Add(this.txt_Receive_Method);
            this.panel68.Controls.Add(this.txt_Receive_Method_Code);
            this.panel68.Location = new System.Drawing.Point(126, 4);
            this.panel68.Margin = new System.Windows.Forms.Padding(2);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(170, 28);
            this.panel68.TabIndex = 15;
            // 
            // label47
            // 
            this.label47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(2, 2);
            this.label47.Margin = new System.Windows.Forms.Padding(0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(120, 32);
            this.label47.TabIndex = 0;
            this.label47.Text = "배송_구분";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel35.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel35.ColumnCount = 2;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel35.Controls.Add(this.panel21, 1, 0);
            this.tableLayoutPanel35.Location = new System.Drawing.Point(0, 185);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(453, 37);
            this.tableLayoutPanel35.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(2, 2);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 33);
            this.label15.TabIndex = 0;
            this.label15.Text = "비고";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel21
            // 
            this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Controls.Add(this.txt_Get_Etc1);
            this.panel21.Location = new System.Drawing.Point(126, 4);
            this.panel21.Margin = new System.Windows.Forms.Padding(2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(323, 29);
            this.panel21.TabIndex = 15;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel37.ColumnCount = 2;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel37.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel37.Location = new System.Drawing.Point(0, 147);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(619, 37);
            this.tableLayoutPanel37.TabIndex = 6;
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(2, 2);
            this.label31.Margin = new System.Windows.Forms.Padding(0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(120, 33);
            this.label31.TabIndex = 0;
            this.label31.Text = "주소2";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.txtAddress2);
            this.panel19.Location = new System.Drawing.Point(126, 4);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(489, 29);
            this.panel19.TabIndex = 15;
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel42.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel42.Controls.Add(this.panel20, 1, 0);
            this.tableLayoutPanel42.Location = new System.Drawing.Point(301, 109);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 1;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(484, 37);
            this.tableLayoutPanel42.TabIndex = 5;
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(2, 2);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 33);
            this.label33.TabIndex = 0;
            this.label33.Text = "주소1";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel20
            // 
            this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Controls.Add(this.txtAddress1);
            this.panel20.Location = new System.Drawing.Point(126, 4);
            this.panel20.Margin = new System.Windows.Forms.Padding(2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(354, 29);
            this.panel20.TabIndex = 15;
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel41.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel41.ColumnCount = 2;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.Controls.Add(this.panel73, 1, 0);
            this.tableLayoutPanel41.Controls.Add(this.label59, 0, 0);
            this.tableLayoutPanel41.Location = new System.Drawing.Point(0, 110);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 1;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel41.TabIndex = 4;
            // 
            // panel73
            // 
            this.panel73.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel73.BackColor = System.Drawing.Color.White;
            this.panel73.Controls.Add(this.mtxtZip1);
            this.panel73.Controls.Add(this.butt_AddCode);
            this.panel73.Location = new System.Drawing.Point(126, 4);
            this.panel73.Margin = new System.Windows.Forms.Padding(2);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(170, 28);
            this.panel73.TabIndex = 15;
            // 
            // mtxtZip1
            // 
            this.mtxtZip1.Location = new System.Drawing.Point(3, 3);
            this.mtxtZip1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtZip1.Name = "mtxtZip1";
            this.mtxtZip1.Size = new System.Drawing.Size(90, 21);
            this.mtxtZip1.TabIndex = 45;
            this.mtxtZip1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtZip1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtZip1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label59
            // 
            this.label59.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(2, 2);
            this.label59.Margin = new System.Windows.Forms.Padding(0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(120, 32);
            this.label59.TabIndex = 0;
            this.label59.Text = "우편번호";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel40.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel40.ColumnCount = 2;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.Controls.Add(this.panel72, 1, 0);
            this.tableLayoutPanel40.Controls.Add(this.label58, 0, 0);
            this.tableLayoutPanel40.Location = new System.Drawing.Point(227, 74);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 1;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(227, 36);
            this.tableLayoutPanel40.TabIndex = 3;
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.White;
            this.panel72.Controls.Add(this.mtxtTel2);
            this.panel72.Location = new System.Drawing.Point(126, 4);
            this.panel72.Margin = new System.Windows.Forms.Padding(2);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(97, 28);
            this.panel72.TabIndex = 15;
            // 
            // mtxtTel2
            // 
            this.mtxtTel2.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel2.Name = "mtxtTel2";
            this.mtxtTel2.Size = new System.Drawing.Size(91, 21);
            this.mtxtTel2.TabIndex = 13;
            this.mtxtTel2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtTel2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtTel2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label58
            // 
            this.label58.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label58.ForeColor = System.Drawing.Color.White;
            this.label58.Location = new System.Drawing.Point(2, 2);
            this.label58.Margin = new System.Windows.Forms.Padding(0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(120, 32);
            this.label58.TabIndex = 0;
            this.label58.Text = "연락처2";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel39.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.Controls.Add(this.panel71, 1, 0);
            this.tableLayoutPanel39.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel39.Location = new System.Drawing.Point(0, 74);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 1;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(227, 36);
            this.tableLayoutPanel39.TabIndex = 2;
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.Color.White;
            this.panel71.Controls.Add(this.mtxtTel1);
            this.panel71.Location = new System.Drawing.Point(126, 4);
            this.panel71.Margin = new System.Windows.Forms.Padding(2);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(97, 28);
            this.panel71.TabIndex = 15;
            // 
            // mtxtTel1
            // 
            this.mtxtTel1.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel1.Name = "mtxtTel1";
            this.mtxtTel1.Size = new System.Drawing.Size(91, 21);
            this.mtxtTel1.TabIndex = 12;
            this.mtxtTel1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtTel1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtTel1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label57
            // 
            this.label57.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label57.ForeColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(2, 2);
            this.label57.Margin = new System.Windows.Forms.Padding(0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(120, 32);
            this.label57.TabIndex = 0;
            this.label57.Text = "연락처1";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel36.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.panel69, 1, 0);
            this.tableLayoutPanel36.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel36.Location = new System.Drawing.Point(301, 2);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(317, 71);
            this.tableLayoutPanel36.TabIndex = 196;
            // 
            // panel69
            // 
            this.panel69.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel69.BackColor = System.Drawing.Color.White;
            this.panel69.Controls.Add(this.opt_Rec_Add2);
            this.panel69.Controls.Add(this.opt_Rec_Add1);
            this.panel69.Location = new System.Drawing.Point(126, 4);
            this.panel69.Margin = new System.Windows.Forms.Padding(2);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(187, 63);
            this.panel69.TabIndex = 15;
            // 
            // label49
            // 
            this.label49.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(2, 2);
            this.label49.Margin = new System.Windows.Forms.Padding(0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(120, 67);
            this.label49.TabIndex = 0;
            this.label49.Text = "배송지";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.panel70, 1, 0);
            this.tableLayoutPanel38.Controls.Add(this.label53, 0, 0);
            this.tableLayoutPanel38.Location = new System.Drawing.Point(0, 38);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel38.TabIndex = 1;
            // 
            // panel70
            // 
            this.panel70.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel70.BackColor = System.Drawing.Color.White;
            this.panel70.Controls.Add(this.txt_Get_Name1);
            this.panel70.Location = new System.Drawing.Point(126, 4);
            this.panel70.Margin = new System.Windows.Forms.Padding(2);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(170, 28);
            this.panel70.TabIndex = 15;
            // 
            // label53
            // 
            this.label53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(2, 2);
            this.label53.Margin = new System.Windows.Forms.Padding(0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(120, 32);
            this.label53.TabIndex = 0;
            this.label53.Text = "수령인명";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pan_Rec_Item
            // 
            this.pan_Rec_Item.Controls.Add(this.dGridView_Base_Rece_Item);
            this.pan_Rec_Item.Controls.Add(this.panel15);
            this.pan_Rec_Item.Dock = System.Windows.Forms.DockStyle.Left;
            this.pan_Rec_Item.Location = new System.Drawing.Point(0, 0);
            this.pan_Rec_Item.Name = "pan_Rec_Item";
            this.pan_Rec_Item.Size = new System.Drawing.Size(203, 254);
            this.pan_Rec_Item.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.chk_Total);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(203, 27);
            this.panel15.TabIndex = 0;
            // 
            // chk_Total
            // 
            this.chk_Total.AutoSize = true;
            this.chk_Total.Location = new System.Drawing.Point(13, 3);
            this.chk_Total.Name = "chk_Total";
            this.chk_Total.Size = new System.Drawing.Size(78, 16);
            this.chk_Total.TabIndex = 0;
            this.chk_Total.TabStop = false;
            this.chk_Total.Text = "전체_체크";
            this.chk_Total.UseVisualStyleBackColor = true;
            this.chk_Total.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chk_Total_MouseClick);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dGridView_Base);
            this.panel5.Controls.Add(this.panel29);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 28);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1806, 184);
            this.panel5.TabIndex = 0;
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.tableLayoutPanel75);
            this.panel29.Controls.Add(this.tableLayoutPanel61);
            this.panel29.Controls.Add(this.tableLayoutPanel62);
            this.panel29.Controls.Add(this.tableLayoutPanel64);
            this.panel29.Controls.Add(this.tableLayoutPanel63);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(306, 182);
            this.panel29.TabIndex = 0;
            // 
            // tableLayoutPanel75
            // 
            this.tableLayoutPanel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel75.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel75.ColumnCount = 2;
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel75.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel75.Controls.Add(this.panel89, 1, 0);
            this.tableLayoutPanel75.Controls.Add(this.label85, 0, 0);
            this.tableLayoutPanel75.Location = new System.Drawing.Point(3, 146);
            this.tableLayoutPanel75.Name = "tableLayoutPanel75";
            this.tableLayoutPanel75.RowCount = 1;
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel75.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel75.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel75.TabIndex = 173;
            // 
            // panel89
            // 
            this.panel89.BackColor = System.Drawing.Color.White;
            this.panel89.Controls.Add(this.txt_Tel);
            this.panel89.Location = new System.Drawing.Point(126, 4);
            this.panel89.Margin = new System.Windows.Forms.Padding(2);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(170, 28);
            this.panel89.TabIndex = 15;
            // 
            // txt_Tel
            // 
            this.txt_Tel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Tel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Tel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Tel.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_Tel.ForeColor = System.Drawing.Color.IndianRed;
            this.txt_Tel.Location = new System.Drawing.Point(3, 4);
            this.txt_Tel.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Tel.MaxLength = 30;
            this.txt_Tel.Name = "txt_Tel";
            this.txt_Tel.ReadOnly = true;
            this.txt_Tel.Size = new System.Drawing.Size(165, 21);
            this.txt_Tel.TabIndex = 165;
            this.txt_Tel.TabStop = false;
            // 
            // label85
            // 
            this.label85.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label85.ForeColor = System.Drawing.Color.White;
            this.label85.Location = new System.Drawing.Point(2, 2);
            this.label85.Margin = new System.Windows.Forms.Padding(0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(120, 32);
            this.label85.TabIndex = 0;
            this.label85.Text = "연락처";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel61
            // 
            this.tableLayoutPanel61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel61.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel61.ColumnCount = 2;
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel61.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel61.Controls.Add(this.panel24, 1, 0);
            this.tableLayoutPanel61.Controls.Add(this.label64, 0, 0);
            this.tableLayoutPanel61.Location = new System.Drawing.Point(3, 2);
            this.tableLayoutPanel61.Name = "tableLayoutPanel61";
            this.tableLayoutPanel61.RowCount = 1;
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel61.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel61.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel61.TabIndex = 0;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Controls.Add(this.mtxtMbid);
            this.panel24.Location = new System.Drawing.Point(126, 4);
            this.panel24.Margin = new System.Windows.Forms.Padding(2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(170, 28);
            this.panel24.TabIndex = 15;
            // 
            // label64
            // 
            this.label64.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(2, 2);
            this.label64.Margin = new System.Windows.Forms.Padding(0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(120, 32);
            this.label64.TabIndex = 0;
            this.label64.Text = "회원_번호";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel62
            // 
            this.tableLayoutPanel62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel62.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel62.ColumnCount = 2;
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.Controls.Add(this.panel25, 1, 0);
            this.tableLayoutPanel62.Controls.Add(this.label65, 0, 0);
            this.tableLayoutPanel62.Location = new System.Drawing.Point(3, 38);
            this.tableLayoutPanel62.Name = "tableLayoutPanel62";
            this.tableLayoutPanel62.RowCount = 1;
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel62.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel62.TabIndex = 1;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Controls.Add(this.txtName);
            this.panel25.Location = new System.Drawing.Point(126, 4);
            this.panel25.Margin = new System.Windows.Forms.Padding(2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(170, 28);
            this.panel25.TabIndex = 15;
            // 
            // label65
            // 
            this.label65.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label65.ForeColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(2, 2);
            this.label65.Margin = new System.Windows.Forms.Padding(0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(120, 32);
            this.label65.TabIndex = 0;
            this.label65.Text = "성명";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel64
            // 
            this.tableLayoutPanel64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel64.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel64.ColumnCount = 2;
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel64.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel64.Controls.Add(this.panel27, 1, 0);
            this.tableLayoutPanel64.Controls.Add(this.label67, 0, 0);
            this.tableLayoutPanel64.Location = new System.Drawing.Point(3, 112);
            this.tableLayoutPanel64.Name = "tableLayoutPanel64";
            this.tableLayoutPanel64.RowCount = 1;
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel64.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel64.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel64.TabIndex = 172;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Controls.Add(this.txtCenter);
            this.panel27.Controls.Add(this.txtCenter_Code);
            this.panel27.Location = new System.Drawing.Point(126, 4);
            this.panel27.Margin = new System.Windows.Forms.Padding(2);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(170, 28);
            this.panel27.TabIndex = 15;
            // 
            // label67
            // 
            this.label67.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label67.ForeColor = System.Drawing.Color.White;
            this.label67.Location = new System.Drawing.Point(2, 2);
            this.label67.Margin = new System.Windows.Forms.Padding(0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(120, 32);
            this.label67.TabIndex = 0;
            this.label67.Text = "센타";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel63
            // 
            this.tableLayoutPanel63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel63.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel63.ColumnCount = 2;
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel63.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel63.Controls.Add(this.panel26, 1, 0);
            this.tableLayoutPanel63.Controls.Add(this.label66, 0, 0);
            this.tableLayoutPanel63.Location = new System.Drawing.Point(3, 75);
            this.tableLayoutPanel63.Name = "tableLayoutPanel63";
            this.tableLayoutPanel63.RowCount = 1;
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel63.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel63.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel63.TabIndex = 171;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.mtxtSn);
            this.panel26.Location = new System.Drawing.Point(126, 4);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(170, 28);
            this.panel26.TabIndex = 15;
            // 
            // label66
            // 
            this.label66.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label66.ForeColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(2, 2);
            this.label66.Margin = new System.Windows.Forms.Padding(0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(120, 32);
            this.label66.TabIndex = 0;
            this.label66.Text = "주민번호";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel65
            // 
            this.tableLayoutPanel65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel65.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel65.ColumnCount = 2;
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel65.Controls.Add(this.panel28, 1, 0);
            this.tableLayoutPanel65.Controls.Add(this.label68, 0, 0);
            this.tableLayoutPanel65.Location = new System.Drawing.Point(5, 612);
            this.tableLayoutPanel65.Name = "tableLayoutPanel65";
            this.tableLayoutPanel65.RowCount = 1;
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel65.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel65.TabIndex = 173;
            this.tableLayoutPanel65.Visible = false;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Controls.Add(this.txt_SOrd);
            this.panel28.Location = new System.Drawing.Point(126, 4);
            this.panel28.Margin = new System.Windows.Forms.Padding(2);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(170, 28);
            this.panel28.TabIndex = 15;
            // 
            // label68
            // 
            this.label68.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label68.ForeColor = System.Drawing.Color.White;
            this.label68.Location = new System.Drawing.Point(2, 2);
            this.label68.Margin = new System.Windows.Forms.Padding(0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(120, 32);
            this.label68.TabIndex = 0;
            this.label68.Text = "주문번호_검색";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.tableLayoutPanel58);
            this.panel8.Controls.Add(this.tableLayoutPanel47);
            this.panel8.Controls.Add(this.tableLayoutPanel44);
            this.panel8.Controls.Add(this.tableLayoutPanel6);
            this.panel8.Controls.Add(this.tableLayoutPanel65);
            this.panel8.Controls.Add(this.tableLayoutPanel68);
            this.panel8.Controls.Add(this.tableLayoutPanel67);
            this.panel8.Controls.Add(this.tableLayoutPanel66);
            this.panel8.Controls.Add(this.tableLayoutPanel56);
            this.panel8.Controls.Add(this.tableLayoutPanel5);
            this.panel8.Controls.Add(this.tableLayoutPanel4);
            this.panel8.Controls.Add(this.tableLayoutPanel3);
            this.panel8.Controls.Add(this.tableLayoutPanel1);
            this.panel8.Controls.Add(this.butt_Print);
            this.panel8.Controls.Add(this.butt_Ord_Clear);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 212);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(274, 957);
            this.panel8.TabIndex = 1;
            // 
            // tableLayoutPanel58
            // 
            this.tableLayoutPanel58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel58.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel58.ColumnCount = 2;
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel58.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel58.Controls.Add(this.panel79, 1, 0);
            this.tableLayoutPanel58.Controls.Add(this.label79, 0, 0);
            this.tableLayoutPanel58.Location = new System.Drawing.Point(2, 32);
            this.tableLayoutPanel58.Name = "tableLayoutPanel58";
            this.tableLayoutPanel58.RowCount = 1;
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel58.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel58.Size = new System.Drawing.Size(268, 36);
            this.tableLayoutPanel58.TabIndex = 200;
            // 
            // panel79
            // 
            this.panel79.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel79.BackColor = System.Drawing.Color.White;
            this.panel79.Controls.Add(this.radioB_CALL);
            this.panel79.Controls.Add(this.radioB_DESK);
            this.panel79.Location = new System.Drawing.Point(126, 4);
            this.panel79.Margin = new System.Windows.Forms.Padding(2);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(138, 28);
            this.panel79.TabIndex = 15;
            // 
            // radioB_CALL
            // 
            this.radioB_CALL.AutoSize = true;
            this.radioB_CALL.Location = new System.Drawing.Point(80, 6);
            this.radioB_CALL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_CALL.Name = "radioB_CALL";
            this.radioB_CALL.Size = new System.Drawing.Size(47, 16);
            this.radioB_CALL.TabIndex = 57;
            this.radioB_CALL.Text = "전화";
            this.radioB_CALL.UseVisualStyleBackColor = true;
            // 
            // radioB_DESK
            // 
            this.radioB_DESK.AutoSize = true;
            this.radioB_DESK.Checked = true;
            this.radioB_DESK.Location = new System.Drawing.Point(4, 6);
            this.radioB_DESK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_DESK.Name = "radioB_DESK";
            this.radioB_DESK.Size = new System.Drawing.Size(59, 16);
            this.radioB_DESK.TabIndex = 56;
            this.radioB_DESK.TabStop = true;
            this.radioB_DESK.Text = "데스크";
            this.radioB_DESK.UseVisualStyleBackColor = true;
            // 
            // label79
            // 
            this.label79.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label79.ForeColor = System.Drawing.Color.White;
            this.label79.Location = new System.Drawing.Point(2, 2);
            this.label79.Margin = new System.Windows.Forms.Padding(0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(120, 32);
            this.label79.TabIndex = 0;
            this.label79.Text = "주문_구분";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel47
            // 
            this.tableLayoutPanel47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel47.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel47.ColumnCount = 2;
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.Controls.Add(this.panel76, 1, 0);
            this.tableLayoutPanel47.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel47.Location = new System.Drawing.Point(2, 297);
            this.tableLayoutPanel47.Name = "tableLayoutPanel47";
            this.tableLayoutPanel47.RowCount = 1;
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel47.Size = new System.Drawing.Size(268, 36);
            this.tableLayoutPanel47.TabIndex = 199;
            // 
            // panel76
            // 
            this.panel76.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel76.BackColor = System.Drawing.Color.White;
            this.panel76.Controls.Add(this.txt_InputPass_Pay);
            this.panel76.Location = new System.Drawing.Point(126, 4);
            this.panel76.Margin = new System.Windows.Forms.Padding(2);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(138, 28);
            this.panel76.TabIndex = 15;
            // 
            // txt_InputPass_Pay
            // 
            this.txt_InputPass_Pay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_InputPass_Pay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_InputPass_Pay.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_InputPass_Pay.Location = new System.Drawing.Point(3, 3);
            this.txt_InputPass_Pay.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_InputPass_Pay.MaxLength = 5;
            this.txt_InputPass_Pay.Name = "txt_InputPass_Pay";
            this.txt_InputPass_Pay.ReadOnly = true;
            this.txt_InputPass_Pay.Size = new System.Drawing.Size(132, 22);
            this.txt_InputPass_Pay.TabIndex = 0;
            this.txt_InputPass_Pay.Tag = "2";
            this.txt_InputPass_Pay.TextChanged += new System.EventHandler(this.txt_InputPass_Pay_TextChanged);
            this.txt_InputPass_Pay.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_InputPass_Pay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_InputPass_Pay.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(2, 2);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 32);
            this.label36.TabIndex = 0;
            this.label36.Text = "배송비";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel44.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel44.ColumnCount = 2;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.Controls.Add(this.panel23, 1, 0);
            this.tableLayoutPanel44.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel44.Location = new System.Drawing.Point(7, 659);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 1;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel44.TabIndex = 198;
            this.tableLayoutPanel44.Visible = false;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.txt_TotalCV);
            this.panel23.Location = new System.Drawing.Point(126, 4);
            this.panel23.Margin = new System.Windows.Forms.Padding(2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(170, 28);
            this.panel23.TabIndex = 15;
            // 
            // txt_TotalCV
            // 
            this.txt_TotalCV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_TotalCV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_TotalCV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TotalCV.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_TotalCV.Location = new System.Drawing.Point(3, 4);
            this.txt_TotalCV.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_TotalCV.MaxLength = 30;
            this.txt_TotalCV.Name = "txt_TotalCV";
            this.txt_TotalCV.ReadOnly = true;
            this.txt_TotalCV.Size = new System.Drawing.Size(164, 21);
            this.txt_TotalCV.TabIndex = 166;
            this.txt_TotalCV.TabStop = false;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(2, 2);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(120, 32);
            this.label29.TabIndex = 0;
            this.label29.Text = "총CV";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.panel7, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 533);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel6.TabIndex = 197;
            this.tableLayoutPanel6.Visible = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.txt_TotalPrice);
            this.panel7.Location = new System.Drawing.Point(126, 4);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(170, 28);
            this.panel7.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(2, 2);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 32);
            this.label4.TabIndex = 0;
            this.label4.Text = "구매액";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel68
            // 
            this.tableLayoutPanel68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel68.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel68.ColumnCount = 2;
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel68.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel68.Controls.Add(this.panel36, 1, 0);
            this.tableLayoutPanel68.Controls.Add(this.label71, 0, 0);
            this.tableLayoutPanel68.Location = new System.Drawing.Point(2, 389);
            this.tableLayoutPanel68.Name = "tableLayoutPanel68";
            this.tableLayoutPanel68.RowCount = 1;
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel68.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel68.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel68.TabIndex = 196;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.White;
            this.panel36.Controls.Add(this.txt_Ins_Number);
            this.panel36.Location = new System.Drawing.Point(126, 4);
            this.panel36.Margin = new System.Windows.Forms.Padding(2);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(140, 28);
            this.panel36.TabIndex = 15;
            // 
            // label71
            // 
            this.label71.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label71.ForeColor = System.Drawing.Color.White;
            this.label71.Location = new System.Drawing.Point(2, 2);
            this.label71.Margin = new System.Windows.Forms.Padding(0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(120, 32);
            this.label71.TabIndex = 0;
            this.label71.Text = "공제번호";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel67
            // 
            this.tableLayoutPanel67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel67.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel67.ColumnCount = 2;
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel67.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel67.Controls.Add(this.panel35, 1, 0);
            this.tableLayoutPanel67.Controls.Add(this.label70, 0, 0);
            this.tableLayoutPanel67.Location = new System.Drawing.Point(4, 570);
            this.tableLayoutPanel67.Name = "tableLayoutPanel67";
            this.tableLayoutPanel67.RowCount = 1;
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel67.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel67.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel67.TabIndex = 195;
            this.tableLayoutPanel67.Visible = false;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.txt_TotalPv);
            this.panel35.Location = new System.Drawing.Point(126, 4);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(170, 28);
            this.panel35.TabIndex = 15;
            // 
            // label70
            // 
            this.label70.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label70.ForeColor = System.Drawing.Color.White;
            this.label70.Location = new System.Drawing.Point(2, 2);
            this.label70.Margin = new System.Windows.Forms.Padding(0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(120, 32);
            this.label70.TabIndex = 0;
            this.label70.Text = "총PV";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel66
            // 
            this.tableLayoutPanel66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel66.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel66.ColumnCount = 2;
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel66.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel66.Controls.Add(this.panel34, 1, 0);
            this.tableLayoutPanel66.Controls.Add(this.label69, 0, 0);
            this.tableLayoutPanel66.Location = new System.Drawing.Point(2, 353);
            this.tableLayoutPanel66.Name = "tableLayoutPanel66";
            this.tableLayoutPanel66.RowCount = 1;
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel66.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel66.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel66.TabIndex = 194;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Controls.Add(this.txt_OrderNumber);
            this.panel34.Location = new System.Drawing.Point(126, 4);
            this.panel34.Margin = new System.Windows.Forms.Padding(2);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(140, 28);
            this.panel34.TabIndex = 15;
            // 
            // label69
            // 
            this.label69.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label69.ForeColor = System.Drawing.Color.White;
            this.label69.Location = new System.Drawing.Point(2, 2);
            this.label69.Margin = new System.Windows.Forms.Padding(0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(120, 32);
            this.label69.TabIndex = 0;
            this.label69.Text = "주문번호";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel56
            // 
            this.tableLayoutPanel56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel56.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel56.ColumnCount = 2;
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel56.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel56.Controls.Add(this.panel33, 1, 0);
            this.tableLayoutPanel56.Controls.Add(this.label52, 0, 0);
            this.tableLayoutPanel56.Location = new System.Drawing.Point(2, 202);
            this.tableLayoutPanel56.Name = "tableLayoutPanel56";
            this.tableLayoutPanel56.RowCount = 1;
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel56.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 93F));
            this.tableLayoutPanel56.Size = new System.Drawing.Size(270, 95);
            this.tableLayoutPanel56.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Controls.Add(this.txt_ETC1);
            this.panel33.Location = new System.Drawing.Point(126, 4);
            this.panel33.Margin = new System.Windows.Forms.Padding(2);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(140, 87);
            this.panel33.TabIndex = 15;
            // 
            // label52
            // 
            this.label52.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(2, 2);
            this.label52.Margin = new System.Windows.Forms.Padding(0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(120, 91);
            this.label52.TabIndex = 0;
            this.label52.Text = "비고";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.panel32, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label51, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(2, 167);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Controls.Add(this.txtCenter2_Code);
            this.panel32.Controls.Add(this.txtCenter2);
            this.panel32.Location = new System.Drawing.Point(126, 4);
            this.panel32.Margin = new System.Windows.Forms.Padding(2);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(140, 28);
            this.panel32.TabIndex = 15;
            // 
            // label51
            // 
            this.label51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(2, 2);
            this.label51.Margin = new System.Windows.Forms.Padding(0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(120, 32);
            this.label51.TabIndex = 0;
            this.label51.Text = "구매_센타";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel31, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(2, 101);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel4.TabIndex = 191;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.mtxtSellDate2);
            this.panel31.Controls.Add(this.DTP_SellDate2);
            this.panel31.Location = new System.Drawing.Point(126, 4);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(140, 28);
            this.panel31.TabIndex = 15;
            // 
            // mtxtSellDate2
            // 
            this.mtxtSellDate2.Location = new System.Drawing.Point(3, 4);
            this.mtxtSellDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate2.Name = "mtxtSellDate2";
            this.mtxtSellDate2.Size = new System.Drawing.Size(113, 21);
            this.mtxtSellDate2.TabIndex = 107;
            this.mtxtSellDate2.TabStop = false;
            this.mtxtSellDate2.TextChanged += new System.EventHandler(this.MtxtSellDate2_TextChanged);
            this.mtxtSellDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSellDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtSellDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_SellDate2
            // 
            this.DTP_SellDate2.Location = new System.Drawing.Point(116, 4);
            this.DTP_SellDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate2.Name = "DTP_SellDate2";
            this.DTP_SellDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate2.TabIndex = 105;
            this.DTP_SellDate2.TabStop = false;
            this.DTP_SellDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(2, 2);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(120, 32);
            this.label37.TabIndex = 0;
            this.label37.Text = "정산_일자";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel30, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(2, 132);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.lblSellCode_Code);
            this.panel30.Controls.Add(this.lblSellCode);
            this.panel30.Controls.Add(this.txtSellCode_Code);
            this.panel30.Controls.Add(this.txtSellCode);
            this.panel30.Location = new System.Drawing.Point(126, 4);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(140, 28);
            this.panel30.TabIndex = 15;
            // 
            // lblSellCode_Code
            // 
            this.lblSellCode_Code.AutoSize = true;
            this.lblSellCode_Code.Location = new System.Drawing.Point(61, 13);
            this.lblSellCode_Code.Name = "lblSellCode_Code";
            this.lblSellCode_Code.Size = new System.Drawing.Size(35, 12);
            this.lblSellCode_Code.TabIndex = 105;
            this.lblSellCode_Code.Text = "Code";
            this.lblSellCode_Code.Visible = false;
            // 
            // lblSellCode
            // 
            this.lblSellCode.AutoSize = true;
            this.lblSellCode.Location = new System.Drawing.Point(11, 13);
            this.lblSellCode.Name = "lblSellCode";
            this.lblSellCode.Size = new System.Drawing.Size(39, 12);
            this.lblSellCode.TabIndex = 104;
            this.lblSellCode.Text = "Name";
            this.lblSellCode.Visible = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "구매_종류";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 65);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(270, 36);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.mtxtSellDate);
            this.panel6.Controls.Add(this.DTP_SellDate);
            this.panel6.Location = new System.Drawing.Point(126, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(140, 28);
            this.panel6.TabIndex = 15;
            // 
            // mtxtSellDate
            // 
            this.mtxtSellDate.Location = new System.Drawing.Point(3, 4);
            this.mtxtSellDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate.Name = "mtxtSellDate";
            this.mtxtSellDate.Size = new System.Drawing.Size(113, 21);
            this.mtxtSellDate.TabIndex = 106;
            this.mtxtSellDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSellDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtSellDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "구매_일자";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Print
            // 
            this.butt_Print.BackColor = System.Drawing.Color.White;
            this.butt_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Print.Location = new System.Drawing.Point(2, 431);
            this.butt_Print.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Print.Name = "butt_Print";
            this.butt_Print.Size = new System.Drawing.Size(269, 29);
            this.butt_Print.TabIndex = 188;
            this.butt_Print.TabStop = false;
            this.butt_Print.Text = "거래명세서";
            this.butt_Print.UseVisualStyleBackColor = false;
            this.butt_Print.Click += new System.EventHandler(this.butt_Print_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(914, 980);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(30, 26);
            this.groupBox6.TabIndex = 1000;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "판매_내역";
            this.groupBox6.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(84, 47);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.groupBox2);
            this.panel17.Location = new System.Drawing.Point(967, 980);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(15, 39);
            this.panel17.TabIndex = 0;
            this.panel17.Visible = false;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 105F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.label55, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.txt_ETC2, 1, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(455, 81);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(456, 32);
            this.tableLayoutPanel10.TabIndex = 4;
            this.tableLayoutPanel10.Visible = false;
            // 
            // label55
            // 
            this.label55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(222)))), ((int)(((byte)(176)))));
            this.label55.Location = new System.Drawing.Point(5, 2);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(99, 28);
            this.label55.TabIndex = 12;
            this.label55.Text = "비고";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_ETC2
            // 
            this.txt_ETC2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC2.Location = new System.Drawing.Point(112, 6);
            this.txt_ETC2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_ETC2.MaxLength = 100;
            this.txt_ETC2.Name = "txt_ETC2";
            this.txt_ETC2.Size = new System.Drawing.Size(339, 22);
            this.txt_ETC2.TabIndex = 4;
            this.txt_ETC2.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_ETC2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_ETC2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_ETC2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tableLayoutPanel10);
            this.groupBox4.Location = new System.Drawing.Point(999, 982);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(18, 24);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Visible = false;
            // 
            // pane_Cash
            // 
            this.pane_Cash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pane_Cash.Location = new System.Drawing.Point(832, 980);
            this.pane_Cash.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pane_Cash.Name = "pane_Cash";
            this.pane_Cash.Size = new System.Drawing.Size(21, 21);
            this.pane_Cash.TabIndex = 5;
            this.pane_Cash.Visible = false;
            // 
            // pane_Card
            // 
            this.pane_Card.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pane_Card.Location = new System.Drawing.Point(872, 980);
            this.pane_Card.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pane_Card.Name = "pane_Card";
            this.pane_Card.Size = new System.Drawing.Size(27, 22);
            this.pane_Card.TabIndex = 7;
            this.pane_Card.Visible = false;
            // 
            // pane_Bank
            // 
            this.pane_Bank.Location = new System.Drawing.Point(789, 978);
            this.pane_Bank.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pane_Bank.Name = "pane_Bank";
            this.pane_Bank.Size = new System.Drawing.Size(24, 21);
            this.pane_Bank.TabIndex = 6;
            this.pane_Bank.Visible = false;
            // 
            // dGridView_Base_Mile
            // 
            this.dGridView_Base_Mile.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Mile.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Mile.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dGridView_Base_Mile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Mile.DefaultCellStyle = dataGridViewCellStyle28;
            this.dGridView_Base_Mile.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Mile.Location = new System.Drawing.Point(333, 978);
            this.dGridView_Base_Mile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Mile.Name = "dGridView_Base_Mile";
            this.dGridView_Base_Mile.RowTemplate.Height = 23;
            this.dGridView_Base_Mile.Size = new System.Drawing.Size(169, 191);
            this.dGridView_Base_Mile.TabIndex = 1522;
            this.dGridView_Base_Mile.Visible = false;
            // 
            // sfd
            // 
            this.sfd.FileName = "C:\\\\";
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.groupBox3);
            this.panel67.Controls.Add(this.groupBox7);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel67.Location = new System.Drawing.Point(274, 212);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(1532, 418);
            this.panel67.TabIndex = 2;
            // 
            // frmSell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(1426, 1058);
            this.ClientSize = new System.Drawing.Size(1823, 1020);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel67);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.dGridView_Base_Mile);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.pane_Bank);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.pane_Cash);
            this.Controls.Add(this.txt_Base_Rec_Code);
            this.Controls.Add(this.txt_Base_Rec);
            this.Controls.Add(this.DTP_GetDate1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.pane_Card);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.txtGetDate1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dGridView_Base_Rece_Add);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("굴림", 9F);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmSell";
            this.Text = "구매_등록_수정";
            this.Activated += new System.EventHandler(this.frmBase_Activated);
            this.Load += new System.EventHandler(this.frmBase_From_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            this.Resize += new System.EventHandler(this.frmBase_Resize);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tab_Sell.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_Item)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart_edu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Leave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Mem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Item)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel_Cacu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Cacu)).EndInit();
            this.panel66.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.tab_Cacu.ResumeLayout(false);
            this.tab_Card.ResumeLayout(false);
            this.tableLayoutPanel59.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel80.PerformLayout();
            this.tableLayoutPanel72.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.panel81.PerformLayout();
            this.tableLayoutPanel52.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.tableLayoutPanel55.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel56.PerformLayout();
            this.tableLayoutPanel57.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.tableLayoutPanel50.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.tableLayoutPanel54.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.tableLayoutPanel53.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.tableLayoutPanel51.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.tableL_CD.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.tab_Cash.ResumeLayout(false);
            this.tab_Cash.PerformLayout();
            this.tableLayoutPanel74.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel86.PerformLayout();
            this.tableLayoutPanel48.ResumeLayout(false);
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tab_Bank.ResumeLayout(false);
            this.tableLayoutPanel76.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel60.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel61.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel58.PerformLayout();
            this.tab_VA_Bank.ResumeLayout(false);
            this.tab_VA_Bank.PerformLayout();
            this.tableLayoutPanel46.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.panel75.PerformLayout();
            this.tableLayoutPanel60.ResumeLayout(false);
            this.panel82.ResumeLayout(false);
            this.panel82.PerformLayout();
            this.tableLayoutPanel70.ResumeLayout(false);
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            this.tableLayoutPanel71.ResumeLayout(false);
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.tableLayoutPanel69.ResumeLayout(false);
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.tableLayoutPanel73.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel87.PerformLayout();
            this.tableLayoutPanel49.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            this.tab_Mile.ResumeLayout(false);
            this.tableLayoutPanel32.ResumeLayout(false);
            this.panel65.ResumeLayout(false);
            this.panel65.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.panel63.ResumeLayout(false);
            this.panel63.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.tableLayoutPanel45.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.panel74.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.tableLayoutPanel18.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Item)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Add)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel77.ResumeLayout(false);
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel68.PerformLayout();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tableLayoutPanel42.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.tableLayoutPanel41.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.panel73.PerformLayout();
            this.tableLayoutPanel40.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.tableLayoutPanel39.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.tableLayoutPanel36.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.pan_Rec_Item.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.tableLayoutPanel75.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.panel89.PerformLayout();
            this.tableLayoutPanel61.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tableLayoutPanel62.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.tableLayoutPanel64.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.tableLayoutPanel63.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tableLayoutPanel65.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel58.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            this.panel79.PerformLayout();
            this.tableLayoutPanel47.ResumeLayout(false);
            this.panel76.ResumeLayout(false);
            this.panel76.PerformLayout();
            this.tableLayoutPanel44.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tableLayoutPanel68.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.tableLayoutPanel67.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.tableLayoutPanel66.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tableLayoutPanel56.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Mile)).EndInit();
            this.panel67.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button butt_Excel;
        private System.Windows.Forms.Button butt_Delete;
        private System.Windows.Forms.Button butt_Clear;
        private System.Windows.Forms.Button butt_Save;
        private System.Windows.Forms.Button butt_Exit;
        private System.Windows.Forms.MaskedTextBox mtxtSn;
        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DataGridView dGridView_Base;
        private System.Windows.Forms.TextBox txtCenter_Code;
        private System.Windows.Forms.TextBox txtCenter;
        private System.Windows.Forms.TextBox txtCenter2_Code;
        private System.Windows.Forms.TextBox txtCenter2;
        private System.Windows.Forms.TextBox txtSellCode_Code;
        private System.Windows.Forms.TextBox txtSellCode;
        private System.Windows.Forms.DateTimePicker DTP_SellDate;
        private System.Windows.Forms.Button butt_Ord_Clear;
        private System.Windows.Forms.TextBox txt_TotalPv;
        private System.Windows.Forms.TextBox txt_TotalPrice;
        private System.Windows.Forms.TextBox txt_OrderNumber;
        private System.Windows.Forms.TextBox txt_ETC1;
        private System.Windows.Forms.DataGridView dGridView_Base_Item;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txt_Item_Etc;
        private System.Windows.Forms.TextBox txt_ItemCount;
        private System.Windows.Forms.TextBox txt_ItemName;
        private System.Windows.Forms.TextBox txt_ItemCode;
        private System.Windows.Forms.Button butt_Item_Clear;
        private System.Windows.Forms.Button butt_Item_Save;
        private System.Windows.Forms.Button butt_Item_Del;
        private System.Windows.Forms.TextBox txt_SalesItemIndex;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece_Item;
        private System.Windows.Forms.TextBox txt_Receive_Method_Code;
        private System.Windows.Forms.TextBox txt_Receive_Method;
        private System.Windows.Forms.TextBox txt_Get_Name1;
        private System.Windows.Forms.TextBox txt_Get_Etc1;
        private System.Windows.Forms.TextBox txtGetDate1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button butt_AddCode;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.DateTimePicker DTP_GetDate1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_Base_Rec_Code;
        private System.Windows.Forms.TextBox txt_Base_Rec;
        private System.Windows.Forms.TextBox txt_Pass_Number;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RadioButton opt_Rec_Add2;
        private System.Windows.Forms.RadioButton opt_Rec_Add1;
        private System.Windows.Forms.Button butt_Rec_Add;
        private System.Windows.Forms.RadioButton opt_Rec_Add3;
        private System.Windows.Forms.Button butt_Rec_Del;
        private System.Windows.Forms.Button butt_Rec_Clear;
        private System.Windows.Forms.Button butt_Rec_Save;
        private System.Windows.Forms.TextBox txt_RecIndex;
        private System.Windows.Forms.TextBox txt_Price_1;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate1;
        private System.Windows.Forms.Panel panel_Cacu;
        private System.Windows.Forms.TextBox txt_C_Name_2;
        private System.Windows.Forms.TextBox txt_Price_2;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate2;
        private System.Windows.Forms.TextBox txt_C_Bank_Code_3;
        private System.Windows.Forms.TextBox txt_C_Bank_Code;
        private System.Windows.Forms.TextBox txt_C_Bank;
        private System.Windows.Forms.TextBox txt_C_Bank_Code_2;
        private System.Windows.Forms.TextBox txt_C_Card_Code;
        private System.Windows.Forms.TextBox txt_C_Name_3;
        private System.Windows.Forms.TextBox txt_Price_3;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate3;
        private System.Windows.Forms.TextBox txt_C_Card_Ap_Num;
        private System.Windows.Forms.TextBox txt_C_Card_Number;
        private System.Windows.Forms.TextBox txt_C_index;
        private System.Windows.Forms.Button butt_Cacu_Del;
        private System.Windows.Forms.Button butt_Cacu_Clear;
        private System.Windows.Forms.Button butt_Cacu_Save;
        private System.Windows.Forms.ComboBox combo_C_Card_Per;
        private System.Windows.Forms.ComboBox combo_C_Card_Month;
        private System.Windows.Forms.ComboBox combo_C_Card_Year;
        private System.Windows.Forms.TextBox txt_Price_3_2;
        private System.Windows.Forms.TextBox txt_C_Etc;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece_Add;
        private System.Windows.Forms.TextBox txt_UnaccMoney;
        private System.Windows.Forms.TextBox txt_TotalInputPrice;
        private System.Windows.Forms.TextBox txt_Ins_Number;
        private System.Windows.Forms.TabControl tab_Cacu;
        private System.Windows.Forms.TabPage tab_Card;
        private System.Windows.Forms.TabPage tab_Cash;
        private System.Windows.Forms.TabPage tab_Bank;
        private System.Windows.Forms.TabControl tab_Sell;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dGridView_Base_Cacu;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel pan_Rec_Item;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.CheckBox chk_Total;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_SumPV;
        private System.Windows.Forms.TextBox txt_SumPr;
        private System.Windows.Forms.TextBox txt_SumCnt;
        private System.Windows.Forms.TextBox txt_SumCard;
        private System.Windows.Forms.TextBox txt_SumBank;
        private System.Windows.Forms.TextBox txt_SumCash;
        private System.Windows.Forms.TextBox txt_SOrd;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Item;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Leave;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Mem;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_edu;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txt_ETC2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel pane_Cash;
        private System.Windows.Forms.Panel pane_Card;
        private System.Windows.Forms.Panel pane_Bank;
        private System.Windows.Forms.DateTimePicker DTP_SellDate2;
        private System.Windows.Forms.TextBox txt_SumMile;
        private System.Windows.Forms.DataGridView dGridView_Base_Mile;
        private System.Windows.Forms.Button butt_Print;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel64;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel63;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel62;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel61;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel65;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel68;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel67;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel66;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel56;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate2;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_C_Card;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel57;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tab_Mile;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.TextBox txt_Price_4_2;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.TextBox txt_Price_4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate4;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button butt_Mile_Search;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.MaskedTextBox mtxtTel2;
        private System.Windows.Forms.MaskedTextBox mtxtTel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.MaskedTextBox mtxtZip1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox txt_SumCV;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txt_TotalCV;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox chk_app;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button button_Ok;
        private System.Windows.Forms.TextBox txt_Sugi_TF;
        private System.Windows.Forms.TabPage tab_VA_Bank;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.TextBox txtBank;
        private System.Windows.Forms.TextBox txtBank_Code;
        private System.Windows.Forms.TextBox txt_AV_C_Number3;
        private System.Windows.Forms.Button buttonV_Cancel;
        private System.Windows.Forms.Button buttonV_Ok;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel60;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.TextBox txt_AV_C_Number1;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel70;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.TextBox txt_AV_C_Code;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel71;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.TextBox txt_Price_5;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel69;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.TextBox txt_AV_C_AppDate1;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel73;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.TextBox txt_Price_5_2;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel47;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.TextBox txt_InputPass_Pay;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel48;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txt_C_Cash_Number2;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txt_C_Cash_Send_Nu;
        private System.Windows.Forms.RadioButton radioB_C_Cash_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_C_Cash_Send_TF1;
        private System.Windows.Forms.CheckBox check_Cash;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txt_AVC_Cash_Number2;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txt_AVC_Cash_Send_Nu;
        private System.Windows.Forms.RadioButton radioB_AVC_Cash_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_AVC_Cash_Send_TF1;
        private System.Windows.Forms.CheckBox check_AVCash;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txt_C_Card_Month;
        private System.Windows.Forms.TextBox txt_C_Card_Year;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel58;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.RadioButton radioB_CALL;
        private System.Windows.Forms.RadioButton radioB_DESK;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txt_Us;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel59;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.TextBox txt_C_B_Number;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel72;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.TextBox txt_C_P_Number;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.CheckBox check_Not_Cash;
        private System.Windows.Forms.CheckBox check_Not_AVCash;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel74;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txt_C_Cash_Number2_2;
        private System.Windows.Forms.CheckBox check_Cash_Pre;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TableLayoutPanel tableL_CD;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.TextBox txt_Price_CC;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel75;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.TextBox txt_Tel;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel76;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txt_C_Bank_Number2_2;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox txt_C_Bank_Send_Nu;
        private System.Windows.Forms.RadioButton radioB_C_Bank_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_C_Bank_Send_TF1;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel77;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label lblSellCode_Code;
        private System.Windows.Forms.Label lblSellCode;
    }
}