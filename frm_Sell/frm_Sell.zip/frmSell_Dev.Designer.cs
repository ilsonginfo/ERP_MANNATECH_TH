﻿namespace MLM_Program
{
    partial class frmSell_Dev
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSell_Dev));
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Save = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.Root1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.emptySpaceItem12 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Tel = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.butt_Ord_Clear = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.txt_ETC1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.txt_InputPass_Pay = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.txt_OrderNumber = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Ins_Number = new DevExpress.XtraEditors.TextEdit();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.txt_TotalPrice = new DevExpress.XtraEditors.TextEdit();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.txt_TotalPv = new DevExpress.XtraEditors.TextEdit();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SOrd = new DevExpress.XtraEditors.TextEdit();
            this.labelControl33 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl34 = new DevExpress.XtraEditors.LabelControl();
            this.txt_TotalCV = new DevExpress.XtraEditors.TextEdit();
            this.labelControl35 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl108 = new DevExpress.XtraEditors.LabelControl();
            this.combo_C_Card_Per = new System.Windows.Forms.ComboBox();
            this.txt_C_Card_Ap_Num = new DevExpress.XtraEditors.TextEdit();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl84 = new DevExpress.XtraEditors.LabelControl();
            this.button_Cancel = new DevExpress.XtraEditors.SimpleButton();
            this.txt_C_B_Number = new DevExpress.XtraEditors.TextEdit();
            this.button_Ok = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl85 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl86 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl83 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Card_Month = new DevExpress.XtraEditors.TextEdit();
            this.labelControl81 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl82 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl80 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Card_Year = new DevExpress.XtraEditors.TextEdit();
            this.labelControl78 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl79 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Name_3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Card_Number = new DevExpress.XtraEditors.TextEdit();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Price_3_2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Price_3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.mtxtSellDate2 = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.mtxtSellDate = new System.Windows.Forms.MaskedTextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txt_SumCard = new DevExpress.XtraEditors.TextEdit();
            this.labelControl91 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl92 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SumCash = new DevExpress.XtraEditors.TextEdit();
            this.labelControl90 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl93 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SumBank = new DevExpress.XtraEditors.TextEdit();
            this.labelControl94 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl95 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SumMile = new DevExpress.XtraEditors.TextEdit();
            this.labelControl96 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl97 = new DevExpress.XtraEditors.LabelControl();
            this.txt_TotalInputPrice = new DevExpress.XtraEditors.TextEdit();
            this.labelControl100 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl101 = new DevExpress.XtraEditors.LabelControl();
            this.txt_UnaccMoney = new DevExpress.XtraEditors.TextEdit();
            this.labelControl104 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl105 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl110 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl111 = new DevExpress.XtraEditors.LabelControl();
            this.label34 = new System.Windows.Forms.Label();
            this.chk_app = new System.Windows.Forms.CheckBox();
            this.txt_Sugi_TF = new System.Windows.Forms.TextBox();
            this.butt_Cacu_Clear = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Cacu_Save = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Cacu_Del = new DevExpress.XtraEditors.SimpleButton();
            this.label6 = new System.Windows.Forms.Label();
            this.radioB_CALL = new System.Windows.Forms.RadioButton();
            this.radioB_DESK = new System.Windows.Forms.RadioButton();
            this.dGridView_Base = new System.Windows.Forms.DataGridView();
            this.dGridView_Base_Cacu = new System.Windows.Forms.DataGridView();
            this.txt_C_index = new System.Windows.Forms.TextBox();
            this.txt_SalesItemIndex = new System.Windows.Forms.TextBox();
            this.txtCenter = new System.Windows.Forms.TextBox();
            this.txtCenter_Code = new System.Windows.Forms.TextBox();
            this.txt_C_Card = new System.Windows.Forms.TextBox();
            this.butt_Print = new System.Windows.Forms.Button();
            this.combo_C_Card_Year = new System.Windows.Forms.ComboBox();
            this.combo_C_Card_Month = new System.Windows.Forms.ComboBox();
            this.txt_C_Etc = new System.Windows.Forms.TextBox();
            this.tableL_CD = new System.Windows.Forms.TableLayoutPanel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.txt_Price_CC = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtGetDate1 = new System.Windows.Forms.TextBox();
            this.txt_Base_Rec = new System.Windows.Forms.TextBox();
            this.txt_Base_Rec_Code = new System.Windows.Forms.TextBox();
            this.tab_Cacu = new System.Windows.Forms.TabControl();
            this.tab_Card = new System.Windows.Forms.TabPage();
            this.mtxtPriceDate3 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate3 = new System.Windows.Forms.DateTimePicker();
            this.txt_C_P_Number = new System.Windows.Forms.TextBox();
            this.txt_C_Card_Code = new System.Windows.Forms.TextBox();
            this.tab_Cash = new System.Windows.Forms.TabPage();
            this.mtxtPriceDate1 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Price_1 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.check_Cash_Pre = new System.Windows.Forms.CheckBox();
            this.labelControl88 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl89 = new DevExpress.XtraEditors.LabelControl();
            this.check_Not_Cash = new System.Windows.Forms.CheckBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txt_C_Cash_Number2_2 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txt_C_Cash_Send_Nu = new System.Windows.Forms.TextBox();
            this.radioB_C_Cash_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_C_Cash_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.check_Cash = new System.Windows.Forms.CheckBox();
            this.btn_CASH_OK = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl98 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl99 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Cash_Number2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl102 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl103 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl106 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl107 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl87 = new DevExpress.XtraEditors.LabelControl();
            this.tab_Bank = new System.Windows.Forms.TabPage();
            this.txt_C_Bank_Code_3 = new System.Windows.Forms.TextBox();
            this.txt_C_Bank_Code_2 = new System.Windows.Forms.TextBox();
            this.txt_C_Bank_Code = new System.Windows.Forms.TextBox();
            this.mtxtPriceDate2 = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PriceDate2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_C_Bank_Number2_2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_C_Bank_Send_Nu = new System.Windows.Forms.TextBox();
            this.radioB_C_Bank_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_C_Bank_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.labelControl113 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl114 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl115 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl125 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl126 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Bank = new DevExpress.XtraEditors.TextEdit();
            this.labelControl122 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl123 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl117 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl118 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl112 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl120 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl121 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl124 = new DevExpress.XtraEditors.LabelControl();
            this.txt_C_Name_2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl127 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl128 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Price_2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl131 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl132 = new DevExpress.XtraEditors.LabelControl();
            this.tab_VA_Bank = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.panel78 = new System.Windows.Forms.Panel();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.radioB_AVC_Cash_Send_TF2 = new System.Windows.Forms.RadioButton();
            this.radioB_AVC_Cash_Send_TF1 = new System.Windows.Forms.RadioButton();
            this.check_AVCash = new System.Windows.Forms.CheckBox();
            this.label78 = new System.Windows.Forms.Label();
            this.txt_AV_C_Number3 = new System.Windows.Forms.TextBox();
            this.txtBank_Code = new System.Windows.Forms.TextBox();
            this.txtBank = new DevExpress.XtraEditors.TextEdit();
            this.labelControl109 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl144 = new DevExpress.XtraEditors.LabelControl();
            this.txt_AV_C_Number1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl142 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl143 = new DevExpress.XtraEditors.LabelControl();
            this.label86 = new System.Windows.Forms.Label();
            this.btnGetMemberHPTel = new DevExpress.XtraEditors.SimpleButton();
            this.txt_VA_DEST_TEL = new DevExpress.XtraEditors.TextEdit();
            this.labelControl140 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl141 = new DevExpress.XtraEditors.LabelControl();
            this.txt_AV_C_Code = new DevExpress.XtraEditors.TextEdit();
            this.labelControl138 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl139 = new DevExpress.XtraEditors.LabelControl();
            this.txt_AV_C_AppDate1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl136 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl137 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Price_5 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl134 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl135 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Price_5_2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl130 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl133 = new DevExpress.XtraEditors.LabelControl();
            this.buttonV_Cancel = new DevExpress.XtraEditors.SimpleButton();
            this.buttonV_Ok = new DevExpress.XtraEditors.SimpleButton();
            this.check_Not_AVCash = new System.Windows.Forms.CheckBox();
            this.txt_AVC_Cash_Send_Nu = new System.Windows.Forms.TextBox();
            this.txt_AVC_Cash_Number2 = new System.Windows.Forms.TextBox();
            this.lblSellCode_Code = new System.Windows.Forms.Label();
            this.lblSellCode = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mtxtZip1 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtTel2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtTel1 = new System.Windows.Forms.MaskedTextBox();
            this.txt_ETC2 = new System.Windows.Forms.TextBox();
            this.txt_Receive_Method = new System.Windows.Forms.TextBox();
            this.txt_Receive_Method_Code = new System.Windows.Forms.TextBox();
            this.dGridView_Base_Rece = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chk_Total = new System.Windows.Forms.CheckBox();
            this.pan_Rec_Item = new System.Windows.Forms.Panel();
            this.dGridView_Base_Rece_Item = new System.Windows.Forms.DataGridView();
            this.panel69 = new System.Windows.Forms.Panel();
            this.opt_Rec_Add2 = new System.Windows.Forms.RadioButton();
            this.opt_Rec_Add1 = new System.Windows.Forms.RadioButton();
            this.butt_Rec_Clear = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Rec_Save = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Rec_Del = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Pass_Number = new DevExpress.XtraEditors.TextEdit();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Get_Etc1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.txtAddress2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.txtAddress1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.butt_Rec_Add = new DevExpress.XtraEditors.SimpleButton();
            this.butt_AddCode = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Get_Name1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.txt_RecIndex = new System.Windows.Forms.TextBox();
            this.dGridView_Base_Mile = new System.Windows.Forms.DataGridView();
            this.dGridView_Base_Rece_Add = new System.Windows.Forms.DataGridView();
            this.panel_Cacu = new System.Windows.Forms.Panel();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txt_SumCnt = new System.Windows.Forms.TextBox();
            this.txt_ItemCode = new System.Windows.Forms.TextBox();
            this.txt_ItemName = new System.Windows.Forms.TextBox();
            this.dGridView_Base_Item = new System.Windows.Forms.DataGridView();
            this.txt_SumCV = new DevExpress.XtraEditors.TextEdit();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SumPV = new DevExpress.XtraEditors.TextEdit();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.txt_SumPr = new DevExpress.XtraEditors.TextEdit();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.butt_Item_Clear = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Item_Save = new DevExpress.XtraEditors.SimpleButton();
            this.butt_Item_Del = new DevExpress.XtraEditors.SimpleButton();
            this.txt_ItemCount = new DevExpress.XtraEditors.TextEdit();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.txt_Item_Etc = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtSellCode_Code = new System.Windows.Forms.TextBox();
            this.txtCenter2_Code = new System.Windows.Forms.TextBox();
            this.txtSellCode = new System.Windows.Forms.TextBox();
            this.txtCenter2 = new System.Windows.Forms.TextBox();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtxtSn = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Tel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ETC1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_InputPass_Pay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_OrderNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Ins_Number.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalPrice.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalPv.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SOrd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalCV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Ap_Num.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_B_Number.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Month.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Year.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Name_3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Number.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_3_2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCard.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCash.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumBank.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumMile.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalInputPrice.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_UnaccMoney.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Cacu)).BeginInit();
            this.tableL_CD.SuspendLayout();
            this.panel88.SuspendLayout();
            this.tab_Cacu.SuspendLayout();
            this.tab_Card.SuspendLayout();
            this.tab_Cash.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Cash_Number2.Properties)).BeginInit();
            this.tab_Bank.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Bank.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Name_2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_2.Properties)).BeginInit();
            this.tab_VA_Bank.SuspendLayout();
            this.tableLayoutPanel49.SuspendLayout();
            this.panel78.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBank.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_Number1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_VA_DEST_TEL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_Code.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_AppDate1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_5_2.Properties)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece)).BeginInit();
            this.panel2.SuspendLayout();
            this.pan_Rec_Item.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Item)).BeginInit();
            this.panel69.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Pass_Number.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Get_Etc1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Get_Name1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Mile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Add)).BeginInit();
            this.panel_Cacu.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Item)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumPV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumPr.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ItemCount.Properties)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.butt_Clear);
            this.layoutControl1.Controls.Add(this.butt_Save);
            this.layoutControl1.Controls.Add(this.butt_Exit);
            this.layoutControl1.Controls.Add(this.butt_Delete);
            this.layoutControl1.Location = new System.Drawing.Point(1, 3);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.Root = this.Root;
            this.layoutControl1.Size = new System.Drawing.Size(1830, 48);
            this.layoutControl1.TabIndex = 0;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.Location = new System.Drawing.Point(12, 12);
            this.butt_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(123, 24);
            this.butt_Clear.TabIndex = 1533;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.White;
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.Location = new System.Drawing.Point(139, 12);
            this.butt_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(121, 24);
            this.butt_Save.TabIndex = 1533;
            this.butt_Save.Text = "저장";
            this.butt_Save.UseVisualStyleBackColor = false;
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(1711, 12);
            this.butt_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(107, 24);
            this.butt_Exit.TabIndex = 1533;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(264, 12);
            this.butt_Delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(131, 24);
            this.butt_Delete.TabIndex = 1533;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "주문_취소";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Visible = false;
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.Root1});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(1830, 48);
            this.Root.TextVisible = false;
            // 
            // Root1
            // 
            this.Root1.CustomizationFormText = "Root";
            this.Root1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root1.GroupBordersVisible = false;
            this.Root1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem12,
            this.layoutControlItem2,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem6});
            this.Root1.Location = new System.Drawing.Point(0, 0);
            this.Root1.Name = "Root1";
            this.Root1.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Root1.Size = new System.Drawing.Size(1810, 28);
            this.Root1.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Root1.Text = "Root";
            this.Root1.TextVisible = false;
            // 
            // emptySpaceItem12
            // 
            this.emptySpaceItem12.AllowHotTrack = false;
            this.emptySpaceItem12.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem12.Location = new System.Drawing.Point(387, 0);
            this.emptySpaceItem12.Name = "emptySpaceItem12";
            this.emptySpaceItem12.Size = new System.Drawing.Size(1312, 28);
            this.emptySpaceItem12.Text = "emptySpaceItem1";
            this.emptySpaceItem12.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.butt_Delete;
            this.layoutControlItem2.Location = new System.Drawing.Point(252, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(135, 28);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.butt_Exit;
            this.layoutControlItem4.Location = new System.Drawing.Point(1699, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(111, 28);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.butt_Save;
            this.layoutControlItem5.Location = new System.Drawing.Point(127, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(125, 28);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.butt_Clear;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(127, 28);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl1.Appearance.Options.UseBackColor = true;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Location = new System.Drawing.Point(38, 72);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(120, 32);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "회원번호";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl6.Appearance.Options.UseBackColor = true;
            this.labelControl6.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl6.Location = new System.Drawing.Point(164, 72);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(170, 32);
            this.labelControl6.TabIndex = 11;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl2.Appearance.Options.UseBackColor = true;
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl2.Location = new System.Drawing.Point(38, 110);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(120, 32);
            this.labelControl2.TabIndex = 13;
            this.labelControl2.Text = "성명";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl3.Appearance.Options.UseBackColor = true;
            this.labelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl3.Location = new System.Drawing.Point(164, 110);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(170, 32);
            this.labelControl3.TabIndex = 14;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl4.Appearance.Options.UseBackColor = true;
            this.labelControl4.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl4.Location = new System.Drawing.Point(38, 148);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(120, 32);
            this.labelControl4.TabIndex = 16;
            this.labelControl4.Text = "주민번호";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl5.Appearance.Options.UseBackColor = true;
            this.labelControl5.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl5.Location = new System.Drawing.Point(164, 148);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(170, 32);
            this.labelControl5.TabIndex = 17;
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl7.Appearance.Options.UseBackColor = true;
            this.labelControl7.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl7.Location = new System.Drawing.Point(38, 186);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(120, 32);
            this.labelControl7.TabIndex = 19;
            this.labelControl7.Text = "센타";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl8.Appearance.Options.UseBackColor = true;
            this.labelControl8.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl8.Location = new System.Drawing.Point(164, 186);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(170, 32);
            this.labelControl8.TabIndex = 20;
            // 
            // txt_Tel
            // 
            this.txt_Tel.Location = new System.Drawing.Point(167, 229);
            this.txt_Tel.Name = "txt_Tel";
            this.txt_Tel.Properties.AutoHeight = false;
            this.txt_Tel.Size = new System.Drawing.Size(164, 21);
            this.txt_Tel.TabIndex = 21;
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl9.Appearance.Options.UseBackColor = true;
            this.labelControl9.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl9.Location = new System.Drawing.Point(38, 224);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(120, 32);
            this.labelControl9.TabIndex = 22;
            this.labelControl9.Text = "연락처";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl10.Appearance.Options.UseBackColor = true;
            this.labelControl10.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl10.Location = new System.Drawing.Point(164, 224);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(170, 32);
            this.labelControl10.TabIndex = 23;
            // 
            // butt_Ord_Clear
            // 
            this.butt_Ord_Clear.Location = new System.Drawing.Point(3, 5);
            this.butt_Ord_Clear.Name = "butt_Ord_Clear";
            this.butt_Ord_Clear.Size = new System.Drawing.Size(265, 39);
            this.butt_Ord_Clear.TabIndex = 26;
            this.butt_Ord_Clear.Text = "새주문 등록";
            this.butt_Ord_Clear.Click += new System.EventHandler(this.Base_Small_Button_Click);
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl11.Appearance.Options.UseBackColor = true;
            this.labelControl11.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl11.Location = new System.Drawing.Point(3, 50);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(120, 32);
            this.labelControl11.TabIndex = 28;
            this.labelControl11.Text = "주문구분";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl12.Appearance.Options.UseBackColor = true;
            this.labelControl12.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl12.Location = new System.Drawing.Point(129, 50);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(139, 32);
            this.labelControl12.TabIndex = 29;
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl13.Appearance.Options.UseBackColor = true;
            this.labelControl13.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl13.Location = new System.Drawing.Point(3, 88);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(120, 32);
            this.labelControl13.TabIndex = 31;
            this.labelControl13.Text = "주문일자";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl14.Appearance.Options.UseBackColor = true;
            this.labelControl14.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl14.Location = new System.Drawing.Point(129, 88);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(139, 32);
            this.labelControl14.TabIndex = 32;
            // 
            // labelControl15
            // 
            this.labelControl15.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl15.Appearance.Options.UseBackColor = true;
            this.labelControl15.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl15.Location = new System.Drawing.Point(3, 126);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(120, 32);
            this.labelControl15.TabIndex = 34;
            this.labelControl15.Text = "정산일자";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl16.Appearance.Options.UseBackColor = true;
            this.labelControl16.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl16.Location = new System.Drawing.Point(129, 126);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(139, 32);
            this.labelControl16.TabIndex = 35;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl17.Appearance.Options.UseBackColor = true;
            this.labelControl17.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl17.Location = new System.Drawing.Point(3, 164);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(120, 32);
            this.labelControl17.TabIndex = 37;
            this.labelControl17.Text = "주문종류";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl18.Appearance.Options.UseBackColor = true;
            this.labelControl18.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl18.Location = new System.Drawing.Point(129, 164);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(139, 32);
            this.labelControl18.TabIndex = 38;
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl19.Appearance.Options.UseBackColor = true;
            this.labelControl19.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl19.Location = new System.Drawing.Point(3, 202);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(120, 32);
            this.labelControl19.TabIndex = 40;
            this.labelControl19.Text = "주문센타";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl20.Appearance.Options.UseBackColor = true;
            this.labelControl20.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl20.Location = new System.Drawing.Point(129, 202);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(139, 32);
            this.labelControl20.TabIndex = 41;
            // 
            // txt_ETC1
            // 
            this.txt_ETC1.Location = new System.Drawing.Point(132, 245);
            this.txt_ETC1.Name = "txt_ETC1";
            this.txt_ETC1.Properties.AutoHeight = false;
            this.txt_ETC1.Size = new System.Drawing.Size(130, 121);
            this.txt_ETC1.TabIndex = 42;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl21.Appearance.Options.UseBackColor = true;
            this.labelControl21.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl21.Location = new System.Drawing.Point(3, 240);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(120, 139);
            this.labelControl21.TabIndex = 43;
            this.labelControl21.Text = "비고";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl22.Appearance.Options.UseBackColor = true;
            this.labelControl22.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl22.Location = new System.Drawing.Point(129, 240);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(139, 139);
            this.labelControl22.TabIndex = 44;
            // 
            // txt_InputPass_Pay
            // 
            this.txt_InputPass_Pay.Location = new System.Drawing.Point(132, 390);
            this.txt_InputPass_Pay.Name = "txt_InputPass_Pay";
            this.txt_InputPass_Pay.Properties.AutoHeight = false;
            this.txt_InputPass_Pay.Size = new System.Drawing.Size(130, 21);
            this.txt_InputPass_Pay.TabIndex = 45;
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl23.Appearance.Options.UseBackColor = true;
            this.labelControl23.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl23.Location = new System.Drawing.Point(3, 385);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(120, 32);
            this.labelControl23.TabIndex = 46;
            this.labelControl23.Text = "배송비";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl24.Appearance.Options.UseBackColor = true;
            this.labelControl24.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl24.Location = new System.Drawing.Point(129, 385);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(139, 32);
            this.labelControl24.TabIndex = 47;
            // 
            // txt_OrderNumber
            // 
            this.txt_OrderNumber.Location = new System.Drawing.Point(132, 428);
            this.txt_OrderNumber.Name = "txt_OrderNumber";
            this.txt_OrderNumber.Properties.AutoHeight = false;
            this.txt_OrderNumber.Size = new System.Drawing.Size(130, 21);
            this.txt_OrderNumber.TabIndex = 48;
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl25.Appearance.Options.UseBackColor = true;
            this.labelControl25.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl25.Location = new System.Drawing.Point(3, 423);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(120, 32);
            this.labelControl25.TabIndex = 49;
            this.labelControl25.Text = "주문번호";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl26.Appearance.Options.UseBackColor = true;
            this.labelControl26.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl26.Location = new System.Drawing.Point(129, 423);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(139, 32);
            this.labelControl26.TabIndex = 50;
            // 
            // txt_Ins_Number
            // 
            this.txt_Ins_Number.Location = new System.Drawing.Point(132, 466);
            this.txt_Ins_Number.Name = "txt_Ins_Number";
            this.txt_Ins_Number.Properties.AutoHeight = false;
            this.txt_Ins_Number.Size = new System.Drawing.Size(130, 21);
            this.txt_Ins_Number.TabIndex = 51;
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl27.Appearance.Options.UseBackColor = true;
            this.labelControl27.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl27.Location = new System.Drawing.Point(3, 461);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Size = new System.Drawing.Size(120, 32);
            this.labelControl27.TabIndex = 52;
            this.labelControl27.Text = "공제번호";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl28.Appearance.Options.UseBackColor = true;
            this.labelControl28.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl28.Location = new System.Drawing.Point(129, 461);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(139, 32);
            this.labelControl28.TabIndex = 53;
            // 
            // txt_TotalPrice
            // 
            this.txt_TotalPrice.Location = new System.Drawing.Point(132, 549);
            this.txt_TotalPrice.Name = "txt_TotalPrice";
            this.txt_TotalPrice.Properties.AutoHeight = false;
            this.txt_TotalPrice.Size = new System.Drawing.Size(130, 21);
            this.txt_TotalPrice.TabIndex = 55;
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl29.Appearance.Options.UseBackColor = true;
            this.labelControl29.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl29.Location = new System.Drawing.Point(3, 544);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Size = new System.Drawing.Size(120, 32);
            this.labelControl29.TabIndex = 56;
            this.labelControl29.Text = "주문액";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl30.Appearance.Options.UseBackColor = true;
            this.labelControl30.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl30.Location = new System.Drawing.Point(129, 544);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(139, 32);
            this.labelControl30.TabIndex = 57;
            // 
            // txt_TotalPv
            // 
            this.txt_TotalPv.Location = new System.Drawing.Point(132, 587);
            this.txt_TotalPv.Name = "txt_TotalPv";
            this.txt_TotalPv.Properties.AutoHeight = false;
            this.txt_TotalPv.Size = new System.Drawing.Size(130, 21);
            this.txt_TotalPv.TabIndex = 58;
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl31.Appearance.Options.UseBackColor = true;
            this.labelControl31.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl31.Location = new System.Drawing.Point(3, 582);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(120, 32);
            this.labelControl31.TabIndex = 59;
            this.labelControl31.Text = "총PV";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl32.Appearance.Options.UseBackColor = true;
            this.labelControl32.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl32.Location = new System.Drawing.Point(129, 582);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(139, 32);
            this.labelControl32.TabIndex = 60;
            // 
            // txt_SOrd
            // 
            this.txt_SOrd.Location = new System.Drawing.Point(132, 625);
            this.txt_SOrd.Name = "txt_SOrd";
            this.txt_SOrd.Properties.AutoHeight = false;
            this.txt_SOrd.Size = new System.Drawing.Size(130, 21);
            this.txt_SOrd.TabIndex = 61;
            // 
            // labelControl33
            // 
            this.labelControl33.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl33.Appearance.Options.UseBackColor = true;
            this.labelControl33.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl33.Location = new System.Drawing.Point(3, 620);
            this.labelControl33.Name = "labelControl33";
            this.labelControl33.Size = new System.Drawing.Size(120, 32);
            this.labelControl33.TabIndex = 62;
            this.labelControl33.Text = "주문번호 검색";
            // 
            // labelControl34
            // 
            this.labelControl34.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl34.Appearance.Options.UseBackColor = true;
            this.labelControl34.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl34.Location = new System.Drawing.Point(129, 620);
            this.labelControl34.Name = "labelControl34";
            this.labelControl34.Size = new System.Drawing.Size(139, 32);
            this.labelControl34.TabIndex = 63;
            // 
            // txt_TotalCV
            // 
            this.txt_TotalCV.Location = new System.Drawing.Point(132, 663);
            this.txt_TotalCV.Name = "txt_TotalCV";
            this.txt_TotalCV.Properties.AutoHeight = false;
            this.txt_TotalCV.Size = new System.Drawing.Size(130, 21);
            this.txt_TotalCV.TabIndex = 64;
            // 
            // labelControl35
            // 
            this.labelControl35.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl35.Appearance.Options.UseBackColor = true;
            this.labelControl35.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl35.Location = new System.Drawing.Point(3, 658);
            this.labelControl35.Name = "labelControl35";
            this.labelControl35.Size = new System.Drawing.Size(120, 32);
            this.labelControl35.TabIndex = 65;
            this.labelControl35.Text = "총CV";
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl36.Appearance.Options.UseBackColor = true;
            this.labelControl36.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl36.Location = new System.Drawing.Point(129, 658);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(139, 32);
            this.labelControl36.TabIndex = 66;
            // 
            // labelControl108
            // 
            this.labelControl108.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl108.Appearance.Options.UseBackColor = true;
            this.labelControl108.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl108.Location = new System.Drawing.Point(486, 185);
            this.labelControl108.Name = "labelControl108";
            this.labelControl108.Size = new System.Drawing.Size(160, 32);
            this.labelControl108.TabIndex = 265;
            this.labelControl108.Text = "카드";
            // 
            // combo_C_Card_Per
            // 
            this.combo_C_Card_Per.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Per.FormattingEnabled = true;
            this.combo_C_Card_Per.Location = new System.Drawing.Point(406, 87);
            this.combo_C_Card_Per.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.combo_C_Card_Per.Name = "combo_C_Card_Per";
            this.combo_C_Card_Per.Size = new System.Drawing.Size(130, 21);
            this.combo_C_Card_Per.TabIndex = 263;
            // 
            // txt_C_Card_Ap_Num
            // 
            this.txt_C_Card_Ap_Num.Location = new System.Drawing.Point(135, 126);
            this.txt_C_Card_Ap_Num.Name = "txt_C_Card_Ap_Num";
            this.txt_C_Card_Ap_Num.Properties.AutoHeight = false;
            this.txt_C_Card_Ap_Num.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Card_Ap_Num.TabIndex = 261;
            // 
            // labelControl75
            // 
            this.labelControl75.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl75.Appearance.Options.UseBackColor = true;
            this.labelControl75.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl75.Location = new System.Drawing.Point(132, 121);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(139, 32);
            this.labelControl75.TabIndex = 262;
            // 
            // labelControl84
            // 
            this.labelControl84.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl84.Appearance.Options.UseBackColor = true;
            this.labelControl84.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl84.Location = new System.Drawing.Point(132, 158);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(139, 32);
            this.labelControl84.TabIndex = 260;
            // 
            // button_Cancel
            // 
            this.button_Cancel.Location = new System.Drawing.Point(96, 196);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(84, 31);
            this.button_Cancel.TabIndex = 230;
            this.button_Cancel.Text = "승인 취소";
            // 
            // txt_C_B_Number
            // 
            this.txt_C_B_Number.Location = new System.Drawing.Point(406, 163);
            this.txt_C_B_Number.Name = "txt_C_B_Number";
            this.txt_C_B_Number.Properties.AutoHeight = false;
            this.txt_C_B_Number.Size = new System.Drawing.Size(130, 21);
            this.txt_C_B_Number.TabIndex = 255;
            // 
            // button_Ok
            // 
            this.button_Ok.Location = new System.Drawing.Point(6, 196);
            this.button_Ok.Name = "button_Ok";
            this.button_Ok.Size = new System.Drawing.Size(84, 31);
            this.button_Ok.TabIndex = 229;
            this.button_Ok.Text = "카드 승인";
            // 
            // labelControl85
            // 
            this.labelControl85.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl85.Appearance.Options.UseBackColor = true;
            this.labelControl85.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl85.Location = new System.Drawing.Point(277, 158);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(120, 32);
            this.labelControl85.TabIndex = 256;
            this.labelControl85.Text = "생년월일(EX : 790301)";
            // 
            // labelControl86
            // 
            this.labelControl86.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl86.Appearance.Options.UseBackColor = true;
            this.labelControl86.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl86.Location = new System.Drawing.Point(403, 158);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(139, 32);
            this.labelControl86.TabIndex = 257;
            // 
            // labelControl83
            // 
            this.labelControl83.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl83.Appearance.Options.UseBackColor = true;
            this.labelControl83.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl83.Location = new System.Drawing.Point(6, 158);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(120, 32);
            this.labelControl83.TabIndex = 253;
            this.labelControl83.Text = "앞2자리";
            // 
            // txt_C_Card_Month
            // 
            this.txt_C_Card_Month.Location = new System.Drawing.Point(205, 87);
            this.txt_C_Card_Month.Name = "txt_C_Card_Month";
            this.txt_C_Card_Month.Properties.AutoHeight = false;
            this.txt_C_Card_Month.Size = new System.Drawing.Size(57, 21);
            this.txt_C_Card_Month.TabIndex = 250;
            // 
            // labelControl81
            // 
            this.labelControl81.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl81.Appearance.Options.UseBackColor = true;
            this.labelControl81.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl81.Location = new System.Drawing.Point(277, 120);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(120, 32);
            this.labelControl81.TabIndex = 229;
            this.labelControl81.Text = "결제일";
            // 
            // labelControl82
            // 
            this.labelControl82.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl82.Appearance.Options.UseBackColor = true;
            this.labelControl82.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl82.Location = new System.Drawing.Point(403, 120);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(139, 32);
            this.labelControl82.TabIndex = 230;
            // 
            // labelControl80
            // 
            this.labelControl80.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl80.Appearance.Options.UseBackColor = true;
            this.labelControl80.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl80.Location = new System.Drawing.Point(202, 82);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(66, 32);
            this.labelControl80.TabIndex = 251;
            // 
            // txt_C_Card_Year
            // 
            this.txt_C_Card_Year.Location = new System.Drawing.Point(136, 87);
            this.txt_C_Card_Year.Name = "txt_C_Card_Year";
            this.txt_C_Card_Year.Properties.AutoHeight = false;
            this.txt_C_Card_Year.Size = new System.Drawing.Size(57, 21);
            this.txt_C_Card_Year.TabIndex = 247;
            // 
            // labelControl78
            // 
            this.labelControl78.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl78.Appearance.Options.UseBackColor = true;
            this.labelControl78.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl78.Location = new System.Drawing.Point(6, 120);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(120, 32);
            this.labelControl78.TabIndex = 248;
            this.labelControl78.Text = "승인번호";
            // 
            // labelControl79
            // 
            this.labelControl79.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl79.Appearance.Options.UseBackColor = true;
            this.labelControl79.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl79.Location = new System.Drawing.Point(133, 82);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(66, 32);
            this.labelControl79.TabIndex = 249;
            // 
            // labelControl76
            // 
            this.labelControl76.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl76.Appearance.Options.UseBackColor = true;
            this.labelControl76.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl76.Location = new System.Drawing.Point(277, 82);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(120, 32);
            this.labelControl76.TabIndex = 245;
            this.labelControl76.Text = "할부기간";
            // 
            // labelControl77
            // 
            this.labelControl77.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl77.Appearance.Options.UseBackColor = true;
            this.labelControl77.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl77.Location = new System.Drawing.Point(403, 82);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(139, 32);
            this.labelControl77.TabIndex = 246;
            // 
            // labelControl74
            // 
            this.labelControl74.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl74.Appearance.Options.UseBackColor = true;
            this.labelControl74.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl74.Location = new System.Drawing.Point(6, 82);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(120, 32);
            this.labelControl74.TabIndex = 242;
            this.labelControl74.Text = "유효기간(년 / 월)";
            // 
            // txt_C_Name_3
            // 
            this.txt_C_Name_3.Location = new System.Drawing.Point(406, 49);
            this.txt_C_Name_3.Name = "txt_C_Name_3";
            this.txt_C_Name_3.Properties.AutoHeight = false;
            this.txt_C_Name_3.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Name_3.TabIndex = 238;
            // 
            // labelControl72
            // 
            this.labelControl72.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl72.Appearance.Options.UseBackColor = true;
            this.labelControl72.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl72.Location = new System.Drawing.Point(277, 44);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(120, 32);
            this.labelControl72.TabIndex = 239;
            this.labelControl72.Text = "소유자명";
            // 
            // labelControl73
            // 
            this.labelControl73.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl73.Appearance.Options.UseBackColor = true;
            this.labelControl73.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl73.Location = new System.Drawing.Point(403, 44);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(139, 32);
            this.labelControl73.TabIndex = 240;
            // 
            // txt_C_Card_Number
            // 
            this.txt_C_Card_Number.Location = new System.Drawing.Point(135, 49);
            this.txt_C_Card_Number.Name = "txt_C_Card_Number";
            this.txt_C_Card_Number.Properties.AutoHeight = false;
            this.txt_C_Card_Number.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Card_Number.TabIndex = 235;
            // 
            // labelControl70
            // 
            this.labelControl70.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl70.Appearance.Options.UseBackColor = true;
            this.labelControl70.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl70.Location = new System.Drawing.Point(6, 44);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(120, 32);
            this.labelControl70.TabIndex = 236;
            this.labelControl70.Text = "카드번호";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl71.Appearance.Options.UseBackColor = true;
            this.labelControl71.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl71.Location = new System.Drawing.Point(132, 44);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(139, 32);
            this.labelControl71.TabIndex = 237;
            // 
            // txt_Price_3_2
            // 
            this.txt_Price_3_2.Location = new System.Drawing.Point(406, 11);
            this.txt_Price_3_2.Name = "txt_Price_3_2";
            this.txt_Price_3_2.Properties.AutoHeight = false;
            this.txt_Price_3_2.Size = new System.Drawing.Size(130, 21);
            this.txt_Price_3_2.TabIndex = 232;
            // 
            // labelControl68
            // 
            this.labelControl68.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl68.Appearance.Options.UseBackColor = true;
            this.labelControl68.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl68.Location = new System.Drawing.Point(277, 6);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(120, 32);
            this.labelControl68.TabIndex = 233;
            this.labelControl68.Text = "승인금액";
            // 
            // labelControl69
            // 
            this.labelControl69.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl69.Appearance.Options.UseBackColor = true;
            this.labelControl69.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl69.Location = new System.Drawing.Point(403, 6);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(139, 32);
            this.labelControl69.TabIndex = 234;
            // 
            // txt_Price_3
            // 
            this.txt_Price_3.Location = new System.Drawing.Point(135, 11);
            this.txt_Price_3.Name = "txt_Price_3";
            this.txt_Price_3.Properties.AutoHeight = false;
            this.txt_Price_3.Size = new System.Drawing.Size(130, 21);
            this.txt_Price_3.TabIndex = 229;
            // 
            // labelControl66
            // 
            this.labelControl66.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl66.Appearance.Options.UseBackColor = true;
            this.labelControl66.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl66.Location = new System.Drawing.Point(6, 6);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Size = new System.Drawing.Size(120, 32);
            this.labelControl66.TabIndex = 230;
            this.labelControl66.Text = "결제액";
            // 
            // labelControl67
            // 
            this.labelControl67.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl67.Appearance.Options.UseBackColor = true;
            this.labelControl67.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl67.Location = new System.Drawing.Point(132, 6);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(139, 32);
            this.labelControl67.TabIndex = 231;
            // 
            // mtxtSellDate2
            // 
            this.mtxtSellDate2.Location = new System.Drawing.Point(132, 131);
            this.mtxtSellDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate2.Name = "mtxtSellDate2";
            this.mtxtSellDate2.Size = new System.Drawing.Size(113, 22);
            this.mtxtSellDate2.TabIndex = 287;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(245, 131);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(21, 22);
            this.dateTimePicker1.TabIndex = 286;
            this.dateTimePicker1.TabStop = false;
            // 
            // mtxtSellDate
            // 
            this.mtxtSellDate.Location = new System.Drawing.Point(132, 93);
            this.mtxtSellDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate.Name = "mtxtSellDate";
            this.mtxtSellDate.Size = new System.Drawing.Size(113, 22);
            this.mtxtSellDate.TabIndex = 289;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(245, 93);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(21, 22);
            this.dateTimePicker2.TabIndex = 288;
            this.dateTimePicker2.TabStop = false;
            // 
            // txt_SumCard
            // 
            this.txt_SumCard.Location = new System.Drawing.Point(1561, 305);
            this.txt_SumCard.Name = "txt_SumCard";
            this.txt_SumCard.Properties.AutoHeight = false;
            this.txt_SumCard.Size = new System.Drawing.Size(130, 21);
            this.txt_SumCard.TabIndex = 299;
            // 
            // labelControl91
            // 
            this.labelControl91.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl91.Appearance.Options.UseBackColor = true;
            this.labelControl91.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl91.Location = new System.Drawing.Point(1432, 300);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(120, 32);
            this.labelControl91.TabIndex = 300;
            this.labelControl91.Text = "카드";
            // 
            // labelControl92
            // 
            this.labelControl92.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl92.Appearance.Options.UseBackColor = true;
            this.labelControl92.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl92.Location = new System.Drawing.Point(1558, 300);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(139, 32);
            this.labelControl92.TabIndex = 301;
            // 
            // txt_SumCash
            // 
            this.txt_SumCash.Location = new System.Drawing.Point(1562, 343);
            this.txt_SumCash.Name = "txt_SumCash";
            this.txt_SumCash.Properties.AutoHeight = false;
            this.txt_SumCash.Size = new System.Drawing.Size(130, 21);
            this.txt_SumCash.TabIndex = 302;
            // 
            // labelControl90
            // 
            this.labelControl90.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl90.Appearance.Options.UseBackColor = true;
            this.labelControl90.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl90.Location = new System.Drawing.Point(1433, 338);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(120, 32);
            this.labelControl90.TabIndex = 303;
            this.labelControl90.Text = "현금";
            // 
            // labelControl93
            // 
            this.labelControl93.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl93.Appearance.Options.UseBackColor = true;
            this.labelControl93.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl93.Location = new System.Drawing.Point(1559, 338);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(139, 32);
            this.labelControl93.TabIndex = 304;
            // 
            // txt_SumBank
            // 
            this.txt_SumBank.Location = new System.Drawing.Point(1562, 381);
            this.txt_SumBank.Name = "txt_SumBank";
            this.txt_SumBank.Properties.AutoHeight = false;
            this.txt_SumBank.Size = new System.Drawing.Size(130, 21);
            this.txt_SumBank.TabIndex = 305;
            // 
            // labelControl94
            // 
            this.labelControl94.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl94.Appearance.Options.UseBackColor = true;
            this.labelControl94.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl94.Location = new System.Drawing.Point(1433, 376);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(120, 32);
            this.labelControl94.TabIndex = 306;
            this.labelControl94.Text = "무통장";
            // 
            // labelControl95
            // 
            this.labelControl95.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl95.Appearance.Options.UseBackColor = true;
            this.labelControl95.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl95.Location = new System.Drawing.Point(1559, 376);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(139, 32);
            this.labelControl95.TabIndex = 307;
            // 
            // txt_SumMile
            // 
            this.txt_SumMile.Location = new System.Drawing.Point(1562, 419);
            this.txt_SumMile.Name = "txt_SumMile";
            this.txt_SumMile.Properties.AutoHeight = false;
            this.txt_SumMile.Size = new System.Drawing.Size(130, 21);
            this.txt_SumMile.TabIndex = 308;
            // 
            // labelControl96
            // 
            this.labelControl96.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl96.Appearance.Options.UseBackColor = true;
            this.labelControl96.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl96.Location = new System.Drawing.Point(1433, 414);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(120, 32);
            this.labelControl96.TabIndex = 309;
            this.labelControl96.Text = "마일리지";
            // 
            // labelControl97
            // 
            this.labelControl97.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl97.Appearance.Options.UseBackColor = true;
            this.labelControl97.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl97.Location = new System.Drawing.Point(1559, 414);
            this.labelControl97.Name = "labelControl97";
            this.labelControl97.Size = new System.Drawing.Size(139, 32);
            this.labelControl97.TabIndex = 310;
            // 
            // txt_TotalInputPrice
            // 
            this.txt_TotalInputPrice.Location = new System.Drawing.Point(1562, 457);
            this.txt_TotalInputPrice.Name = "txt_TotalInputPrice";
            this.txt_TotalInputPrice.Properties.AutoHeight = false;
            this.txt_TotalInputPrice.Size = new System.Drawing.Size(130, 21);
            this.txt_TotalInputPrice.TabIndex = 311;
            // 
            // labelControl100
            // 
            this.labelControl100.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl100.Appearance.Options.UseBackColor = true;
            this.labelControl100.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl100.Location = new System.Drawing.Point(1433, 452);
            this.labelControl100.Name = "labelControl100";
            this.labelControl100.Size = new System.Drawing.Size(120, 32);
            this.labelControl100.TabIndex = 312;
            this.labelControl100.Text = "결제액";
            // 
            // labelControl101
            // 
            this.labelControl101.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl101.Appearance.Options.UseBackColor = true;
            this.labelControl101.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl101.Location = new System.Drawing.Point(1559, 452);
            this.labelControl101.Name = "labelControl101";
            this.labelControl101.Size = new System.Drawing.Size(139, 32);
            this.labelControl101.TabIndex = 313;
            // 
            // txt_UnaccMoney
            // 
            this.txt_UnaccMoney.Location = new System.Drawing.Point(1562, 495);
            this.txt_UnaccMoney.Name = "txt_UnaccMoney";
            this.txt_UnaccMoney.Properties.AutoHeight = false;
            this.txt_UnaccMoney.Size = new System.Drawing.Size(130, 21);
            this.txt_UnaccMoney.TabIndex = 314;
            // 
            // labelControl104
            // 
            this.labelControl104.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl104.Appearance.Options.UseBackColor = true;
            this.labelControl104.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl104.Location = new System.Drawing.Point(1433, 490);
            this.labelControl104.Name = "labelControl104";
            this.labelControl104.Size = new System.Drawing.Size(120, 32);
            this.labelControl104.TabIndex = 315;
            this.labelControl104.Text = "미결제";
            // 
            // labelControl105
            // 
            this.labelControl105.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl105.Appearance.Options.UseBackColor = true;
            this.labelControl105.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl105.Location = new System.Drawing.Point(1559, 490);
            this.labelControl105.Name = "labelControl105";
            this.labelControl105.Size = new System.Drawing.Size(139, 32);
            this.labelControl105.TabIndex = 316;
            // 
            // labelControl110
            // 
            this.labelControl110.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl110.Appearance.Options.UseBackColor = true;
            this.labelControl110.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl110.Location = new System.Drawing.Point(1433, 546);
            this.labelControl110.Name = "labelControl110";
            this.labelControl110.Size = new System.Drawing.Size(120, 32);
            this.labelControl110.TabIndex = 318;
            this.labelControl110.Text = "자동승인";
            // 
            // labelControl111
            // 
            this.labelControl111.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl111.Appearance.Options.UseBackColor = true;
            this.labelControl111.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl111.Location = new System.Drawing.Point(1559, 546);
            this.labelControl111.Name = "labelControl111";
            this.labelControl111.Size = new System.Drawing.Size(139, 32);
            this.labelControl111.TabIndex = 319;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.Blue;
            this.label34.Location = new System.Drawing.Point(1558, 562);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(237, 13);
            this.label34.TabIndex = 321;
            this.label34.Text = "(필수사항:카드번호,유효기간,승인금액)";
            // 
            // chk_app
            // 
            this.chk_app.AutoSize = true;
            this.chk_app.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.chk_app.ForeColor = System.Drawing.Color.Red;
            this.chk_app.Location = new System.Drawing.Point(1562, 546);
            this.chk_app.Name = "chk_app";
            this.chk_app.Size = new System.Drawing.Size(187, 16);
            this.chk_app.TabIndex = 320;
            this.chk_app.Text = "매출 저장시 카드 자동 승인";
            this.chk_app.UseVisualStyleBackColor = true;
            // 
            // txt_Sugi_TF
            // 
            this.txt_Sugi_TF.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Sugi_TF.Location = new System.Drawing.Point(1725, 521);
            this.txt_Sugi_TF.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Sugi_TF.MaxLength = 8;
            this.txt_Sugi_TF.Name = "txt_Sugi_TF";
            this.txt_Sugi_TF.Size = new System.Drawing.Size(70, 22);
            this.txt_Sugi_TF.TabIndex = 322;
            this.txt_Sugi_TF.Tag = "2";
            this.txt_Sugi_TF.Visible = false;
            // 
            // butt_Cacu_Clear
            // 
            this.butt_Cacu_Clear.Location = new System.Drawing.Point(170, 3);
            this.butt_Cacu_Clear.Name = "butt_Cacu_Clear";
            this.butt_Cacu_Clear.Size = new System.Drawing.Size(84, 31);
            this.butt_Cacu_Clear.TabIndex = 325;
            this.butt_Cacu_Clear.Text = "취소";
            // 
            // butt_Cacu_Save
            // 
            this.butt_Cacu_Save.Location = new System.Drawing.Point(80, 3);
            this.butt_Cacu_Save.Name = "butt_Cacu_Save";
            this.butt_Cacu_Save.Size = new System.Drawing.Size(84, 31);
            this.butt_Cacu_Save.TabIndex = 324;
            this.butt_Cacu_Save.Text = "추가";
            // 
            // butt_Cacu_Del
            // 
            this.butt_Cacu_Del.Location = new System.Drawing.Point(7, 3);
            this.butt_Cacu_Del.Name = "butt_Cacu_Del";
            this.butt_Cacu_Del.Size = new System.Drawing.Size(67, 31);
            this.butt_Cacu_Del.TabIndex = 323;
            this.butt_Cacu_Del.Text = "지우기";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(782, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 327;
            this.label6.Text = "결제 내역";
            // 
            // radioB_CALL
            // 
            this.radioB_CALL.AutoSize = true;
            this.radioB_CALL.Location = new System.Drawing.Point(206, 58);
            this.radioB_CALL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_CALL.Name = "radioB_CALL";
            this.radioB_CALL.Size = new System.Drawing.Size(51, 17);
            this.radioB_CALL.TabIndex = 331;
            this.radioB_CALL.Text = "전화";
            this.radioB_CALL.UseVisualStyleBackColor = true;
            // 
            // radioB_DESK
            // 
            this.radioB_DESK.AutoSize = true;
            this.radioB_DESK.Checked = true;
            this.radioB_DESK.Location = new System.Drawing.Point(130, 58);
            this.radioB_DESK.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_DESK.Name = "radioB_DESK";
            this.radioB_DESK.Size = new System.Drawing.Size(64, 17);
            this.radioB_DESK.TabIndex = 330;
            this.radioB_DESK.TabStop = true;
            this.radioB_DESK.Text = "데스크";
            this.radioB_DESK.UseVisualStyleBackColor = true;
            // 
            // dGridView_Base
            // 
            this.dGridView_Base.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridView_Base.Location = new System.Drawing.Point(342, 46);
            this.dGridView_Base.Name = "dGridView_Base";
            this.dGridView_Base.RowTemplate.Height = 23;
            this.dGridView_Base.Size = new System.Drawing.Size(1356, 189);
            this.dGridView_Base.TabIndex = 332;
            // 
            // dGridView_Base_Cacu
            // 
            this.dGridView_Base_Cacu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridView_Base_Cacu.Location = new System.Drawing.Point(781, 584);
            this.dGridView_Base_Cacu.Name = "dGridView_Base_Cacu";
            this.dGridView_Base_Cacu.RowTemplate.Height = 23;
            this.dGridView_Base_Cacu.Size = new System.Drawing.Size(917, 80);
            this.dGridView_Base_Cacu.TabIndex = 334;
            // 
            // txt_C_index
            // 
            this.txt_C_index.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_index.Location = new System.Drawing.Point(1045, 590);
            this.txt_C_index.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_C_index.MaxLength = 8;
            this.txt_C_index.Name = "txt_C_index";
            this.txt_C_index.ReadOnly = true;
            this.txt_C_index.Size = new System.Drawing.Size(51, 22);
            this.txt_C_index.TabIndex = 336;
            this.txt_C_index.TabStop = false;
            this.txt_C_index.Visible = false;
            // 
            // txt_SalesItemIndex
            // 
            this.txt_SalesItemIndex.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_SalesItemIndex.Location = new System.Drawing.Point(1102, 589);
            this.txt_SalesItemIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_SalesItemIndex.MaxLength = 8;
            this.txt_SalesItemIndex.Name = "txt_SalesItemIndex";
            this.txt_SalesItemIndex.ReadOnly = true;
            this.txt_SalesItemIndex.Size = new System.Drawing.Size(54, 22);
            this.txt_SalesItemIndex.TabIndex = 338;
            this.txt_SalesItemIndex.TabStop = false;
            this.txt_SalesItemIndex.Visible = false;
            // 
            // txtCenter
            // 
            this.txtCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCenter.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCenter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCenter.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter.Location = new System.Drawing.Point(167, 192);
            this.txtCenter.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtCenter.MaxLength = 30;
            this.txtCenter.Name = "txtCenter";
            this.txtCenter.ReadOnly = true;
            this.txtCenter.Size = new System.Drawing.Size(117, 22);
            this.txtCenter.TabIndex = 343;
            this.txtCenter.TabStop = false;
            this.txtCenter.Tag = "ncode";
            // 
            // txtCenter_Code
            // 
            this.txtCenter_Code.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCenter_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter_Code.Location = new System.Drawing.Point(284, 192);
            this.txtCenter_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter_Code.MaxLength = 30;
            this.txtCenter_Code.Name = "txtCenter_Code";
            this.txtCenter_Code.Size = new System.Drawing.Size(47, 22);
            this.txtCenter_Code.TabIndex = 344;
            this.txtCenter_Code.TabStop = false;
            // 
            // txt_C_Card
            // 
            this.txt_C_Card.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card.Location = new System.Drawing.Point(549, 192);
            this.txt_C_Card.Margin = new System.Windows.Forms.Padding(0);
            this.txt_C_Card.MaxLength = 30;
            this.txt_C_Card.Name = "txt_C_Card";
            this.txt_C_Card.Size = new System.Drawing.Size(70, 22);
            this.txt_C_Card.TabIndex = 267;
            this.txt_C_Card.Tag = "ncode";
            // 
            // butt_Print
            // 
            this.butt_Print.BackColor = System.Drawing.Color.White;
            this.butt_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Print.Location = new System.Drawing.Point(3, 500);
            this.butt_Print.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Print.Name = "butt_Print";
            this.butt_Print.Size = new System.Drawing.Size(269, 29);
            this.butt_Print.TabIndex = 346;
            this.butt_Print.TabStop = false;
            this.butt_Print.Text = "거래명세서";
            this.butt_Print.UseVisualStyleBackColor = false;
            // 
            // combo_C_Card_Year
            // 
            this.combo_C_Card_Year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Year.FormattingEnabled = true;
            this.combo_C_Card_Year.Location = new System.Drawing.Point(163, 122);
            this.combo_C_Card_Year.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Year.Name = "combo_C_Card_Year";
            this.combo_C_Card_Year.Size = new System.Drawing.Size(59, 21);
            this.combo_C_Card_Year.TabIndex = 347;
            this.combo_C_Card_Year.TabStop = false;
            // 
            // combo_C_Card_Month
            // 
            this.combo_C_Card_Month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Month.FormattingEnabled = true;
            this.combo_C_Card_Month.Location = new System.Drawing.Point(222, 125);
            this.combo_C_Card_Month.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Month.Name = "combo_C_Card_Month";
            this.combo_C_Card_Month.Size = new System.Drawing.Size(40, 21);
            this.combo_C_Card_Month.TabIndex = 348;
            this.combo_C_Card_Month.TabStop = false;
            // 
            // txt_C_Etc
            // 
            this.txt_C_Etc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.txt_C_Etc.BackColor = System.Drawing.Color.White;
            this.txt_C_Etc.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Etc.Location = new System.Drawing.Point(1335, 584);
            this.txt_C_Etc.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Etc.MaxLength = 100;
            this.txt_C_Etc.Name = "txt_C_Etc";
            this.txt_C_Etc.Size = new System.Drawing.Size(82, 22);
            this.txt_C_Etc.TabIndex = 0;
            // 
            // tableL_CD
            // 
            this.tableL_CD.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tableL_CD.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableL_CD.ColumnCount = 2;
            this.tableL_CD.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableL_CD.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_CD.Controls.Add(this.panel88, 1, 0);
            this.tableL_CD.Controls.Add(this.label82, 0, 0);
            this.tableL_CD.Location = new System.Drawing.Point(179, 210);
            this.tableL_CD.Name = "tableL_CD";
            this.tableL_CD.RowCount = 1;
            this.tableL_CD.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_CD.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableL_CD.Size = new System.Drawing.Size(228, 36);
            this.tableL_CD.TabIndex = 349;
            this.tableL_CD.Visible = false;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.White;
            this.panel88.Controls.Add(this.txt_Price_CC);
            this.panel88.Location = new System.Drawing.Point(126, 4);
            this.panel88.Margin = new System.Windows.Forms.Padding(2);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(98, 28);
            this.panel88.TabIndex = 15;
            // 
            // txt_Price_CC
            // 
            this.txt_Price_CC.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Price_CC.Location = new System.Drawing.Point(3, 3);
            this.txt_Price_CC.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Price_CC.MaxLength = 8;
            this.txt_Price_CC.Name = "txt_Price_CC";
            this.txt_Price_CC.Size = new System.Drawing.Size(92, 22);
            this.txt_Price_CC.TabIndex = 0;
            this.txt_Price_CC.Tag = "2";
            // 
            // label82
            // 
            this.label82.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label82.BackColor = System.Drawing.Color.White;
            this.label82.ForeColor = System.Drawing.Color.White;
            this.label82.Location = new System.Drawing.Point(2, 2);
            this.label82.Margin = new System.Windows.Forms.Padding(0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(120, 32);
            this.label82.TabIndex = 0;
            this.label82.Text = "부분_취소금액";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtGetDate1
            // 
            this.txtGetDate1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtGetDate1.Location = new System.Drawing.Point(130, 372);
            this.txtGetDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtGetDate1.MaxLength = 8;
            this.txtGetDate1.Name = "txtGetDate1";
            this.txtGetDate1.Size = new System.Drawing.Size(68, 22);
            this.txtGetDate1.TabIndex = 351;
            this.txtGetDate1.TabStop = false;
            this.txtGetDate1.Tag = "1";
            this.txtGetDate1.Visible = false;
            // 
            // txt_Base_Rec
            // 
            this.txt_Base_Rec.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Base_Rec.Location = new System.Drawing.Point(135, 402);
            this.txt_Base_Rec.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Base_Rec.MaxLength = 30;
            this.txt_Base_Rec.Name = "txt_Base_Rec";
            this.txt_Base_Rec.Size = new System.Drawing.Size(148, 22);
            this.txt_Base_Rec.TabIndex = 352;
            this.txt_Base_Rec.TabStop = false;
            this.txt_Base_Rec.Tag = "ncode";
            this.txt_Base_Rec.Visible = false;
            // 
            // txt_Base_Rec_Code
            // 
            this.txt_Base_Rec_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Base_Rec_Code.Location = new System.Drawing.Point(340, 387);
            this.txt_Base_Rec_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Base_Rec_Code.MaxLength = 30;
            this.txt_Base_Rec_Code.Name = "txt_Base_Rec_Code";
            this.txt_Base_Rec_Code.Size = new System.Drawing.Size(77, 22);
            this.txt_Base_Rec_Code.TabIndex = 353;
            this.txt_Base_Rec_Code.Visible = false;
            // 
            // tab_Cacu
            // 
            this.tab_Cacu.Controls.Add(this.tab_Card);
            this.tab_Cacu.Controls.Add(this.tab_Cash);
            this.tab_Cacu.Controls.Add(this.tab_Bank);
            this.tab_Cacu.Controls.Add(this.tab_VA_Bank);
            this.tab_Cacu.Location = new System.Drawing.Point(3, 3);
            this.tab_Cacu.Name = "tab_Cacu";
            this.tab_Cacu.SelectedIndex = 0;
            this.tab_Cacu.Size = new System.Drawing.Size(643, 258);
            this.tab_Cacu.TabIndex = 354;
            // 
            // tab_Card
            // 
            this.tab_Card.Controls.Add(this.mtxtPriceDate3);
            this.tab_Card.Controls.Add(this.DTP_PriceDate3);
            this.tab_Card.Controls.Add(this.txt_C_P_Number);
            this.tab_Card.Controls.Add(this.txt_C_Card_Code);
            this.tab_Card.Controls.Add(this.tableL_CD);
            this.tab_Card.Controls.Add(this.labelControl66);
            this.tab_Card.Controls.Add(this.txt_C_Card);
            this.tab_Card.Controls.Add(this.labelControl108);
            this.tab_Card.Controls.Add(this.txt_Price_3);
            this.tab_Card.Controls.Add(this.combo_C_Card_Per);
            this.tab_Card.Controls.Add(this.txt_C_Card_Ap_Num);
            this.tab_Card.Controls.Add(this.labelControl68);
            this.tab_Card.Controls.Add(this.labelControl75);
            this.tab_Card.Controls.Add(this.txt_Price_3_2);
            this.tab_Card.Controls.Add(this.labelControl84);
            this.tab_Card.Controls.Add(this.labelControl70);
            this.tab_Card.Controls.Add(this.txt_C_Card_Number);
            this.tab_Card.Controls.Add(this.button_Cancel);
            this.tab_Card.Controls.Add(this.txt_C_B_Number);
            this.tab_Card.Controls.Add(this.labelControl72);
            this.tab_Card.Controls.Add(this.button_Ok);
            this.tab_Card.Controls.Add(this.txt_C_Name_3);
            this.tab_Card.Controls.Add(this.labelControl85);
            this.tab_Card.Controls.Add(this.labelControl74);
            this.tab_Card.Controls.Add(this.labelControl86);
            this.tab_Card.Controls.Add(this.labelControl77);
            this.tab_Card.Controls.Add(this.labelControl83);
            this.tab_Card.Controls.Add(this.labelControl76);
            this.tab_Card.Controls.Add(this.txt_C_Card_Month);
            this.tab_Card.Controls.Add(this.labelControl81);
            this.tab_Card.Controls.Add(this.labelControl78);
            this.tab_Card.Controls.Add(this.labelControl82);
            this.tab_Card.Controls.Add(this.txt_C_Card_Year);
            this.tab_Card.Controls.Add(this.labelControl80);
            this.tab_Card.Controls.Add(this.labelControl67);
            this.tab_Card.Controls.Add(this.labelControl69);
            this.tab_Card.Controls.Add(this.labelControl71);
            this.tab_Card.Controls.Add(this.labelControl73);
            this.tab_Card.Controls.Add(this.labelControl79);
            this.tab_Card.Controls.Add(this.combo_C_Card_Year);
            this.tab_Card.Controls.Add(this.combo_C_Card_Month);
            this.tab_Card.Location = new System.Drawing.Point(4, 23);
            this.tab_Card.Name = "tab_Card";
            this.tab_Card.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Card.Size = new System.Drawing.Size(635, 231);
            this.tab_Card.TabIndex = 0;
            this.tab_Card.Text = "카드";
            this.tab_Card.UseVisualStyleBackColor = true;
            // 
            // mtxtPriceDate3
            // 
            this.mtxtPriceDate3.Location = new System.Drawing.Point(407, 126);
            this.mtxtPriceDate3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate3.Name = "mtxtPriceDate3";
            this.mtxtPriceDate3.Size = new System.Drawing.Size(112, 22);
            this.mtxtPriceDate3.TabIndex = 352;
            // 
            // DTP_PriceDate3
            // 
            this.DTP_PriceDate3.Location = new System.Drawing.Point(515, 126);
            this.DTP_PriceDate3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate3.Name = "DTP_PriceDate3";
            this.DTP_PriceDate3.Size = new System.Drawing.Size(21, 22);
            this.DTP_PriceDate3.TabIndex = 353;
            this.DTP_PriceDate3.TabStop = false;
            // 
            // txt_C_P_Number
            // 
            this.txt_C_P_Number.Location = new System.Drawing.Point(136, 164);
            this.txt_C_P_Number.Name = "txt_C_P_Number";
            this.txt_C_P_Number.Size = new System.Drawing.Size(129, 22);
            this.txt_C_P_Number.TabIndex = 351;
            // 
            // txt_C_Card_Code
            // 
            this.txt_C_Card_Code.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_C_Card_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Card_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Card_Code.ForeColor = System.Drawing.Color.White;
            this.txt_C_Card_Code.Location = new System.Drawing.Point(619, 191);
            this.txt_C_Card_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Code.MaxLength = 30;
            this.txt_C_Card_Code.Name = "txt_C_Card_Code";
            this.txt_C_Card_Code.ReadOnly = true;
            this.txt_C_Card_Code.Size = new System.Drawing.Size(42, 22);
            this.txt_C_Card_Code.TabIndex = 350;
            this.txt_C_Card_Code.TabStop = false;
            // 
            // tab_Cash
            // 
            this.tab_Cash.Controls.Add(this.mtxtPriceDate1);
            this.tab_Cash.Controls.Add(this.DTP_PriceDate1);
            this.tab_Cash.Controls.Add(this.txt_Price_1);
            this.tab_Cash.Controls.Add(this.label83);
            this.tab_Cash.Controls.Add(this.check_Cash_Pre);
            this.tab_Cash.Controls.Add(this.labelControl88);
            this.tab_Cash.Controls.Add(this.labelControl89);
            this.tab_Cash.Controls.Add(this.check_Not_Cash);
            this.tab_Cash.Controls.Add(this.label62);
            this.tab_Cash.Controls.Add(this.txt_C_Cash_Number2_2);
            this.tab_Cash.Controls.Add(this.label61);
            this.tab_Cash.Controls.Add(this.txt_C_Cash_Send_Nu);
            this.tab_Cash.Controls.Add(this.radioB_C_Cash_Send_TF2);
            this.tab_Cash.Controls.Add(this.radioB_C_Cash_Send_TF1);
            this.tab_Cash.Controls.Add(this.check_Cash);
            this.tab_Cash.Controls.Add(this.btn_CASH_OK);
            this.tab_Cash.Controls.Add(this.labelControl98);
            this.tab_Cash.Controls.Add(this.labelControl99);
            this.tab_Cash.Controls.Add(this.txt_C_Cash_Number2);
            this.tab_Cash.Controls.Add(this.labelControl102);
            this.tab_Cash.Controls.Add(this.labelControl103);
            this.tab_Cash.Controls.Add(this.labelControl106);
            this.tab_Cash.Controls.Add(this.labelControl107);
            this.tab_Cash.Controls.Add(this.labelControl87);
            this.tab_Cash.Location = new System.Drawing.Point(4, 23);
            this.tab_Cash.Name = "tab_Cash";
            this.tab_Cash.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Cash.Size = new System.Drawing.Size(635, 231);
            this.tab_Cash.TabIndex = 1;
            this.tab_Cash.Text = "현금";
            this.tab_Cash.UseVisualStyleBackColor = true;
            // 
            // mtxtPriceDate1
            // 
            this.mtxtPriceDate1.Location = new System.Drawing.Point(134, 49);
            this.mtxtPriceDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate1.Name = "mtxtPriceDate1";
            this.mtxtPriceDate1.Size = new System.Drawing.Size(113, 22);
            this.mtxtPriceDate1.TabIndex = 324;
            // 
            // DTP_PriceDate1
            // 
            this.DTP_PriceDate1.Location = new System.Drawing.Point(242, 49);
            this.DTP_PriceDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate1.Name = "DTP_PriceDate1";
            this.DTP_PriceDate1.Size = new System.Drawing.Size(21, 22);
            this.DTP_PriceDate1.TabIndex = 325;
            this.DTP_PriceDate1.TabStop = false;
            // 
            // txt_Price_1
            // 
            this.txt_Price_1.Location = new System.Drawing.Point(134, 11);
            this.txt_Price_1.Name = "txt_Price_1";
            this.txt_Price_1.Size = new System.Drawing.Size(129, 22);
            this.txt_Price_1.TabIndex = 323;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(530, 155);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(131, 13);
            this.label83.TabIndex = 321;
            this.label83.Text = "현금영수증_승인번호";
            // 
            // check_Cash_Pre
            // 
            this.check_Cash_Pre.AutoSize = true;
            this.check_Cash_Pre.ForeColor = System.Drawing.Color.Red;
            this.check_Cash_Pre.Location = new System.Drawing.Point(532, 131);
            this.check_Cash_Pre.Name = "check_Cash_Pre";
            this.check_Cash_Pre.Size = new System.Drawing.Size(131, 17);
            this.check_Cash_Pre.TabIndex = 320;
            this.check_Cash_Pre.Text = "단말기_신고_처리";
            this.check_Cash_Pre.UseVisualStyleBackColor = true;
            // 
            // labelControl88
            // 
            this.labelControl88.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl88.Appearance.Options.UseBackColor = true;
            this.labelControl88.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl88.Location = new System.Drawing.Point(403, 103);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(123, 92);
            this.labelControl88.TabIndex = 318;
            this.labelControl88.Text = "카드 단말기 신고";
            // 
            // labelControl89
            // 
            this.labelControl89.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl89.Appearance.Options.UseBackColor = true;
            this.labelControl89.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl89.Location = new System.Drawing.Point(530, 108);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(268, 83);
            this.labelControl89.TabIndex = 319;
            // 
            // check_Not_Cash
            // 
            this.check_Not_Cash.AutoSize = true;
            this.check_Not_Cash.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.check_Not_Cash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.check_Not_Cash.Location = new System.Drawing.Point(404, 81);
            this.check_Not_Cash.Name = "check_Not_Cash";
            this.check_Not_Cash.Size = new System.Drawing.Size(253, 16);
            this.check_Not_Cash.TabIndex = 317;
            this.check_Not_Cash.Text = "현금영수증/세금계산서_미신고/미발행";
            this.check_Not_Cash.UseVisualStyleBackColor = true;
            this.check_Not_Cash.Visible = false;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(131, 148);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(128, 13);
            this.label62.TabIndex = 315;
            this.label62.Text = "현금영수증 인증번호";
            this.label62.Visible = false;
            // 
            // txt_C_Cash_Number2_2
            // 
            this.txt_C_Cash_Number2_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Cash_Number2_2.Location = new System.Drawing.Point(261, 144);
            this.txt_C_Cash_Number2_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Cash_Number2_2.MaxLength = 20;
            this.txt_C_Cash_Number2_2.Name = "txt_C_Cash_Number2_2";
            this.txt_C_Cash_Number2_2.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Cash_Number2_2.TabIndex = 312;
            this.txt_C_Cash_Number2_2.Tag = "1";
            this.txt_C_Cash_Number2_2.Visible = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(130, 120);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(128, 13);
            this.label61.TabIndex = 314;
            this.label61.Text = "현금영수증 신청번호";
            // 
            // txt_C_Cash_Send_Nu
            // 
            this.txt_C_Cash_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Cash_Send_Nu.Location = new System.Drawing.Point(261, 117);
            this.txt_C_Cash_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Cash_Send_Nu.MaxLength = 20;
            this.txt_C_Cash_Send_Nu.Name = "txt_C_Cash_Send_Nu";
            this.txt_C_Cash_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Cash_Send_Nu.TabIndex = 313;
            this.txt_C_Cash_Send_Nu.Tag = "1";
            // 
            // radioB_C_Cash_Send_TF2
            // 
            this.radioB_C_Cash_Send_TF2.AutoSize = true;
            this.radioB_C_Cash_Send_TF2.Location = new System.Drawing.Point(333, 97);
            this.radioB_C_Cash_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Cash_Send_TF2.Name = "radioB_C_Cash_Send_TF2";
            this.radioB_C_Cash_Send_TF2.Size = new System.Drawing.Size(64, 17);
            this.radioB_C_Cash_Send_TF2.TabIndex = 311;
            this.radioB_C_Cash_Send_TF2.Text = "사업자";
            this.radioB_C_Cash_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_C_Cash_Send_TF1
            // 
            this.radioB_C_Cash_Send_TF1.AutoSize = true;
            this.radioB_C_Cash_Send_TF1.Checked = true;
            this.radioB_C_Cash_Send_TF1.Location = new System.Drawing.Point(275, 97);
            this.radioB_C_Cash_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Cash_Send_TF1.Name = "radioB_C_Cash_Send_TF1";
            this.radioB_C_Cash_Send_TF1.Size = new System.Drawing.Size(51, 17);
            this.radioB_C_Cash_Send_TF1.TabIndex = 310;
            this.radioB_C_Cash_Send_TF1.TabStop = true;
            this.radioB_C_Cash_Send_TF1.Text = "개인";
            this.radioB_C_Cash_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // check_Cash
            // 
            this.check_Cash.AutoSize = true;
            this.check_Cash.ForeColor = System.Drawing.Color.Red;
            this.check_Cash.Location = new System.Drawing.Point(132, 96);
            this.check_Cash.Name = "check_Cash";
            this.check_Cash.Size = new System.Drawing.Size(124, 17);
            this.check_Cash.TabIndex = 309;
            this.check_Cash.Text = "현금영수증_신고";
            this.check_Cash.UseVisualStyleBackColor = true;
            // 
            // btn_CASH_OK
            // 
            this.btn_CASH_OK.Location = new System.Drawing.Point(3, 180);
            this.btn_CASH_OK.Name = "btn_CASH_OK";
            this.btn_CASH_OK.Size = new System.Drawing.Size(127, 31);
            this.btn_CASH_OK.TabIndex = 301;
            this.btn_CASH_OK.Text = "현금결제 승인";
            // 
            // labelControl98
            // 
            this.labelControl98.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl98.Appearance.Options.UseBackColor = true;
            this.labelControl98.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl98.Location = new System.Drawing.Point(3, 82);
            this.labelControl98.Name = "labelControl98";
            this.labelControl98.Size = new System.Drawing.Size(123, 92);
            this.labelControl98.TabIndex = 307;
            this.labelControl98.Text = "현금영수증";
            // 
            // labelControl99
            // 
            this.labelControl99.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl99.Appearance.Options.UseBackColor = true;
            this.labelControl99.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl99.Location = new System.Drawing.Point(130, 87);
            this.labelControl99.Name = "labelControl99";
            this.labelControl99.Size = new System.Drawing.Size(268, 83);
            this.labelControl99.TabIndex = 308;
            // 
            // txt_C_Cash_Number2
            // 
            this.txt_C_Cash_Number2.Location = new System.Drawing.Point(328, 13);
            this.txt_C_Cash_Number2.Name = "txt_C_Cash_Number2";
            this.txt_C_Cash_Number2.Properties.AutoHeight = false;
            this.txt_C_Cash_Number2.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Cash_Number2.TabIndex = 304;
            // 
            // labelControl102
            // 
            this.labelControl102.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl102.Appearance.Options.UseBackColor = true;
            this.labelControl102.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl102.Location = new System.Drawing.Point(3, 44);
            this.labelControl102.Name = "labelControl102";
            this.labelControl102.Size = new System.Drawing.Size(120, 32);
            this.labelControl102.TabIndex = 305;
            this.labelControl102.Text = "결제일";
            // 
            // labelControl103
            // 
            this.labelControl103.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl103.Appearance.Options.UseBackColor = true;
            this.labelControl103.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl103.Location = new System.Drawing.Point(129, 44);
            this.labelControl103.Name = "labelControl103";
            this.labelControl103.Size = new System.Drawing.Size(139, 32);
            this.labelControl103.TabIndex = 306;
            // 
            // labelControl106
            // 
            this.labelControl106.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl106.Appearance.Options.UseBackColor = true;
            this.labelControl106.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl106.Location = new System.Drawing.Point(3, 6);
            this.labelControl106.Name = "labelControl106";
            this.labelControl106.Size = new System.Drawing.Size(120, 32);
            this.labelControl106.TabIndex = 302;
            this.labelControl106.Text = "결제액";
            // 
            // labelControl107
            // 
            this.labelControl107.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl107.Appearance.Options.UseBackColor = true;
            this.labelControl107.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl107.Location = new System.Drawing.Point(129, 6);
            this.labelControl107.Name = "labelControl107";
            this.labelControl107.Size = new System.Drawing.Size(139, 32);
            this.labelControl107.TabIndex = 303;
            // 
            // labelControl87
            // 
            this.labelControl87.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl87.Appearance.Options.UseBackColor = true;
            this.labelControl87.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl87.Location = new System.Drawing.Point(116, 83);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(288, 91);
            this.labelControl87.TabIndex = 316;
            // 
            // tab_Bank
            // 
            this.tab_Bank.Controls.Add(this.txt_C_Bank_Code_3);
            this.tab_Bank.Controls.Add(this.txt_C_Bank_Code_2);
            this.tab_Bank.Controls.Add(this.txt_C_Bank_Code);
            this.tab_Bank.Controls.Add(this.mtxtPriceDate2);
            this.tab_Bank.Controls.Add(this.DTP_PriceDate2);
            this.tab_Bank.Controls.Add(this.label1);
            this.tab_Bank.Controls.Add(this.txt_C_Bank_Number2_2);
            this.tab_Bank.Controls.Add(this.label2);
            this.tab_Bank.Controls.Add(this.txt_C_Bank_Send_Nu);
            this.tab_Bank.Controls.Add(this.radioB_C_Bank_Send_TF2);
            this.tab_Bank.Controls.Add(this.radioB_C_Bank_Send_TF1);
            this.tab_Bank.Controls.Add(this.labelControl113);
            this.tab_Bank.Controls.Add(this.labelControl114);
            this.tab_Bank.Controls.Add(this.labelControl115);
            this.tab_Bank.Controls.Add(this.labelControl125);
            this.tab_Bank.Controls.Add(this.labelControl126);
            this.tab_Bank.Controls.Add(this.txt_C_Bank);
            this.tab_Bank.Controls.Add(this.labelControl122);
            this.tab_Bank.Controls.Add(this.labelControl123);
            this.tab_Bank.Controls.Add(this.labelControl117);
            this.tab_Bank.Controls.Add(this.labelControl118);
            this.tab_Bank.Controls.Add(this.labelControl112);
            this.tab_Bank.Controls.Add(this.labelControl120);
            this.tab_Bank.Controls.Add(this.labelControl121);
            this.tab_Bank.Controls.Add(this.labelControl124);
            this.tab_Bank.Controls.Add(this.txt_C_Name_2);
            this.tab_Bank.Controls.Add(this.labelControl127);
            this.tab_Bank.Controls.Add(this.labelControl128);
            this.tab_Bank.Controls.Add(this.txt_Price_2);
            this.tab_Bank.Controls.Add(this.labelControl131);
            this.tab_Bank.Controls.Add(this.labelControl132);
            this.tab_Bank.Location = new System.Drawing.Point(4, 23);
            this.tab_Bank.Name = "tab_Bank";
            this.tab_Bank.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Bank.Size = new System.Drawing.Size(635, 231);
            this.tab_Bank.TabIndex = 2;
            this.tab_Bank.Text = "무통장";
            this.tab_Bank.UseVisualStyleBackColor = true;
            // 
            // txt_C_Bank_Code_3
            // 
            this.txt_C_Bank_Code_3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code_3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code_3.Location = new System.Drawing.Point(135, 123);
            this.txt_C_Bank_Code_3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code_3.MaxLength = 30;
            this.txt_C_Bank_Code_3.Name = "txt_C_Bank_Code_3";
            this.txt_C_Bank_Code_3.ReadOnly = true;
            this.txt_C_Bank_Code_3.Size = new System.Drawing.Size(401, 22);
            this.txt_C_Bank_Code_3.TabIndex = 348;
            this.txt_C_Bank_Code_3.TabStop = false;
            // 
            // txt_C_Bank_Code_2
            // 
            this.txt_C_Bank_Code_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code_2.Location = new System.Drawing.Point(406, 84);
            this.txt_C_Bank_Code_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code_2.MaxLength = 30;
            this.txt_C_Bank_Code_2.Name = "txt_C_Bank_Code_2";
            this.txt_C_Bank_Code_2.ReadOnly = true;
            this.txt_C_Bank_Code_2.Size = new System.Drawing.Size(130, 22);
            this.txt_C_Bank_Code_2.TabIndex = 347;
            this.txt_C_Bank_Code_2.TabStop = false;
            // 
            // txt_C_Bank_Code
            // 
            this.txt_C_Bank_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_C_Bank_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_C_Bank_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Bank_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Code.Location = new System.Drawing.Point(135, 82);
            this.txt_C_Bank_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Code.MaxLength = 30;
            this.txt_C_Bank_Code.Name = "txt_C_Bank_Code";
            this.txt_C_Bank_Code.ReadOnly = true;
            this.txt_C_Bank_Code.Size = new System.Drawing.Size(130, 22);
            this.txt_C_Bank_Code.TabIndex = 346;
            this.txt_C_Bank_Code.TabStop = false;
            // 
            // mtxtPriceDate2
            // 
            this.mtxtPriceDate2.Location = new System.Drawing.Point(406, 8);
            this.mtxtPriceDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPriceDate2.Name = "mtxtPriceDate2";
            this.mtxtPriceDate2.Size = new System.Drawing.Size(113, 22);
            this.mtxtPriceDate2.TabIndex = 344;
            // 
            // DTP_PriceDate2
            // 
            this.DTP_PriceDate2.Location = new System.Drawing.Point(515, 8);
            this.DTP_PriceDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PriceDate2.Name = "DTP_PriceDate2";
            this.DTP_PriceDate2.Size = new System.Drawing.Size(21, 22);
            this.DTP_PriceDate2.TabIndex = 345;
            this.DTP_PriceDate2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(131, 218);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 342;
            this.label1.Text = "현금영수증 인증번호";
            this.label1.Visible = false;
            // 
            // txt_C_Bank_Number2_2
            // 
            this.txt_C_Bank_Number2_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Number2_2.Location = new System.Drawing.Point(261, 214);
            this.txt_C_Bank_Number2_2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Number2_2.MaxLength = 20;
            this.txt_C_Bank_Number2_2.Name = "txt_C_Bank_Number2_2";
            this.txt_C_Bank_Number2_2.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Bank_Number2_2.TabIndex = 339;
            this.txt_C_Bank_Number2_2.Tag = "1";
            this.txt_C_Bank_Number2_2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 13);
            this.label2.TabIndex = 341;
            this.label2.Text = "현금영수증 신청번호";
            // 
            // txt_C_Bank_Send_Nu
            // 
            this.txt_C_Bank_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_C_Bank_Send_Nu.Location = new System.Drawing.Point(261, 187);
            this.txt_C_Bank_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Bank_Send_Nu.MaxLength = 20;
            this.txt_C_Bank_Send_Nu.Name = "txt_C_Bank_Send_Nu";
            this.txt_C_Bank_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_C_Bank_Send_Nu.TabIndex = 340;
            this.txt_C_Bank_Send_Nu.Tag = "1";
            // 
            // radioB_C_Bank_Send_TF2
            // 
            this.radioB_C_Bank_Send_TF2.AutoSize = true;
            this.radioB_C_Bank_Send_TF2.Location = new System.Drawing.Point(333, 167);
            this.radioB_C_Bank_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Bank_Send_TF2.Name = "radioB_C_Bank_Send_TF2";
            this.radioB_C_Bank_Send_TF2.Size = new System.Drawing.Size(64, 17);
            this.radioB_C_Bank_Send_TF2.TabIndex = 338;
            this.radioB_C_Bank_Send_TF2.Text = "사업자";
            this.radioB_C_Bank_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_C_Bank_Send_TF1
            // 
            this.radioB_C_Bank_Send_TF1.AutoSize = true;
            this.radioB_C_Bank_Send_TF1.Checked = true;
            this.radioB_C_Bank_Send_TF1.Location = new System.Drawing.Point(275, 167);
            this.radioB_C_Bank_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_C_Bank_Send_TF1.Name = "radioB_C_Bank_Send_TF1";
            this.radioB_C_Bank_Send_TF1.Size = new System.Drawing.Size(51, 17);
            this.radioB_C_Bank_Send_TF1.TabIndex = 337;
            this.radioB_C_Bank_Send_TF1.TabStop = true;
            this.radioB_C_Bank_Send_TF1.Text = "개인";
            this.radioB_C_Bank_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // labelControl113
            // 
            this.labelControl113.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl113.Appearance.Options.UseBackColor = true;
            this.labelControl113.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl113.Location = new System.Drawing.Point(3, 152);
            this.labelControl113.Name = "labelControl113";
            this.labelControl113.Size = new System.Drawing.Size(123, 92);
            this.labelControl113.TabIndex = 335;
            this.labelControl113.Text = "현금영수증";
            // 
            // labelControl114
            // 
            this.labelControl114.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl114.Appearance.Options.UseBackColor = true;
            this.labelControl114.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl114.Location = new System.Drawing.Point(130, 157);
            this.labelControl114.Name = "labelControl114";
            this.labelControl114.Size = new System.Drawing.Size(268, 83);
            this.labelControl114.TabIndex = 336;
            // 
            // labelControl115
            // 
            this.labelControl115.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl115.Appearance.Options.UseBackColor = true;
            this.labelControl115.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl115.Location = new System.Drawing.Point(116, 153);
            this.labelControl115.Name = "labelControl115";
            this.labelControl115.Size = new System.Drawing.Size(288, 91);
            this.labelControl115.TabIndex = 343;
            // 
            // labelControl125
            // 
            this.labelControl125.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl125.Appearance.Options.UseBackColor = true;
            this.labelControl125.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl125.Location = new System.Drawing.Point(277, 79);
            this.labelControl125.Name = "labelControl125";
            this.labelControl125.Size = new System.Drawing.Size(120, 32);
            this.labelControl125.TabIndex = 333;
            this.labelControl125.Text = "회사 은행명";
            // 
            // labelControl126
            // 
            this.labelControl126.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl126.Appearance.Options.UseBackColor = true;
            this.labelControl126.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl126.Location = new System.Drawing.Point(403, 79);
            this.labelControl126.Name = "labelControl126";
            this.labelControl126.Size = new System.Drawing.Size(139, 32);
            this.labelControl126.TabIndex = 334;
            // 
            // txt_C_Bank
            // 
            this.txt_C_Bank.Location = new System.Drawing.Point(406, 46);
            this.txt_C_Bank.Name = "txt_C_Bank";
            this.txt_C_Bank.Properties.AutoHeight = false;
            this.txt_C_Bank.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Bank.TabIndex = 329;
            // 
            // labelControl122
            // 
            this.labelControl122.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl122.Appearance.Options.UseBackColor = true;
            this.labelControl122.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl122.Location = new System.Drawing.Point(277, 41);
            this.labelControl122.Name = "labelControl122";
            this.labelControl122.Size = new System.Drawing.Size(120, 32);
            this.labelControl122.TabIndex = 330;
            this.labelControl122.Text = "계좌가명";
            // 
            // labelControl123
            // 
            this.labelControl123.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl123.Appearance.Options.UseBackColor = true;
            this.labelControl123.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl123.Location = new System.Drawing.Point(403, 41);
            this.labelControl123.Name = "labelControl123";
            this.labelControl123.Size = new System.Drawing.Size(139, 32);
            this.labelControl123.TabIndex = 331;
            // 
            // labelControl117
            // 
            this.labelControl117.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl117.Appearance.Options.UseBackColor = true;
            this.labelControl117.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl117.Location = new System.Drawing.Point(277, 3);
            this.labelControl117.Name = "labelControl117";
            this.labelControl117.Size = new System.Drawing.Size(120, 32);
            this.labelControl117.TabIndex = 326;
            this.labelControl117.Text = "결제일";
            // 
            // labelControl118
            // 
            this.labelControl118.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl118.Appearance.Options.UseBackColor = true;
            this.labelControl118.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl118.Location = new System.Drawing.Point(403, 3);
            this.labelControl118.Name = "labelControl118";
            this.labelControl118.Size = new System.Drawing.Size(139, 32);
            this.labelControl118.TabIndex = 327;
            // 
            // labelControl112
            // 
            this.labelControl112.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl112.Appearance.Options.UseBackColor = true;
            this.labelControl112.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl112.Location = new System.Drawing.Point(132, 118);
            this.labelControl112.Name = "labelControl112";
            this.labelControl112.Size = new System.Drawing.Size(410, 32);
            this.labelControl112.TabIndex = 325;
            // 
            // labelControl120
            // 
            this.labelControl120.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl120.Appearance.Options.UseBackColor = true;
            this.labelControl120.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl120.Location = new System.Drawing.Point(6, 117);
            this.labelControl120.Name = "labelControl120";
            this.labelControl120.Size = new System.Drawing.Size(120, 32);
            this.labelControl120.TabIndex = 322;
            this.labelControl120.Text = "계좌번호";
            // 
            // labelControl121
            // 
            this.labelControl121.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl121.Appearance.Options.UseBackColor = true;
            this.labelControl121.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl121.Location = new System.Drawing.Point(133, 79);
            this.labelControl121.Name = "labelControl121";
            this.labelControl121.Size = new System.Drawing.Size(138, 32);
            this.labelControl121.TabIndex = 323;
            // 
            // labelControl124
            // 
            this.labelControl124.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl124.Appearance.Options.UseBackColor = true;
            this.labelControl124.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl124.Location = new System.Drawing.Point(6, 79);
            this.labelControl124.Name = "labelControl124";
            this.labelControl124.Size = new System.Drawing.Size(120, 32);
            this.labelControl124.TabIndex = 320;
            this.labelControl124.Text = "회사 은행 코드";
            // 
            // txt_C_Name_2
            // 
            this.txt_C_Name_2.Location = new System.Drawing.Point(135, 46);
            this.txt_C_Name_2.Name = "txt_C_Name_2";
            this.txt_C_Name_2.Properties.AutoHeight = false;
            this.txt_C_Name_2.Size = new System.Drawing.Size(130, 21);
            this.txt_C_Name_2.TabIndex = 317;
            // 
            // labelControl127
            // 
            this.labelControl127.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl127.Appearance.Options.UseBackColor = true;
            this.labelControl127.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl127.Location = new System.Drawing.Point(6, 41);
            this.labelControl127.Name = "labelControl127";
            this.labelControl127.Size = new System.Drawing.Size(120, 32);
            this.labelControl127.TabIndex = 318;
            this.labelControl127.Text = "입금자명";
            // 
            // labelControl128
            // 
            this.labelControl128.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl128.Appearance.Options.UseBackColor = true;
            this.labelControl128.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl128.Location = new System.Drawing.Point(132, 41);
            this.labelControl128.Name = "labelControl128";
            this.labelControl128.Size = new System.Drawing.Size(139, 32);
            this.labelControl128.TabIndex = 319;
            // 
            // txt_Price_2
            // 
            this.txt_Price_2.Location = new System.Drawing.Point(135, 8);
            this.txt_Price_2.Name = "txt_Price_2";
            this.txt_Price_2.Properties.AutoHeight = false;
            this.txt_Price_2.Size = new System.Drawing.Size(130, 21);
            this.txt_Price_2.TabIndex = 314;
            // 
            // labelControl131
            // 
            this.labelControl131.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl131.Appearance.Options.UseBackColor = true;
            this.labelControl131.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl131.Location = new System.Drawing.Point(6, 3);
            this.labelControl131.Name = "labelControl131";
            this.labelControl131.Size = new System.Drawing.Size(120, 32);
            this.labelControl131.TabIndex = 315;
            this.labelControl131.Text = "결제액";
            // 
            // labelControl132
            // 
            this.labelControl132.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl132.Appearance.Options.UseBackColor = true;
            this.labelControl132.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl132.Location = new System.Drawing.Point(132, 3);
            this.labelControl132.Name = "labelControl132";
            this.labelControl132.Size = new System.Drawing.Size(139, 32);
            this.labelControl132.TabIndex = 316;
            // 
            // tab_VA_Bank
            // 
            this.tab_VA_Bank.Controls.Add(this.tableLayoutPanel49);
            this.tab_VA_Bank.Controls.Add(this.txt_AV_C_Number3);
            this.tab_VA_Bank.Controls.Add(this.txtBank_Code);
            this.tab_VA_Bank.Controls.Add(this.txtBank);
            this.tab_VA_Bank.Controls.Add(this.labelControl109);
            this.tab_VA_Bank.Controls.Add(this.labelControl144);
            this.tab_VA_Bank.Controls.Add(this.txt_AV_C_Number1);
            this.tab_VA_Bank.Controls.Add(this.labelControl142);
            this.tab_VA_Bank.Controls.Add(this.labelControl143);
            this.tab_VA_Bank.Controls.Add(this.label86);
            this.tab_VA_Bank.Controls.Add(this.btnGetMemberHPTel);
            this.tab_VA_Bank.Controls.Add(this.txt_VA_DEST_TEL);
            this.tab_VA_Bank.Controls.Add(this.labelControl140);
            this.tab_VA_Bank.Controls.Add(this.labelControl141);
            this.tab_VA_Bank.Controls.Add(this.txt_AV_C_Code);
            this.tab_VA_Bank.Controls.Add(this.labelControl138);
            this.tab_VA_Bank.Controls.Add(this.labelControl139);
            this.tab_VA_Bank.Controls.Add(this.txt_AV_C_AppDate1);
            this.tab_VA_Bank.Controls.Add(this.labelControl136);
            this.tab_VA_Bank.Controls.Add(this.labelControl137);
            this.tab_VA_Bank.Controls.Add(this.txt_Price_5);
            this.tab_VA_Bank.Controls.Add(this.labelControl134);
            this.tab_VA_Bank.Controls.Add(this.labelControl135);
            this.tab_VA_Bank.Controls.Add(this.txt_Price_5_2);
            this.tab_VA_Bank.Controls.Add(this.labelControl130);
            this.tab_VA_Bank.Controls.Add(this.labelControl133);
            this.tab_VA_Bank.Controls.Add(this.buttonV_Cancel);
            this.tab_VA_Bank.Controls.Add(this.buttonV_Ok);
            this.tab_VA_Bank.Controls.Add(this.check_Not_AVCash);
            this.tab_VA_Bank.Location = new System.Drawing.Point(4, 23);
            this.tab_VA_Bank.Name = "tab_VA_Bank";
            this.tab_VA_Bank.Padding = new System.Windows.Forms.Padding(3);
            this.tab_VA_Bank.Size = new System.Drawing.Size(635, 231);
            this.tab_VA_Bank.TabIndex = 3;
            this.tab_VA_Bank.Text = "가상계좌";
            this.tab_VA_Bank.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel49.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel49.ColumnCount = 2;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.Controls.Add(this.panel78, 1, 0);
            this.tableLayoutPanel49.Controls.Add(this.label78, 0, 0);
            this.tableLayoutPanel49.Location = new System.Drawing.Point(3, 212);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 1;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 78F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(386, 80);
            this.tableLayoutPanel49.TabIndex = 361;
            this.tableLayoutPanel49.Visible = false;
            // 
            // panel78
            // 
            this.panel78.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel78.BackColor = System.Drawing.Color.White;
            this.panel78.Controls.Add(this.label63);
            this.panel78.Controls.Add(this.textBox1);
            this.panel78.Controls.Add(this.label76);
            this.panel78.Controls.Add(this.textBox2);
            this.panel78.Controls.Add(this.radioB_AVC_Cash_Send_TF2);
            this.panel78.Controls.Add(this.radioB_AVC_Cash_Send_TF1);
            this.panel78.Controls.Add(this.check_AVCash);
            this.panel78.Location = new System.Drawing.Point(126, 4);
            this.panel78.Margin = new System.Windows.Forms.Padding(2);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(256, 72);
            this.panel78.TabIndex = 15;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(5, 54);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(128, 13);
            this.label63.TabIndex = 177;
            this.label63.Text = "현금영수증 인증번호";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("굴림", 9F);
            this.textBox1.ForeColor = System.Drawing.Color.Red;
            this.textBox1.Location = new System.Drawing.Point(123, 49);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.textBox1.MaxLength = 30;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(128, 21);
            this.textBox1.TabIndex = 176;
            this.textBox1.TabStop = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(4, 29);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(128, 13);
            this.label76.TabIndex = 57;
            this.label76.Text = "현금영수증 신청번호";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.textBox2.Location = new System.Drawing.Point(123, 24);
            this.textBox2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.textBox2.MaxLength = 20;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(128, 22);
            this.textBox2.TabIndex = 56;
            this.textBox2.Tag = "1";
            // 
            // radioB_AVC_Cash_Send_TF2
            // 
            this.radioB_AVC_Cash_Send_TF2.AutoSize = true;
            this.radioB_AVC_Cash_Send_TF2.Location = new System.Drawing.Point(195, 4);
            this.radioB_AVC_Cash_Send_TF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_AVC_Cash_Send_TF2.Name = "radioB_AVC_Cash_Send_TF2";
            this.radioB_AVC_Cash_Send_TF2.Size = new System.Drawing.Size(64, 17);
            this.radioB_AVC_Cash_Send_TF2.TabIndex = 55;
            this.radioB_AVC_Cash_Send_TF2.Text = "사업자";
            this.radioB_AVC_Cash_Send_TF2.UseVisualStyleBackColor = true;
            // 
            // radioB_AVC_Cash_Send_TF1
            // 
            this.radioB_AVC_Cash_Send_TF1.AutoSize = true;
            this.radioB_AVC_Cash_Send_TF1.Checked = true;
            this.radioB_AVC_Cash_Send_TF1.Location = new System.Drawing.Point(137, 4);
            this.radioB_AVC_Cash_Send_TF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_AVC_Cash_Send_TF1.Name = "radioB_AVC_Cash_Send_TF1";
            this.radioB_AVC_Cash_Send_TF1.Size = new System.Drawing.Size(51, 17);
            this.radioB_AVC_Cash_Send_TF1.TabIndex = 54;
            this.radioB_AVC_Cash_Send_TF1.TabStop = true;
            this.radioB_AVC_Cash_Send_TF1.Text = "개인";
            this.radioB_AVC_Cash_Send_TF1.UseVisualStyleBackColor = true;
            // 
            // check_AVCash
            // 
            this.check_AVCash.AutoSize = true;
            this.check_AVCash.ForeColor = System.Drawing.Color.Red;
            this.check_AVCash.Location = new System.Drawing.Point(6, 5);
            this.check_AVCash.Name = "check_AVCash";
            this.check_AVCash.Size = new System.Drawing.Size(124, 17);
            this.check_AVCash.TabIndex = 0;
            this.check_AVCash.Text = "현금영수증_신고";
            this.check_AVCash.UseVisualStyleBackColor = true;
            // 
            // label78
            // 
            this.label78.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label78.ForeColor = System.Drawing.Color.White;
            this.label78.Location = new System.Drawing.Point(2, 2);
            this.label78.Margin = new System.Windows.Forms.Padding(0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(120, 76);
            this.label78.TabIndex = 0;
            this.label78.Text = "현금영수증";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_AV_C_Number3
            // 
            this.txt_AV_C_Number3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_AV_C_Number3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AV_C_Number3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AV_C_Number3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AV_C_Number3.Location = new System.Drawing.Point(310, 197);
            this.txt_AV_C_Number3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AV_C_Number3.MaxLength = 30;
            this.txt_AV_C_Number3.Name = "txt_AV_C_Number3";
            this.txt_AV_C_Number3.ReadOnly = true;
            this.txt_AV_C_Number3.Size = new System.Drawing.Size(322, 22);
            this.txt_AV_C_Number3.TabIndex = 360;
            this.txt_AV_C_Number3.TabStop = false;
            this.txt_AV_C_Number3.Visible = false;
            // 
            // txtBank_Code
            // 
            this.txtBank_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtBank_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBank_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtBank_Code.ForeColor = System.Drawing.Color.White;
            this.txtBank_Code.Location = new System.Drawing.Point(585, 180);
            this.txtBank_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtBank_Code.MaxLength = 30;
            this.txtBank_Code.Name = "txtBank_Code";
            this.txtBank_Code.ReadOnly = true;
            this.txtBank_Code.Size = new System.Drawing.Size(42, 22);
            this.txtBank_Code.TabIndex = 359;
            this.txtBank_Code.TabStop = false;
            // 
            // txtBank
            // 
            this.txtBank.Location = new System.Drawing.Point(562, 179);
            this.txtBank.Name = "txtBank";
            this.txtBank.Properties.AutoHeight = false;
            this.txtBank.Size = new System.Drawing.Size(130, 21);
            this.txtBank.TabIndex = 356;
            // 
            // labelControl109
            // 
            this.labelControl109.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl109.Appearance.Options.UseBackColor = true;
            this.labelControl109.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl109.Location = new System.Drawing.Point(433, 174);
            this.labelControl109.Name = "labelControl109";
            this.labelControl109.Size = new System.Drawing.Size(120, 32);
            this.labelControl109.TabIndex = 357;
            this.labelControl109.Text = "신청은행";
            // 
            // labelControl144
            // 
            this.labelControl144.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl144.Appearance.Options.UseBackColor = true;
            this.labelControl144.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl144.Location = new System.Drawing.Point(559, 174);
            this.labelControl144.Name = "labelControl144";
            this.labelControl144.Size = new System.Drawing.Size(139, 32);
            this.labelControl144.TabIndex = 358;
            // 
            // txt_AV_C_Number1
            // 
            this.txt_AV_C_Number1.Location = new System.Drawing.Point(402, 79);
            this.txt_AV_C_Number1.Name = "txt_AV_C_Number1";
            this.txt_AV_C_Number1.Properties.AutoHeight = false;
            this.txt_AV_C_Number1.Size = new System.Drawing.Size(130, 21);
            this.txt_AV_C_Number1.TabIndex = 353;
            // 
            // labelControl142
            // 
            this.labelControl142.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl142.Appearance.Options.UseBackColor = true;
            this.labelControl142.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl142.Location = new System.Drawing.Point(273, 74);
            this.labelControl142.Name = "labelControl142";
            this.labelControl142.Size = new System.Drawing.Size(120, 32);
            this.labelControl142.TabIndex = 354;
            this.labelControl142.Text = "계좌번호";
            // 
            // labelControl143
            // 
            this.labelControl143.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl143.Appearance.Options.UseBackColor = true;
            this.labelControl143.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl143.Location = new System.Drawing.Point(399, 74);
            this.labelControl143.Name = "labelControl143";
            this.labelControl143.Size = new System.Drawing.Size(139, 32);
            this.labelControl143.TabIndex = 355;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(132, 143);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(282, 13);
            this.label86.TabIndex = 352;
            this.label86.Text = "※미기입시 자동으로 회원연락처로 전송됩니다.";
            // 
            // btnGetMemberHPTel
            // 
            this.btnGetMemberHPTel.Location = new System.Drawing.Point(356, 116);
            this.btnGetMemberHPTel.Name = "btnGetMemberHPTel";
            this.btnGetMemberHPTel.Size = new System.Drawing.Size(197, 24);
            this.btnGetMemberHPTel.TabIndex = 351;
            this.btnGetMemberHPTel.Text = "회원연락처가져오기";
            // 
            // txt_VA_DEST_TEL
            // 
            this.txt_VA_DEST_TEL.Location = new System.Drawing.Point(132, 117);
            this.txt_VA_DEST_TEL.Name = "txt_VA_DEST_TEL";
            this.txt_VA_DEST_TEL.Properties.AutoHeight = false;
            this.txt_VA_DEST_TEL.Size = new System.Drawing.Size(218, 23);
            this.txt_VA_DEST_TEL.TabIndex = 348;
            // 
            // labelControl140
            // 
            this.labelControl140.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl140.Appearance.Options.UseBackColor = true;
            this.labelControl140.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl140.Location = new System.Drawing.Point(3, 112);
            this.labelControl140.Name = "labelControl140";
            this.labelControl140.Size = new System.Drawing.Size(120, 50);
            this.labelControl140.TabIndex = 349;
            this.labelControl140.Text = "계좌발송연락처";
            // 
            // labelControl141
            // 
            this.labelControl141.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl141.Appearance.Options.UseBackColor = true;
            this.labelControl141.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl141.Location = new System.Drawing.Point(129, 112);
            this.labelControl141.Name = "labelControl141";
            this.labelControl141.Size = new System.Drawing.Size(430, 50);
            this.labelControl141.TabIndex = 350;
            // 
            // txt_AV_C_Code
            // 
            this.txt_AV_C_Code.Location = new System.Drawing.Point(131, 81);
            this.txt_AV_C_Code.Name = "txt_AV_C_Code";
            this.txt_AV_C_Code.Properties.AutoHeight = false;
            this.txt_AV_C_Code.Size = new System.Drawing.Size(130, 21);
            this.txt_AV_C_Code.TabIndex = 345;
            // 
            // labelControl138
            // 
            this.labelControl138.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl138.Appearance.Options.UseBackColor = true;
            this.labelControl138.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl138.Location = new System.Drawing.Point(2, 76);
            this.labelControl138.Name = "labelControl138";
            this.labelControl138.Size = new System.Drawing.Size(120, 32);
            this.labelControl138.TabIndex = 346;
            this.labelControl138.Text = "가상계좌은행코드";
            // 
            // labelControl139
            // 
            this.labelControl139.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl139.Appearance.Options.UseBackColor = true;
            this.labelControl139.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl139.Location = new System.Drawing.Point(128, 76);
            this.labelControl139.Name = "labelControl139";
            this.labelControl139.Size = new System.Drawing.Size(139, 32);
            this.labelControl139.TabIndex = 347;
            // 
            // txt_AV_C_AppDate1
            // 
            this.txt_AV_C_AppDate1.Location = new System.Drawing.Point(402, 45);
            this.txt_AV_C_AppDate1.Name = "txt_AV_C_AppDate1";
            this.txt_AV_C_AppDate1.Properties.AutoHeight = false;
            this.txt_AV_C_AppDate1.Size = new System.Drawing.Size(130, 21);
            this.txt_AV_C_AppDate1.TabIndex = 342;
            // 
            // labelControl136
            // 
            this.labelControl136.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl136.Appearance.Options.UseBackColor = true;
            this.labelControl136.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl136.Location = new System.Drawing.Point(273, 40);
            this.labelControl136.Name = "labelControl136";
            this.labelControl136.Size = new System.Drawing.Size(120, 32);
            this.labelControl136.TabIndex = 343;
            this.labelControl136.Text = "가상계좌요청/입금일";
            // 
            // labelControl137
            // 
            this.labelControl137.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl137.Appearance.Options.UseBackColor = true;
            this.labelControl137.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl137.Location = new System.Drawing.Point(399, 40);
            this.labelControl137.Name = "labelControl137";
            this.labelControl137.Size = new System.Drawing.Size(139, 32);
            this.labelControl137.TabIndex = 344;
            // 
            // txt_Price_5
            // 
            this.txt_Price_5.Location = new System.Drawing.Point(132, 45);
            this.txt_Price_5.Name = "txt_Price_5";
            this.txt_Price_5.Properties.AutoHeight = false;
            this.txt_Price_5.Size = new System.Drawing.Size(130, 21);
            this.txt_Price_5.TabIndex = 339;
            // 
            // labelControl134
            // 
            this.labelControl134.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl134.Appearance.Options.UseBackColor = true;
            this.labelControl134.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl134.Location = new System.Drawing.Point(3, 40);
            this.labelControl134.Name = "labelControl134";
            this.labelControl134.Size = new System.Drawing.Size(120, 32);
            this.labelControl134.TabIndex = 340;
            this.labelControl134.Text = "입금액";
            // 
            // labelControl135
            // 
            this.labelControl135.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl135.Appearance.Options.UseBackColor = true;
            this.labelControl135.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl135.Location = new System.Drawing.Point(129, 40);
            this.labelControl135.Name = "labelControl135";
            this.labelControl135.Size = new System.Drawing.Size(139, 32);
            this.labelControl135.TabIndex = 341;
            // 
            // txt_Price_5_2
            // 
            this.txt_Price_5_2.Location = new System.Drawing.Point(132, 7);
            this.txt_Price_5_2.Name = "txt_Price_5_2";
            this.txt_Price_5_2.Properties.AutoHeight = false;
            this.txt_Price_5_2.Size = new System.Drawing.Size(130, 21);
            this.txt_Price_5_2.TabIndex = 336;
            // 
            // labelControl130
            // 
            this.labelControl130.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl130.Appearance.Options.UseBackColor = true;
            this.labelControl130.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl130.Location = new System.Drawing.Point(3, 2);
            this.labelControl130.Name = "labelControl130";
            this.labelControl130.Size = new System.Drawing.Size(120, 32);
            this.labelControl130.TabIndex = 337;
            this.labelControl130.Text = "가상계좌 요청액";
            // 
            // labelControl133
            // 
            this.labelControl133.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl133.Appearance.Options.UseBackColor = true;
            this.labelControl133.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl133.Location = new System.Drawing.Point(129, 2);
            this.labelControl133.Name = "labelControl133";
            this.labelControl133.Size = new System.Drawing.Size(139, 32);
            this.labelControl133.TabIndex = 338;
            // 
            // buttonV_Cancel
            // 
            this.buttonV_Cancel.Location = new System.Drawing.Point(128, 168);
            this.buttonV_Cancel.Name = "buttonV_Cancel";
            this.buttonV_Cancel.Size = new System.Drawing.Size(121, 24);
            this.buttonV_Cancel.TabIndex = 335;
            this.buttonV_Cancel.Text = "가상계좌_취소";
            // 
            // buttonV_Ok
            // 
            this.buttonV_Ok.Location = new System.Drawing.Point(3, 168);
            this.buttonV_Ok.Name = "buttonV_Ok";
            this.buttonV_Ok.Size = new System.Drawing.Size(121, 24);
            this.buttonV_Ok.TabIndex = 334;
            this.buttonV_Ok.Text = "가상계좌_발생";
            // 
            // check_Not_AVCash
            // 
            this.check_Not_AVCash.AutoSize = true;
            this.check_Not_AVCash.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.check_Not_AVCash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.check_Not_AVCash.Location = new System.Drawing.Point(3, 190);
            this.check_Not_AVCash.Name = "check_Not_AVCash";
            this.check_Not_AVCash.Size = new System.Drawing.Size(253, 16);
            this.check_Not_AVCash.TabIndex = 332;
            this.check_Not_AVCash.Text = "현금영수증/세금계산서_미신고/미발행";
            this.check_Not_AVCash.UseVisualStyleBackColor = true;
            this.check_Not_AVCash.Visible = false;
            // 
            // txt_AVC_Cash_Send_Nu
            // 
            this.txt_AVC_Cash_Send_Nu.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_AVC_Cash_Send_Nu.Location = new System.Drawing.Point(1159, 584);
            this.txt_AVC_Cash_Send_Nu.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AVC_Cash_Send_Nu.MaxLength = 20;
            this.txt_AVC_Cash_Send_Nu.Name = "txt_AVC_Cash_Send_Nu";
            this.txt_AVC_Cash_Send_Nu.Size = new System.Drawing.Size(128, 22);
            this.txt_AVC_Cash_Send_Nu.TabIndex = 355;
            this.txt_AVC_Cash_Send_Nu.Tag = "1";
            // 
            // txt_AVC_Cash_Number2
            // 
            this.txt_AVC_Cash_Number2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_AVC_Cash_Number2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AVC_Cash_Number2.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_AVC_Cash_Number2.ForeColor = System.Drawing.Color.Red;
            this.txt_AVC_Cash_Number2.Location = new System.Drawing.Point(1028, 584);
            this.txt_AVC_Cash_Number2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_AVC_Cash_Number2.MaxLength = 30;
            this.txt_AVC_Cash_Number2.Name = "txt_AVC_Cash_Number2";
            this.txt_AVC_Cash_Number2.ReadOnly = true;
            this.txt_AVC_Cash_Number2.Size = new System.Drawing.Size(128, 21);
            this.txt_AVC_Cash_Number2.TabIndex = 356;
            this.txt_AVC_Cash_Number2.TabStop = false;
            // 
            // lblSellCode_Code
            // 
            this.lblSellCode_Code.AutoSize = true;
            this.lblSellCode_Code.Location = new System.Drawing.Point(201, 118);
            this.lblSellCode_Code.Name = "lblSellCode_Code";
            this.lblSellCode_Code.Size = new System.Drawing.Size(40, 13);
            this.lblSellCode_Code.TabIndex = 358;
            this.lblSellCode_Code.Text = "Code";
            this.lblSellCode_Code.Visible = false;
            // 
            // lblSellCode
            // 
            this.lblSellCode.AutoSize = true;
            this.lblSellCode.Location = new System.Drawing.Point(151, 118);
            this.lblSellCode.Name = "lblSellCode";
            this.lblSellCode.Size = new System.Drawing.Size(43, 13);
            this.lblSellCode.TabIndex = 357;
            this.lblSellCode.Text = "Name";
            this.lblSellCode.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mtxtZip1);
            this.groupBox1.Controls.Add(this.mtxtTel2);
            this.groupBox1.Controls.Add(this.mtxtTel1);
            this.groupBox1.Controls.Add(this.txt_ETC2);
            this.groupBox1.Controls.Add(this.txt_Receive_Method);
            this.groupBox1.Controls.Add(this.txt_Receive_Method_Code);
            this.groupBox1.Controls.Add(this.dGridView_Base_Rece);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.pan_Rec_Item);
            this.groupBox1.Controls.Add(this.panel69);
            this.groupBox1.Controls.Add(this.butt_Rec_Clear);
            this.groupBox1.Controls.Add(this.butt_Rec_Save);
            this.groupBox1.Controls.Add(this.butt_Rec_Del);
            this.groupBox1.Controls.Add(this.labelControl64);
            this.groupBox1.Controls.Add(this.labelControl65);
            this.groupBox1.Controls.Add(this.txt_Pass_Number);
            this.groupBox1.Controls.Add(this.labelControl62);
            this.groupBox1.Controls.Add(this.labelControl63);
            this.groupBox1.Controls.Add(this.txt_Get_Etc1);
            this.groupBox1.Controls.Add(this.labelControl60);
            this.groupBox1.Controls.Add(this.labelControl61);
            this.groupBox1.Controls.Add(this.txtAddress2);
            this.groupBox1.Controls.Add(this.labelControl58);
            this.groupBox1.Controls.Add(this.labelControl59);
            this.groupBox1.Controls.Add(this.txtAddress1);
            this.groupBox1.Controls.Add(this.labelControl56);
            this.groupBox1.Controls.Add(this.labelControl57);
            this.groupBox1.Controls.Add(this.butt_Rec_Add);
            this.groupBox1.Controls.Add(this.butt_AddCode);
            this.groupBox1.Controls.Add(this.labelControl54);
            this.groupBox1.Controls.Add(this.labelControl55);
            this.groupBox1.Controls.Add(this.labelControl52);
            this.groupBox1.Controls.Add(this.labelControl53);
            this.groupBox1.Controls.Add(this.labelControl50);
            this.groupBox1.Controls.Add(this.labelControl51);
            this.groupBox1.Controls.Add(this.txt_Get_Name1);
            this.groupBox1.Controls.Add(this.labelControl48);
            this.groupBox1.Controls.Add(this.labelControl49);
            this.groupBox1.Controls.Add(this.labelControl46);
            this.groupBox1.Controls.Add(this.labelControl47);
            this.groupBox1.Controls.Add(this.txt_RecIndex);
            this.groupBox1.Controls.Add(this.txt_Base_Rec_Code);
            this.groupBox1.Controls.Add(this.txt_Base_Rec);
            this.groupBox1.Controls.Add(this.txtGetDate1);
            this.groupBox1.Location = new System.Drawing.Point(328, 670);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1296, 388);
            this.groupBox1.TabIndex = 359;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "배송 내역";
            // 
            // mtxtZip1
            // 
            this.mtxtZip1.Location = new System.Drawing.Point(328, 130);
            this.mtxtZip1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtZip1.Name = "mtxtZip1";
            this.mtxtZip1.Size = new System.Drawing.Size(90, 22);
            this.mtxtZip1.TabIndex = 390;
            // 
            // mtxtTel2
            // 
            this.mtxtTel2.Location = new System.Drawing.Point(565, 93);
            this.mtxtTel2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel2.Name = "mtxtTel2";
            this.mtxtTel2.Size = new System.Drawing.Size(127, 22);
            this.mtxtTel2.TabIndex = 389;
            // 
            // mtxtTel1
            // 
            this.mtxtTel1.Location = new System.Drawing.Point(326, 93);
            this.mtxtTel1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel1.Name = "mtxtTel1";
            this.mtxtTel1.Size = new System.Drawing.Size(91, 22);
            this.mtxtTel1.TabIndex = 388;
            // 
            // txt_ETC2
            // 
            this.txt_ETC2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC2.Location = new System.Drawing.Point(522, 250);
            this.txt_ETC2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_ETC2.MaxLength = 100;
            this.txt_ETC2.Name = "txt_ETC2";
            this.txt_ETC2.Size = new System.Drawing.Size(466, 22);
            this.txt_ETC2.TabIndex = 387;
            // 
            // txt_Receive_Method
            // 
            this.txt_Receive_Method.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Receive_Method.Location = new System.Drawing.Point(322, 19);
            this.txt_Receive_Method.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Receive_Method.MaxLength = 30;
            this.txt_Receive_Method.Name = "txt_Receive_Method";
            this.txt_Receive_Method.Size = new System.Drawing.Size(126, 22);
            this.txt_Receive_Method.TabIndex = 385;
            this.txt_Receive_Method.Tag = "ncode";
            // 
            // txt_Receive_Method_Code
            // 
            this.txt_Receive_Method_Code.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_Receive_Method_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Receive_Method_Code.ForeColor = System.Drawing.Color.White;
            this.txt_Receive_Method_Code.Location = new System.Drawing.Point(449, 19);
            this.txt_Receive_Method_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_Receive_Method_Code.MaxLength = 30;
            this.txt_Receive_Method_Code.Name = "txt_Receive_Method_Code";
            this.txt_Receive_Method_Code.Size = new System.Drawing.Size(37, 22);
            this.txt_Receive_Method_Code.TabIndex = 386;
            this.txt_Receive_Method_Code.TabStop = false;
            // 
            // dGridView_Base_Rece
            // 
            this.dGridView_Base_Rece.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridView_Base_Rece.Location = new System.Drawing.Point(13, 278);
            this.dGridView_Base_Rece.Name = "dGridView_Base_Rece";
            this.dGridView_Base_Rece.RowTemplate.Height = 23;
            this.dGridView_Base_Rece.Size = new System.Drawing.Size(1277, 104);
            this.dGridView_Base_Rece.TabIndex = 383;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chk_Total);
            this.panel2.Location = new System.Drawing.Point(6, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(181, 26);
            this.panel2.TabIndex = 381;
            // 
            // chk_Total
            // 
            this.chk_Total.AutoSize = true;
            this.chk_Total.Location = new System.Drawing.Point(3, 3);
            this.chk_Total.Name = "chk_Total";
            this.chk_Total.Size = new System.Drawing.Size(85, 17);
            this.chk_Total.TabIndex = 1;
            this.chk_Total.TabStop = false;
            this.chk_Total.Text = "전체_체크";
            this.chk_Total.UseVisualStyleBackColor = true;
            // 
            // pan_Rec_Item
            // 
            this.pan_Rec_Item.Controls.Add(this.dGridView_Base_Rece_Item);
            this.pan_Rec_Item.Location = new System.Drawing.Point(6, 39);
            this.pan_Rec_Item.Name = "pan_Rec_Item";
            this.pan_Rec_Item.Size = new System.Drawing.Size(181, 233);
            this.pan_Rec_Item.TabIndex = 380;
            // 
            // dGridView_Base_Rece_Item
            // 
            this.dGridView_Base_Rece_Item.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Rece_Item.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Rece_Item.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dGridView_Base_Rece_Item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Rece_Item.DefaultCellStyle = dataGridViewCellStyle2;
            this.dGridView_Base_Rece_Item.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Rece_Item.Location = new System.Drawing.Point(3, 4);
            this.dGridView_Base_Rece_Item.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Rece_Item.Name = "dGridView_Base_Rece_Item";
            this.dGridView_Base_Rece_Item.RowTemplate.Height = 23;
            this.dGridView_Base_Rece_Item.Size = new System.Drawing.Size(137, 121);
            this.dGridView_Base_Rece_Item.TabIndex = 227;
            this.dGridView_Base_Rece_Item.TabStop = false;
            // 
            // panel69
            // 
            this.panel69.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel69.BackColor = System.Drawing.Color.White;
            this.panel69.Controls.Add(this.opt_Rec_Add2);
            this.panel69.Controls.Add(this.opt_Rec_Add1);
            this.panel69.Location = new System.Drawing.Point(630, 16);
            this.panel69.Margin = new System.Windows.Forms.Padding(2);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(349, 61);
            this.panel69.TabIndex = 379;
            // 
            // opt_Rec_Add2
            // 
            this.opt_Rec_Add2.AutoSize = true;
            this.opt_Rec_Add2.Location = new System.Drawing.Point(6, 38);
            this.opt_Rec_Add2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opt_Rec_Add2.Name = "opt_Rec_Add2";
            this.opt_Rec_Add2.Size = new System.Drawing.Size(90, 17);
            this.opt_Rec_Add2.TabIndex = 54;
            this.opt_Rec_Add2.Text = "기본배송지";
            this.opt_Rec_Add2.UseVisualStyleBackColor = true;
            // 
            // opt_Rec_Add1
            // 
            this.opt_Rec_Add1.AutoSize = true;
            this.opt_Rec_Add1.Location = new System.Drawing.Point(6, 8);
            this.opt_Rec_Add1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.opt_Rec_Add1.Name = "opt_Rec_Add1";
            this.opt_Rec_Add1.Size = new System.Drawing.Size(77, 17);
            this.opt_Rec_Add1.TabIndex = 53;
            this.opt_Rec_Add1.Text = "회원주소";
            this.opt_Rec_Add1.UseVisualStyleBackColor = true;
            // 
            // butt_Rec_Clear
            // 
            this.butt_Rec_Clear.Location = new System.Drawing.Point(356, 241);
            this.butt_Rec_Clear.Name = "butt_Rec_Clear";
            this.butt_Rec_Clear.Size = new System.Drawing.Size(84, 31);
            this.butt_Rec_Clear.TabIndex = 378;
            this.butt_Rec_Clear.Text = "취소";
            // 
            // butt_Rec_Save
            // 
            this.butt_Rec_Save.Location = new System.Drawing.Point(266, 241);
            this.butt_Rec_Save.Name = "butt_Rec_Save";
            this.butt_Rec_Save.Size = new System.Drawing.Size(84, 31);
            this.butt_Rec_Save.TabIndex = 377;
            this.butt_Rec_Save.Text = "추가";
            // 
            // butt_Rec_Del
            // 
            this.butt_Rec_Del.Location = new System.Drawing.Point(193, 241);
            this.butt_Rec_Del.Name = "butt_Rec_Del";
            this.butt_Rec_Del.Size = new System.Drawing.Size(67, 31);
            this.butt_Rec_Del.TabIndex = 376;
            this.butt_Rec_Del.Text = "지우기";
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl64.Appearance.Options.UseBackColor = true;
            this.labelControl64.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl64.Location = new System.Drawing.Point(495, 13);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Size = new System.Drawing.Size(120, 70);
            this.labelControl64.TabIndex = 374;
            this.labelControl64.Text = "배송지";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl65.Appearance.Options.UseBackColor = true;
            this.labelControl65.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl65.Location = new System.Drawing.Point(621, 13);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(367, 70);
            this.labelControl65.TabIndex = 375;
            // 
            // txt_Pass_Number
            // 
            this.txt_Pass_Number.Location = new System.Drawing.Point(724, 207);
            this.txt_Pass_Number.Name = "txt_Pass_Number";
            this.txt_Pass_Number.Properties.AutoHeight = false;
            this.txt_Pass_Number.Size = new System.Drawing.Size(260, 21);
            this.txt_Pass_Number.TabIndex = 371;
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl62.Appearance.Options.UseBackColor = true;
            this.labelControl62.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl62.Location = new System.Drawing.Point(595, 202);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Size = new System.Drawing.Size(120, 32);
            this.labelControl62.TabIndex = 372;
            this.labelControl62.Text = "운송장번호";
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl63.Appearance.Options.UseBackColor = true;
            this.labelControl63.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl63.Location = new System.Drawing.Point(721, 202);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Size = new System.Drawing.Size(271, 32);
            this.labelControl63.TabIndex = 373;
            // 
            // txt_Get_Etc1
            // 
            this.txt_Get_Etc1.Location = new System.Drawing.Point(322, 207);
            this.txt_Get_Etc1.Name = "txt_Get_Etc1";
            this.txt_Get_Etc1.Properties.AutoHeight = false;
            this.txt_Get_Etc1.Size = new System.Drawing.Size(260, 21);
            this.txt_Get_Etc1.TabIndex = 368;
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl60.Appearance.Options.UseBackColor = true;
            this.labelControl60.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl60.Location = new System.Drawing.Point(193, 202);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Size = new System.Drawing.Size(120, 32);
            this.labelControl60.TabIndex = 369;
            this.labelControl60.Text = "비고";
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl61.Appearance.Options.UseBackColor = true;
            this.labelControl61.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl61.Location = new System.Drawing.Point(319, 202);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Size = new System.Drawing.Size(271, 32);
            this.labelControl61.TabIndex = 370;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(322, 169);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Properties.AutoHeight = false;
            this.txtAddress2.Size = new System.Drawing.Size(522, 21);
            this.txtAddress2.TabIndex = 365;
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl58.Appearance.Options.UseBackColor = true;
            this.labelControl58.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl58.Location = new System.Drawing.Point(193, 164);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Size = new System.Drawing.Size(120, 32);
            this.labelControl58.TabIndex = 366;
            this.labelControl58.Text = "주소2";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl59.Appearance.Options.UseBackColor = true;
            this.labelControl59.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl59.Location = new System.Drawing.Point(319, 164);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Size = new System.Drawing.Size(533, 32);
            this.labelControl59.TabIndex = 367;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(643, 133);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Properties.AutoHeight = false;
            this.txtAddress1.Size = new System.Drawing.Size(341, 21);
            this.txtAddress1.TabIndex = 362;
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl56.Appearance.Options.UseBackColor = true;
            this.labelControl56.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl56.Location = new System.Drawing.Point(514, 128);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Size = new System.Drawing.Size(120, 32);
            this.labelControl56.TabIndex = 363;
            this.labelControl56.Text = "주소1";
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl57.Appearance.Options.UseBackColor = true;
            this.labelControl57.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl57.Location = new System.Drawing.Point(640, 128);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Size = new System.Drawing.Size(352, 32);
            this.labelControl57.TabIndex = 364;
            // 
            // butt_Rec_Add
            // 
            this.butt_Rec_Add.Location = new System.Drawing.Point(698, 88);
            this.butt_Rec_Add.Name = "butt_Rec_Add";
            this.butt_Rec_Add.Size = new System.Drawing.Size(146, 30);
            this.butt_Rec_Add.TabIndex = 361;
            this.butt_Rec_Add.Text = "과거배송지";
            // 
            // butt_AddCode
            // 
            this.butt_AddCode.Location = new System.Drawing.Point(427, 128);
            this.butt_AddCode.Name = "butt_AddCode";
            this.butt_AddCode.Size = new System.Drawing.Size(81, 30);
            this.butt_AddCode.TabIndex = 360;
            this.butt_AddCode.Text = "우편번호";
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl54.Appearance.Options.UseBackColor = true;
            this.labelControl54.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl54.Location = new System.Drawing.Point(193, 126);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Size = new System.Drawing.Size(120, 32);
            this.labelControl54.TabIndex = 358;
            this.labelControl54.Text = "우편번호";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl55.Appearance.Options.UseBackColor = true;
            this.labelControl55.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl55.Location = new System.Drawing.Point(319, 126);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Size = new System.Drawing.Size(102, 32);
            this.labelControl55.TabIndex = 359;
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl52.Appearance.Options.UseBackColor = true;
            this.labelControl52.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl52.Location = new System.Drawing.Point(427, 88);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(120, 32);
            this.labelControl52.TabIndex = 355;
            this.labelControl52.Text = "연락처2";
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl53.Appearance.Options.UseBackColor = true;
            this.labelControl53.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl53.Location = new System.Drawing.Point(553, 88);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Size = new System.Drawing.Size(139, 32);
            this.labelControl53.TabIndex = 356;
            // 
            // labelControl50
            // 
            this.labelControl50.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl50.Appearance.Options.UseBackColor = true;
            this.labelControl50.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl50.Location = new System.Drawing.Point(193, 89);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(120, 32);
            this.labelControl50.TabIndex = 352;
            this.labelControl50.Text = "연락처1";
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl51.Appearance.Options.UseBackColor = true;
            this.labelControl51.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl51.Location = new System.Drawing.Point(319, 89);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(102, 32);
            this.labelControl51.TabIndex = 353;
            // 
            // txt_Get_Name1
            // 
            this.txt_Get_Name1.Location = new System.Drawing.Point(322, 56);
            this.txt_Get_Name1.Name = "txt_Get_Name1";
            this.txt_Get_Name1.Properties.AutoHeight = false;
            this.txt_Get_Name1.Size = new System.Drawing.Size(161, 21);
            this.txt_Get_Name1.TabIndex = 348;
            // 
            // labelControl48
            // 
            this.labelControl48.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl48.Appearance.Options.UseBackColor = true;
            this.labelControl48.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl48.Location = new System.Drawing.Point(193, 51);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(120, 32);
            this.labelControl48.TabIndex = 349;
            this.labelControl48.Text = "수령인명";
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl49.Appearance.Options.UseBackColor = true;
            this.labelControl49.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl49.Location = new System.Drawing.Point(319, 51);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(170, 32);
            this.labelControl49.TabIndex = 350;
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl46.Appearance.Options.UseBackColor = true;
            this.labelControl46.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl46.Location = new System.Drawing.Point(193, 13);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(120, 32);
            this.labelControl46.TabIndex = 346;
            this.labelControl46.Text = "배송구분";
            // 
            // labelControl47
            // 
            this.labelControl47.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl47.Appearance.Options.UseBackColor = true;
            this.labelControl47.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl47.Location = new System.Drawing.Point(319, 13);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(170, 32);
            this.labelControl47.TabIndex = 347;
            // 
            // txt_RecIndex
            // 
            this.txt_RecIndex.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_RecIndex.Location = new System.Drawing.Point(460, 249);
            this.txt_RecIndex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_RecIndex.MaxLength = 8;
            this.txt_RecIndex.Name = "txt_RecIndex";
            this.txt_RecIndex.ReadOnly = true;
            this.txt_RecIndex.Size = new System.Drawing.Size(51, 22);
            this.txt_RecIndex.TabIndex = 384;
            this.txt_RecIndex.TabStop = false;
            this.txt_RecIndex.Visible = false;
            // 
            // dGridView_Base_Mile
            // 
            this.dGridView_Base_Mile.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Mile.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Mile.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGridView_Base_Mile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Mile.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGridView_Base_Mile.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Mile.Location = new System.Drawing.Point(1503, 987);
            this.dGridView_Base_Mile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Mile.Name = "dGridView_Base_Mile";
            this.dGridView_Base_Mile.RowTemplate.Height = 23;
            this.dGridView_Base_Mile.Size = new System.Drawing.Size(169, 191);
            this.dGridView_Base_Mile.TabIndex = 1524;
            this.dGridView_Base_Mile.Visible = false;
            // 
            // dGridView_Base_Rece_Add
            // 
            this.dGridView_Base_Rece_Add.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Rece_Add.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Rece_Add.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dGridView_Base_Rece_Add.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("굴림", 9.75F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Rece_Add.DefaultCellStyle = dataGridViewCellStyle6;
            this.dGridView_Base_Rece_Add.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Rece_Add.Location = new System.Drawing.Point(1681, 985);
            this.dGridView_Base_Rece_Add.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Base_Rece_Add.Name = "dGridView_Base_Rece_Add";
            this.dGridView_Base_Rece_Add.RowTemplate.Height = 23;
            this.dGridView_Base_Rece_Add.Size = new System.Drawing.Size(169, 191);
            this.dGridView_Base_Rece_Add.TabIndex = 1523;
            this.dGridView_Base_Rece_Add.Visible = false;
            // 
            // panel_Cacu
            // 
            this.panel_Cacu.Controls.Add(this.tab_Cacu);
            this.panel_Cacu.Location = new System.Drawing.Point(781, 280);
            this.panel_Cacu.Name = "panel_Cacu";
            this.panel_Cacu.Size = new System.Drawing.Size(645, 261);
            this.panel_Cacu.TabIndex = 1527;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txt_SumCnt);
            this.groupBox7.Controls.Add(this.txt_ItemCode);
            this.groupBox7.Controls.Add(this.txt_ItemName);
            this.groupBox7.Controls.Add(this.dGridView_Base_Item);
            this.groupBox7.Controls.Add(this.txt_SumCV);
            this.groupBox7.Controls.Add(this.labelControl45);
            this.groupBox7.Controls.Add(this.txt_SumPV);
            this.groupBox7.Controls.Add(this.labelControl43);
            this.groupBox7.Controls.Add(this.labelControl44);
            this.groupBox7.Controls.Add(this.txt_SumPr);
            this.groupBox7.Controls.Add(this.labelControl41);
            this.groupBox7.Controls.Add(this.labelControl42);
            this.groupBox7.Controls.Add(this.butt_Item_Clear);
            this.groupBox7.Controls.Add(this.butt_Item_Save);
            this.groupBox7.Controls.Add(this.butt_Item_Del);
            this.groupBox7.Controls.Add(this.txt_ItemCount);
            this.groupBox7.Controls.Add(this.labelControl39);
            this.groupBox7.Controls.Add(this.labelControl40);
            this.groupBox7.Controls.Add(this.labelControl37);
            this.groupBox7.Controls.Add(this.labelControl38);
            this.groupBox7.Controls.Add(this.txt_Item_Etc);
            this.groupBox7.Location = new System.Drawing.Point(312, 262);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(466, 402);
            this.groupBox7.TabIndex = 1528;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "상품 내역";
            // 
            // txt_SumCnt
            // 
            this.txt_SumCnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_SumCnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_SumCnt.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_SumCnt.Location = new System.Drawing.Point(276, 403);
            this.txt_SumCnt.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_SumCnt.MaxLength = 30;
            this.txt_SumCnt.Name = "txt_SumCnt";
            this.txt_SumCnt.ReadOnly = true;
            this.txt_SumCnt.Size = new System.Drawing.Size(70, 21);
            this.txt_SumCnt.TabIndex = 1531;
            this.txt_SumCnt.TabStop = false;
            // 
            // txt_ItemCode
            // 
            this.txt_ItemCode.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ItemCode.Location = new System.Drawing.Point(156, 19);
            this.txt_ItemCode.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ItemCode.MaxLength = 8;
            this.txt_ItemCode.Name = "txt_ItemCode";
            this.txt_ItemCode.Size = new System.Drawing.Size(58, 22);
            this.txt_ItemCode.TabIndex = 1545;
            this.txt_ItemCode.Tag = "ncode";
            // 
            // txt_ItemName
            // 
            this.txt_ItemName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_ItemName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ItemName.Font = new System.Drawing.Font("굴림", 9F);
            this.txt_ItemName.ForeColor = System.Drawing.Color.White;
            this.txt_ItemName.Location = new System.Drawing.Point(214, 19);
            this.txt_ItemName.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_ItemName.MaxLength = 30;
            this.txt_ItemName.Name = "txt_ItemName";
            this.txt_ItemName.ReadOnly = true;
            this.txt_ItemName.Size = new System.Drawing.Size(220, 21);
            this.txt_ItemName.TabIndex = 1546;
            this.txt_ItemName.TabStop = false;
            // 
            // dGridView_Base_Item
            // 
            this.dGridView_Base_Item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridView_Base_Item.Location = new System.Drawing.Point(19, 89);
            this.dGridView_Base_Item.Name = "dGridView_Base_Item";
            this.dGridView_Base_Item.RowTemplate.Height = 23;
            this.dGridView_Base_Item.Size = new System.Drawing.Size(431, 256);
            this.dGridView_Base_Item.TabIndex = 1543;
            // 
            // txt_SumCV
            // 
            this.txt_SumCV.Location = new System.Drawing.Point(397, 361);
            this.txt_SumCV.Name = "txt_SumCV";
            this.txt_SumCV.Properties.AutoHeight = false;
            this.txt_SumCV.Size = new System.Drawing.Size(43, 21);
            this.txt_SumCV.TabIndex = 1541;
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl45.Appearance.Options.UseBackColor = true;
            this.labelControl45.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl45.Location = new System.Drawing.Point(393, 356);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(55, 32);
            this.labelControl45.TabIndex = 1542;
            // 
            // txt_SumPV
            // 
            this.txt_SumPV.Location = new System.Drawing.Point(340, 361);
            this.txt_SumPV.Name = "txt_SumPV";
            this.txt_SumPV.Properties.AutoHeight = false;
            this.txt_SumPV.Size = new System.Drawing.Size(43, 21);
            this.txt_SumPV.TabIndex = 1538;
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl43.Appearance.Options.UseBackColor = true;
            this.labelControl43.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl43.Location = new System.Drawing.Point(203, 356);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(131, 32);
            this.labelControl43.TabIndex = 1539;
            this.labelControl43.Text = "PV / BV합";
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl44.Appearance.Options.UseBackColor = true;
            this.labelControl44.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl44.Location = new System.Drawing.Point(336, 356);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(55, 32);
            this.labelControl44.TabIndex = 1540;
            // 
            // txt_SumPr
            // 
            this.txt_SumPr.Location = new System.Drawing.Point(146, 361);
            this.txt_SumPr.Name = "txt_SumPr";
            this.txt_SumPr.Properties.AutoHeight = false;
            this.txt_SumPr.Size = new System.Drawing.Size(43, 21);
            this.txt_SumPr.TabIndex = 1535;
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl41.Appearance.Options.UseBackColor = true;
            this.labelControl41.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl41.Location = new System.Drawing.Point(16, 356);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(120, 32);
            this.labelControl41.TabIndex = 1536;
            this.labelControl41.Text = "금액합";
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl42.Appearance.Options.UseBackColor = true;
            this.labelControl42.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl42.Location = new System.Drawing.Point(142, 356);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(55, 32);
            this.labelControl42.TabIndex = 1537;
            // 
            // butt_Item_Clear
            // 
            this.butt_Item_Clear.Location = new System.Drawing.Point(366, 54);
            this.butt_Item_Clear.Name = "butt_Item_Clear";
            this.butt_Item_Clear.Size = new System.Drawing.Size(84, 31);
            this.butt_Item_Clear.TabIndex = 1534;
            this.butt_Item_Clear.Text = "취소";
            // 
            // butt_Item_Save
            // 
            this.butt_Item_Save.Location = new System.Drawing.Point(276, 54);
            this.butt_Item_Save.Name = "butt_Item_Save";
            this.butt_Item_Save.Size = new System.Drawing.Size(84, 31);
            this.butt_Item_Save.TabIndex = 1533;
            this.butt_Item_Save.Text = "추가";
            // 
            // butt_Item_Del
            // 
            this.butt_Item_Del.Location = new System.Drawing.Point(203, 54);
            this.butt_Item_Del.Name = "butt_Item_Del";
            this.butt_Item_Del.Size = new System.Drawing.Size(67, 31);
            this.butt_Item_Del.TabIndex = 1532;
            this.butt_Item_Del.Text = "지우기";
            // 
            // txt_ItemCount
            // 
            this.txt_ItemCount.Location = new System.Drawing.Point(146, 58);
            this.txt_ItemCount.Name = "txt_ItemCount";
            this.txt_ItemCount.Properties.AutoHeight = false;
            this.txt_ItemCount.Size = new System.Drawing.Size(43, 21);
            this.txt_ItemCount.TabIndex = 1529;
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl39.Appearance.Options.UseBackColor = true;
            this.labelControl39.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl39.Location = new System.Drawing.Point(16, 53);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(120, 32);
            this.labelControl39.TabIndex = 1530;
            this.labelControl39.Text = "수량";
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl40.Appearance.Options.UseBackColor = true;
            this.labelControl40.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl40.Location = new System.Drawing.Point(142, 53);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(55, 32);
            this.labelControl40.TabIndex = 1531;
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl37.Appearance.Options.UseBackColor = true;
            this.labelControl37.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl37.Location = new System.Drawing.Point(16, 15);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(120, 32);
            this.labelControl37.TabIndex = 1527;
            this.labelControl37.Text = "상품코드/상품명";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
            this.labelControl38.Appearance.Options.UseBackColor = true;
            this.labelControl38.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl38.Location = new System.Drawing.Point(142, 15);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Size = new System.Drawing.Size(308, 32);
            this.labelControl38.TabIndex = 1528;
            // 
            // txt_Item_Etc
            // 
            this.txt_Item_Etc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Item_Etc.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Item_Etc.Location = new System.Drawing.Point(30, 99);
            this.txt_Item_Etc.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Item_Etc.MaxLength = 100;
            this.txt_Item_Etc.Name = "txt_Item_Etc";
            this.txt_Item_Etc.Size = new System.Drawing.Size(56, 22);
            this.txt_Item_Etc.TabIndex = 1544;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.butt_Cacu_Del);
            this.panel18.Controls.Add(this.butt_Cacu_Save);
            this.panel18.Controls.Add(this.butt_Cacu_Clear);
            this.panel18.Location = new System.Drawing.Point(781, 543);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(646, 38);
            this.panel18.TabIndex = 1529;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtSellCode_Code);
            this.panel8.Controls.Add(this.txtCenter2_Code);
            this.panel8.Controls.Add(this.txtSellCode);
            this.panel8.Controls.Add(this.txtCenter2);
            this.panel8.Controls.Add(this.butt_Ord_Clear);
            this.panel8.Controls.Add(this.labelControl11);
            this.panel8.Controls.Add(this.labelControl13);
            this.panel8.Controls.Add(this.lblSellCode_Code);
            this.panel8.Controls.Add(this.lblSellCode);
            this.panel8.Controls.Add(this.labelControl15);
            this.panel8.Controls.Add(this.butt_Print);
            this.panel8.Controls.Add(this.labelControl17);
            this.panel8.Controls.Add(this.labelControl19);
            this.panel8.Controls.Add(this.radioB_CALL);
            this.panel8.Controls.Add(this.labelControl21);
            this.panel8.Controls.Add(this.radioB_DESK);
            this.panel8.Controls.Add(this.txt_ETC1);
            this.panel8.Controls.Add(this.labelControl23);
            this.panel8.Controls.Add(this.txt_InputPass_Pay);
            this.panel8.Controls.Add(this.labelControl25);
            this.panel8.Controls.Add(this.txt_OrderNumber);
            this.panel8.Controls.Add(this.labelControl27);
            this.panel8.Controls.Add(this.txt_Ins_Number);
            this.panel8.Controls.Add(this.labelControl29);
            this.panel8.Controls.Add(this.txt_TotalPrice);
            this.panel8.Controls.Add(this.labelControl31);
            this.panel8.Controls.Add(this.txt_TotalPv);
            this.panel8.Controls.Add(this.labelControl33);
            this.panel8.Controls.Add(this.txt_SOrd);
            this.panel8.Controls.Add(this.labelControl35);
            this.panel8.Controls.Add(this.txt_TotalCV);
            this.panel8.Controls.Add(this.dateTimePicker2);
            this.panel8.Controls.Add(this.mtxtSellDate2);
            this.panel8.Controls.Add(this.mtxtSellDate);
            this.panel8.Controls.Add(this.dateTimePicker1);
            this.panel8.Controls.Add(this.labelControl12);
            this.panel8.Controls.Add(this.labelControl14);
            this.panel8.Controls.Add(this.labelControl16);
            this.panel8.Controls.Add(this.labelControl18);
            this.panel8.Controls.Add(this.labelControl20);
            this.panel8.Controls.Add(this.labelControl22);
            this.panel8.Controls.Add(this.labelControl24);
            this.panel8.Controls.Add(this.labelControl26);
            this.panel8.Controls.Add(this.labelControl28);
            this.panel8.Controls.Add(this.labelControl30);
            this.panel8.Controls.Add(this.labelControl32);
            this.panel8.Controls.Add(this.labelControl34);
            this.panel8.Controls.Add(this.labelControl36);
            this.panel8.Location = new System.Drawing.Point(38, 262);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(277, 883);
            this.panel8.TabIndex = 1530;
            // 
            // txtSellCode_Code
            // 
            this.txtSellCode_Code.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSellCode_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode_Code.ForeColor = System.Drawing.Color.Lime;
            this.txtSellCode_Code.Location = new System.Drawing.Point(225, 168);
            this.txtSellCode_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode_Code.MaxLength = 30;
            this.txtSellCode_Code.Name = "txtSellCode_Code";
            this.txtSellCode_Code.Size = new System.Drawing.Size(42, 22);
            this.txtSellCode_Code.TabIndex = 1534;
            this.txtSellCode_Code.TabStop = false;
            // 
            // txtCenter2_Code
            // 
            this.txtCenter2_Code.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCenter2_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter2_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter2_Code.Location = new System.Drawing.Point(225, 207);
            this.txtCenter2_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter2_Code.MaxLength = 30;
            this.txtCenter2_Code.Name = "txtCenter2_Code";
            this.txtCenter2_Code.Size = new System.Drawing.Size(42, 22);
            this.txtCenter2_Code.TabIndex = 360;
            this.txtCenter2_Code.TabStop = false;
            // 
            // txtSellCode
            // 
            this.txtSellCode.BackColor = System.Drawing.Color.White;
            this.txtSellCode.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode.Location = new System.Drawing.Point(132, 168);
            this.txtSellCode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode.MaxLength = 30;
            this.txtSellCode.Name = "txtSellCode";
            this.txtSellCode.Size = new System.Drawing.Size(93, 22);
            this.txtSellCode.TabIndex = 1533;
            this.txtSellCode.Tag = "ncode";
            // 
            // txtCenter2
            // 
            this.txtCenter2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter2.Location = new System.Drawing.Point(132, 207);
            this.txtCenter2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter2.MaxLength = 30;
            this.txtCenter2.Name = "txtCenter2";
            this.txtCenter2.Size = new System.Drawing.Size(93, 22);
            this.txtCenter2.TabIndex = 359;
            this.txtCenter2.Tag = "ncode";
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtMbid.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.mtxtMbid.Location = new System.Drawing.Point(167, 77);
            this.mtxtMbid.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.Size = new System.Drawing.Size(164, 22);
            this.mtxtMbid.TabIndex = 326;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName.Location = new System.Drawing.Point(167, 114);
            this.txtName.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(164, 22);
            this.txtName.TabIndex = 1531;
            this.txtName.TabStop = false;
            this.txtName.Tag = "name";
            // 
            // mtxtSn
            // 
            this.mtxtSn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtSn.BackColor = System.Drawing.SystemColors.HighlightText;
            this.mtxtSn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtSn.Location = new System.Drawing.Point(167, 153);
            this.mtxtSn.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSn.Name = "mtxtSn";
            this.mtxtSn.ReadOnly = true;
            this.mtxtSn.Size = new System.Drawing.Size(164, 22);
            this.mtxtSn.TabIndex = 1532;
            this.mtxtSn.TabStop = false;
            // 
            // frmSell_Dev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1823, 1061);
            this.Controls.Add(this.mtxtSn);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.mtxtMbid);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.panel_Cacu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtCenter);
            this.Controls.Add(this.txtCenter_Code);
            this.Controls.Add(this.dGridView_Base_Cacu);
            this.Controls.Add(this.dGridView_Base);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Sugi_TF);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.chk_app);
            this.Controls.Add(this.labelControl110);
            this.Controls.Add(this.labelControl111);
            this.Controls.Add(this.txt_UnaccMoney);
            this.Controls.Add(this.labelControl104);
            this.Controls.Add(this.labelControl105);
            this.Controls.Add(this.txt_TotalInputPrice);
            this.Controls.Add(this.labelControl100);
            this.Controls.Add(this.labelControl101);
            this.Controls.Add(this.txt_SumMile);
            this.Controls.Add(this.labelControl96);
            this.Controls.Add(this.labelControl97);
            this.Controls.Add(this.txt_SumBank);
            this.Controls.Add(this.labelControl94);
            this.Controls.Add(this.labelControl95);
            this.Controls.Add(this.txt_SumCash);
            this.Controls.Add(this.labelControl90);
            this.Controls.Add(this.labelControl93);
            this.Controls.Add(this.txt_SumCard);
            this.Controls.Add(this.labelControl91);
            this.Controls.Add(this.labelControl92);
            this.Controls.Add(this.txt_Tel);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.layoutControl1);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.txt_C_Etc);
            this.Controls.Add(this.txt_AVC_Cash_Send_Nu);
            this.Controls.Add(this.txt_SalesItemIndex);
            this.Controls.Add(this.txt_C_index);
            this.Controls.Add(this.txt_AVC_Cash_Number2);
            this.Controls.Add(this.dGridView_Base_Mile);
            this.Controls.Add(this.dGridView_Base_Rece_Add);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSell_Dev";
            this.Text = "판매 등록";
            this.Load += new System.EventHandler(this.frmSell_Dev_Load);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Tel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ETC1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_InputPass_Pay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_OrderNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Ins_Number.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalPrice.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalPv.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SOrd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalCV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Ap_Num.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_B_Number.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Month.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Year.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Name_3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Card_Number.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_3_2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCard.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCash.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumBank.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumMile.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_TotalInputPrice.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_UnaccMoney.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Cacu)).EndInit();
            this.tableL_CD.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.tab_Cacu.ResumeLayout(false);
            this.tab_Card.ResumeLayout(false);
            this.tab_Card.PerformLayout();
            this.tab_Cash.ResumeLayout(false);
            this.tab_Cash.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Cash_Number2.Properties)).EndInit();
            this.tab_Bank.ResumeLayout(false);
            this.tab_Bank.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Bank.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_C_Name_2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_2.Properties)).EndInit();
            this.tab_VA_Bank.ResumeLayout(false);
            this.tab_VA_Bank.PerformLayout();
            this.tableLayoutPanel49.ResumeLayout(false);
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtBank.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_Number1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_VA_DEST_TEL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_Code.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_AV_C_AppDate1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Price_5_2.Properties)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pan_Rec_Item.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Item)).EndInit();
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Pass_Number.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Get_Etc1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddress1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Get_Name1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Mile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Rece_Add)).EndInit();
            this.panel_Cacu.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Item)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumCV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumPV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_SumPr.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ItemCount.Properties)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.LayoutControlGroup Root1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem12;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txt_Tel;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.SimpleButton butt_Ord_Clear;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit txt_ETC1;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.TextEdit txt_InputPass_Pay;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.TextEdit txt_OrderNumber;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit txt_Ins_Number;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.TextEdit txt_TotalPrice;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.TextEdit txt_TotalPv;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.TextEdit txt_SOrd;
        private DevExpress.XtraEditors.LabelControl labelControl33;
        private DevExpress.XtraEditors.LabelControl labelControl34;
        private DevExpress.XtraEditors.TextEdit txt_TotalCV;
        private DevExpress.XtraEditors.LabelControl labelControl35;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.TextEdit txt_C_Name_3;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.TextEdit txt_C_Card_Number;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.TextEdit txt_Price_3_2;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.TextEdit txt_Price_3;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.TextEdit txt_C_Card_Month;
        private DevExpress.XtraEditors.LabelControl labelControl80;
        private DevExpress.XtraEditors.TextEdit txt_C_Card_Year;
        private DevExpress.XtraEditors.LabelControl labelControl78;
        private DevExpress.XtraEditors.LabelControl labelControl79;
        private DevExpress.XtraEditors.LabelControl labelControl81;
        private DevExpress.XtraEditors.LabelControl labelControl82;
        private DevExpress.XtraEditors.TextEdit txt_C_B_Number;
        private DevExpress.XtraEditors.LabelControl labelControl85;
        private DevExpress.XtraEditors.LabelControl labelControl86;
        private DevExpress.XtraEditors.LabelControl labelControl83;
        private DevExpress.XtraEditors.SimpleButton button_Cancel;
        private DevExpress.XtraEditors.SimpleButton button_Ok;
        private DevExpress.XtraEditors.TextEdit txt_C_Card_Ap_Num;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private DevExpress.XtraEditors.LabelControl labelControl84;
        private System.Windows.Forms.ComboBox combo_C_Card_Per;
        private DevExpress.XtraEditors.LabelControl labelControl108;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private DevExpress.XtraEditors.TextEdit txt_SumCard;
        private DevExpress.XtraEditors.LabelControl labelControl91;
        private DevExpress.XtraEditors.LabelControl labelControl92;
        private DevExpress.XtraEditors.TextEdit txt_SumCash;
        private DevExpress.XtraEditors.LabelControl labelControl90;
        private DevExpress.XtraEditors.LabelControl labelControl93;
        private DevExpress.XtraEditors.TextEdit txt_SumBank;
        private DevExpress.XtraEditors.LabelControl labelControl94;
        private DevExpress.XtraEditors.LabelControl labelControl95;
        private DevExpress.XtraEditors.TextEdit txt_SumMile;
        private DevExpress.XtraEditors.LabelControl labelControl96;
        private DevExpress.XtraEditors.LabelControl labelControl97;
        private DevExpress.XtraEditors.TextEdit txt_TotalInputPrice;
        private DevExpress.XtraEditors.LabelControl labelControl100;
        private DevExpress.XtraEditors.LabelControl labelControl101;
        private DevExpress.XtraEditors.TextEdit txt_UnaccMoney;
        private DevExpress.XtraEditors.LabelControl labelControl104;
        private DevExpress.XtraEditors.LabelControl labelControl105;
        private DevExpress.XtraEditors.LabelControl labelControl110;
        private DevExpress.XtraEditors.LabelControl labelControl111;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckBox chk_app;
        private System.Windows.Forms.TextBox txt_Sugi_TF;
        private DevExpress.XtraEditors.SimpleButton butt_Cacu_Clear;
        private DevExpress.XtraEditors.SimpleButton butt_Cacu_Save;
        private DevExpress.XtraEditors.SimpleButton butt_Cacu_Del;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton radioB_CALL;
        private System.Windows.Forms.RadioButton radioB_DESK;
        private System.Windows.Forms.DataGridView dGridView_Base;
        private System.Windows.Forms.DataGridView dGridView_Base_Cacu;
        private System.Windows.Forms.TextBox txt_C_index;
        private System.Windows.Forms.TextBox txt_SalesItemIndex;
        private System.Windows.Forms.TextBox txtCenter;
        private System.Windows.Forms.TextBox txtCenter_Code;
        private System.Windows.Forms.TextBox txt_C_Card;
        private System.Windows.Forms.Button butt_Print;
        private System.Windows.Forms.ComboBox combo_C_Card_Year;
        private System.Windows.Forms.ComboBox combo_C_Card_Month;
        private System.Windows.Forms.TextBox txt_C_Etc;
        private System.Windows.Forms.TableLayoutPanel tableL_CD;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.TextBox txt_Price_CC;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtGetDate1;
        private System.Windows.Forms.TextBox txt_Base_Rec;
        private System.Windows.Forms.TextBox txt_Base_Rec_Code;
        private System.Windows.Forms.TabControl tab_Cacu;
        private System.Windows.Forms.TabPage tab_Card;
        private System.Windows.Forms.TabPage tab_Cash;
        private System.Windows.Forms.TabPage tab_Bank;
        private System.Windows.Forms.TabPage tab_VA_Bank;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.CheckBox check_Cash_Pre;
        private DevExpress.XtraEditors.LabelControl labelControl88;
        private DevExpress.XtraEditors.LabelControl labelControl89;
        private System.Windows.Forms.CheckBox check_Not_Cash;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txt_C_Cash_Number2_2;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txt_C_Cash_Send_Nu;
        private System.Windows.Forms.RadioButton radioB_C_Cash_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_C_Cash_Send_TF1;
        private System.Windows.Forms.CheckBox check_Cash;
        private DevExpress.XtraEditors.SimpleButton btn_CASH_OK;
        private DevExpress.XtraEditors.LabelControl labelControl98;
        private DevExpress.XtraEditors.LabelControl labelControl99;
        private DevExpress.XtraEditors.TextEdit txt_C_Cash_Number2;
        private DevExpress.XtraEditors.LabelControl labelControl102;
        private DevExpress.XtraEditors.LabelControl labelControl103;
        private DevExpress.XtraEditors.LabelControl labelControl106;
        private DevExpress.XtraEditors.LabelControl labelControl107;
        private DevExpress.XtraEditors.LabelControl labelControl87;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_C_Bank_Number2_2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_C_Bank_Send_Nu;
        private System.Windows.Forms.RadioButton radioB_C_Bank_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_C_Bank_Send_TF1;
        private DevExpress.XtraEditors.LabelControl labelControl113;
        private DevExpress.XtraEditors.LabelControl labelControl114;
        private DevExpress.XtraEditors.LabelControl labelControl115;
        private DevExpress.XtraEditors.LabelControl labelControl125;
        private DevExpress.XtraEditors.LabelControl labelControl126;
        private DevExpress.XtraEditors.TextEdit txt_C_Bank;
        private DevExpress.XtraEditors.LabelControl labelControl122;
        private DevExpress.XtraEditors.LabelControl labelControl123;
        private DevExpress.XtraEditors.LabelControl labelControl117;
        private DevExpress.XtraEditors.LabelControl labelControl118;
        private DevExpress.XtraEditors.LabelControl labelControl112;
        private DevExpress.XtraEditors.LabelControl labelControl120;
        private DevExpress.XtraEditors.LabelControl labelControl121;
        private DevExpress.XtraEditors.LabelControl labelControl124;
        private DevExpress.XtraEditors.TextEdit txt_C_Name_2;
        private DevExpress.XtraEditors.LabelControl labelControl127;
        private DevExpress.XtraEditors.LabelControl labelControl128;
        private DevExpress.XtraEditors.TextEdit txt_Price_2;
        private DevExpress.XtraEditors.LabelControl labelControl131;
        private DevExpress.XtraEditors.LabelControl labelControl132;
        private DevExpress.XtraEditors.TextEdit txt_AV_C_Number1;
        private DevExpress.XtraEditors.LabelControl labelControl142;
        private DevExpress.XtraEditors.LabelControl labelControl143;
        private System.Windows.Forms.Label label86;
        private DevExpress.XtraEditors.SimpleButton btnGetMemberHPTel;
        private DevExpress.XtraEditors.TextEdit txt_VA_DEST_TEL;
        private DevExpress.XtraEditors.LabelControl labelControl140;
        private DevExpress.XtraEditors.LabelControl labelControl141;
        private DevExpress.XtraEditors.TextEdit txt_AV_C_Code;
        private DevExpress.XtraEditors.LabelControl labelControl138;
        private DevExpress.XtraEditors.LabelControl labelControl139;
        private DevExpress.XtraEditors.TextEdit txt_AV_C_AppDate1;
        private DevExpress.XtraEditors.LabelControl labelControl136;
        private DevExpress.XtraEditors.LabelControl labelControl137;
        private DevExpress.XtraEditors.TextEdit txt_Price_5;
        private DevExpress.XtraEditors.LabelControl labelControl134;
        private DevExpress.XtraEditors.LabelControl labelControl135;
        private DevExpress.XtraEditors.TextEdit txt_Price_5_2;
        private DevExpress.XtraEditors.LabelControl labelControl130;
        private DevExpress.XtraEditors.LabelControl labelControl133;
        private DevExpress.XtraEditors.SimpleButton buttonV_Cancel;
        private DevExpress.XtraEditors.SimpleButton buttonV_Ok;
        private System.Windows.Forms.CheckBox check_Not_AVCash;
        private System.Windows.Forms.TextBox txt_Price_1;
        private System.Windows.Forms.TextBox txt_C_Card_Code;
        private DevExpress.XtraEditors.TextEdit txtBank;
        private DevExpress.XtraEditors.LabelControl labelControl109;
        private DevExpress.XtraEditors.LabelControl labelControl144;
        private System.Windows.Forms.TextBox txtBank_Code;
        private System.Windows.Forms.TextBox txt_AV_C_Number3;
        private System.Windows.Forms.TextBox txt_AVC_Cash_Send_Nu;
        private System.Windows.Forms.TextBox txt_AVC_Cash_Number2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton radioB_AVC_Cash_Send_TF2;
        private System.Windows.Forms.RadioButton radioB_AVC_Cash_Send_TF1;
        private System.Windows.Forms.CheckBox check_AVCash;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label lblSellCode_Code;
        private System.Windows.Forms.Label lblSellCode;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_ETC2;
        private System.Windows.Forms.TextBox txt_Receive_Method;
        private System.Windows.Forms.TextBox txt_Receive_Method_Code;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chk_Total;
        private System.Windows.Forms.Panel pan_Rec_Item;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece_Item;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.RadioButton opt_Rec_Add2;
        private System.Windows.Forms.RadioButton opt_Rec_Add1;
        private DevExpress.XtraEditors.SimpleButton butt_Rec_Clear;
        private DevExpress.XtraEditors.SimpleButton butt_Rec_Save;
        private DevExpress.XtraEditors.SimpleButton butt_Rec_Del;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.TextEdit txt_Pass_Number;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.TextEdit txt_Get_Etc1;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.TextEdit txtAddress2;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.TextEdit txtAddress1;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.SimpleButton butt_Rec_Add;
        private DevExpress.XtraEditors.SimpleButton butt_AddCode;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.TextEdit txt_Get_Name1;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private System.Windows.Forms.TextBox txt_RecIndex;
        private System.Windows.Forms.DataGridView dGridView_Base_Mile;
        private System.Windows.Forms.DataGridView dGridView_Base_Rece_Add;
        private System.Windows.Forms.TextBox txt_C_P_Number;
        private System.Windows.Forms.Panel panel_Cacu;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txt_ItemCode;
        private System.Windows.Forms.TextBox txt_ItemName;
        private System.Windows.Forms.DataGridView dGridView_Base_Item;
        private DevExpress.XtraEditors.TextEdit txt_SumCV;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.TextEdit txt_SumPV;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.TextEdit txt_SumPr;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.SimpleButton butt_Item_Clear;
        private DevExpress.XtraEditors.SimpleButton butt_Item_Save;
        private DevExpress.XtraEditors.SimpleButton butt_Item_Del;
        private DevExpress.XtraEditors.TextEdit txt_ItemCount;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private System.Windows.Forms.TextBox txt_Item_Etc;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_SumCnt;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate3;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate3;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate2;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate2;
        private System.Windows.Forms.MaskedTextBox mtxtPriceDate1;
        private System.Windows.Forms.DateTimePicker DTP_PriceDate1;
        private System.Windows.Forms.MaskedTextBox mtxtTel1;
        private System.Windows.Forms.MaskedTextBox mtxtTel2;
        private System.Windows.Forms.MaskedTextBox mtxtZip1;
        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.MaskedTextBox mtxtSn;
        private System.Windows.Forms.Button butt_Delete;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private System.Windows.Forms.TextBox txt_C_Bank_Code;
        private System.Windows.Forms.TextBox txt_C_Bank_Code_2;
        private System.Windows.Forms.TextBox txt_C_Bank_Code_3;
        private System.Windows.Forms.TextBox txtCenter2_Code;
        private System.Windows.Forms.TextBox txtCenter2;
        private System.Windows.Forms.TextBox txtSellCode_Code;
        private System.Windows.Forms.TextBox txtSellCode;
        private System.Windows.Forms.Button butt_Exit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private System.Windows.Forms.Button butt_Save;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private System.Windows.Forms.Button butt_Clear;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
    }
}