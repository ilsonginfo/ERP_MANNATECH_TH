﻿namespace MLM_Program
{
    partial class frmClose_4_Select_03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dGridCtrl_Base = new DevExpress.XtraGrid.GridControl();
            this.dGridView_Base = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.dGridView_Base_Sum = new System.Windows.Forms.DataGridView();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tab_Detail_02 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_1 = new System.Windows.Forms.DataGridView();
            this.tab_Dir = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_5 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_2 = new System.Windows.Forms.DataGridView();
            this.tab_save = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_3 = new System.Windows.Forms.DataGridView();
            this.tab_nom = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_4 = new System.Windows.Forms.DataGridView();
            this.tab_etc = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.txt_ETC11 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txt_ETC10 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.txt_ETC9 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.txt_ETC8 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txt_ETC7 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txt_ETC6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.txt_ETC5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txt_ETC4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txt_ETC3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_ETC2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txt_ETC1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tab_Detail_01 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_1 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_2 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_2 = new System.Windows.Forms.Button();
            this.tab_Save_D = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_3 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_3 = new System.Windows.Forms.Button();
            this.tab_Up = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_4 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_G = new System.Windows.Forms.DataGridView();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.checkB_150 = new System.Windows.Forms.CheckBox();
            this.checkB_140 = new System.Windows.Forms.CheckBox();
            this.checkB_10 = new System.Windows.Forms.CheckBox();
            this.checkB_110 = new System.Windows.Forms.CheckBox();
            this.checkB_100 = new System.Windows.Forms.CheckBox();
            this.checkB_130 = new System.Windows.Forms.CheckBox();
            this.checkB_90 = new System.Windows.Forms.CheckBox();
            this.checkB_120 = new System.Windows.Forms.CheckBox();
            this.checkB_80 = new System.Windows.Forms.CheckBox();
            this.checkB_70 = new System.Windows.Forms.CheckBox();
            this.checkB_60 = new System.Windows.Forms.CheckBox();
            this.checkB_50 = new System.Windows.Forms.CheckBox();
            this.checkB_40 = new System.Windows.Forms.CheckBox();
            this.checkB_30 = new System.Windows.Forms.CheckBox();
            this.checkB_Up = new System.Windows.Forms.RadioButton();
            this.combo_Grade2_Code = new System.Windows.Forms.ComboBox();
            this.combo_Grade2 = new System.Windows.Forms.ComboBox();
            this.checkB_Up_60 = new System.Windows.Forms.CheckBox();
            this.checkB_20 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.radio_PayTF_Re_D_2 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_Re_D_1 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_ALL = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_Not = new System.Windows.Forms.RadioButton();
            this.radio_PayTF3 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF2 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF1 = new System.Windows.Forms.RadioButton();
            this.label34 = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.checkB_E_31 = new System.Windows.Forms.RadioButton();
            this.checkB_E_30 = new System.Windows.Forms.RadioButton();
            this.checkB_E_1 = new System.Windows.Forms.RadioButton();
            this.label21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.combo_CGrade_Code = new System.Windows.Forms.ComboBox();
            this.combo_CGrade = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txt_Us_num = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.mtxtPayDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtPayDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DTP_PayDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_PayDate1 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.txtCenter_Code = new System.Windows.Forms.TextBox();
            this.txtCenter = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.txtToEndDate_Code = new System.Windows.Forms.TextBox();
            this.txtToEndDate = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.combo_Grade_Code = new System.Windows.Forms.ComboBox();
            this.combo_Grade = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.mtxtToDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtToDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.DTP_ToDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_ToDate1 = new System.Windows.Forms.DateTimePicker();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.mtxtFromDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtFromDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.DTP_FromDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_FromDate1 = new System.Windows.Forms.DateTimePicker();
            this.label43 = new System.Windows.Forms.Label();
            this.grB_Search = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.mtxtMbid2 = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioB_P = new System.Windows.Forms.RadioButton();
            this.radioB_PM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_PM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_PM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_P_7 = new System.Windows.Forms.RadioButton();
            this.radioB_P_1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioB_S = new System.Windows.Forms.RadioButton();
            this.radioB_SM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_S_7 = new System.Windows.Forms.RadioButton();
            this.radioB_S_1 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioB_R = new System.Windows.Forms.RadioButton();
            this.radioB_RM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_R_7 = new System.Windows.Forms.RadioButton();
            this.radioB_R_1 = new System.Windows.Forms.RadioButton();
            this.button_base = new System.Windows.Forms.Button();
            this.butt_Exp = new System.Windows.Forms.Button();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.pn_Button = new System.Windows.Forms.Panel();
            this.butt_Excel = new System.Windows.Forms.Button();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Select = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            this.panel44 = new System.Windows.Forms.Panel();
            this.radioB_Mi_No = new System.Windows.Forms.RadioButton();
            this.radioB_Mi = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.prB = new System.Windows.Forms.ProgressBar();
            this.label32 = new System.Windows.Forms.Label();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.mtxtSellDate = new System.Windows.Forms.MaskedTextBox();
            this.DTP_SellDate = new System.Windows.Forms.DateTimePicker();
            this.label33 = new System.Windows.Forms.Label();
            this.butt_Save = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.chk_Total = new System.Windows.Forms.CheckBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.radioB_Su_Not = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioB_Su = new System.Windows.Forms.RadioButton();
            this.label29 = new System.Windows.Forms.Label();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.radioB_Leave = new System.Windows.Forms.RadioButton();
            this.radioB_Leave_Not = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.chk_Leave_Only = new System.Windows.Forms.CheckBox();
            this.chk_Leave = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dGridCtrl_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sum)).BeginInit();
            this.panel9.SuspendLayout();
            this.tab_Detail_02.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_1)).BeginInit();
            this.tab_Dir.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_5)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_2)).BeginInit();
            this.tab_save.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_3)).BeginInit();
            this.tab_nom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_4)).BeginInit();
            this.tab_etc.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.panel23.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.panel18.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tab_Detail_01.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_2)).BeginInit();
            this.tab_Save_D.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_3)).BeginInit();
            this.tab_Up.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_4)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_G)).BeginInit();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.panel32.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.panel31.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.panel28.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.panel29.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.panel33.SuspendLayout();
            this.grB_Search.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.panel35.SuspendLayout();
            this.pn_Button.SuspendLayout();
            this.panel44.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.panel43.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.panel42.SuspendLayout();
            this.SuspendLayout();
            // 
            // dGridCtrl_Base
            // 
            this.dGridCtrl_Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridCtrl_Base.Location = new System.Drawing.Point(190, 0);
            this.dGridCtrl_Base.MainView = this.dGridView_Base;
            this.dGridCtrl_Base.Name = "dGridCtrl_Base";
            this.dGridCtrl_Base.Size = new System.Drawing.Size(1498, 451);
            this.dGridCtrl_Base.TabIndex = 13;
            this.dGridCtrl_Base.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.dGridView_Base});
            // 
            // dGridView_Base
            // 
            this.dGridView_Base.GridControl = this.dGridCtrl_Base;
            this.dGridView_Base.IndicatorWidth = 35;
            this.dGridView_Base.Name = "dGridView_Base";
            this.dGridView_Base.OptionsBehavior.AutoSelectAllInEditor = false;
            this.dGridView_Base.OptionsBehavior.Editable = false;
            this.dGridView_Base.OptionsBehavior.ReadOnly = true;
            this.dGridView_Base.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.dGridView_Base_CustomDrawRowIndicator);
            this.dGridView_Base.DoubleClick += new System.EventHandler(this.dGridView_Base_DoubleClick_2);
            // 
            // dGridView_Base_Sum
            // 
            this.dGridView_Base_Sum.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Sum.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Sum.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dGridView_Base_Sum.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Sum.DefaultCellStyle = dataGridViewCellStyle2;
            this.dGridView_Base_Sum.Dock = System.Windows.Forms.DockStyle.Left;
            this.dGridView_Base_Sum.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Sum.Location = new System.Drawing.Point(0, 0);
            this.dGridView_Base_Sum.Name = "dGridView_Base_Sum";
            this.dGridView_Base_Sum.RowTemplate.Height = 23;
            this.dGridView_Base_Sum.Size = new System.Drawing.Size(190, 451);
            this.dGridView_Base_Sum.TabIndex = 11;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tab_Detail_02);
            this.panel9.Controls.Add(this.tab_Detail_01);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(0, 481);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1688, 276);
            this.panel9.TabIndex = 12;
            // 
            // tab_Detail_02
            // 
            this.tab_Detail_02.Controls.Add(this.tabPage3);
            this.tab_Detail_02.Controls.Add(this.tab_Dir);
            this.tab_Detail_02.Controls.Add(this.tabPage4);
            this.tab_Detail_02.Controls.Add(this.tab_save);
            this.tab_Detail_02.Controls.Add(this.tab_nom);
            this.tab_Detail_02.Controls.Add(this.tab_etc);
            this.tab_Detail_02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Detail_02.Location = new System.Drawing.Point(760, 0);
            this.tab_Detail_02.Name = "tab_Detail_02";
            this.tab_Detail_02.SelectedIndex = 0;
            this.tab_Detail_02.Size = new System.Drawing.Size(928, 276);
            this.tab_Detail_02.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dGridView_Detail_1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(920, 250);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "본인매출";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_1
            // 
            this.dGridView_Detail_1.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGridView_Detail_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGridView_Detail_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_1.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_1.Name = "dGridView_Detail_1";
            this.dGridView_Detail_1.RowTemplate.Height = 23;
            this.dGridView_Detail_1.Size = new System.Drawing.Size(914, 244);
            this.dGridView_Detail_1.TabIndex = 13;
            // 
            // tab_Dir
            // 
            this.tab_Dir.Controls.Add(this.dGridView_Detail_5);
            this.tab_Dir.Location = new System.Drawing.Point(4, 22);
            this.tab_Dir.Name = "tab_Dir";
            this.tab_Dir.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Dir.Size = new System.Drawing.Size(654, 250);
            this.tab_Dir.TabIndex = 5;
            this.tab_Dir.Text = "직후원내역";
            this.tab_Dir.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_5
            // 
            this.dGridView_Detail_5.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dGridView_Detail_5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_5.DefaultCellStyle = dataGridViewCellStyle6;
            this.dGridView_Detail_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_5.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_5.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_5.Name = "dGridView_Detail_5";
            this.dGridView_Detail_5.RowTemplate.Height = 23;
            this.dGridView_Detail_5.Size = new System.Drawing.Size(648, 244);
            this.dGridView_Detail_5.TabIndex = 15;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dGridView_Detail_2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(654, 250);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "하선그룹매출";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_2
            // 
            this.dGridView_Detail_2.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dGridView_Detail_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_2.DefaultCellStyle = dataGridViewCellStyle8;
            this.dGridView_Detail_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_2.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_2.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_2.Name = "dGridView_Detail_2";
            this.dGridView_Detail_2.RowTemplate.Height = 23;
            this.dGridView_Detail_2.Size = new System.Drawing.Size(648, 244);
            this.dGridView_Detail_2.TabIndex = 14;
            // 
            // tab_save
            // 
            this.tab_save.Controls.Add(this.dGridView_Detail_3);
            this.tab_save.Location = new System.Drawing.Point(4, 22);
            this.tab_save.Name = "tab_save";
            this.tab_save.Padding = new System.Windows.Forms.Padding(3);
            this.tab_save.Size = new System.Drawing.Size(654, 250);
            this.tab_save.TabIndex = 2;
            this.tab_save.Text = "후원역추적";
            this.tab_save.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_3
            // 
            this.dGridView_Detail_3.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dGridView_Detail_3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_3.DefaultCellStyle = dataGridViewCellStyle10;
            this.dGridView_Detail_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_3.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_3.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_3.Name = "dGridView_Detail_3";
            this.dGridView_Detail_3.RowTemplate.Height = 23;
            this.dGridView_Detail_3.Size = new System.Drawing.Size(648, 244);
            this.dGridView_Detail_3.TabIndex = 14;
            // 
            // tab_nom
            // 
            this.tab_nom.Controls.Add(this.dGridView_Detail_4);
            this.tab_nom.Location = new System.Drawing.Point(4, 22);
            this.tab_nom.Name = "tab_nom";
            this.tab_nom.Padding = new System.Windows.Forms.Padding(3);
            this.tab_nom.Size = new System.Drawing.Size(654, 250);
            this.tab_nom.TabIndex = 3;
            this.tab_nom.Text = "추천역추적";
            this.tab_nom.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_4
            // 
            this.dGridView_Detail_4.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dGridView_Detail_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_4.DefaultCellStyle = dataGridViewCellStyle12;
            this.dGridView_Detail_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_4.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_4.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_4.Name = "dGridView_Detail_4";
            this.dGridView_Detail_4.RowTemplate.Height = 23;
            this.dGridView_Detail_4.Size = new System.Drawing.Size(648, 244);
            this.dGridView_Detail_4.TabIndex = 14;
            // 
            // tab_etc
            // 
            this.tab_etc.BackColor = System.Drawing.SystemColors.Control;
            this.tab_etc.Controls.Add(this.tableLayoutPanel15);
            this.tab_etc.Controls.Add(this.tableLayoutPanel17);
            this.tab_etc.Controls.Add(this.tableLayoutPanel13);
            this.tab_etc.Controls.Add(this.tableLayoutPanel14);
            this.tab_etc.Controls.Add(this.tableLayoutPanel12);
            this.tab_etc.Controls.Add(this.tableLayoutPanel9);
            this.tab_etc.Controls.Add(this.tableLayoutPanel11);
            this.tab_etc.Controls.Add(this.tableLayoutPanel5);
            this.tab_etc.Controls.Add(this.tableLayoutPanel10);
            this.tab_etc.Controls.Add(this.tableLayoutPanel3);
            this.tab_etc.Controls.Add(this.tableLayoutPanel16);
            this.tab_etc.Location = new System.Drawing.Point(4, 22);
            this.tab_etc.Name = "tab_etc";
            this.tab_etc.Size = new System.Drawing.Size(654, 250);
            this.tab_etc.TabIndex = 4;
            this.tab_etc.Text = "기타";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.panel22, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(695, 119);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel15.TabIndex = 266;
            this.tableLayoutPanel15.Visible = false;
            // 
            // panel22
            // 
            this.panel22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Controls.Add(this.txt_ETC11);
            this.panel22.Location = new System.Drawing.Point(126, 4);
            this.panel22.Margin = new System.Windows.Forms.Padding(2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(117, 28);
            this.panel22.TabIndex = 15;
            // 
            // txt_ETC11
            // 
            this.txt_ETC11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC11.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC11.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC11.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC11.MaxLength = 30;
            this.txt_ETC11.Name = "txt_ETC11";
            this.txt_ETC11.ReadOnly = true;
            this.txt_ETC11.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC11.TabIndex = 190;
            this.txt_ETC11.TabStop = false;
            this.txt_ETC11.Tag = "";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(2, 2);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 32);
            this.label17.TabIndex = 0;
            this.label17.Text = "총누적B";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.panel23, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(695, 83);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel17.TabIndex = 265;
            this.tableLayoutPanel17.Visible = false;
            // 
            // panel23
            // 
            this.panel23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.txt_ETC10);
            this.panel23.Location = new System.Drawing.Point(126, 4);
            this.panel23.Margin = new System.Windows.Forms.Padding(2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(117, 28);
            this.panel23.TabIndex = 15;
            // 
            // txt_ETC10
            // 
            this.txt_ETC10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC10.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC10.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC10.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC10.MaxLength = 30;
            this.txt_ETC10.Name = "txt_ETC10";
            this.txt_ETC10.ReadOnly = true;
            this.txt_ETC10.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC10.TabIndex = 190;
            this.txt_ETC10.TabStop = false;
            this.txt_ETC10.Tag = "";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(2, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 32);
            this.label18.TabIndex = 0;
            this.label18.Text = "총누적A";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.panel20, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(251, 39);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel13.TabIndex = 264;
            // 
            // panel20
            // 
            this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Controls.Add(this.txt_ETC9);
            this.panel20.Location = new System.Drawing.Point(126, 4);
            this.panel20.Margin = new System.Windows.Forms.Padding(2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(117, 28);
            this.panel20.TabIndex = 15;
            // 
            // txt_ETC9
            // 
            this.txt_ETC9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC9.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC9.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC9.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC9.MaxLength = 30;
            this.txt_ETC9.Name = "txt_ETC9";
            this.txt_ETC9.ReadOnly = true;
            this.txt_ETC9.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC9.TabIndex = 190;
            this.txt_ETC9.TabStop = false;
            this.txt_ETC9.Tag = "";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "크라운 연속횟수";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.panel21, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(251, 3);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel14.TabIndex = 263;
            // 
            // panel21
            // 
            this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Controls.Add(this.txt_ETC8);
            this.panel21.Location = new System.Drawing.Point(126, 4);
            this.panel21.Margin = new System.Windows.Forms.Padding(2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(117, 28);
            this.panel21.TabIndex = 15;
            // 
            // txt_ETC8
            // 
            this.txt_ETC8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC8.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC8.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC8.MaxLength = 30;
            this.txt_ETC8.Name = "txt_ETC8";
            this.txt_ETC8.ReadOnly = true;
            this.txt_ETC8.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC8.TabIndex = 190;
            this.txt_ETC8.TabStop = false;
            this.txt_ETC8.Tag = "";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(2, 2);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 32);
            this.label15.TabIndex = 0;
            this.label15.Text = "다이아 연속횟수";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(4, 74);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel12.TabIndex = 262;
            // 
            // panel19
            // 
            this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.txt_ETC7);
            this.panel19.Location = new System.Drawing.Point(126, 4);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(117, 28);
            this.panel19.TabIndex = 15;
            // 
            // txt_ETC7
            // 
            this.txt_ETC7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC7.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC7.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC7.MaxLength = 30;
            this.txt_ETC7.Name = "txt_ETC7";
            this.txt_ETC7.ReadOnly = true;
            this.txt_ETC7.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC7.TabIndex = 190;
            this.txt_ETC7.TabStop = false;
            this.txt_ETC7.Tag = "";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 32);
            this.label11.TabIndex = 0;
            this.label11.Text = "에메랄드 연속횟수";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.panel17, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(4, 39);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel9.TabIndex = 261;
            // 
            // panel17
            // 
            this.panel17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.txt_ETC6);
            this.panel17.Location = new System.Drawing.Point(126, 4);
            this.panel17.Margin = new System.Windows.Forms.Padding(2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(117, 28);
            this.panel17.TabIndex = 15;
            // 
            // txt_ETC6
            // 
            this.txt_ETC6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC6.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC6.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC6.MaxLength = 30;
            this.txt_ETC6.Name = "txt_ETC6";
            this.txt_ETC6.ReadOnly = true;
            this.txt_ETC6.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC6.TabIndex = 190;
            this.txt_ETC6.TabStop = false;
            this.txt_ETC6.Tag = "";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 32);
            this.label9.TabIndex = 0;
            this.label9.Text = "루비 연속횟수";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.panel18, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(4, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel11.TabIndex = 260;
            // 
            // panel18
            // 
            this.panel18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Controls.Add(this.txt_ETC5);
            this.panel18.Location = new System.Drawing.Point(126, 4);
            this.panel18.Margin = new System.Windows.Forms.Padding(2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(117, 28);
            this.panel18.TabIndex = 15;
            // 
            // txt_ETC5
            // 
            this.txt_ETC5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC5.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC5.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC5.MaxLength = 30;
            this.txt_ETC5.Name = "txt_ETC5";
            this.txt_ETC5.ReadOnly = true;
            this.txt_ETC5.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC5.TabIndex = 190;
            this.txt_ETC5.TabStop = false;
            this.txt_ETC5.Tag = "";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 2);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 32);
            this.label10.TabIndex = 0;
            this.label10.Text = "플래티넘 연속횟수";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(307, 163);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel5.TabIndex = 259;
            this.tableLayoutPanel5.Visible = false;
            // 
            // panel15
            // 
            this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.txt_ETC4);
            this.panel15.Location = new System.Drawing.Point(126, 4);
            this.panel15.Margin = new System.Windows.Forms.Padding(2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(195, 28);
            this.panel15.TabIndex = 15;
            // 
            // txt_ETC4
            // 
            this.txt_ETC4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC4.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC4.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC4.MaxLength = 30;
            this.txt_ETC4.Name = "txt_ETC4";
            this.txt_ETC4.ReadOnly = true;
            this.txt_ETC4.Size = new System.Drawing.Size(189, 22);
            this.txt_ETC4.TabIndex = 190;
            this.txt_ETC4.TabStop = false;
            this.txt_ETC4.Tag = "";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "골드B";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(307, 126);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel10.TabIndex = 258;
            this.tableLayoutPanel10.Visible = false;
            // 
            // panel16
            // 
            this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.txt_ETC3);
            this.panel16.Location = new System.Drawing.Point(126, 4);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(195, 28);
            this.panel16.TabIndex = 15;
            // 
            // txt_ETC3
            // 
            this.txt_ETC3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC3.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC3.MaxLength = 30;
            this.txt_ETC3.Name = "txt_ETC3";
            this.txt_ETC3.ReadOnly = true;
            this.txt_ETC3.Size = new System.Drawing.Size(189, 22);
            this.txt_ETC3.TabIndex = 190;
            this.txt_ETC3.TabStop = false;
            this.txt_ETC3.Tag = "";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 32);
            this.label6.TabIndex = 0;
            this.label6.Text = "골드A";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel13, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(695, 197);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel3.TabIndex = 257;
            this.tableLayoutPanel3.Visible = false;
            // 
            // panel13
            // 
            this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.txt_ETC2);
            this.panel13.Location = new System.Drawing.Point(126, 4);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(117, 28);
            this.panel13.TabIndex = 15;
            // 
            // txt_ETC2
            // 
            this.txt_ETC2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC2.MaxLength = 30;
            this.txt_ETC2.Name = "txt_ETC2";
            this.txt_ETC2.ReadOnly = true;
            this.txt_ETC2.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC2.TabIndex = 190;
            this.txt_ETC2.TabStop = false;
            this.txt_ETC2.Tag = "";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "당마감누적B";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(695, 161);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel16.TabIndex = 256;
            this.tableLayoutPanel16.Visible = false;
            // 
            // panel14
            // 
            this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.txt_ETC1);
            this.panel14.Location = new System.Drawing.Point(126, 4);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(117, 28);
            this.panel14.TabIndex = 15;
            // 
            // txt_ETC1
            // 
            this.txt_ETC1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC1.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC1.MaxLength = 30;
            this.txt_ETC1.Name = "txt_ETC1";
            this.txt_ETC1.ReadOnly = true;
            this.txt_ETC1.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC1.TabIndex = 190;
            this.txt_ETC1.TabStop = false;
            this.txt_ETC1.Tag = "";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(2, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 32);
            this.label16.TabIndex = 0;
            this.label16.Text = "당마감누적A";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Detail_01
            // 
            this.tab_Detail_01.Controls.Add(this.tabPage1);
            this.tab_Detail_01.Controls.Add(this.tabPage2);
            this.tab_Detail_01.Controls.Add(this.tab_Save_D);
            this.tab_Detail_01.Controls.Add(this.tab_Up);
            this.tab_Detail_01.Controls.Add(this.tabPage5);
            this.tab_Detail_01.Dock = System.Windows.Forms.DockStyle.Left;
            this.tab_Detail_01.Location = new System.Drawing.Point(0, 0);
            this.tab_Detail_01.Name = "tab_Detail_01";
            this.tab_Detail_01.SelectedIndex = 0;
            this.tab_Detail_01.Size = new System.Drawing.Size(760, 276);
            this.tab_Detail_01.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dGridView_Pay_1);
            this.tabPage1.Controls.Add(this.butt_Excel_Pay_1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(752, 250);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "센터보너스";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_1
            // 
            this.dGridView_Pay_1.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dGridView_Pay_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_1.DefaultCellStyle = dataGridViewCellStyle14;
            this.dGridView_Pay_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_1.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_1.Name = "dGridView_Pay_1";
            this.dGridView_Pay_1.RowTemplate.Height = 23;
            this.dGridView_Pay_1.Size = new System.Drawing.Size(746, 218);
            this.dGridView_Pay_1.TabIndex = 12;
            // 
            // butt_Excel_Pay_1
            // 
            this.butt_Excel_Pay_1.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_1.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_1.Name = "butt_Excel_Pay_1";
            this.butt_Excel_Pay_1.Size = new System.Drawing.Size(746, 26);
            this.butt_Excel_Pay_1.TabIndex = 150;
            this.butt_Excel_Pay_1.TabStop = false;
            this.butt_Excel_Pay_1.Text = "Excel";
            this.butt_Excel_Pay_1.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_1.Click += new System.EventHandler(this.butt_Excel_Pay_1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dGridView_Pay_2);
            this.tabPage2.Controls.Add(this.butt_Excel_Pay_2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(752, 250);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "추천기간하선판매";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_2
            // 
            this.dGridView_Pay_2.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dGridView_Pay_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_2.DefaultCellStyle = dataGridViewCellStyle16;
            this.dGridView_Pay_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_2.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_2.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_2.Name = "dGridView_Pay_2";
            this.dGridView_Pay_2.RowTemplate.Height = 23;
            this.dGridView_Pay_2.Size = new System.Drawing.Size(746, 218);
            this.dGridView_Pay_2.TabIndex = 12;
            // 
            // butt_Excel_Pay_2
            // 
            this.butt_Excel_Pay_2.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_2.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_2.Name = "butt_Excel_Pay_2";
            this.butt_Excel_Pay_2.Size = new System.Drawing.Size(746, 26);
            this.butt_Excel_Pay_2.TabIndex = 150;
            this.butt_Excel_Pay_2.TabStop = false;
            this.butt_Excel_Pay_2.Text = "Excel";
            this.butt_Excel_Pay_2.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_2.Click += new System.EventHandler(this.butt_Excel_Pay_2_Click);
            // 
            // tab_Save_D
            // 
            this.tab_Save_D.Controls.Add(this.dGridView_Pay_3);
            this.tab_Save_D.Controls.Add(this.butt_Excel_Pay_3);
            this.tab_Save_D.Location = new System.Drawing.Point(4, 22);
            this.tab_Save_D.Name = "tab_Save_D";
            this.tab_Save_D.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Save_D.Size = new System.Drawing.Size(752, 250);
            this.tab_Save_D.TabIndex = 2;
            this.tab_Save_D.Text = "후원기간하선판매";
            this.tab_Save_D.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_3
            // 
            this.dGridView_Pay_3.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dGridView_Pay_3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_3.DefaultCellStyle = dataGridViewCellStyle18;
            this.dGridView_Pay_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_3.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_3.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_3.Name = "dGridView_Pay_3";
            this.dGridView_Pay_3.RowTemplate.Height = 23;
            this.dGridView_Pay_3.Size = new System.Drawing.Size(746, 218);
            this.dGridView_Pay_3.TabIndex = 13;
            // 
            // butt_Excel_Pay_3
            // 
            this.butt_Excel_Pay_3.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_3.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_3.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_3.Name = "butt_Excel_Pay_3";
            this.butt_Excel_Pay_3.Size = new System.Drawing.Size(746, 26);
            this.butt_Excel_Pay_3.TabIndex = 151;
            this.butt_Excel_Pay_3.TabStop = false;
            this.butt_Excel_Pay_3.Text = "Excel";
            this.butt_Excel_Pay_3.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_3.Click += new System.EventHandler(this.butt_Excel_Pay_3_Click);
            // 
            // tab_Up
            // 
            this.tab_Up.Controls.Add(this.dGridView_Pay_4);
            this.tab_Up.Location = new System.Drawing.Point(4, 22);
            this.tab_Up.Name = "tab_Up";
            this.tab_Up.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Up.Size = new System.Drawing.Size(752, 250);
            this.tab_Up.TabIndex = 3;
            this.tab_Up.Text = "판매_역추적";
            this.tab_Up.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_4
            // 
            this.dGridView_Pay_4.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dGridView_Pay_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_4.DefaultCellStyle = dataGridViewCellStyle20;
            this.dGridView_Pay_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_4.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_4.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Pay_4.Name = "dGridView_Pay_4";
            this.dGridView_Pay_4.RowTemplate.Height = 23;
            this.dGridView_Pay_4.Size = new System.Drawing.Size(746, 244);
            this.dGridView_Pay_4.TabIndex = 13;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dGridView_Pay_G);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(752, 250);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "기간직추액티브인원";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_G
            // 
            this.dGridView_Pay_G.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_G.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_G.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dGridView_Pay_G.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_G.DefaultCellStyle = dataGridViewCellStyle22;
            this.dGridView_Pay_G.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_G.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_G.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Pay_G.Name = "dGridView_Pay_G";
            this.dGridView_Pay_G.RowTemplate.Height = 23;
            this.dGridView_Pay_G.Size = new System.Drawing.Size(746, 244);
            this.dGridView_Pay_G.TabIndex = 13;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.tableLayoutPanel28);
            this.panel12.Controls.Add(this.tableLayoutPanel23);
            this.panel12.Controls.Add(this.tableLayoutPanel21);
            this.panel12.Controls.Add(this.tableLayoutPanel29);
            this.panel12.Controls.Add(this.tableLayoutPanel20);
            this.panel12.Controls.Add(this.tableLayoutPanel19);
            this.panel12.Controls.Add(this.tableLayoutPanel18);
            this.panel12.Controls.Add(this.tableLayoutPanel2);
            this.panel12.Controls.Add(this.tableLayoutPanel30);
            this.panel12.Controls.Add(this.tableLayoutPanel31);
            this.panel12.Controls.Add(this.tableLayoutPanel32);
            this.panel12.Controls.Add(this.tableLayoutPanel33);
            this.panel12.Controls.Add(this.tableLayoutPanel36);
            this.panel12.Controls.Add(this.grB_Search);
            this.panel12.Controls.Add(this.tableLayoutPanel37);
            this.panel12.Controls.Add(this.tableLayoutPanel38);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 28);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1690, 113);
            this.panel12.TabIndex = 0;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.panel32, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(350, 76);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(1126, 36);
            this.tableLayoutPanel21.TabIndex = 18;
            // 
            // panel32
            // 
            this.panel32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Controls.Add(this.checkB_150);
            this.panel32.Controls.Add(this.checkB_140);
            this.panel32.Controls.Add(this.checkB_10);
            this.panel32.Controls.Add(this.checkB_110);
            this.panel32.Controls.Add(this.checkB_100);
            this.panel32.Controls.Add(this.checkB_130);
            this.panel32.Controls.Add(this.checkB_90);
            this.panel32.Controls.Add(this.checkB_120);
            this.panel32.Controls.Add(this.checkB_80);
            this.panel32.Controls.Add(this.checkB_70);
            this.panel32.Controls.Add(this.checkB_60);
            this.panel32.Controls.Add(this.checkB_50);
            this.panel32.Controls.Add(this.checkB_40);
            this.panel32.Controls.Add(this.checkB_30);
            this.panel32.Controls.Add(this.checkB_Up);
            this.panel32.Controls.Add(this.combo_Grade2_Code);
            this.panel32.Controls.Add(this.combo_Grade2);
            this.panel32.Controls.Add(this.checkB_Up_60);
            this.panel32.Controls.Add(this.checkB_20);
            this.panel32.Location = new System.Drawing.Point(91, 4);
            this.panel32.Margin = new System.Windows.Forms.Padding(2);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(1031, 28);
            this.panel32.TabIndex = 15;
            // 
            // checkB_150
            // 
            this.checkB_150.AutoSize = true;
            this.checkB_150.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_150.ForeColor = System.Drawing.Color.Black;
            this.checkB_150.Location = new System.Drawing.Point(957, 6);
            this.checkB_150.Name = "checkB_150";
            this.checkB_150.Size = new System.Drawing.Size(72, 16);
            this.checkB_150.TabIndex = 218;
            this.checkB_150.Text = "임페리얼";
            this.checkB_150.UseVisualStyleBackColor = true;
            // 
            // checkB_140
            // 
            this.checkB_140.AutoSize = true;
            this.checkB_140.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_140.ForeColor = System.Drawing.Color.Black;
            this.checkB_140.Location = new System.Drawing.Point(897, 6);
            this.checkB_140.Name = "checkB_140";
            this.checkB_140.Size = new System.Drawing.Size(60, 16);
            this.checkB_140.TabIndex = 217;
            this.checkB_140.Text = "크라운";
            this.checkB_140.UseVisualStyleBackColor = true;
            // 
            // checkB_10
            // 
            this.checkB_10.AutoSize = true;
            this.checkB_10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_10.ForeColor = System.Drawing.Color.Black;
            this.checkB_10.Location = new System.Drawing.Point(99, 6);
            this.checkB_10.Name = "checkB_10";
            this.checkB_10.Size = new System.Drawing.Size(54, 16);
            this.checkB_10.TabIndex = 216;
            this.checkB_10.Text = "1스타";
            this.checkB_10.UseVisualStyleBackColor = true;
            // 
            // checkB_110
            // 
            this.checkB_110.AutoSize = true;
            this.checkB_110.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_110.ForeColor = System.Drawing.Color.Black;
            this.checkB_110.Location = new System.Drawing.Point(669, 6);
            this.checkB_110.Name = "checkB_110";
            this.checkB_110.Size = new System.Drawing.Size(60, 16);
            this.checkB_110.TabIndex = 214;
            this.checkB_110.Text = "다이아";
            this.checkB_110.UseVisualStyleBackColor = true;
            // 
            // checkB_100
            // 
            this.checkB_100.AutoSize = true;
            this.checkB_100.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_100.ForeColor = System.Drawing.Color.Black;
            this.checkB_100.Location = new System.Drawing.Point(597, 6);
            this.checkB_100.Name = "checkB_100";
            this.checkB_100.Size = new System.Drawing.Size(72, 16);
            this.checkB_100.TabIndex = 213;
            this.checkB_100.Text = "에메랄드";
            this.checkB_100.UseVisualStyleBackColor = true;
            // 
            // checkB_130
            // 
            this.checkB_130.AutoSize = true;
            this.checkB_130.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_130.ForeColor = System.Drawing.Color.Black;
            this.checkB_130.Location = new System.Drawing.Point(813, 6);
            this.checkB_130.Name = "checkB_130";
            this.checkB_130.Size = new System.Drawing.Size(84, 16);
            this.checkB_130.TabIndex = 216;
            this.checkB_130.Text = "레드다이아";
            this.checkB_130.UseVisualStyleBackColor = true;
            // 
            // checkB_90
            // 
            this.checkB_90.AutoSize = true;
            this.checkB_90.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_90.ForeColor = System.Drawing.Color.Black;
            this.checkB_90.Location = new System.Drawing.Point(525, 6);
            this.checkB_90.Name = "checkB_90";
            this.checkB_90.Size = new System.Drawing.Size(72, 16);
            this.checkB_90.TabIndex = 212;
            this.checkB_90.Text = "사파이어";
            this.checkB_90.UseVisualStyleBackColor = true;
            // 
            // checkB_120
            // 
            this.checkB_120.AutoSize = true;
            this.checkB_120.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_120.ForeColor = System.Drawing.Color.Black;
            this.checkB_120.Location = new System.Drawing.Point(729, 6);
            this.checkB_120.Name = "checkB_120";
            this.checkB_120.Size = new System.Drawing.Size(84, 16);
            this.checkB_120.TabIndex = 215;
            this.checkB_120.Text = "블루다이아";
            this.checkB_120.UseVisualStyleBackColor = true;
            // 
            // checkB_80
            // 
            this.checkB_80.AutoSize = true;
            this.checkB_80.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_80.ForeColor = System.Drawing.Color.Black;
            this.checkB_80.Location = new System.Drawing.Point(477, 6);
            this.checkB_80.Name = "checkB_80";
            this.checkB_80.Size = new System.Drawing.Size(48, 16);
            this.checkB_80.TabIndex = 211;
            this.checkB_80.Text = "루비";
            this.checkB_80.UseVisualStyleBackColor = true;
            // 
            // checkB_70
            // 
            this.checkB_70.AutoSize = true;
            this.checkB_70.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_70.ForeColor = System.Drawing.Color.Black;
            this.checkB_70.Location = new System.Drawing.Point(429, 6);
            this.checkB_70.Name = "checkB_70";
            this.checkB_70.Size = new System.Drawing.Size(48, 16);
            this.checkB_70.TabIndex = 210;
            this.checkB_70.Text = "골드";
            this.checkB_70.UseVisualStyleBackColor = true;
            // 
            // checkB_60
            // 
            this.checkB_60.AutoSize = true;
            this.checkB_60.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_60.ForeColor = System.Drawing.Color.Black;
            this.checkB_60.Location = new System.Drawing.Point(381, 6);
            this.checkB_60.Name = "checkB_60";
            this.checkB_60.Size = new System.Drawing.Size(48, 16);
            this.checkB_60.TabIndex = 209;
            this.checkB_60.Text = "실버";
            this.checkB_60.UseVisualStyleBackColor = true;
            // 
            // checkB_50
            // 
            this.checkB_50.AutoSize = true;
            this.checkB_50.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_50.ForeColor = System.Drawing.Color.Black;
            this.checkB_50.Location = new System.Drawing.Point(321, 6);
            this.checkB_50.Name = "checkB_50";
            this.checkB_50.Size = new System.Drawing.Size(60, 16);
            this.checkB_50.TabIndex = 208;
            this.checkB_50.Text = "브론즈";
            this.checkB_50.UseVisualStyleBackColor = true;
            // 
            // checkB_40
            // 
            this.checkB_40.AutoSize = true;
            this.checkB_40.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_40.ForeColor = System.Drawing.Color.Black;
            this.checkB_40.Location = new System.Drawing.Point(261, 6);
            this.checkB_40.Name = "checkB_40";
            this.checkB_40.Size = new System.Drawing.Size(60, 16);
            this.checkB_40.TabIndex = 207;
            this.checkB_40.Text = "매니저";
            this.checkB_40.UseVisualStyleBackColor = true;
            // 
            // checkB_30
            // 
            this.checkB_30.AutoSize = true;
            this.checkB_30.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_30.ForeColor = System.Drawing.Color.Black;
            this.checkB_30.Location = new System.Drawing.Point(207, 6);
            this.checkB_30.Name = "checkB_30";
            this.checkB_30.Size = new System.Drawing.Size(54, 16);
            this.checkB_30.TabIndex = 206;
            this.checkB_30.Text = "3스타";
            this.checkB_30.UseVisualStyleBackColor = true;
            // 
            // checkB_Up
            // 
            this.checkB_Up.AutoSize = true;
            this.checkB_Up.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_Up.ForeColor = System.Drawing.Color.Blue;
            this.checkB_Up.Location = new System.Drawing.Point(4, 6);
            this.checkB_Up.Name = "checkB_Up";
            this.checkB_Up.Size = new System.Drawing.Size(95, 16);
            this.checkB_Up.TabIndex = 205;
            this.checkB_Up.TabStop = true;
            this.checkB_Up.Text = "직급_승급자";
            this.checkB_Up.UseVisualStyleBackColor = true;
            // 
            // combo_Grade2_Code
            // 
            this.combo_Grade2_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade2_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade2_Code.FormattingEnabled = true;
            this.combo_Grade2_Code.Location = new System.Drawing.Point(233, 30);
            this.combo_Grade2_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade2_Code.Name = "combo_Grade2_Code";
            this.combo_Grade2_Code.Size = new System.Drawing.Size(346, 20);
            this.combo_Grade2_Code.TabIndex = 204;
            this.combo_Grade2_Code.TabStop = false;
            this.combo_Grade2_Code.Visible = false;
            // 
            // combo_Grade2
            // 
            this.combo_Grade2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade2.FormattingEnabled = true;
            this.combo_Grade2.Location = new System.Drawing.Point(101, 30);
            this.combo_Grade2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade2.Name = "combo_Grade2";
            this.combo_Grade2.Size = new System.Drawing.Size(346, 20);
            this.combo_Grade2.TabIndex = 203;
            // 
            // checkB_Up_60
            // 
            this.checkB_Up_60.AutoSize = true;
            this.checkB_Up_60.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_Up_60.ForeColor = System.Drawing.Color.Blue;
            this.checkB_Up_60.Location = new System.Drawing.Point(143, 30);
            this.checkB_Up_60.Name = "checkB_Up_60";
            this.checkB_Up_60.Size = new System.Drawing.Size(114, 16);
            this.checkB_Up_60.TabIndex = 1;
            this.checkB_Up_60.Text = "PD이상_승급자";
            this.checkB_Up_60.UseVisualStyleBackColor = true;
            // 
            // checkB_20
            // 
            this.checkB_20.AutoSize = true;
            this.checkB_20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_20.ForeColor = System.Drawing.Color.Black;
            this.checkB_20.Location = new System.Drawing.Point(153, 6);
            this.checkB_20.Name = "checkB_20";
            this.checkB_20.Size = new System.Drawing.Size(54, 16);
            this.checkB_20.TabIndex = 0;
            this.checkB_20.Text = "2스타";
            this.checkB_20.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(2, 2);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 32);
            this.label22.TabIndex = 0;
            this.label22.Text = "신규_승급";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel29.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Controls.Add(this.panel26, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(2, 3);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(347, 72);
            this.tableLayoutPanel29.TabIndex = 17;
            // 
            // panel26
            // 
            this.panel26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.radio_PayTF_Re_D_2);
            this.panel26.Controls.Add(this.radio_PayTF_Re_D_1);
            this.panel26.Controls.Add(this.radio_PayTF_ALL);
            this.panel26.Controls.Add(this.radio_PayTF_Not);
            this.panel26.Controls.Add(this.radio_PayTF3);
            this.panel26.Controls.Add(this.radio_PayTF2);
            this.panel26.Controls.Add(this.radio_PayTF1);
            this.panel26.Location = new System.Drawing.Point(70, 4);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(273, 64);
            this.panel26.TabIndex = 15;
            // 
            // radio_PayTF_Re_D_2
            // 
            this.radio_PayTF_Re_D_2.AutoSize = true;
            this.radio_PayTF_Re_D_2.Location = new System.Drawing.Point(74, 43);
            this.radio_PayTF_Re_D_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Re_D_2.Name = "radio_PayTF_Re_D_2";
            this.radio_PayTF_Re_D_2.Size = new System.Drawing.Size(165, 16);
            this.radio_PayTF_Re_D_2.TabIndex = 71;
            this.radio_PayTF_Re_D_2.Tag = "D_1";
            this.radio_PayTF_Re_D_2.Text = "이월된+이월한 반품공제액";
            this.radio_PayTF_Re_D_2.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_Re_D_1
            // 
            this.radio_PayTF_Re_D_1.AutoSize = true;
            this.radio_PayTF_Re_D_1.Location = new System.Drawing.Point(74, 22);
            this.radio_PayTF_Re_D_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Re_D_1.Name = "radio_PayTF_Re_D_1";
            this.radio_PayTF_Re_D_1.Size = new System.Drawing.Size(129, 16);
            this.radio_PayTF_Re_D_1.TabIndex = 70;
            this.radio_PayTF_Re_D_1.Tag = "D_1";
            this.radio_PayTF_Re_D_1.Text = "이월한반품공제액 +";
            this.radio_PayTF_Re_D_1.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_ALL
            // 
            this.radio_PayTF_ALL.AutoSize = true;
            this.radio_PayTF_ALL.Location = new System.Drawing.Point(74, 2);
            this.radio_PayTF_ALL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_ALL.Name = "radio_PayTF_ALL";
            this.radio_PayTF_ALL.Size = new System.Drawing.Size(89, 16);
            this.radio_PayTF_ALL.TabIndex = 69;
            this.radio_PayTF_ALL.Tag = "D_1";
            this.radio_PayTF_ALL.Text = "지급+미지급";
            this.radio_PayTF_ALL.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_Not
            // 
            this.radio_PayTF_Not.AutoSize = true;
            this.radio_PayTF_Not.Location = new System.Drawing.Point(3, 43);
            this.radio_PayTF_Not.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Not.Name = "radio_PayTF_Not";
            this.radio_PayTF_Not.Size = new System.Drawing.Size(59, 16);
            this.radio_PayTF_Not.TabIndex = 68;
            this.radio_PayTF_Not.Tag = "D_1";
            this.radio_PayTF_Not.Text = "미지급";
            this.radio_PayTF_Not.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF3
            // 
            this.radio_PayTF3.AutoSize = true;
            this.radio_PayTF3.Location = new System.Drawing.Point(185, 2);
            this.radio_PayTF3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF3.Name = "radio_PayTF3";
            this.radio_PayTF3.Size = new System.Drawing.Size(71, 16);
            this.radio_PayTF3.TabIndex = 67;
            this.radio_PayTF3.Tag = "D_1";
            this.radio_PayTF3.Text = "미발생자";
            this.radio_PayTF3.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF2
            // 
            this.radio_PayTF2.AutoSize = true;
            this.radio_PayTF2.Location = new System.Drawing.Point(3, 2);
            this.radio_PayTF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF2.Name = "radio_PayTF2";
            this.radio_PayTF2.Size = new System.Drawing.Size(47, 16);
            this.radio_PayTF2.TabIndex = 66;
            this.radio_PayTF2.Tag = "D_1";
            this.radio_PayTF2.Text = "전체";
            this.radio_PayTF2.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF1
            // 
            this.radio_PayTF1.AutoSize = true;
            this.radio_PayTF1.Checked = true;
            this.radio_PayTF1.Location = new System.Drawing.Point(3, 22);
            this.radio_PayTF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF1.Name = "radio_PayTF1";
            this.radio_PayTF1.Size = new System.Drawing.Size(47, 16);
            this.radio_PayTF1.TabIndex = 65;
            this.radio_PayTF1.TabStop = true;
            this.radio_PayTF1.Tag = "D_1";
            this.radio_PayTF1.Text = "지급";
            this.radio_PayTF1.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(2, 2);
            this.label34.Margin = new System.Windows.Forms.Padding(0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(64, 68);
            this.label34.TabIndex = 0;
            this.label34.Text = "구분";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.panel31, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel20.Location = new System.Drawing.Point(101, 177);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(626, 36);
            this.tableLayoutPanel20.TabIndex = 16;
            this.tableLayoutPanel20.Visible = false;
            // 
            // panel31
            // 
            this.panel31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.checkB_E_31);
            this.panel31.Controls.Add(this.checkB_E_30);
            this.panel31.Controls.Add(this.checkB_E_1);
            this.panel31.Location = new System.Drawing.Point(126, 4);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(496, 28);
            this.panel31.TabIndex = 15;
            // 
            // checkB_E_31
            // 
            this.checkB_E_31.AutoSize = true;
            this.checkB_E_31.Location = new System.Drawing.Point(215, 5);
            this.checkB_E_31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkB_E_31.Name = "checkB_E_31";
            this.checkB_E_31.Size = new System.Drawing.Size(115, 16);
            this.checkB_E_31.TabIndex = 68;
            this.checkB_E_31.Tag = "D_1";
            this.checkB_E_31.Text = "30일 초과 발생자";
            this.checkB_E_31.UseVisualStyleBackColor = true;
            // 
            // checkB_E_30
            // 
            this.checkB_E_30.AutoSize = true;
            this.checkB_E_30.Location = new System.Drawing.Point(95, 6);
            this.checkB_E_30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkB_E_30.Name = "checkB_E_30";
            this.checkB_E_30.Size = new System.Drawing.Size(111, 16);
            this.checkB_E_30.TabIndex = 67;
            this.checkB_E_30.Tag = "D_1";
            this.checkB_E_30.Text = "30일이내 발생자";
            this.checkB_E_30.UseVisualStyleBackColor = true;
            // 
            // checkB_E_1
            // 
            this.checkB_E_1.AutoSize = true;
            this.checkB_E_1.Location = new System.Drawing.Point(3, 6);
            this.checkB_E_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkB_E_1.Name = "checkB_E_1";
            this.checkB_E_1.Size = new System.Drawing.Size(83, 16);
            this.checkB_E_1.TabIndex = 66;
            this.checkB_E_1.Tag = "D_1";
            this.checkB_E_1.Text = "최조발생자";
            this.checkB_E_1.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(2, 2);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(120, 32);
            this.label21.TabIndex = 0;
            this.label21.Text = "엘리트 직급 관련";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.panel25, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(350, 39);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 1;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel19.TabIndex = 15;
            // 
            // panel25
            // 
            this.panel25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Controls.Add(this.combo_CGrade_Code);
            this.panel25.Controls.Add(this.combo_CGrade);
            this.panel25.Location = new System.Drawing.Point(126, 4);
            this.panel25.Margin = new System.Windows.Forms.Padding(2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(195, 28);
            this.panel25.TabIndex = 15;
            // 
            // combo_CGrade_Code
            // 
            this.combo_CGrade_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_CGrade_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_CGrade_Code.Enabled = false;
            this.combo_CGrade_Code.FormattingEnabled = true;
            this.combo_CGrade_Code.Location = new System.Drawing.Point(145, 3);
            this.combo_CGrade_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_CGrade_Code.Name = "combo_CGrade_Code";
            this.combo_CGrade_Code.Size = new System.Drawing.Size(47, 20);
            this.combo_CGrade_Code.TabIndex = 202;
            this.combo_CGrade_Code.TabStop = false;
            // 
            // combo_CGrade
            // 
            this.combo_CGrade.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_CGrade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_CGrade.FormattingEnabled = true;
            this.combo_CGrade.Location = new System.Drawing.Point(3, 3);
            this.combo_CGrade.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_CGrade.Name = "combo_CGrade";
            this.combo_CGrade.Size = new System.Drawing.Size(141, 20);
            this.combo_CGrade.TabIndex = 193;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(2, 2);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 32);
            this.label20.TabIndex = 0;
            this.label20.Text = "월최고직급";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.panel24, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(1068, 110);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel18.TabIndex = 14;
            this.tableLayoutPanel18.Visible = false;
            // 
            // panel24
            // 
            this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Controls.Add(this.txt_Us_num);
            this.panel24.Location = new System.Drawing.Point(126, 4);
            this.panel24.Margin = new System.Windows.Forms.Padding(2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(195, 28);
            this.panel24.TabIndex = 15;
            // 
            // txt_Us_num
            // 
            this.txt_Us_num.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Us_num.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Us_num.Location = new System.Drawing.Point(3, 3);
            this.txt_Us_num.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txt_Us_num.MaxLength = 7;
            this.txt_Us_num.Name = "txt_Us_num";
            this.txt_Us_num.Size = new System.Drawing.Size(189, 22);
            this.txt_Us_num.TabIndex = 7;
            this.txt_Us_num.Tag = "1";
            this.txt_Us_num.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Us_num.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Us_num.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 32);
            this.label19.TabIndex = 0;
            this.label19.Text = "미국회원_번호";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel10, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(1002, 39);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.mtxtPayDate2);
            this.panel10.Controls.Add(this.mtxtPayDate1);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Controls.Add(this.DTP_PayDate2);
            this.panel10.Controls.Add(this.DTP_PayDate1);
            this.panel10.Location = new System.Drawing.Point(126, 4);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(195, 28);
            this.panel10.TabIndex = 15;
            // 
            // mtxtPayDate2
            // 
            this.mtxtPayDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtPayDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPayDate2.Name = "mtxtPayDate2";
            this.mtxtPayDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtPayDate2.TabIndex = 64;
            this.mtxtPayDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPayDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPayDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtPayDate1
            // 
            this.mtxtPayDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtPayDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPayDate1.Name = "mtxtPayDate1";
            this.mtxtPayDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtPayDate1.TabIndex = 0;
            this.mtxtPayDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPayDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPayDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(94, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(9, 15);
            this.label8.TabIndex = 60;
            this.label8.Text = "~";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DTP_PayDate2
            // 
            this.DTP_PayDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_PayDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PayDate2.Name = "DTP_PayDate2";
            this.DTP_PayDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_PayDate2.TabIndex = 62;
            this.DTP_PayDate2.TabStop = false;
            this.DTP_PayDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_PayDate1
            // 
            this.DTP_PayDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_PayDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PayDate1.Name = "DTP_PayDate1";
            this.DTP_PayDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_PayDate1.TabIndex = 59;
            this.DTP_PayDate1.TabStop = false;
            this.DTP_PayDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 32);
            this.label13.TabIndex = 0;
            this.label13.Text = "지급_일자";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel30.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.panel27, 1, 0);
            this.tableLayoutPanel30.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(101, 141);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel30.TabIndex = 3;
            this.tableLayoutPanel30.Visible = false;
            // 
            // panel27
            // 
            this.panel27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Controls.Add(this.txtCenter_Code);
            this.panel27.Controls.Add(this.txtCenter);
            this.panel27.Location = new System.Drawing.Point(126, 4);
            this.panel27.Margin = new System.Windows.Forms.Padding(2);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(195, 28);
            this.panel27.TabIndex = 15;
            // 
            // txtCenter_Code
            // 
            this.txtCenter_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtCenter_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter_Code.Location = new System.Drawing.Point(146, 3);
            this.txtCenter_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter_Code.MaxLength = 30;
            this.txtCenter_Code.Name = "txtCenter_Code";
            this.txtCenter_Code.Size = new System.Drawing.Size(46, 22);
            this.txtCenter_Code.TabIndex = 78;
            this.txtCenter_Code.TabStop = false;
            // 
            // txtCenter
            // 
            this.txtCenter.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter.Location = new System.Drawing.Point(3, 3);
            this.txtCenter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter.MaxLength = 30;
            this.txtCenter.Name = "txtCenter";
            this.txtCenter.Size = new System.Drawing.Size(142, 22);
            this.txtCenter.TabIndex = 5;
            this.txtCenter.Tag = "ncode";
            this.txtCenter.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtCenter.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtCenter.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtCenter.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(2, 2);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(120, 32);
            this.label35.TabIndex = 0;
            this.label35.Text = "센타";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel31.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.panel28, 1, 0);
            this.tableLayoutPanel31.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel31.Location = new System.Drawing.Point(1002, 2);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(324, 36);
            this.tableLayoutPanel31.TabIndex = 2;
            // 
            // panel28
            // 
            this.panel28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Controls.Add(this.txtToEndDate_Code);
            this.panel28.Controls.Add(this.txtToEndDate);
            this.panel28.Location = new System.Drawing.Point(126, 4);
            this.panel28.Margin = new System.Windows.Forms.Padding(2);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(194, 28);
            this.panel28.TabIndex = 15;
            // 
            // txtToEndDate_Code
            // 
            this.txtToEndDate_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtToEndDate_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtToEndDate_Code.ForeColor = System.Drawing.Color.White;
            this.txtToEndDate_Code.Location = new System.Drawing.Point(107, 3);
            this.txtToEndDate_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToEndDate_Code.MaxLength = 30;
            this.txtToEndDate_Code.Name = "txtToEndDate_Code";
            this.txtToEndDate_Code.Size = new System.Drawing.Size(84, 22);
            this.txtToEndDate_Code.TabIndex = 78;
            this.txtToEndDate_Code.TabStop = false;
            // 
            // txtToEndDate
            // 
            this.txtToEndDate.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtToEndDate.Location = new System.Drawing.Point(3, 3);
            this.txtToEndDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToEndDate.MaxLength = 8;
            this.txtToEndDate.Name = "txtToEndDate";
            this.txtToEndDate.Size = new System.Drawing.Size(104, 22);
            this.txtToEndDate.TabIndex = 5;
            this.txtToEndDate.Tag = "ncode1";
            this.txtToEndDate.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtToEndDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtToEndDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtToEndDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(2, 2);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 32);
            this.label36.TabIndex = 0;
            this.label36.Text = "마감일";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.panel29, 1, 0);
            this.tableLayoutPanel32.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel32.Location = new System.Drawing.Point(427, 141);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel32.TabIndex = 8;
            this.tableLayoutPanel32.Visible = false;
            // 
            // panel29
            // 
            this.panel29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.combo_Grade_Code);
            this.panel29.Controls.Add(this.combo_Grade);
            this.panel29.Location = new System.Drawing.Point(126, 4);
            this.panel29.Margin = new System.Windows.Forms.Padding(2);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(170, 28);
            this.panel29.TabIndex = 15;
            // 
            // combo_Grade_Code
            // 
            this.combo_Grade_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade_Code.Enabled = false;
            this.combo_Grade_Code.FormattingEnabled = true;
            this.combo_Grade_Code.Location = new System.Drawing.Point(134, 3);
            this.combo_Grade_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade_Code.Name = "combo_Grade_Code";
            this.combo_Grade_Code.Size = new System.Drawing.Size(34, 20);
            this.combo_Grade_Code.TabIndex = 202;
            this.combo_Grade_Code.TabStop = false;
            // 
            // combo_Grade
            // 
            this.combo_Grade.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade.FormattingEnabled = true;
            this.combo_Grade.Location = new System.Drawing.Point(3, 3);
            this.combo_Grade.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade.Name = "combo_Grade";
            this.combo_Grade.Size = new System.Drawing.Size(130, 20);
            this.combo_Grade.TabIndex = 193;
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(2, 2);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(120, 32);
            this.label37.TabIndex = 0;
            this.label37.Text = "최고직급";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.panel30, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(676, 39);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel33.TabIndex = 5;
            // 
            // panel30
            // 
            this.panel30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.mtxtToDate2);
            this.panel30.Controls.Add(this.mtxtToDate1);
            this.panel30.Controls.Add(this.label38);
            this.panel30.Controls.Add(this.DTP_ToDate2);
            this.panel30.Controls.Add(this.DTP_ToDate1);
            this.panel30.Location = new System.Drawing.Point(126, 4);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(195, 28);
            this.panel30.TabIndex = 15;
            // 
            // mtxtToDate2
            // 
            this.mtxtToDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtToDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtToDate2.Name = "mtxtToDate2";
            this.mtxtToDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtToDate2.TabIndex = 64;
            this.mtxtToDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtToDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtToDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtToDate1
            // 
            this.mtxtToDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtToDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtToDate1.Name = "mtxtToDate1";
            this.mtxtToDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtToDate1.TabIndex = 0;
            this.mtxtToDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtToDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtToDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(94, 7);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(9, 15);
            this.label38.TabIndex = 60;
            this.label38.Text = "~";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DTP_ToDate2
            // 
            this.DTP_ToDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_ToDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_ToDate2.Name = "DTP_ToDate2";
            this.DTP_ToDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_ToDate2.TabIndex = 62;
            this.DTP_ToDate2.TabStop = false;
            this.DTP_ToDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_ToDate1
            // 
            this.DTP_ToDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_ToDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_ToDate1.Name = "DTP_ToDate1";
            this.DTP_ToDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_ToDate1.TabIndex = 59;
            this.DTP_ToDate1.TabStop = false;
            this.DTP_ToDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(2, 2);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 32);
            this.label39.TabIndex = 0;
            this.label39.Text = "마감_종료일";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel36.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.panel33, 1, 0);
            this.tableLayoutPanel36.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel36.Location = new System.Drawing.Point(729, 116);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel36.TabIndex = 4;
            this.tableLayoutPanel36.Visible = false;
            // 
            // panel33
            // 
            this.panel33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Controls.Add(this.mtxtFromDate2);
            this.panel33.Controls.Add(this.mtxtFromDate1);
            this.panel33.Controls.Add(this.label42);
            this.panel33.Controls.Add(this.DTP_FromDate2);
            this.panel33.Controls.Add(this.DTP_FromDate1);
            this.panel33.Location = new System.Drawing.Point(126, 4);
            this.panel33.Margin = new System.Windows.Forms.Padding(2);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(195, 28);
            this.panel33.TabIndex = 15;
            // 
            // mtxtFromDate2
            // 
            this.mtxtFromDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtFromDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtFromDate2.Name = "mtxtFromDate2";
            this.mtxtFromDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtFromDate2.TabIndex = 64;
            this.mtxtFromDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtFromDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtFromDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtFromDate1
            // 
            this.mtxtFromDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtFromDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtFromDate1.Name = "mtxtFromDate1";
            this.mtxtFromDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtFromDate1.TabIndex = 0;
            this.mtxtFromDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtFromDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtFromDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(94, 7);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(9, 15);
            this.label42.TabIndex = 60;
            this.label42.Text = "~";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DTP_FromDate2
            // 
            this.DTP_FromDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_FromDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_FromDate2.Name = "DTP_FromDate2";
            this.DTP_FromDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_FromDate2.TabIndex = 56;
            this.DTP_FromDate2.TabStop = false;
            this.DTP_FromDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_FromDate1
            // 
            this.DTP_FromDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_FromDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_FromDate1.Name = "DTP_FromDate1";
            this.DTP_FromDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_FromDate1.TabIndex = 53;
            this.DTP_FromDate1.TabStop = false;
            this.DTP_FromDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(2, 2);
            this.label43.Margin = new System.Windows.Forms.Padding(0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 32);
            this.label43.TabIndex = 0;
            this.label43.Text = "마감_시작일";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // grB_Search
            // 
            this.grB_Search.Controls.Add(this.panel4);
            this.grB_Search.Controls.Add(this.panel2);
            this.grB_Search.Controls.Add(this.button_base);
            this.grB_Search.Controls.Add(this.butt_Exp);
            this.grB_Search.Location = new System.Drawing.Point(1304, 29);
            this.grB_Search.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grB_Search.Name = "grB_Search";
            this.grB_Search.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grB_Search.Size = new System.Drawing.Size(158, 195);
            this.grB_Search.TabIndex = 13;
            this.grB_Search.TabStop = false;
            this.grB_Search.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 482);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(152, 0);
            this.panel4.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel8);
            this.panel2.Controls.Add(this.tableLayoutPanel6);
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Controls.Add(this.tableLayoutPanel4);
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 464);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel8.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 39);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(312, 55);
            this.tableLayoutPanel8.TabIndex = 120;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(5, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 51);
            this.label4.TabIndex = 12;
            this.label4.Text = "구분";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Location = new System.Drawing.Point(112, 6);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(195, 43);
            this.panel5.TabIndex = 90;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel6.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel11, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 92);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(312, 36);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Location = new System.Drawing.Point(5, 2);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(99, 32);
            this.label31.TabIndex = 12;
            this.label31.Text = "회원_번호";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel11
            // 
            this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel11.Controls.Add(this.mtxtMbid2);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Location = new System.Drawing.Point(112, 6);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(195, 24);
            this.panel11.TabIndex = 90;
            // 
            // mtxtMbid2
            // 
            this.mtxtMbid2.Location = new System.Drawing.Point(99, 0);
            this.mtxtMbid2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtMbid2.Name = "mtxtMbid2";
            this.mtxtMbid2.Size = new System.Drawing.Size(87, 21);
            this.mtxtMbid2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(90, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(9, 15);
            this.label3.TabIndex = 17;
            this.label3.Text = "-";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 329);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(5, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 98);
            this.label1.TabIndex = 58;
            this.label1.Text = "지급_일자";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.radioB_P);
            this.panel1.Controls.Add(this.radioB_PM_3);
            this.panel1.Controls.Add(this.radioB_PM_2);
            this.panel1.Controls.Add(this.radioB_PM_1);
            this.panel1.Controls.Add(this.radioB_P_7);
            this.panel1.Controls.Add(this.radioB_P_1);
            this.panel1.Location = new System.Drawing.Point(112, 6);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 90);
            this.panel1.TabIndex = 90;
            // 
            // radioB_P
            // 
            this.radioB_P.AutoSize = true;
            this.radioB_P.Location = new System.Drawing.Point(111, 67);
            this.radioB_P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P.Name = "radioB_P";
            this.radioB_P.Size = new System.Drawing.Size(47, 16);
            this.radioB_P.TabIndex = 69;
            this.radioB_P.Tag = "T_1";
            this.radioB_P.Text = "전체";
            this.radioB_P.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_3
            // 
            this.radioB_PM_3.AutoSize = true;
            this.radioB_PM_3.Location = new System.Drawing.Point(10, 66);
            this.radioB_PM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_3.Name = "radioB_PM_3";
            this.radioB_PM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_PM_3.TabIndex = 68;
            this.radioB_PM_3.Tag = "M_3";
            this.radioB_PM_3.Text = "최근3개월";
            this.radioB_PM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_2
            // 
            this.radioB_PM_2.AutoSize = true;
            this.radioB_PM_2.Location = new System.Drawing.Point(111, 46);
            this.radioB_PM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_2.Name = "radioB_PM_2";
            this.radioB_PM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_PM_2.TabIndex = 67;
            this.radioB_PM_2.Tag = "M_2";
            this.radioB_PM_2.Text = "전월";
            this.radioB_PM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_1
            // 
            this.radioB_PM_1.AutoSize = true;
            this.radioB_PM_1.Location = new System.Drawing.Point(10, 46);
            this.radioB_PM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_1.Name = "radioB_PM_1";
            this.radioB_PM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_PM_1.TabIndex = 66;
            this.radioB_PM_1.Tag = "M_1";
            this.radioB_PM_1.Text = "당월";
            this.radioB_PM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_P_7
            // 
            this.radioB_P_7.AutoSize = true;
            this.radioB_P_7.Location = new System.Drawing.Point(111, 26);
            this.radioB_P_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P_7.Name = "radioB_P_7";
            this.radioB_P_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_P_7.TabIndex = 65;
            this.radioB_P_7.Tag = "D_7";
            this.radioB_P_7.Text = "최근7일";
            this.radioB_P_7.UseVisualStyleBackColor = true;
            // 
            // radioB_P_1
            // 
            this.radioB_P_1.AutoSize = true;
            this.radioB_P_1.Location = new System.Drawing.Point(10, 26);
            this.radioB_P_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P_1.Name = "radioB_P_1";
            this.radioB_P_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_P_1.TabIndex = 64;
            this.radioB_P_1.Tag = "D_1";
            this.radioB_P_1.Text = "당일";
            this.radioB_P_1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel4.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 130);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.radioB_S);
            this.panel3.Controls.Add(this.radioB_SM_3);
            this.panel3.Controls.Add(this.radioB_SM_2);
            this.panel3.Controls.Add(this.radioB_SM_1);
            this.panel3.Controls.Add(this.radioB_S_7);
            this.panel3.Controls.Add(this.radioB_S_1);
            this.panel3.Location = new System.Drawing.Point(112, 6);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(195, 90);
            this.panel3.TabIndex = 90;
            // 
            // radioB_S
            // 
            this.radioB_S.AutoSize = true;
            this.radioB_S.Location = new System.Drawing.Point(111, 68);
            this.radioB_S.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S.Name = "radioB_S";
            this.radioB_S.Size = new System.Drawing.Size(47, 16);
            this.radioB_S.TabIndex = 63;
            this.radioB_S.Tag = "T_1";
            this.radioB_S.Text = "전체";
            this.radioB_S.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_3
            // 
            this.radioB_SM_3.AutoSize = true;
            this.radioB_SM_3.Location = new System.Drawing.Point(10, 67);
            this.radioB_SM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_3.Name = "radioB_SM_3";
            this.radioB_SM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_SM_3.TabIndex = 62;
            this.radioB_SM_3.Tag = "M_3";
            this.radioB_SM_3.Text = "최근3개월";
            this.radioB_SM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_2
            // 
            this.radioB_SM_2.AutoSize = true;
            this.radioB_SM_2.Location = new System.Drawing.Point(111, 47);
            this.radioB_SM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_2.Name = "radioB_SM_2";
            this.radioB_SM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_2.TabIndex = 61;
            this.radioB_SM_2.Tag = "M_2";
            this.radioB_SM_2.Text = "전월";
            this.radioB_SM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_1
            // 
            this.radioB_SM_1.AutoSize = true;
            this.radioB_SM_1.Location = new System.Drawing.Point(10, 47);
            this.radioB_SM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_1.Name = "radioB_SM_1";
            this.radioB_SM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_1.TabIndex = 60;
            this.radioB_SM_1.Tag = "M_1";
            this.radioB_SM_1.Text = "당월";
            this.radioB_SM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_S_7
            // 
            this.radioB_S_7.AutoSize = true;
            this.radioB_S_7.Location = new System.Drawing.Point(111, 27);
            this.radioB_S_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_7.Name = "radioB_S_7";
            this.radioB_S_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_S_7.TabIndex = 59;
            this.radioB_S_7.Tag = "D_7";
            this.radioB_S_7.Text = "최근7일";
            this.radioB_S_7.UseVisualStyleBackColor = true;
            // 
            // radioB_S_1
            // 
            this.radioB_S_1.AutoSize = true;
            this.radioB_S_1.Location = new System.Drawing.Point(10, 27);
            this.radioB_S_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_1.Name = "radioB_S_1";
            this.radioB_S_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_S_1.TabIndex = 58;
            this.radioB_S_1.Tag = "D_1";
            this.radioB_S_1.Text = "당일";
            this.radioB_S_1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(5, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 98);
            this.label14.TabIndex = 52;
            this.label14.Text = "마감_시작일";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel7.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.panel7, 1, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 230);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(5, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 98);
            this.label7.TabIndex = 58;
            this.label7.Text = "마감_종료일";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.radioB_R);
            this.panel7.Controls.Add(this.radioB_RM_3);
            this.panel7.Controls.Add(this.radioB_RM_2);
            this.panel7.Controls.Add(this.radioB_RM_1);
            this.panel7.Controls.Add(this.radioB_R_7);
            this.panel7.Controls.Add(this.radioB_R_1);
            this.panel7.Location = new System.Drawing.Point(112, 6);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(195, 90);
            this.panel7.TabIndex = 90;
            // 
            // radioB_R
            // 
            this.radioB_R.AutoSize = true;
            this.radioB_R.Location = new System.Drawing.Point(111, 67);
            this.radioB_R.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R.Name = "radioB_R";
            this.radioB_R.Size = new System.Drawing.Size(47, 16);
            this.radioB_R.TabIndex = 69;
            this.radioB_R.Tag = "T_1";
            this.radioB_R.Text = "전체";
            this.radioB_R.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_3
            // 
            this.radioB_RM_3.AutoSize = true;
            this.radioB_RM_3.Location = new System.Drawing.Point(10, 66);
            this.radioB_RM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_3.Name = "radioB_RM_3";
            this.radioB_RM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_RM_3.TabIndex = 68;
            this.radioB_RM_3.Tag = "M_3";
            this.radioB_RM_3.Text = "최근3개월";
            this.radioB_RM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_2
            // 
            this.radioB_RM_2.AutoSize = true;
            this.radioB_RM_2.Location = new System.Drawing.Point(111, 46);
            this.radioB_RM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_2.Name = "radioB_RM_2";
            this.radioB_RM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_2.TabIndex = 67;
            this.radioB_RM_2.Tag = "M_2";
            this.radioB_RM_2.Text = "전월";
            this.radioB_RM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_1
            // 
            this.radioB_RM_1.AutoSize = true;
            this.radioB_RM_1.Location = new System.Drawing.Point(10, 46);
            this.radioB_RM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_1.Name = "radioB_RM_1";
            this.radioB_RM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_1.TabIndex = 66;
            this.radioB_RM_1.Tag = "M_1";
            this.radioB_RM_1.Text = "당월";
            this.radioB_RM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_R_7
            // 
            this.radioB_R_7.AutoSize = true;
            this.radioB_R_7.Location = new System.Drawing.Point(111, 26);
            this.radioB_R_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_7.Name = "radioB_R_7";
            this.radioB_R_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_R_7.TabIndex = 65;
            this.radioB_R_7.Tag = "D_7";
            this.radioB_R_7.Text = "최근7일";
            this.radioB_R_7.UseVisualStyleBackColor = true;
            // 
            // radioB_R_1
            // 
            this.radioB_R_1.AutoSize = true;
            this.radioB_R_1.Location = new System.Drawing.Point(10, 26);
            this.radioB_R_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_1.Name = "radioB_R_1";
            this.radioB_R_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_R_1.TabIndex = 64;
            this.radioB_R_1.Tag = "D_1";
            this.radioB_R_1.Text = "당일";
            this.radioB_R_1.UseVisualStyleBackColor = true;
            // 
            // button_base
            // 
            this.button_base.Location = new System.Drawing.Point(848, 108);
            this.button_base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_base.Name = "button_base";
            this.button_base.Size = new System.Drawing.Size(25, 28);
            this.button_base.TabIndex = 86;
            this.button_base.Text = "...";
            this.button_base.UseVisualStyleBackColor = true;
            this.button_base.Visible = false;
            // 
            // butt_Exp
            // 
            this.butt_Exp.Location = new System.Drawing.Point(848, 14);
            this.butt_Exp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exp.Name = "butt_Exp";
            this.butt_Exp.Size = new System.Drawing.Size(25, 25);
            this.butt_Exp.TabIndex = 83;
            this.butt_Exp.Text = ".";
            this.butt_Exp.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel37.ColumnCount = 2;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.panel34, 1, 0);
            this.tableLayoutPanel37.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel37.Location = new System.Drawing.Point(676, 3);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel37.TabIndex = 1;
            // 
            // panel34
            // 
            this.panel34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Controls.Add(this.txtName);
            this.panel34.Location = new System.Drawing.Point(126, 4);
            this.panel34.Margin = new System.Windows.Forms.Padding(2);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(195, 28);
            this.panel34.TabIndex = 15;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName.Location = new System.Drawing.Point(3, 3);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(189, 22);
            this.txtName.TabIndex = 2;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(2, 2);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(120, 32);
            this.label44.TabIndex = 0;
            this.label44.Text = "성명";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.panel35, 1, 0);
            this.tableLayoutPanel38.Controls.Add(this.label45, 0, 0);
            this.tableLayoutPanel38.Location = new System.Drawing.Point(350, 3);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // panel35
            // 
            this.panel35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.mtxtMbid);
            this.panel35.Location = new System.Drawing.Point(126, 4);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(195, 28);
            this.panel35.TabIndex = 15;
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtMbid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.Size = new System.Drawing.Size(189, 21);
            this.mtxtMbid.TabIndex = 0;
            this.mtxtMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_MtxtData_KeyPress);
            this.mtxtMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(2, 2);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 32);
            this.label45.TabIndex = 0;
            this.label45.Text = "회원_번호";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pn_Button
            // 
            this.pn_Button.Controls.Add(this.butt_Excel);
            this.pn_Button.Controls.Add(this.butt_Delete);
            this.pn_Button.Controls.Add(this.butt_Clear);
            this.pn_Button.Controls.Add(this.butt_Select);
            this.pn_Button.Controls.Add(this.butt_Exit);
            this.pn_Button.Dock = System.Windows.Forms.DockStyle.Top;
            this.pn_Button.Location = new System.Drawing.Point(0, 0);
            this.pn_Button.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pn_Button.Name = "pn_Button";
            this.pn_Button.Size = new System.Drawing.Size(1690, 28);
            this.pn_Button.TabIndex = 1;
            // 
            // butt_Excel
            // 
            this.butt_Excel.BackColor = System.Drawing.Color.White;
            this.butt_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel.Location = new System.Drawing.Point(528, 1);
            this.butt_Excel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel.Name = "butt_Excel";
            this.butt_Excel.Size = new System.Drawing.Size(111, 26);
            this.butt_Excel.TabIndex = 4;
            this.butt_Excel.TabStop = false;
            this.butt_Excel.Text = "엑셀";
            this.butt_Excel.UseVisualStyleBackColor = false;
            this.butt_Excel.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(125, 1);
            this.butt_Delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(111, 26);
            this.butt_Delete.TabIndex = 3;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "삭제";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Visible = false;
            this.butt_Delete.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.Location = new System.Drawing.Point(266, 1);
            this.butt_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(111, 26);
            this.butt_Clear.TabIndex = 2;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            this.butt_Clear.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Select
            // 
            this.butt_Select.BackColor = System.Drawing.Color.White;
            this.butt_Select.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Select.Location = new System.Drawing.Point(411, 1);
            this.butt_Select.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Select.Name = "butt_Select";
            this.butt_Select.Size = new System.Drawing.Size(111, 26);
            this.butt_Select.TabIndex = 2;
            this.butt_Select.Text = "검색";
            this.butt_Select.UseVisualStyleBackColor = false;
            this.butt_Select.Click += new System.EventHandler(this.Select_Button_Click);
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(658, 1);
            this.butt_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(111, 26);
            this.butt_Exit.TabIndex = 0;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            this.butt_Exit.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // panel44
            // 
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.radioB_Mi_No);
            this.panel44.Controls.Add(this.radioB_Mi);
            this.panel44.Controls.Add(this.button2);
            this.panel44.Controls.Add(this.label30);
            this.panel44.Controls.Add(this.prB);
            this.panel44.Controls.Add(this.label32);
            this.panel44.Controls.Add(this.tableLayoutPanel34);
            this.panel44.Controls.Add(this.butt_Save);
            this.panel44.Controls.Add(this.button1);
            this.panel44.Controls.Add(this.chk_Total);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(1688, 30);
            this.panel44.TabIndex = 28;
            this.panel44.Visible = false;
            // 
            // radioB_Mi_No
            // 
            this.radioB_Mi_No.AutoSize = true;
            this.radioB_Mi_No.Checked = true;
            this.radioB_Mi_No.Location = new System.Drawing.Point(5, 6);
            this.radioB_Mi_No.Name = "radioB_Mi_No";
            this.radioB_Mi_No.Size = new System.Drawing.Size(113, 16);
            this.radioB_Mi_No.TabIndex = 180;
            this.radioB_Mi_No.TabStop = true;
            this.radioB_Mi_No.Text = "미지급으로_적용";
            this.radioB_Mi_No.UseVisualStyleBackColor = true;
            // 
            // radioB_Mi
            // 
            this.radioB_Mi.AutoSize = true;
            this.radioB_Mi.Location = new System.Drawing.Point(1008, 4);
            this.radioB_Mi.Name = "radioB_Mi";
            this.radioB_Mi.Size = new System.Drawing.Size(59, 16);
            this.radioB_Mi.TabIndex = 179;
            this.radioB_Mi.TabStop = true;
            this.radioB_Mi.Text = "미지급";
            this.radioB_Mi.UseVisualStyleBackColor = true;
            this.radioB_Mi.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(590, 41);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 34);
            this.button2.TabIndex = 178;
            this.button2.Text = "현금_영수증_발행";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.ForeColor = System.Drawing.Color.IndianRed;
            this.label30.Location = new System.Drawing.Point(577, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(233, 12);
            this.label30.TabIndex = 88;
            this.label30.Text = "승인일자 미입력시 결제일자 변경 없음";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // prB
            // 
            this.prB.Location = new System.Drawing.Point(329, 13);
            this.prB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.prB.Name = "prB";
            this.prB.Size = new System.Drawing.Size(200, 14);
            this.prB.TabIndex = 177;
            this.prB.Visible = false;
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.ForeColor = System.Drawing.Color.IndianRed;
            this.label32.Location = new System.Drawing.Point(576, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(290, 12);
            this.label32.TabIndex = 87;
            this.label32.Text = "승인일자 입력시 결제일자가 입력된 날짜로 변경";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel34.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Controls.Add(this.panel45, 1, 0);
            this.tableLayoutPanel34.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel34.Location = new System.Drawing.Point(227, 50);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(223, 36);
            this.tableLayoutPanel34.TabIndex = 88;
            this.tableLayoutPanel34.Visible = false;
            // 
            // panel45
            // 
            this.panel45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel45.BackColor = System.Drawing.Color.White;
            this.panel45.Controls.Add(this.mtxtSellDate);
            this.panel45.Controls.Add(this.DTP_SellDate);
            this.panel45.Location = new System.Drawing.Point(126, 4);
            this.panel45.Margin = new System.Windows.Forms.Padding(2);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(93, 28);
            this.panel45.TabIndex = 15;
            // 
            // mtxtSellDate
            // 
            this.mtxtSellDate.Location = new System.Drawing.Point(3, 3);
            this.mtxtSellDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate.Name = "mtxtSellDate";
            this.mtxtSellDate.Size = new System.Drawing.Size(67, 21);
            this.mtxtSellDate.TabIndex = 106;
            // 
            // DTP_SellDate
            // 
            this.DTP_SellDate.Location = new System.Drawing.Point(69, 3);
            this.DTP_SellDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate.Name = "DTP_SellDate";
            this.DTP_SellDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate.TabIndex = 105;
            this.DTP_SellDate.TabStop = false;
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(2, 2);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 32);
            this.label33.TabIndex = 0;
            this.label33.Text = "승인_일자";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.White;
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.Location = new System.Drawing.Point(129, 1);
            this.butt_Save.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(198, 26);
            this.butt_Save.TabIndex = 3;
            this.butt_Save.Text = "선택내역_미지급으로_적용";
            this.butt_Save.UseVisualStyleBackColor = false;
            this.butt_Save.Click += new System.EventHandler(this.butt_Save_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(27, 110);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 26);
            this.button1.TabIndex = 85;
            this.button1.Text = "선택_내역_체크";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // chk_Total
            // 
            this.chk_Total.AutoSize = true;
            this.chk_Total.Location = new System.Drawing.Point(150, 120);
            this.chk_Total.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chk_Total.Name = "chk_Total";
            this.chk_Total.Size = new System.Drawing.Size(78, 16);
            this.chk_Total.TabIndex = 82;
            this.chk_Total.Text = "전체_체크";
            this.chk_Total.UseVisualStyleBackColor = true;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "xlsx";
            this.saveFileDialog1.Filter = "Excel File (*.xlsx)|*.xlsx";
            // 
            // panel36
            // 
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Controls.Add(this.panel9);
            this.panel36.Controls.Add(this.panel44);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel36.Location = new System.Drawing.Point(0, 141);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(1690, 759);
            this.panel36.TabIndex = 29;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.dGridCtrl_Base);
            this.panel37.Controls.Add(this.dGridView_Base_Sum);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(0, 30);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(1688, 451);
            this.panel37.TabIndex = 30;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Controls.Add(this.panel43, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1327, 2);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel28.TabIndex = 40;
            // 
            // panel43
            // 
            this.panel43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel43.BackColor = System.Drawing.Color.White;
            this.panel43.Controls.Add(this.radioB_Su_Not);
            this.panel43.Controls.Add(this.radioButton2);
            this.panel43.Controls.Add(this.radioB_Su);
            this.panel43.Location = new System.Drawing.Point(126, 4);
            this.panel43.Margin = new System.Windows.Forms.Padding(2);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(195, 28);
            this.panel43.TabIndex = 15;
            // 
            // radioB_Su_Not
            // 
            this.radioB_Su_Not.AutoSize = true;
            this.radioB_Su_Not.Location = new System.Drawing.Point(137, 4);
            this.radioB_Su_Not.Name = "radioB_Su_Not";
            this.radioB_Su_Not.Size = new System.Drawing.Size(59, 16);
            this.radioB_Su_Not.TabIndex = 55;
            this.radioB_Su_Not.Text = "미수집";
            this.radioB_Su_Not.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 16);
            this.radioButton2.TabIndex = 53;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "전체";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioB_Su
            // 
            this.radioB_Su.AutoSize = true;
            this.radioB_Su.Location = new System.Drawing.Point(73, 4);
            this.radioB_Su.Name = "radioB_Su";
            this.radioB_Su.Size = new System.Drawing.Size(47, 16);
            this.radioB_Su.TabIndex = 54;
            this.radioB_Su.Text = "수집";
            this.radioB_Su.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(2, 2);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(120, 32);
            this.label29.TabIndex = 0;
            this.label29.Text = "주민번호 수집 구분";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel23.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.panel42, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1327, 39);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(425, 36);
            this.tableLayoutPanel23.TabIndex = 39;
            // 
            // panel42
            // 
            this.panel42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel42.BackColor = System.Drawing.Color.White;
            this.panel42.Controls.Add(this.radioB_Leave);
            this.panel42.Controls.Add(this.radioB_Leave_Not);
            this.panel42.Controls.Add(this.radioButton1);
            this.panel42.Controls.Add(this.chk_Leave_Only);
            this.panel42.Controls.Add(this.chk_Leave);
            this.panel42.Location = new System.Drawing.Point(126, 4);
            this.panel42.Margin = new System.Windows.Forms.Padding(2);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(295, 28);
            this.panel42.TabIndex = 15;
            // 
            // radioB_Leave
            // 
            this.radioB_Leave.AutoSize = true;
            this.radioB_Leave.Location = new System.Drawing.Point(181, 6);
            this.radioB_Leave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_Leave.Name = "radioB_Leave";
            this.radioB_Leave.Size = new System.Drawing.Size(71, 16);
            this.radioB_Leave.TabIndex = 69;
            this.radioB_Leave.Tag = "D_1";
            this.radioB_Leave.Text = "탈퇴자만";
            this.radioB_Leave.UseVisualStyleBackColor = true;
            // 
            // radioB_Leave_Not
            // 
            this.radioB_Leave_Not.AutoSize = true;
            this.radioB_Leave_Not.Location = new System.Drawing.Point(78, 6);
            this.radioB_Leave_Not.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_Leave_Not.Name = "radioB_Leave_Not";
            this.radioB_Leave_Not.Size = new System.Drawing.Size(83, 16);
            this.radioB_Leave_Not.TabIndex = 68;
            this.radioB_Leave_Not.Tag = "D_1";
            this.radioB_Leave_Not.Text = "미탈퇴자만";
            this.radioB_Leave_Not.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(4, 6);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 67;
            this.radioButton1.Tag = "D_1";
            this.radioButton1.Text = "전체";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // chk_Leave_Only
            // 
            this.chk_Leave_Only.AutoSize = true;
            this.chk_Leave_Only.Location = new System.Drawing.Point(95, 33);
            this.chk_Leave_Only.Name = "chk_Leave_Only";
            this.chk_Leave_Only.Size = new System.Drawing.Size(72, 16);
            this.chk_Leave_Only.TabIndex = 19;
            this.chk_Leave_Only.Text = "탈퇴자만";
            this.chk_Leave_Only.UseVisualStyleBackColor = true;
            this.chk_Leave_Only.Visible = false;
            // 
            // chk_Leave
            // 
            this.chk_Leave.AutoSize = true;
            this.chk_Leave.Location = new System.Drawing.Point(4, 34);
            this.chk_Leave.Name = "chk_Leave";
            this.chk_Leave.Size = new System.Drawing.Size(84, 16);
            this.chk_Leave.TabIndex = 17;
            this.chk_Leave.Text = "탈퇴자포함";
            this.chk_Leave.UseVisualStyleBackColor = true;
            this.chk_Leave.Visible = false;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(2, 2);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(120, 32);
            this.label24.TabIndex = 0;
            this.label24.Text = "구분";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmClose_4_Select_03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(1690, 900);
            this.ClientSize = new System.Drawing.Size(1408, 782);
            this.Controls.Add(this.panel36);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.pn_Button);
            this.KeyPreview = true;
            this.Name = "frmClose_4_Select_03";
            this.Text = "월_마감_회원별";
            this.Activated += new System.EventHandler(this.frm_Base_Activated);
            this.Load += new System.EventHandler(this.frmBase_From_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            this.Resize += new System.EventHandler(this.frmBase_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dGridCtrl_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sum)).EndInit();
            this.panel9.ResumeLayout(false);
            this.tab_Detail_02.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_1)).EndInit();
            this.tab_Dir.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_5)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_2)).EndInit();
            this.tab_save.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_3)).EndInit();
            this.tab_nom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_4)).EndInit();
            this.tab_etc.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tab_Detail_01.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_2)).EndInit();
            this.tab_Save_D.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_3)).EndInit();
            this.tab_Up.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_G)).EndInit();
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tableLayoutPanel36.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.grB_Search.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.pn_Button.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dGridView_Base_Sum;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TabControl tab_Detail_01;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dGridView_Pay_1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dGridView_Pay_2;
        private System.Windows.Forms.TabPage tab_Save_D;
        private System.Windows.Forms.DataGridView dGridView_Pay_3;
        private System.Windows.Forms.TabPage tab_Up;
        private System.Windows.Forms.DataGridView dGridView_Pay_4;
        private System.Windows.Forms.TabControl tab_Detail_02;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dGridView_Detail_1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dGridView_Detail_2;
        private System.Windows.Forms.TabPage tab_save;
        private System.Windows.Forms.DataGridView dGridView_Detail_3;
        private System.Windows.Forms.TabPage tab_nom;
        private System.Windows.Forms.DataGridView dGridView_Detail_4;
        private System.Windows.Forms.TabPage tab_etc;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txt_ETC4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txt_ETC3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txt_ETC2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txt_ETC1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.MaskedTextBox mtxtPayDate2;
        private System.Windows.Forms.MaskedTextBox mtxtPayDate1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker DTP_PayDate2;
        private System.Windows.Forms.DateTimePicker DTP_PayDate1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TextBox txtCenter_Code;
        private System.Windows.Forms.TextBox txtCenter;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.TextBox txtToEndDate_Code;
        private System.Windows.Forms.TextBox txtToEndDate;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.ComboBox combo_Grade_Code;
        private System.Windows.Forms.ComboBox combo_Grade;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.MaskedTextBox mtxtToDate2;
        private System.Windows.Forms.MaskedTextBox mtxtToDate1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DateTimePicker DTP_ToDate2;
        private System.Windows.Forms.DateTimePicker DTP_ToDate1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.MaskedTextBox mtxtFromDate2;
        private System.Windows.Forms.MaskedTextBox mtxtFromDate1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.DateTimePicker DTP_FromDate2;
        private System.Windows.Forms.DateTimePicker DTP_FromDate1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox grB_Search;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.MaskedTextBox mtxtMbid2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioB_P;
        private System.Windows.Forms.RadioButton radioB_PM_3;
        private System.Windows.Forms.RadioButton radioB_PM_2;
        private System.Windows.Forms.RadioButton radioB_PM_1;
        private System.Windows.Forms.RadioButton radioB_P_7;
        private System.Windows.Forms.RadioButton radioB_P_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioB_S;
        private System.Windows.Forms.RadioButton radioB_SM_3;
        private System.Windows.Forms.RadioButton radioB_SM_2;
        private System.Windows.Forms.RadioButton radioB_SM_1;
        private System.Windows.Forms.RadioButton radioB_S_7;
        private System.Windows.Forms.RadioButton radioB_S_1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioB_R;
        private System.Windows.Forms.RadioButton radioB_RM_3;
        private System.Windows.Forms.RadioButton radioB_RM_2;
        private System.Windows.Forms.RadioButton radioB_RM_1;
        private System.Windows.Forms.RadioButton radioB_R_7;
        private System.Windows.Forms.RadioButton radioB_R_1;
        private System.Windows.Forms.Button button_base;
        private System.Windows.Forms.Button butt_Exp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel pn_Button;
        private System.Windows.Forms.Button butt_Excel;
        private System.Windows.Forms.Button butt_Delete;
        private System.Windows.Forms.Button butt_Clear;
        private System.Windows.Forms.Button butt_Select;
        private System.Windows.Forms.Button butt_Exit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txt_ETC7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txt_ETC6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox txt_ETC5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox txt_ETC11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txt_ETC10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox txt_ETC9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox txt_ETC8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tab_Dir;
        private System.Windows.Forms.DataGridView dGridView_Detail_5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txt_Us_num;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dGridView_Pay_G;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.ComboBox combo_CGrade_Code;
        private System.Windows.Forms.ComboBox combo_CGrade;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton checkB_E_1;
        private System.Windows.Forms.RadioButton checkB_E_31;
        private System.Windows.Forms.RadioButton checkB_E_30;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.RadioButton radioB_Mi_No;
        private System.Windows.Forms.RadioButton radioB_Mi;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ProgressBar prB;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate;
        private System.Windows.Forms.DateTimePicker DTP_SellDate;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button butt_Save;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chk_Total;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.RadioButton radio_PayTF_Re_D_2;
        private System.Windows.Forms.RadioButton radio_PayTF_Re_D_1;
        private System.Windows.Forms.RadioButton radio_PayTF_ALL;
        private System.Windows.Forms.RadioButton radio_PayTF_Not;
        private System.Windows.Forms.RadioButton radio_PayTF3;
        private System.Windows.Forms.RadioButton radio_PayTF2;
        private System.Windows.Forms.RadioButton radio_PayTF1;
        private System.Windows.Forms.Label label34;
        private DevExpress.XtraGrid.GridControl dGridCtrl_Base;
        private DevExpress.XtraGrid.Views.Grid.GridView dGridView_Base;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.CheckBox checkB_150;
        private System.Windows.Forms.CheckBox checkB_140;
        private System.Windows.Forms.CheckBox checkB_10;
        private System.Windows.Forms.CheckBox checkB_110;
        private System.Windows.Forms.CheckBox checkB_100;
        private System.Windows.Forms.CheckBox checkB_130;
        private System.Windows.Forms.CheckBox checkB_90;
        private System.Windows.Forms.CheckBox checkB_120;
        private System.Windows.Forms.CheckBox checkB_80;
        private System.Windows.Forms.CheckBox checkB_70;
        private System.Windows.Forms.CheckBox checkB_60;
        private System.Windows.Forms.CheckBox checkB_50;
        private System.Windows.Forms.CheckBox checkB_40;
        private System.Windows.Forms.CheckBox checkB_30;
        private System.Windows.Forms.RadioButton checkB_Up;
        private System.Windows.Forms.ComboBox combo_Grade2_Code;
        private System.Windows.Forms.ComboBox combo_Grade2;
        private System.Windows.Forms.CheckBox checkB_Up_60;
        private System.Windows.Forms.CheckBox checkB_20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button butt_Excel_Pay_1;
        private System.Windows.Forms.Button butt_Excel_Pay_2;
        private System.Windows.Forms.Button butt_Excel_Pay_3;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.RadioButton radioB_Su_Not;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioB_Su;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.RadioButton radioB_Leave;
        private System.Windows.Forms.RadioButton radioB_Leave_Not;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.CheckBox chk_Leave_Only;
        private System.Windows.Forms.CheckBox chk_Leave;
        private System.Windows.Forms.Label label24;
    }
}