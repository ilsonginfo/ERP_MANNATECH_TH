﻿namespace MLM_Program
{
    partial class frmMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.butt_Excel = new System.Windows.Forms.Button();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Save = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtxtMbid_s = new System.Windows.Forms.MaskedTextBox();
            this.mtxtMbid_n = new System.Windows.Forms.MaskedTextBox();
            this.DTP_RegDate = new System.Windows.Forms.DateTimePicker();
            this.txtCenter_Code = new System.Windows.Forms.TextBox();
            this.txtCenter = new System.Windows.Forms.TextBox();
            this.butt_AddCode = new System.Windows.Forms.Button();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtBank_Code = new System.Windows.Forms.TextBox();
            this.txtBank = new System.Windows.Forms.TextBox();
            this.txtName_Accnt = new System.Windows.Forms.TextBox();
            this.txtAccount = new System.Windows.Forms.TextBox();
            this.txtName_E_1 = new System.Windows.Forms.TextBox();
            this.txtName_E_2 = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtWebID = new System.Windows.Forms.TextBox();
            this.opt_sell_3 = new System.Windows.Forms.RadioButton();
            this.opt_sell_2 = new System.Windows.Forms.RadioButton();
            this.txtLineCnt = new System.Windows.Forms.TextBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.DTP_EdDate = new System.Windows.Forms.DateTimePicker();
            this.DTP_BrithDay = new System.Windows.Forms.DateTimePicker();
            this.txtSN_s = new System.Windows.Forms.TextBox();
            this.txtSN_n = new System.Windows.Forms.TextBox();
            this.txtName_n = new System.Windows.Forms.TextBox();
            this.txtName_s = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.check_CpnoDocument = new System.Windows.Forms.CheckBox();
            this.check_BankDocument = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.raButt_IN_2 = new System.Windows.Forms.RadioButton();
            this.raButt_IN_1 = new System.Windows.Forms.RadioButton();
            this.tbl_save = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.chk_Top_s = new System.Windows.Forms.CheckBox();
            this.chk_Foreign_s = new System.Windows.Forms.CheckBox();
            this.tbl_nom = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.chk_Top_n = new System.Windows.Forms.CheckBox();
            this.chk_Foreign_n = new System.Windows.Forms.CheckBox();
            this.opt_Bir_TF_2 = new System.Windows.Forms.RadioButton();
            this.opt_Bir_TF_1 = new System.Windows.Forms.RadioButton();
            this.grB_Line = new System.Windows.Forms.GroupBox();
            this.dGridView_Li = new System.Windows.Forms.DataGridView();
            this.dGridView_Base = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.opt_MCode_A = new System.Windows.Forms.RadioButton();
            this.opt_MCode_R = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.check_Cpno_Multi = new System.Windows.Forms.CheckBox();
            this.check_Cpno_Err = new System.Windows.Forms.CheckBox();
            this.check_Cpno = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.raButt_IN_3 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.mtxtRegDate = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.rdoLineLeft = new System.Windows.Forms.RadioButton();
            this.rdoLineRight = new System.Windows.Forms.RadioButton();
            this.pnlZipCode_KR = new System.Windows.Forms.TableLayoutPanel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.mtxtZip1 = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.mtxtTel1 = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.mtxtTel2 = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.label37 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.lbl_ACC = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.mtxtBrithDay = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.mtxtEdDate = new System.Windows.Forms.MaskedTextBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pnlSubDistrict_TH = new System.Windows.Forms.TableLayoutPanel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.cbSubDistrict_TH = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.pnlDistrict_TH = new System.Windows.Forms.TableLayoutPanel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.cbDistrict_TH = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.pnlProvince_TH = new System.Windows.Forms.TableLayoutPanel();
            this.panel73 = new System.Windows.Forms.Panel();
            this.cbProvince_TH = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.pnlZipCode_TH = new System.Windows.Forms.TableLayoutPanel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.txtZipCode_TH = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.tlpNaCode = new System.Windows.Forms.TableLayoutPanel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.combo_Se_2 = new System.Windows.Forms.ComboBox();
            this.combo_Se_Code_2 = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.panel71 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label53 = new System.Windows.Forms.Label();
            this.checkB_SMS_FLAG = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel43 = new System.Windows.Forms.TableLayoutPanel();
            this.label51 = new System.Windows.Forms.Label();
            this.tab_Nation = new System.Windows.Forms.TableLayoutPanel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.combo_Se = new System.Windows.Forms.ComboBox();
            this.combo_Se_Code = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkB_EMail_FLAG = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.radioB_Sex_Y = new System.Windows.Forms.RadioButton();
            this.radioB_Sex_X = new System.Windows.Forms.RadioButton();
            this.label49 = new System.Windows.Forms.Label();
            this.txt_IpinCI = new System.Windows.Forms.TextBox();
            this.txt_IpinDI = new System.Windows.Forms.TextBox();
            this.panel67 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.checkB_AgreeMarketing = new System.Windows.Forms.CheckBox();
            this.checkB_Third_Person_Agree = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel65 = new System.Windows.Forms.TableLayoutPanel();
            this.Lbl_Certify = new System.Windows.Forms.Label();
            this.butt_Certify = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.label44 = new System.Windows.Forms.Label();
            this.panel57 = new System.Windows.Forms.Panel();
            this.mtxtVisaDay = new System.Windows.Forms.MaskedTextBox();
            this.DTP_VisaDay = new System.Windows.Forms.DateTimePicker();
            this.button_Acc_Reg = new System.Windows.Forms.Button();
            this.txtAccount_Reg = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.check_LR = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtB1 = new System.Windows.Forms.TextBox();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel64 = new System.Windows.Forms.Panel();
            this.radioB_G4 = new System.Windows.Forms.RadioButton();
            this.radioB_G8 = new System.Windows.Forms.RadioButton();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.radioB_Begin = new System.Windows.Forms.RadioButton();
            this.radioB_RBO = new System.Windows.Forms.RadioButton();
            this.panel_Config = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tab_Sub = new System.Windows.Forms.TabControl();
            this.tab_Auto = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel43 = new System.Windows.Forms.Panel();
            this.tab_C = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.label47 = new System.Windows.Forms.Label();
            this.panel70 = new System.Windows.Forms.Panel();
            this.mtxtTel2_C = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel69 = new System.Windows.Forms.Panel();
            this.txtEmail_C = new System.Windows.Forms.TextBox();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.raButt_IN_1_C = new System.Windows.Forms.RadioButton();
            this.raButt_IN_2_C = new System.Windows.Forms.RadioButton();
            this.check_CC = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel47 = new System.Windows.Forms.Panel();
            this.txtName_E_2_C = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel48 = new System.Windows.Forms.Panel();
            this.txtName_E_1_C = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.label41 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.mtxtSn_C = new System.Windows.Forms.MaskedTextBox();
            this.tableL_Birth_KR_C = new System.Windows.Forms.TableLayoutPanel();
            this.label42 = new System.Windows.Forms.Label();
            this.panel51 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.mtxtBrithDayC = new System.Windows.Forms.MaskedTextBox();
            this.DTP_BrithDayC = new System.Windows.Forms.DateTimePicker();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.txtName_C = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tab_Day = new System.Windows.Forms.TabPage();
            this.tab_Hide = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.mtxtSn = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txtAddress2_Auto = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.txtName_Auto = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.txtAddress_Auto = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.mtxtTel_Auto = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.butt_AddCode2 = new System.Windows.Forms.Button();
            this.mtxtZip_Auto = new System.Windows.Forms.MaskedTextBox();
            this.butt_AddCodeT1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel52 = new System.Windows.Forms.Panel();
            this.txt_C_Card_Number = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel53 = new System.Windows.Forms.TableLayoutPanel();
            this.label48 = new System.Windows.Forms.Label();
            this.panel54 = new System.Windows.Forms.Panel();
            this.txt_C_Name_3 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.label46 = new System.Windows.Forms.Label();
            this.panel53 = new System.Windows.Forms.Panel();
            this.combo_C_Card_Month = new System.Windows.Forms.ComboBox();
            this.combo_C_Card_Year = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.txt_C_Card_Code = new System.Windows.Forms.TextBox();
            this.txt_C_Card = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.cboRegDateA = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.combo_Auto_Date = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.check_Auto = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.txtRemark_A = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.label50 = new System.Windows.Forms.Label();
            this.panel56 = new System.Windows.Forms.Panel();
            this.txt_Auto_PR = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.label52 = new System.Windows.Forms.Label();
            this.panel58 = new System.Windows.Forms.Panel();
            this.txt_Auto_PR2 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel57 = new System.Windows.Forms.TableLayoutPanel();
            this.label56 = new System.Windows.Forms.Label();
            this.panel65 = new System.Windows.Forms.Panel();
            this.combo_C_Card_Per = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel72 = new System.Windows.Forms.TableLayoutPanel();
            this.label81 = new System.Windows.Forms.Label();
            this.panel84 = new System.Windows.Forms.Panel();
            this.txt_C_P_Number = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel62 = new System.Windows.Forms.TableLayoutPanel();
            this.label80 = new System.Windows.Forms.Label();
            this.panel83 = new System.Windows.Forms.Panel();
            this.txt_C_B_Number = new System.Windows.Forms.TextBox();
            this.txt_Auto_Date = new System.Windows.Forms.TextBox();
            this.dGridView_Good = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tbl_save.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tbl_nom.SuspendLayout();
            this.panel11.SuspendLayout();
            this.grB_Line.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Li)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.panel22.SuspendLayout();
            this.pnlZipCode_KR.SuspendLayout();
            this.panel23.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.panel28.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel29.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.panel31.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.panel32.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.panel33.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.panel35.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel36.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pnlSubDistrict_TH.SuspendLayout();
            this.panel75.SuspendLayout();
            this.pnlDistrict_TH.SuspendLayout();
            this.panel74.SuspendLayout();
            this.pnlProvince_TH.SuspendLayout();
            this.panel73.SuspendLayout();
            this.pnlZipCode_TH.SuspendLayout();
            this.panel72.SuspendLayout();
            this.tlpNaCode.SuspendLayout();
            this.panel39.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            this.panel71.SuspendLayout();
            this.tableLayoutPanel43.SuspendLayout();
            this.tab_Nation.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.tableLayoutPanel65.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel_Config.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tab_Sub.SuspendLayout();
            this.tab_Auto.SuspendLayout();
            this.tab_C.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.panel70.SuspendLayout();
            this.tableLayoutPanel40.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel62.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.panel47.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.panel48.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.panel50.SuspendLayout();
            this.tableL_Birth_KR_C.SuspendLayout();
            this.panel51.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.panel55.SuspendLayout();
            this.tab_Day.SuspendLayout();
            this.tab_Hide.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Good)).BeginInit();
            this.SuspendLayout();
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.ReadOnly = true;
            this.mtxtMbid.Size = new System.Drawing.Size(164, 21);
            this.mtxtMbid.TabIndex = 1;
            this.mtxtMbid.TabStop = false;
            this.mtxtMbid.Click += new System.EventHandler(this.mtxtMbid_Click);
            this.mtxtMbid.TextChanged += new System.EventHandler(this.mtxtMbid_TextChanged);
            this.mtxtMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_KeyPress);
            this.mtxtMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.butt_Excel);
            this.panel1.Controls.Add(this.butt_Delete);
            this.panel1.Controls.Add(this.butt_Clear);
            this.panel1.Controls.Add(this.butt_Save);
            this.panel1.Controls.Add(this.butt_Exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1907, 28);
            this.panel1.TabIndex = 1;
            // 
            // butt_Excel
            // 
            this.butt_Excel.BackColor = System.Drawing.Color.White;
            this.butt_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel.Location = new System.Drawing.Point(528, 1);
            this.butt_Excel.Name = "butt_Excel";
            this.butt_Excel.Size = new System.Drawing.Size(111, 26);
            this.butt_Excel.TabIndex = 4;
            this.butt_Excel.TabStop = false;
            this.butt_Excel.Text = "엑셀";
            this.butt_Excel.UseVisualStyleBackColor = false;
            this.butt_Excel.Visible = false;
            this.butt_Excel.Click += new System.EventHandler(this.butt_Excel_Click);
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(125, 1);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(111, 26);
            this.butt_Delete.TabIndex = 3;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "삭제";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Visible = false;
            this.butt_Delete.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(89)))), ((int)(((byte)(97)))));
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.ForeColor = System.Drawing.Color.White;
            this.butt_Clear.Location = new System.Drawing.Point(266, 1);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(111, 26);
            this.butt_Clear.TabIndex = 2;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            this.butt_Clear.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.ForeColor = System.Drawing.Color.White;
            this.butt_Save.Location = new System.Drawing.Point(411, 1);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(111, 26);
            this.butt_Save.TabIndex = 3;
            this.butt_Save.Text = "저장";
            this.butt_Save.UseVisualStyleBackColor = false;
            this.butt_Save.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(658, 1);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(111, 26);
            this.butt_Exit.TabIndex = 0;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            this.butt_Exit.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName.Location = new System.Drawing.Point(3, 3);
            this.txtName.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(164, 22);
            this.txtName.TabIndex = 2;
            this.txtName.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtMbid_s
            // 
            this.mtxtMbid_s.Location = new System.Drawing.Point(3, 19);
            this.mtxtMbid_s.Name = "mtxtMbid_s";
            this.mtxtMbid_s.Size = new System.Drawing.Size(113, 21);
            this.mtxtMbid_s.TabIndex = 24;
            this.mtxtMbid_s.Click += new System.EventHandler(this.mtxtMbid_Click);
            this.mtxtMbid_s.TextChanged += new System.EventHandler(this.mtxtMbid_TextChanged);
            this.mtxtMbid_s.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid_s.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_KeyPress);
            this.mtxtMbid_s.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtMbid_n
            // 
            this.mtxtMbid_n.Location = new System.Drawing.Point(3, 19);
            this.mtxtMbid_n.Name = "mtxtMbid_n";
            this.mtxtMbid_n.Size = new System.Drawing.Size(113, 21);
            this.mtxtMbid_n.TabIndex = 22;
            this.mtxtMbid_n.Click += new System.EventHandler(this.mtxtMbid_Click);
            this.mtxtMbid_n.TextChanged += new System.EventHandler(this.mtxtMbid_TextChanged);
            this.mtxtMbid_n.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid_n.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_KeyPress);
            this.mtxtMbid_n.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_RegDate
            // 
            this.DTP_RegDate.Location = new System.Drawing.Point(146, 3);
            this.DTP_RegDate.Name = "DTP_RegDate";
            this.DTP_RegDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_RegDate.TabIndex = 0;
            this.DTP_RegDate.TabStop = false;
            this.DTP_RegDate.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // txtCenter_Code
            // 
            this.txtCenter_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.txtCenter_Code.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtCenter_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter_Code.Location = new System.Drawing.Point(109, 3);
            this.txtCenter_Code.MaxLength = 30;
            this.txtCenter_Code.Name = "txtCenter_Code";
            this.txtCenter_Code.Size = new System.Drawing.Size(60, 22);
            this.txtCenter_Code.TabIndex = 81;
            this.txtCenter_Code.TabStop = false;
            // 
            // txtCenter
            // 
            this.txtCenter.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtCenter.Location = new System.Drawing.Point(3, 3);
            this.txtCenter.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtCenter.MaxLength = 30;
            this.txtCenter.Name = "txtCenter";
            this.txtCenter.Size = new System.Drawing.Size(106, 22);
            this.txtCenter.TabIndex = 20;
            this.txtCenter.Tag = "ncode";
            this.txtCenter.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtCenter.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtCenter.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtCenter.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // butt_AddCode
            // 
            this.butt_AddCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_AddCode.Location = new System.Drawing.Point(93, 1);
            this.butt_AddCode.Name = "butt_AddCode";
            this.butt_AddCode.Size = new System.Drawing.Size(75, 26);
            this.butt_AddCode.TabIndex = 11;
            this.butt_AddCode.TabStop = false;
            this.butt_AddCode.Text = "우편_번호";
            this.butt_AddCode.UseVisualStyleBackColor = true;
            this.butt_AddCode.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // txtAddress2
            // 
            this.txtAddress2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress2.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAddress2.Location = new System.Drawing.Point(3, 3);
            this.txtAddress2.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtAddress2.MaxLength = 40;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(465, 22);
            this.txtAddress2.TabIndex = 13;
            this.txtAddress2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtAddress1
            // 
            this.txtAddress1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress1.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAddress1.Location = new System.Drawing.Point(3, 3);
            this.txtAddress1.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtAddress1.MaxLength = 40;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(465, 22);
            this.txtAddress1.TabIndex = 12;
            this.txtAddress1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtBank_Code
            // 
            this.txtBank_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.txtBank_Code.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtBank_Code.ForeColor = System.Drawing.Color.White;
            this.txtBank_Code.Location = new System.Drawing.Point(109, 3);
            this.txtBank_Code.MaxLength = 30;
            this.txtBank_Code.Name = "txtBank_Code";
            this.txtBank_Code.Size = new System.Drawing.Size(60, 22);
            this.txtBank_Code.TabIndex = 100;
            this.txtBank_Code.TabStop = false;
            // 
            // txtBank
            // 
            this.txtBank.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtBank.Location = new System.Drawing.Point(3, 3);
            this.txtBank.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtBank.MaxLength = 30;
            this.txtBank.Name = "txtBank";
            this.txtBank.Size = new System.Drawing.Size(106, 22);
            this.txtBank.TabIndex = 14;
            this.txtBank.Tag = "ncode";
            this.txtBank.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtBank.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtBank.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtBank.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtName_Accnt
            // 
            this.txtName_Accnt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName_Accnt.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_Accnt.Location = new System.Drawing.Point(3, 3);
            this.txtName_Accnt.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtName_Accnt.MaxLength = 30;
            this.txtName_Accnt.Name = "txtName_Accnt";
            this.txtName_Accnt.Size = new System.Drawing.Size(164, 22);
            this.txtName_Accnt.TabIndex = 23;
            this.txtName_Accnt.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtName_Accnt.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_Accnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_Accnt.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtAccount
            // 
            this.txtAccount.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAccount.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAccount.Location = new System.Drawing.Point(3, 3);
            this.txtAccount.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtAccount.MaxLength = 30;
            this.txtAccount.Name = "txtAccount";
            this.txtAccount.Size = new System.Drawing.Size(289, 22);
            this.txtAccount.TabIndex = 15;
            this.txtAccount.Tag = "-";
            this.txtAccount.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAccount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAccount.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtName_E_1
            // 
            this.txtName_E_1.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_E_1.Location = new System.Drawing.Point(3, 3);
            this.txtName_E_1.MaxLength = 30;
            this.txtName_E_1.Name = "txtName_E_1";
            this.txtName_E_1.Size = new System.Drawing.Size(164, 22);
            this.txtName_E_1.TabIndex = 6;
            this.txtName_E_1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_E_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_E_1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtName_E_2
            // 
            this.txtName_E_2.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_E_2.Location = new System.Drawing.Point(3, 3);
            this.txtName_E_2.MaxLength = 30;
            this.txtName_E_2.Name = "txtName_E_2";
            this.txtName_E_2.Size = new System.Drawing.Size(164, 22);
            this.txtName_E_2.TabIndex = 21;
            this.txtName_E_2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_E_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_E_2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtEmail.Location = new System.Drawing.Point(3, 3);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtEmail.MaxLength = 50;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(165, 22);
            this.txtEmail.TabIndex = 9;
            this.txtEmail.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtEmail.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtPassword.Location = new System.Drawing.Point(3, 3);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtPassword.MaxLength = 30;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(164, 22);
            this.txtPassword.TabIndex = 16;
            this.txtPassword.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtPassword.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtWebID
            // 
            this.txtWebID.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtWebID.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtWebID.Location = new System.Drawing.Point(3, 3);
            this.txtWebID.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtWebID.MaxLength = 30;
            this.txtWebID.Name = "txtWebID";
            this.txtWebID.Size = new System.Drawing.Size(164, 22);
            this.txtWebID.TabIndex = 25;
            this.txtWebID.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtWebID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtWebID.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // opt_sell_3
            // 
            this.opt_sell_3.AutoSize = true;
            this.opt_sell_3.Location = new System.Drawing.Point(94, 7);
            this.opt_sell_3.Name = "opt_sell_3";
            this.opt_sell_3.Size = new System.Drawing.Size(59, 16);
            this.opt_sell_3.TabIndex = 55;
            this.opt_sell_3.Text = "소비자";
            this.opt_sell_3.UseVisualStyleBackColor = true;
            // 
            // opt_sell_2
            // 
            this.opt_sell_2.AutoSize = true;
            this.opt_sell_2.Checked = true;
            this.opt_sell_2.Location = new System.Drawing.Point(11, 7);
            this.opt_sell_2.Name = "opt_sell_2";
            this.opt_sell_2.Size = new System.Drawing.Size(59, 16);
            this.opt_sell_2.TabIndex = 54;
            this.opt_sell_2.TabStop = true;
            this.opt_sell_2.Text = "판매원";
            this.opt_sell_2.UseVisualStyleBackColor = true;
            // 
            // txtLineCnt
            // 
            this.txtLineCnt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLineCnt.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtLineCnt.Location = new System.Drawing.Point(146, 3);
            this.txtLineCnt.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtLineCnt.MaxLength = 3;
            this.txtLineCnt.Name = "txtLineCnt";
            this.txtLineCnt.Size = new System.Drawing.Size(21, 22);
            this.txtLineCnt.TabIndex = 8;
            this.txtLineCnt.Tag = "1";
            this.txtLineCnt.Visible = false;
            this.txtLineCnt.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtLineCnt.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtLineCnt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtLineCnt.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRemark.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtRemark.Location = new System.Drawing.Point(3, 3);
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtRemark.MaxLength = 50;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(465, 22);
            this.txtRemark.TabIndex = 30;
            this.txtRemark.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtRemark.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtRemark.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_EdDate
            // 
            this.DTP_EdDate.Location = new System.Drawing.Point(146, 3);
            this.DTP_EdDate.Name = "DTP_EdDate";
            this.DTP_EdDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_EdDate.TabIndex = 126;
            this.DTP_EdDate.TabStop = false;
            this.DTP_EdDate.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_BrithDay
            // 
            this.DTP_BrithDay.Location = new System.Drawing.Point(146, 3);
            this.DTP_BrithDay.Name = "DTP_BrithDay";
            this.DTP_BrithDay.Size = new System.Drawing.Size(21, 21);
            this.DTP_BrithDay.TabIndex = 129;
            this.DTP_BrithDay.TabStop = false;
            this.DTP_BrithDay.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // txtSN_s
            // 
            this.txtSN_s.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtSN_s.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSN_s.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtSN_s.Location = new System.Drawing.Point(193, 19);
            this.txtSN_s.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtSN_s.MaxLength = 4;
            this.txtSN_s.Name = "txtSN_s";
            this.txtSN_s.ReadOnly = true;
            this.txtSN_s.Size = new System.Drawing.Size(107, 22);
            this.txtSN_s.TabIndex = 130;
            this.txtSN_s.TabStop = false;
            this.txtSN_s.Tag = "1";
            // 
            // txtSN_n
            // 
            this.txtSN_n.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtSN_n.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSN_n.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtSN_n.Location = new System.Drawing.Point(193, 19);
            this.txtSN_n.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtSN_n.MaxLength = 4;
            this.txtSN_n.Name = "txtSN_n";
            this.txtSN_n.ReadOnly = true;
            this.txtSN_n.Size = new System.Drawing.Size(107, 22);
            this.txtSN_n.TabIndex = 131;
            this.txtSN_n.TabStop = false;
            this.txtSN_n.Tag = "1";
            // 
            // txtName_n
            // 
            this.txtName_n.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_n.Location = new System.Drawing.Point(116, 19);
            this.txtName_n.MaxLength = 30;
            this.txtName_n.Name = "txtName_n";
            this.txtName_n.Size = new System.Drawing.Size(77, 22);
            this.txtName_n.TabIndex = 23;
            this.txtName_n.Tag = "name";
            this.txtName_n.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_n.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_n.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtName_s
            // 
            this.txtName_s.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_s.Location = new System.Drawing.Point(116, 19);
            this.txtName_s.MaxLength = 30;
            this.txtName_s.Name = "txtName_s";
            this.txtName_s.Size = new System.Drawing.Size(77, 22);
            this.txtName_s.TabIndex = 25;
            this.txtName_s.Tag = "name";
            this.txtName_s.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_s.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_s.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(655, 257);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(49, 45);
            this.groupBox1.TabIndex = 100;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel27.Location = new System.Drawing.Point(613, 90);
            this.tableLayoutPanel27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(224, 49);
            this.tableLayoutPanel27.TabIndex = 172;
            this.tableLayoutPanel27.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.check_CpnoDocument);
            this.panel2.Controls.Add(this.check_BankDocument);
            this.panel2.Location = new System.Drawing.Point(124, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(98, 41);
            this.panel2.TabIndex = 92;
            // 
            // check_CpnoDocument
            // 
            this.check_CpnoDocument.AutoSize = true;
            this.check_CpnoDocument.Checked = true;
            this.check_CpnoDocument.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_CpnoDocument.Location = new System.Drawing.Point(2, 22);
            this.check_CpnoDocument.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.check_CpnoDocument.Name = "check_CpnoDocument";
            this.check_CpnoDocument.Size = new System.Drawing.Size(72, 16);
            this.check_CpnoDocument.TabIndex = 174;
            this.check_CpnoDocument.Text = "통장사본";
            this.check_CpnoDocument.UseVisualStyleBackColor = true;
            // 
            // check_BankDocument
            // 
            this.check_BankDocument.AutoSize = true;
            this.check_BankDocument.Checked = true;
            this.check_BankDocument.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_BankDocument.Location = new System.Drawing.Point(2, 2);
            this.check_BankDocument.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.check_BankDocument.Name = "check_BankDocument";
            this.check_BankDocument.Size = new System.Drawing.Size(84, 16);
            this.check_BankDocument.TabIndex = 173;
            this.check_BankDocument.Text = "신분증사본";
            this.check_BankDocument.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.SystemColors.Control;
            this.label16.Location = new System.Drawing.Point(5, 2);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(114, 45);
            this.label16.TabIndex = 12;
            this.label16.Text = "제출서류";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // raButt_IN_2
            // 
            this.raButt_IN_2.AutoSize = true;
            this.raButt_IN_2.Location = new System.Drawing.Point(71, 6);
            this.raButt_IN_2.Name = "raButt_IN_2";
            this.raButt_IN_2.Size = new System.Drawing.Size(59, 16);
            this.raButt_IN_2.TabIndex = 5;
            this.raButt_IN_2.Text = "외국인";
            this.raButt_IN_2.UseVisualStyleBackColor = true;
            this.raButt_IN_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.radioButt_Sn_MouseUp);
            // 
            // raButt_IN_1
            // 
            this.raButt_IN_1.AutoSize = true;
            this.raButt_IN_1.Checked = true;
            this.raButt_IN_1.Location = new System.Drawing.Point(6, 6);
            this.raButt_IN_1.Name = "raButt_IN_1";
            this.raButt_IN_1.Size = new System.Drawing.Size(59, 16);
            this.raButt_IN_1.TabIndex = 4;
            this.raButt_IN_1.TabStop = true;
            this.raButt_IN_1.Text = "내국인";
            this.raButt_IN_1.UseVisualStyleBackColor = true;
            this.raButt_IN_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.radioButt_Sn_MouseUp);
            // 
            // tbl_save
            // 
            this.tbl_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tbl_save.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tbl_save.ColumnCount = 2;
            this.tbl_save.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tbl_save.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_save.Controls.Add(this.label4, 0, 0);
            this.tbl_save.Controls.Add(this.panel5, 1, 0);
            this.tbl_save.Location = new System.Drawing.Point(1, 567);
            this.tbl_save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbl_save.Name = "tbl_save";
            this.tbl_save.RowCount = 1;
            this.tbl_save.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_save.Size = new System.Drawing.Size(601, 50);
            this.tbl_save.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label4.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(2, 2);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(290, 46);
            this.label4.TabIndex = 0;
            this.label4.Text = "*후원인_회원번호/성명/주민번호";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.chk_Top_s);
            this.panel5.Controls.Add(this.chk_Foreign_s);
            this.panel5.Controls.Add(this.mtxtMbid_s);
            this.panel5.Controls.Add(this.txtSN_s);
            this.panel5.Controls.Add(this.txtName_s);
            this.panel5.Location = new System.Drawing.Point(296, 4);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(301, 42);
            this.panel5.TabIndex = 0;
            // 
            // chk_Top_s
            // 
            this.chk_Top_s.AutoSize = true;
            this.chk_Top_s.Location = new System.Drawing.Point(129, 3);
            this.chk_Top_s.Name = "chk_Top_s";
            this.chk_Top_s.Size = new System.Drawing.Size(90, 16);
            this.chk_Top_s.TabIndex = 143;
            this.chk_Top_s.TabStop = false;
            this.chk_Top_s.Text = "후원_최상위";
            this.chk_Top_s.UseVisualStyleBackColor = true;
            this.chk_Top_s.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chk_Top_MouseUp);
            // 
            // chk_Foreign_s
            // 
            this.chk_Foreign_s.AutoSize = true;
            this.chk_Foreign_s.Location = new System.Drawing.Point(3, 3);
            this.chk_Foreign_s.Name = "chk_Foreign_s";
            this.chk_Foreign_s.Size = new System.Drawing.Size(126, 16);
            this.chk_Foreign_s.TabIndex = 144;
            this.chk_Foreign_s.TabStop = false;
            this.chk_Foreign_s.Text = "후원_외국조직회원";
            this.chk_Foreign_s.UseVisualStyleBackColor = true;
            this.chk_Foreign_s.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chk_Top_MouseUp);
            // 
            // tbl_nom
            // 
            this.tbl_nom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tbl_nom.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tbl_nom.ColumnCount = 2;
            this.tbl_nom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tbl_nom.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_nom.Controls.Add(this.label31, 0, 0);
            this.tbl_nom.Controls.Add(this.panel11, 1, 0);
            this.tbl_nom.Location = new System.Drawing.Point(1, 517);
            this.tbl_nom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbl_nom.Name = "tbl_nom";
            this.tbl_nom.RowCount = 1;
            this.tbl_nom.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbl_nom.Size = new System.Drawing.Size(601, 50);
            this.tbl_nom.TabIndex = 21;
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label31.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(2, 2);
            this.label31.Margin = new System.Windows.Forms.Padding(0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(290, 46);
            this.label31.TabIndex = 0;
            this.label31.Text = "*추천인_회원번호/성명/주민번호";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel11
            // 
            this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.chk_Top_n);
            this.panel11.Controls.Add(this.chk_Foreign_n);
            this.panel11.Controls.Add(this.txtName_n);
            this.panel11.Controls.Add(this.mtxtMbid_n);
            this.panel11.Controls.Add(this.txtSN_n);
            this.panel11.Location = new System.Drawing.Point(296, 4);
            this.panel11.Margin = new System.Windows.Forms.Padding(2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(301, 42);
            this.panel11.TabIndex = 0;
            // 
            // chk_Top_n
            // 
            this.chk_Top_n.AutoSize = true;
            this.chk_Top_n.Location = new System.Drawing.Point(129, 3);
            this.chk_Top_n.Name = "chk_Top_n";
            this.chk_Top_n.Size = new System.Drawing.Size(90, 16);
            this.chk_Top_n.TabIndex = 142;
            this.chk_Top_n.TabStop = false;
            this.chk_Top_n.Text = "추천_최상위";
            this.chk_Top_n.UseVisualStyleBackColor = true;
            this.chk_Top_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chk_Top_MouseUp);
            // 
            // chk_Foreign_n
            // 
            this.chk_Foreign_n.AutoSize = true;
            this.chk_Foreign_n.Location = new System.Drawing.Point(3, 3);
            this.chk_Foreign_n.Name = "chk_Foreign_n";
            this.chk_Foreign_n.Size = new System.Drawing.Size(126, 16);
            this.chk_Foreign_n.TabIndex = 143;
            this.chk_Foreign_n.TabStop = false;
            this.chk_Foreign_n.Text = "추천_외국조직회원";
            this.chk_Foreign_n.UseVisualStyleBackColor = true;
            this.chk_Foreign_n.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chk_Top_MouseUp);
            // 
            // opt_Bir_TF_2
            // 
            this.opt_Bir_TF_2.AutoSize = true;
            this.opt_Bir_TF_2.Location = new System.Drawing.Point(175, 15);
            this.opt_Bir_TF_2.Name = "opt_Bir_TF_2";
            this.opt_Bir_TF_2.Size = new System.Drawing.Size(47, 16);
            this.opt_Bir_TF_2.TabIndex = 55;
            this.opt_Bir_TF_2.Text = "음력";
            this.opt_Bir_TF_2.UseVisualStyleBackColor = true;
            this.opt_Bir_TF_2.Visible = false;
            // 
            // opt_Bir_TF_1
            // 
            this.opt_Bir_TF_1.AutoSize = true;
            this.opt_Bir_TF_1.Checked = true;
            this.opt_Bir_TF_1.Location = new System.Drawing.Point(174, 3);
            this.opt_Bir_TF_1.Name = "opt_Bir_TF_1";
            this.opt_Bir_TF_1.Size = new System.Drawing.Size(47, 16);
            this.opt_Bir_TF_1.TabIndex = 54;
            this.opt_Bir_TF_1.TabStop = true;
            this.opt_Bir_TF_1.Text = "양력";
            this.opt_Bir_TF_1.UseVisualStyleBackColor = true;
            this.opt_Bir_TF_1.Visible = false;
            // 
            // grB_Line
            // 
            this.grB_Line.BackColor = System.Drawing.Color.Transparent;
            this.grB_Line.Controls.Add(this.dGridView_Li);
            this.grB_Line.Location = new System.Drawing.Point(1, 654);
            this.grB_Line.Name = "grB_Line";
            this.grB_Line.Size = new System.Drawing.Size(299, 180);
            this.grB_Line.TabIndex = 141;
            this.grB_Line.TabStop = false;
            this.grB_Line.Text = "입력후원인하선";
            // 
            // dGridView_Li
            // 
            this.dGridView_Li.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Li.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Li.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dGridView_Li.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Li.DefaultCellStyle = dataGridViewCellStyle2;
            this.dGridView_Li.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Li.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Li.Location = new System.Drawing.Point(3, 17);
            this.dGridView_Li.Name = "dGridView_Li";
            this.dGridView_Li.RowTemplate.Height = 23;
            this.dGridView_Li.Size = new System.Drawing.Size(293, 160);
            this.dGridView_Li.TabIndex = 140;
            this.dGridView_Li.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            // 
            // dGridView_Base
            // 
            this.dGridView_Base.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGridView_Base.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGridView_Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Base.Name = "dGridView_Base";
            this.dGridView_Base.RowTemplate.Height = 23;
            this.dGridView_Base.Size = new System.Drawing.Size(1288, 876);
            this.dGridView_Base.TabIndex = 8;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(609, 144);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(207, 60);
            this.tableLayoutPanel2.TabIndex = 177;
            this.tableLayoutPanel2.Visible = false;
            // 
            // panel15
            // 
            this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel15.Controls.Add(this.opt_MCode_A);
            this.panel15.Controls.Add(this.opt_MCode_R);
            this.panel15.Location = new System.Drawing.Point(124, 2);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(81, 56);
            this.panel15.TabIndex = 92;
            // 
            // opt_MCode_A
            // 
            this.opt_MCode_A.AutoSize = true;
            this.opt_MCode_A.Location = new System.Drawing.Point(5, 28);
            this.opt_MCode_A.Name = "opt_MCode_A";
            this.opt_MCode_A.Size = new System.Drawing.Size(71, 16);
            this.opt_MCode_A.TabIndex = 56;
            this.opt_MCode_A.Text = "자동증가";
            this.opt_MCode_A.UseVisualStyleBackColor = true;
            this.opt_MCode_A.MouseUp += new System.Windows.Forms.MouseEventHandler(this.opt_MCode_R_MouseUp);
            // 
            // opt_MCode_R
            // 
            this.opt_MCode_R.AutoSize = true;
            this.opt_MCode_R.Location = new System.Drawing.Point(5, 6);
            this.opt_MCode_R.Name = "opt_MCode_R";
            this.opt_MCode_R.Size = new System.Drawing.Size(71, 16);
            this.opt_MCode_R.TabIndex = 0;
            this.opt_MCode_R.TabStop = true;
            this.opt_MCode_R.Text = "랜덤부여";
            this.opt_MCode_R.UseVisualStyleBackColor = true;
            this.opt_MCode_R.MouseUp += new System.Windows.Forms.MouseEventHandler(this.opt_MCode_R_MouseUp);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("돋움", 9F);
            this.label17.Location = new System.Drawing.Point(2, 2);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 56);
            this.label17.TabIndex = 12;
            this.label17.Text = "회원번호부여방법";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // check_Cpno_Multi
            // 
            this.check_Cpno_Multi.AutoSize = true;
            this.check_Cpno_Multi.Location = new System.Drawing.Point(323, 8);
            this.check_Cpno_Multi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.check_Cpno_Multi.Name = "check_Cpno_Multi";
            this.check_Cpno_Multi.Size = new System.Drawing.Size(88, 16);
            this.check_Cpno_Multi.TabIndex = 4;
            this.check_Cpno_Multi.Text = "다구좌 가능";
            this.check_Cpno_Multi.UseVisualStyleBackColor = true;
            this.check_Cpno_Multi.Visible = false;
            this.check_Cpno_Multi.MouseClick += new System.Windows.Forms.MouseEventHandler(this.check_Cpno_MouseClick);
            // 
            // check_Cpno_Err
            // 
            this.check_Cpno_Err.AutoSize = true;
            this.check_Cpno_Err.Location = new System.Drawing.Point(193, 8);
            this.check_Cpno_Err.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.check_Cpno_Err.Name = "check_Cpno_Err";
            this.check_Cpno_Err.Size = new System.Drawing.Size(124, 16);
            this.check_Cpno_Err.TabIndex = 3;
            this.check_Cpno_Err.Text = "주민번호 오류체크";
            this.check_Cpno_Err.UseVisualStyleBackColor = true;
            this.check_Cpno_Err.MouseClick += new System.Windows.Forms.MouseEventHandler(this.check_Cpno_MouseClick);
            // 
            // check_Cpno
            // 
            this.check_Cpno.AutoSize = true;
            this.check_Cpno.ForeColor = System.Drawing.Color.Black;
            this.check_Cpno.Location = new System.Drawing.Point(4, 8);
            this.check_Cpno.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.check_Cpno.Name = "check_Cpno";
            this.check_Cpno.Size = new System.Drawing.Size(124, 16);
            this.check_Cpno.TabIndex = 2;
            this.check_Cpno.Text = "주민번호 필수입력";
            this.check_Cpno.UseVisualStyleBackColor = true;
            this.check_Cpno.MouseClick += new System.Windows.Forms.MouseEventHandler(this.check_Cpno_MouseClick);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel17, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(1, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel4.TabIndex = 66666;
            // 
            // panel17
            // 
            this.panel17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.mtxtMbid);
            this.panel17.Location = new System.Drawing.Point(126, 4);
            this.panel17.Margin = new System.Windows.Forms.Padding(2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(170, 28);
            this.panel17.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label18.Font = new System.Drawing.Font("돋움", 8F);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(2, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.label18.Size = new System.Drawing.Size(120, 32);
            this.label18.TabIndex = 0;
            this.label18.Text = "회원번호\r\n※회원가입시 자동생성 됩니다.";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Controls.Add(this.panel18, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1, 40);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(300, 36);
            this.tableLayoutPanel28.TabIndex = 0;
            // 
            // panel18
            // 
            this.panel18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Controls.Add(this.txtName);
            this.panel18.Location = new System.Drawing.Point(126, 4);
            this.panel18.Margin = new System.Windows.Forms.Padding(2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(170, 28);
            this.panel18.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label19.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 32);
            this.label19.TabIndex = 0;
            this.label19.Text = "*성명";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel20.Location = new System.Drawing.Point(78, 327);
            this.panel20.Margin = new System.Windows.Forms.Padding(2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(300, 37);
            this.panel20.TabIndex = 15;
            // 
            // panel21
            // 
            this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Controls.Add(this.raButt_IN_3);
            this.panel21.Controls.Add(this.raButt_IN_1);
            this.panel21.Controls.Add(this.raButt_IN_2);
            this.panel21.Location = new System.Drawing.Point(126, 4);
            this.panel21.Margin = new System.Windows.Forms.Padding(2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(170, 29);
            this.panel21.TabIndex = 0;
            // 
            // raButt_IN_3
            // 
            this.raButt_IN_3.AutoSize = true;
            this.raButt_IN_3.Location = new System.Drawing.Point(216, 9);
            this.raButt_IN_3.Name = "raButt_IN_3";
            this.raButt_IN_3.Size = new System.Drawing.Size(59, 16);
            this.raButt_IN_3.TabIndex = 56;
            this.raButt_IN_3.Text = "사업자";
            this.raButt_IN_3.UseVisualStyleBackColor = true;
            this.raButt_IN_3.Visible = false;
            this.raButt_IN_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.radioButt_Sn_MouseUp);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(300, 75);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel3.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "등록_일자";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.mtxtRegDate);
            this.panel4.Controls.Add(this.DTP_RegDate);
            this.panel4.Location = new System.Drawing.Point(126, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(170, 28);
            this.panel4.TabIndex = 0;
            // 
            // mtxtRegDate
            // 
            this.mtxtRegDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtRegDate.Location = new System.Drawing.Point(3, 3);
            this.mtxtRegDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtRegDate.Name = "mtxtRegDate";
            this.mtxtRegDate.Size = new System.Drawing.Size(143, 21);
            this.mtxtRegDate.TabIndex = 19;
            this.mtxtRegDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtRegDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtRegDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.label23, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.panel22, 1, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(1, 617);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel8.TabIndex = 5;
            this.tableLayoutPanel8.Visible = false;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(2, 2);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(120, 33);
            this.label23.TabIndex = 0;
            this.label23.Text = "라인";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Controls.Add(this.rdoLineLeft);
            this.panel22.Controls.Add(this.rdoLineRight);
            this.panel22.Controls.Add(this.txtLineCnt);
            this.panel22.Location = new System.Drawing.Point(126, 4);
            this.panel22.Margin = new System.Windows.Forms.Padding(2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(170, 28);
            this.panel22.TabIndex = 0;
            // 
            // rdoLineLeft
            // 
            this.rdoLineLeft.AutoSize = true;
            this.rdoLineLeft.Checked = true;
            this.rdoLineLeft.Location = new System.Drawing.Point(10, 6);
            this.rdoLineLeft.Name = "rdoLineLeft";
            this.rdoLineLeft.Size = new System.Drawing.Size(35, 16);
            this.rdoLineLeft.TabIndex = 56;
            this.rdoLineLeft.TabStop = true;
            this.rdoLineLeft.Text = "좌";
            this.rdoLineLeft.UseVisualStyleBackColor = true;
            this.rdoLineLeft.CheckedChanged += new System.EventHandler(this.rdoLineLeft_CheckedChanged);
            // 
            // rdoLineRight
            // 
            this.rdoLineRight.AutoSize = true;
            this.rdoLineRight.Location = new System.Drawing.Point(57, 6);
            this.rdoLineRight.Name = "rdoLineRight";
            this.rdoLineRight.Size = new System.Drawing.Size(35, 16);
            this.rdoLineRight.TabIndex = 57;
            this.rdoLineRight.Text = "우";
            this.rdoLineRight.UseVisualStyleBackColor = true;
            this.rdoLineRight.CheckedChanged += new System.EventHandler(this.rdoLineRight_CheckedChanged);
            // 
            // pnlZipCode_KR
            // 
            this.pnlZipCode_KR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.pnlZipCode_KR.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.pnlZipCode_KR.ColumnCount = 2;
            this.pnlZipCode_KR.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.pnlZipCode_KR.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlZipCode_KR.Controls.Add(this.label24, 0, 0);
            this.pnlZipCode_KR.Controls.Add(this.panel23, 1, 0);
            this.pnlZipCode_KR.Location = new System.Drawing.Point(1, 294);
            this.pnlZipCode_KR.Name = "pnlZipCode_KR";
            this.pnlZipCode_KR.RowCount = 1;
            this.pnlZipCode_KR.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlZipCode_KR.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.pnlZipCode_KR.Size = new System.Drawing.Size(300, 37);
            this.pnlZipCode_KR.TabIndex = 15;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(2, 2);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(120, 33);
            this.label24.TabIndex = 0;
            this.label24.Text = "*우편번호";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.butt_AddCode);
            this.panel23.Controls.Add(this.mtxtZip1);
            this.panel23.Location = new System.Drawing.Point(126, 4);
            this.panel23.Margin = new System.Windows.Forms.Padding(2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(169, 28);
            this.panel23.TabIndex = 0;
            // 
            // mtxtZip1
            // 
            this.mtxtZip1.Location = new System.Drawing.Point(3, 3);
            this.mtxtZip1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtZip1.Name = "mtxtZip1";
            this.mtxtZip1.Size = new System.Drawing.Size(88, 21);
            this.mtxtZip1.TabIndex = 10;
            this.mtxtZip1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtZip1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtZip1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel30.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.panel24, 1, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(300, 112);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel30.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(2, 2);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(120, 33);
            this.label25.TabIndex = 0;
            this.label25.Text = "센터";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Controls.Add(this.txtCenter_Code);
            this.panel24.Controls.Add(this.txtCenter);
            this.panel24.Location = new System.Drawing.Point(126, 4);
            this.panel24.Margin = new System.Windows.Forms.Padding(2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(170, 28);
            this.panel24.TabIndex = 0;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel31.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.panel25, 1, 0);
            this.tableLayoutPanel31.Location = new System.Drawing.Point(1, 183);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel31.TabIndex = 10;
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(2, 2);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 33);
            this.label28.TabIndex = 0;
            this.label28.Text = "집전화";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Controls.Add(this.mtxtTel1);
            this.panel25.Location = new System.Drawing.Point(126, 4);
            this.panel25.Margin = new System.Windows.Forms.Padding(2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(170, 28);
            this.panel25.TabIndex = 0;
            // 
            // mtxtTel1
            // 
            this.mtxtTel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtTel1.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel1.Name = "mtxtTel1";
            this.mtxtTel1.Size = new System.Drawing.Size(164, 21);
            this.mtxtTel1.TabIndex = 7;
            this.mtxtTel1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtTel1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtTel1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel32.Controls.Add(this.panel26, 1, 0);
            this.tableLayoutPanel32.Location = new System.Drawing.Point(1, 220);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel32.TabIndex = 12;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(2, 2);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(120, 33);
            this.label29.TabIndex = 0;
            this.label29.Text = "*휴대폰";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.mtxtTel2);
            this.panel26.Location = new System.Drawing.Point(126, 4);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(170, 28);
            this.panel26.TabIndex = 0;
            // 
            // mtxtTel2
            // 
            this.mtxtTel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtTel2.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel2.Name = "mtxtTel2";
            this.mtxtTel2.Size = new System.Drawing.Size(164, 21);
            this.mtxtTel2.TabIndex = 8;
            this.mtxtTel2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtTel2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtTel2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel33.Controls.Add(this.panel27, 1, 0);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(1, 369);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel33.TabIndex = 16;
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(2, 2);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 33);
            this.label33.TabIndex = 0;
            this.label33.Text = "*주소1";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel27
            // 
            this.panel27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Controls.Add(this.txtAddress1);
            this.panel27.Location = new System.Drawing.Point(126, 4);
            this.panel27.Margin = new System.Windows.Forms.Padding(2);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(471, 29);
            this.panel27.TabIndex = 0;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel34.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.panel28, 1, 0);
            this.tableLayoutPanel34.Location = new System.Drawing.Point(1, 406);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel34.TabIndex = 17;
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(2, 2);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 33);
            this.label36.TabIndex = 0;
            this.label36.Text = "주소2";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel28
            // 
            this.panel28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Controls.Add(this.txtAddress2);
            this.panel28.Location = new System.Drawing.Point(126, 4);
            this.panel28.Margin = new System.Windows.Forms.Padding(2);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(471, 29);
            this.panel28.TabIndex = 0;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.label27, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.panel29, 1, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(300, 444);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel16.TabIndex = 19;
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(2, 2);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(120, 33);
            this.label27.TabIndex = 0;
            this.label27.Text = "예금주";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.txtName_Accnt);
            this.panel29.Location = new System.Drawing.Point(126, 4);
            this.panel29.Margin = new System.Windows.Forms.Padding(2);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(170, 28);
            this.panel29.TabIndex = 0;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.panel30, 1, 0);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(1, 443);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel17.TabIndex = 18;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(2, 2);
            this.label34.Margin = new System.Windows.Forms.Padding(0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(120, 33);
            this.label34.TabIndex = 0;
            this.label34.Text = "은행";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.txtBank_Code);
            this.panel30.Controls.Add(this.txtBank);
            this.panel30.Location = new System.Drawing.Point(126, 4);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(170, 28);
            this.panel30.TabIndex = 0;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel35.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel35.ColumnCount = 2;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel35.Controls.Add(this.panel31, 1, 0);
            this.tableLayoutPanel35.Location = new System.Drawing.Point(300, 146);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel35.TabIndex = 9;
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(2, 2);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(120, 33);
            this.label37.TabIndex = 0;
            this.label37.Text = "*영문_Last_Name";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.txtName_E_2);
            this.panel31.Location = new System.Drawing.Point(126, 4);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(170, 28);
            this.panel31.TabIndex = 0;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel36.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.label38, 0, 0);
            this.tableLayoutPanel36.Controls.Add(this.panel32, 1, 0);
            this.tableLayoutPanel36.Location = new System.Drawing.Point(1, 146);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel36.TabIndex = 8;
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(2, 2);
            this.label38.Margin = new System.Windows.Forms.Padding(0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(120, 33);
            this.label38.TabIndex = 0;
            this.label38.Text = "*영문_First_Name";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Controls.Add(this.txtName_E_1);
            this.panel32.Location = new System.Drawing.Point(126, 4);
            this.panel32.Margin = new System.Windows.Forms.Padding(2);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(170, 28);
            this.panel32.TabIndex = 0;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel37.ColumnCount = 2;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel37.Controls.Add(this.panel33, 1, 0);
            this.tableLayoutPanel37.Location = new System.Drawing.Point(1, 480);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(425, 37);
            this.tableLayoutPanel37.TabIndex = 20;
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(2, 2);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 33);
            this.label39.TabIndex = 0;
            this.label39.Text = "계좌번호";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel33
            // 
            this.panel33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Controls.Add(this.lbl_ACC);
            this.panel33.Controls.Add(this.txtAccount);
            this.panel33.Location = new System.Drawing.Point(126, 4);
            this.panel33.Margin = new System.Windows.Forms.Padding(2);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(295, 29);
            this.panel33.TabIndex = 0;
            // 
            // lbl_ACC
            // 
            this.lbl_ACC.AutoSize = true;
            this.lbl_ACC.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_ACC.ForeColor = System.Drawing.Color.Blue;
            this.lbl_ACC.Location = new System.Drawing.Point(227, 6);
            this.lbl_ACC.Name = "lbl_ACC";
            this.lbl_ACC.Size = new System.Drawing.Size(43, 15);
            this.lbl_ACC.TabIndex = 1045;
            this.lbl_ACC.Text = "미인증";
            this.lbl_ACC.Visible = false;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(1, 257);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(301, 37);
            this.tableLayoutPanel6.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 33);
            this.label2.TabIndex = 0;
            this.label2.Text = "*E-mail";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.txtEmail);
            this.panel3.Location = new System.Drawing.Point(126, 4);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(171, 29);
            this.panel3.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(300, 4);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label5.Font = new System.Drawing.Font("돋움", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 33);
            this.label5.TabIndex = 0;
            this.label5.Text = "Web Password\r\n※미기입시\r\nmanna + 생년앞자리";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.txtPassword);
            this.panel6.Location = new System.Drawing.Point(126, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(170, 28);
            this.panel6.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.panel34, 1, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(301, 619);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel10.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 33);
            this.label11.TabIndex = 0;
            this.label11.Text = "Web ID";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Controls.Add(this.txtWebID);
            this.panel34.Location = new System.Drawing.Point(126, 4);
            this.panel34.Margin = new System.Windows.Forms.Padding(2);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(170, 28);
            this.panel34.TabIndex = 15;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.panel35, 1, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(78, 68);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel12.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 33);
            this.label12.TabIndex = 0;
            this.label12.Text = "비고";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel35
            // 
            this.panel35.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.txtRemark);
            this.panel35.Location = new System.Drawing.Point(126, 4);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(471, 28);
            this.panel35.TabIndex = 15;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.panel36, 1, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(1, 76);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel13.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label20.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(2, 2);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 33);
            this.label20.TabIndex = 0;
            this.label20.Text = "*생년월일";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel36
            // 
            this.panel36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel36.BackColor = System.Drawing.Color.White;
            this.panel36.Controls.Add(this.opt_Bir_TF_2);
            this.panel36.Controls.Add(this.mtxtBrithDay);
            this.panel36.Controls.Add(this.DTP_BrithDay);
            this.panel36.Controls.Add(this.opt_Bir_TF_1);
            this.panel36.Location = new System.Drawing.Point(126, 4);
            this.panel36.Margin = new System.Windows.Forms.Padding(2);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(170, 29);
            this.panel36.TabIndex = 0;
            // 
            // mtxtBrithDay
            // 
            this.mtxtBrithDay.Location = new System.Drawing.Point(3, 3);
            this.mtxtBrithDay.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtBrithDay.Name = "mtxtBrithDay";
            this.mtxtBrithDay.Size = new System.Drawing.Size(143, 21);
            this.mtxtBrithDay.TabIndex = 3;
            this.mtxtBrithDay.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtBrithDay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtBrithDay.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.panel37, 1, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(674, 488);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 1;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel19.TabIndex = 23;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(2, 2);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(120, 33);
            this.label21.TabIndex = 0;
            this.label21.Text = "교육일";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.White;
            this.panel37.Controls.Add(this.mtxtEdDate);
            this.panel37.Controls.Add(this.DTP_EdDate);
            this.panel37.Location = new System.Drawing.Point(126, 4);
            this.panel37.Margin = new System.Windows.Forms.Padding(2);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(170, 28);
            this.panel37.TabIndex = 15;
            // 
            // mtxtEdDate
            // 
            this.mtxtEdDate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtEdDate.Location = new System.Drawing.Point(3, 3);
            this.mtxtEdDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtEdDate.Name = "mtxtEdDate";
            this.mtxtEdDate.Size = new System.Drawing.Size(143, 21);
            this.mtxtEdDate.TabIndex = 127;
            this.mtxtEdDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtEdDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtEdDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel38.Location = new System.Drawing.Point(78, 179);
            this.panel38.Margin = new System.Windows.Forms.Padding(2);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(190, 37);
            this.panel38.TabIndex = 200;
            this.panel38.Visible = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pnlSubDistrict_TH);
            this.panel7.Controls.Add(this.pnlDistrict_TH);
            this.panel7.Controls.Add(this.pnlProvince_TH);
            this.panel7.Controls.Add(this.pnlZipCode_TH);
            this.panel7.Controls.Add(this.tlpNaCode);
            this.panel7.Controls.Add(this.tableLayoutPanel45);
            this.panel7.Controls.Add(this.checkB_SMS_FLAG);
            this.panel7.Controls.Add(this.tableLayoutPanel43);
            this.panel7.Controls.Add(this.tab_Nation);
            this.panel7.Controls.Add(this.checkB_EMail_FLAG);
            this.panel7.Controls.Add(this.tableLayoutPanel36);
            this.panel7.Controls.Add(this.tableLayoutPanel35);
            this.panel7.Controls.Add(this.tableLayoutPanel42);
            this.panel7.Controls.Add(this.txt_IpinCI);
            this.panel7.Controls.Add(this.txt_IpinDI);
            this.panel7.Controls.Add(this.panel67);
            this.panel7.Controls.Add(this.tableLayoutPanel30);
            this.panel7.Controls.Add(this.tableLayoutPanel65);
            this.panel7.Controls.Add(this.butt_Certify);
            this.panel7.Controls.Add(this.tableLayoutPanel28);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.tableLayoutPanel39);
            this.panel7.Controls.Add(this.button_Acc_Reg);
            this.panel7.Controls.Add(this.txtAccount_Reg);
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.panel12);
            this.panel7.Controls.Add(this.tableLayoutPanel8);
            this.panel7.Controls.Add(this.grB_Line);
            this.panel7.Controls.Add(this.tbl_nom);
            this.panel7.Controls.Add(this.tableLayoutPanel1);
            this.panel7.Controls.Add(this.tableLayoutPanel13);
            this.panel7.Controls.Add(this.tbl_save);
            this.panel7.Controls.Add(this.groupBox1);
            this.panel7.Controls.Add(this.tableLayoutPanel2);
            this.panel7.Controls.Add(this.tableLayoutPanel4);
            this.panel7.Controls.Add(this.tableLayoutPanel27);
            this.panel7.Controls.Add(this.tableLayoutPanel19);
            this.panel7.Controls.Add(this.tableLayoutPanel7);
            this.panel7.Controls.Add(this.tableLayoutPanel10);
            this.panel7.Controls.Add(this.tableLayoutPanel6);
            this.panel7.Controls.Add(this.tableLayoutPanel3);
            this.panel7.Controls.Add(this.tableLayoutPanel37);
            this.panel7.Controls.Add(this.pnlZipCode_KR);
            this.panel7.Controls.Add(this.tableLayoutPanel31);
            this.panel7.Controls.Add(this.tableLayoutPanel17);
            this.panel7.Controls.Add(this.tableLayoutPanel32);
            this.panel7.Controls.Add(this.tableLayoutPanel34);
            this.panel7.Controls.Add(this.tableLayoutPanel33);
            this.panel7.Controls.Add(this.tableLayoutPanel16);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel7.Location = new System.Drawing.Point(0, 28);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(605, 908);
            this.panel7.TabIndex = 0;
            // 
            // pnlSubDistrict_TH
            // 
            this.pnlSubDistrict_TH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.pnlSubDistrict_TH.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.pnlSubDistrict_TH.ColumnCount = 2;
            this.pnlSubDistrict_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.pnlSubDistrict_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlSubDistrict_TH.Controls.Add(this.panel75, 1, 0);
            this.pnlSubDistrict_TH.Controls.Add(this.label59, 0, 0);
            this.pnlSubDistrict_TH.Location = new System.Drawing.Point(300, 331);
            this.pnlSubDistrict_TH.Name = "pnlSubDistrict_TH";
            this.pnlSubDistrict_TH.RowCount = 1;
            this.pnlSubDistrict_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlSubDistrict_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.pnlSubDistrict_TH.Size = new System.Drawing.Size(300, 37);
            this.pnlSubDistrict_TH.TabIndex = 15;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.White;
            this.panel75.Controls.Add(this.cbSubDistrict_TH);
            this.panel75.Location = new System.Drawing.Point(126, 4);
            this.panel75.Margin = new System.Windows.Forms.Padding(2);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(169, 28);
            this.panel75.TabIndex = 0;
            // 
            // cbSubDistrict_TH
            // 
            this.cbSubDistrict_TH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSubDistrict_TH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSubDistrict_TH.FormattingEnabled = true;
            this.cbSubDistrict_TH.Location = new System.Drawing.Point(3, 4);
            this.cbSubDistrict_TH.Name = "cbSubDistrict_TH";
            this.cbSubDistrict_TH.Size = new System.Drawing.Size(163, 20);
            this.cbSubDistrict_TH.TabIndex = 204;
            this.cbSubDistrict_TH.Tag = "tab_Nation";
            this.cbSubDistrict_TH.SelectedIndexChanged += new System.EventHandler(this.cbSubDistrict_TH_SelectedIndexChanged);
            // 
            // label59
            // 
            this.label59.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(2, 2);
            this.label59.Margin = new System.Windows.Forms.Padding(0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(120, 33);
            this.label59.TabIndex = 0;
            this.label59.Text = "*태국_SubDistrict";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlDistrict_TH
            // 
            this.pnlDistrict_TH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.pnlDistrict_TH.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.pnlDistrict_TH.ColumnCount = 2;
            this.pnlDistrict_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.pnlDistrict_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlDistrict_TH.Controls.Add(this.panel74, 1, 0);
            this.pnlDistrict_TH.Controls.Add(this.label58, 0, 0);
            this.pnlDistrict_TH.Location = new System.Drawing.Point(300, 294);
            this.pnlDistrict_TH.Name = "pnlDistrict_TH";
            this.pnlDistrict_TH.RowCount = 1;
            this.pnlDistrict_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlDistrict_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.pnlDistrict_TH.Size = new System.Drawing.Size(300, 37);
            this.pnlDistrict_TH.TabIndex = 15;
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.White;
            this.panel74.Controls.Add(this.cbDistrict_TH);
            this.panel74.Location = new System.Drawing.Point(126, 4);
            this.panel74.Margin = new System.Windows.Forms.Padding(2);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(169, 28);
            this.panel74.TabIndex = 0;
            // 
            // cbDistrict_TH
            // 
            this.cbDistrict_TH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbDistrict_TH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDistrict_TH.FormattingEnabled = true;
            this.cbDistrict_TH.Location = new System.Drawing.Point(3, 4);
            this.cbDistrict_TH.Name = "cbDistrict_TH";
            this.cbDistrict_TH.Size = new System.Drawing.Size(163, 20);
            this.cbDistrict_TH.TabIndex = 204;
            this.cbDistrict_TH.Tag = "tab_Nation";
            this.cbDistrict_TH.SelectedIndexChanged += new System.EventHandler(this.cbDistrict_TH_SelectedIndexChanged);
            // 
            // label58
            // 
            this.label58.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label58.ForeColor = System.Drawing.Color.White;
            this.label58.Location = new System.Drawing.Point(2, 2);
            this.label58.Margin = new System.Windows.Forms.Padding(0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(120, 33);
            this.label58.TabIndex = 0;
            this.label58.Text = "*태국_District";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlProvince_TH
            // 
            this.pnlProvince_TH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.pnlProvince_TH.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.pnlProvince_TH.ColumnCount = 2;
            this.pnlProvince_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.pnlProvince_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlProvince_TH.Controls.Add(this.panel73, 1, 0);
            this.pnlProvince_TH.Controls.Add(this.label57, 0, 0);
            this.pnlProvince_TH.Location = new System.Drawing.Point(300, 258);
            this.pnlProvince_TH.Name = "pnlProvince_TH";
            this.pnlProvince_TH.RowCount = 1;
            this.pnlProvince_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlProvince_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.pnlProvince_TH.Size = new System.Drawing.Size(300, 37);
            this.pnlProvince_TH.TabIndex = 15;
            // 
            // panel73
            // 
            this.panel73.BackColor = System.Drawing.Color.White;
            this.panel73.Controls.Add(this.cbProvince_TH);
            this.panel73.Location = new System.Drawing.Point(126, 4);
            this.panel73.Margin = new System.Windows.Forms.Padding(2);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(169, 28);
            this.panel73.TabIndex = 0;
            // 
            // cbProvince_TH
            // 
            this.cbProvince_TH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbProvince_TH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProvince_TH.FormattingEnabled = true;
            this.cbProvince_TH.Location = new System.Drawing.Point(3, 4);
            this.cbProvince_TH.Name = "cbProvince_TH";
            this.cbProvince_TH.Size = new System.Drawing.Size(163, 20);
            this.cbProvince_TH.TabIndex = 204;
            this.cbProvince_TH.Tag = "tab_Nation";
            this.cbProvince_TH.SelectedIndexChanged += new System.EventHandler(this.cbProvince_TH_SelectedIndexChanged);
            // 
            // label57
            // 
            this.label57.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label57.ForeColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(2, 2);
            this.label57.Margin = new System.Windows.Forms.Padding(0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(120, 33);
            this.label57.TabIndex = 0;
            this.label57.Text = "*태국_Province";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlZipCode_TH
            // 
            this.pnlZipCode_TH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.pnlZipCode_TH.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.pnlZipCode_TH.ColumnCount = 2;
            this.pnlZipCode_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.pnlZipCode_TH.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlZipCode_TH.Controls.Add(this.panel72, 1, 0);
            this.pnlZipCode_TH.Controls.Add(this.label55, 0, 0);
            this.pnlZipCode_TH.Location = new System.Drawing.Point(1, 294);
            this.pnlZipCode_TH.Name = "pnlZipCode_TH";
            this.pnlZipCode_TH.RowCount = 1;
            this.pnlZipCode_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlZipCode_TH.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.pnlZipCode_TH.Size = new System.Drawing.Size(300, 37);
            this.pnlZipCode_TH.TabIndex = 15;
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.White;
            this.panel72.Controls.Add(this.txtZipCode_TH);
            this.panel72.Location = new System.Drawing.Point(126, 4);
            this.panel72.Margin = new System.Windows.Forms.Padding(2);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(169, 28);
            this.panel72.TabIndex = 0;
            // 
            // txtZipCode_TH
            // 
            this.txtZipCode_TH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtZipCode_TH.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtZipCode_TH.Location = new System.Drawing.Point(2, 3);
            this.txtZipCode_TH.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtZipCode_TH.MaxLength = 50;
            this.txtZipCode_TH.Name = "txtZipCode_TH";
            this.txtZipCode_TH.Size = new System.Drawing.Size(165, 22);
            this.txtZipCode_TH.TabIndex = 9;
            this.txtZipCode_TH.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtZipCode_TH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtZipCode_TH.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label55
            // 
            this.label55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(2, 2);
            this.label55.Margin = new System.Windows.Forms.Padding(0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(120, 33);
            this.label55.TabIndex = 0;
            this.label55.Text = "*우편번호";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tlpNaCode
            // 
            this.tlpNaCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tlpNaCode.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlpNaCode.ColumnCount = 2;
            this.tlpNaCode.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tlpNaCode.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpNaCode.Controls.Add(this.panel39, 1, 0);
            this.tlpNaCode.Controls.Add(this.label54, 0, 0);
            this.tlpNaCode.Location = new System.Drawing.Point(301, 660);
            this.tlpNaCode.Name = "tlpNaCode";
            this.tlpNaCode.RowCount = 1;
            this.tlpNaCode.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpNaCode.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tlpNaCode.Size = new System.Drawing.Size(300, 38);
            this.tlpNaCode.TabIndex = 66667;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.White;
            this.panel39.Controls.Add(this.combo_Se_2);
            this.panel39.Controls.Add(this.combo_Se_Code_2);
            this.panel39.Location = new System.Drawing.Point(105, 4);
            this.panel39.Margin = new System.Windows.Forms.Padding(2);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(191, 28);
            this.panel39.TabIndex = 15;
            // 
            // combo_Se_2
            // 
            this.combo_Se_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Se_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se_2.FormattingEnabled = true;
            this.combo_Se_2.Location = new System.Drawing.Point(66, 4);
            this.combo_Se_2.Name = "combo_Se_2";
            this.combo_Se_2.Size = new System.Drawing.Size(120, 20);
            this.combo_Se_2.TabIndex = 203;
            this.combo_Se_2.Tag = "tab_Nation";
            this.combo_Se_2.SelectedIndexChanged += new System.EventHandler(this.combo_Se_2_SelectedIndexChanged);
            // 
            // combo_Se_Code_2
            // 
            this.combo_Se_Code_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Se_Code_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se_Code_2.FormattingEnabled = true;
            this.combo_Se_Code_2.Location = new System.Drawing.Point(2, 4);
            this.combo_Se_Code_2.Name = "combo_Se_Code_2";
            this.combo_Se_Code_2.Size = new System.Drawing.Size(58, 20);
            this.combo_Se_Code_2.TabIndex = 206;
            this.combo_Se_Code_2.TabStop = false;
            this.combo_Se_Code_2.Tag = "tab_Nation";
            this.combo_Se_Code_2.SelectedIndexChanged += new System.EventHandler(this.combo_Se_Code_2_SelectedIndexChanged);
            // 
            // label54
            // 
            this.label54.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(2, 2);
            this.label54.Margin = new System.Windows.Forms.Padding(0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(99, 34);
            this.label54.TabIndex = 0;
            this.label54.Text = "국가_코드";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel45.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.Controls.Add(this.panel71, 1, 0);
            this.tableLayoutPanel45.Controls.Add(this.label53, 0, 0);
            this.tableLayoutPanel45.Location = new System.Drawing.Point(300, 183);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 1;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel45.TabIndex = 11;
            // 
            // panel71
            // 
            this.panel71.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel71.BackColor = System.Drawing.Color.White;
            this.panel71.Controls.Add(this.opt_sell_3);
            this.panel71.Controls.Add(this.radioButton1);
            this.panel71.Controls.Add(this.opt_sell_2);
            this.panel71.Location = new System.Drawing.Point(126, 4);
            this.panel71.Margin = new System.Windows.Forms.Padding(2);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(170, 29);
            this.panel71.TabIndex = 0;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(216, 9);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(59, 16);
            this.radioButton1.TabIndex = 56;
            this.radioButton1.Text = "사업자";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Visible = false;
            // 
            // label53
            // 
            this.label53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(2, 2);
            this.label53.Margin = new System.Windows.Forms.Padding(0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(120, 33);
            this.label53.TabIndex = 0;
            this.label53.Text = "판매자 소비자 구분";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // checkB_SMS_FLAG
            // 
            this.checkB_SMS_FLAG.AutoSize = true;
            this.checkB_SMS_FLAG.Checked = true;
            this.checkB_SMS_FLAG.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkB_SMS_FLAG.ForeColor = System.Drawing.Color.Black;
            this.checkB_SMS_FLAG.Location = new System.Drawing.Point(476, 270);
            this.checkB_SMS_FLAG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkB_SMS_FLAG.Name = "checkB_SMS_FLAG";
            this.checkB_SMS_FLAG.Size = new System.Drawing.Size(111, 16);
            this.checkB_SMS_FLAG.TabIndex = 3;
            this.checkB_SMS_FLAG.Text = "SMS_수신_가능";
            this.checkB_SMS_FLAG.UseVisualStyleBackColor = true;
            this.checkB_SMS_FLAG.Visible = false;
            // 
            // tableLayoutPanel43
            // 
            this.tableLayoutPanel43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel43.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel43.ColumnCount = 2;
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.Controls.Add(this.panel21, 1, 0);
            this.tableLayoutPanel43.Controls.Add(this.label51, 0, 0);
            this.tableLayoutPanel43.Location = new System.Drawing.Point(1, 110);
            this.tableLayoutPanel43.Name = "tableLayoutPanel43";
            this.tableLayoutPanel43.RowCount = 1;
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel43.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel43.TabIndex = 6;
            // 
            // label51
            // 
            this.label51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(2, 2);
            this.label51.Margin = new System.Windows.Forms.Padding(0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(120, 33);
            this.label51.TabIndex = 0;
            this.label51.Text = "국적";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Nation
            // 
            this.tab_Nation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tab_Nation.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tab_Nation.ColumnCount = 2;
            this.tab_Nation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 99F));
            this.tab_Nation.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tab_Nation.Controls.Add(this.panel8, 1, 0);
            this.tab_Nation.Controls.Add(this.label3, 0, 0);
            this.tab_Nation.Location = new System.Drawing.Point(300, 699);
            this.tab_Nation.Name = "tab_Nation";
            this.tab_Nation.RowCount = 1;
            this.tab_Nation.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tab_Nation.Size = new System.Drawing.Size(300, 37);
            this.tab_Nation.TabIndex = 1001;
            this.tab_Nation.Visible = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.combo_Se);
            this.panel8.Controls.Add(this.combo_Se_Code);
            this.panel8.Location = new System.Drawing.Point(105, 4);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(191, 28);
            this.panel8.TabIndex = 15;
            // 
            // combo_Se
            // 
            this.combo_Se.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Se.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se.FormattingEnabled = true;
            this.combo_Se.Location = new System.Drawing.Point(67, 4);
            this.combo_Se.Name = "combo_Se";
            this.combo_Se.Size = new System.Drawing.Size(121, 20);
            this.combo_Se.TabIndex = 203;
            this.combo_Se.Tag = "tab_Nation";
            // 
            // combo_Se_Code
            // 
            this.combo_Se_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Se_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se_Code.FormattingEnabled = true;
            this.combo_Se_Code.Location = new System.Drawing.Point(4, 4);
            this.combo_Se_Code.Name = "combo_Se_Code";
            this.combo_Se_Code.Size = new System.Drawing.Size(57, 20);
            this.combo_Se_Code.TabIndex = 206;
            this.combo_Se_Code.TabStop = false;
            this.combo_Se_Code.Tag = "tab_Nation";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 33);
            this.label3.TabIndex = 0;
            this.label3.Text = "소속국가";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // checkB_EMail_FLAG
            // 
            this.checkB_EMail_FLAG.AutoSize = true;
            this.checkB_EMail_FLAG.Checked = true;
            this.checkB_EMail_FLAG.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkB_EMail_FLAG.ForeColor = System.Drawing.Color.Black;
            this.checkB_EMail_FLAG.Location = new System.Drawing.Point(476, 298);
            this.checkB_EMail_FLAG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkB_EMail_FLAG.Name = "checkB_EMail_FLAG";
            this.checkB_EMail_FLAG.Size = new System.Drawing.Size(116, 16);
            this.checkB_EMail_FLAG.TabIndex = 4;
            this.checkB_EMail_FLAG.Text = "EMail_수신_가능";
            this.checkB_EMail_FLAG.UseVisualStyleBackColor = true;
            this.checkB_EMail_FLAG.Visible = false;
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel42.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.Controls.Add(this.panel66, 1, 0);
            this.tableLayoutPanel42.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel42.Location = new System.Drawing.Point(300, 41);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 1;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel42.TabIndex = 2;
            // 
            // panel66
            // 
            this.panel66.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel66.BackColor = System.Drawing.Color.White;
            this.panel66.Controls.Add(this.radioB_Sex_Y);
            this.panel66.Controls.Add(this.radioB_Sex_X);
            this.panel66.Location = new System.Drawing.Point(126, 4);
            this.panel66.Margin = new System.Windows.Forms.Padding(2);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(170, 29);
            this.panel66.TabIndex = 0;
            // 
            // radioB_Sex_Y
            // 
            this.radioB_Sex_Y.AutoSize = true;
            this.radioB_Sex_Y.Location = new System.Drawing.Point(3, 6);
            this.radioB_Sex_Y.Name = "radioB_Sex_Y";
            this.radioB_Sex_Y.Size = new System.Drawing.Size(47, 16);
            this.radioB_Sex_Y.TabIndex = 17;
            this.radioB_Sex_Y.TabStop = true;
            this.radioB_Sex_Y.Text = "남성";
            this.radioB_Sex_Y.UseVisualStyleBackColor = true;
            // 
            // radioB_Sex_X
            // 
            this.radioB_Sex_X.AutoSize = true;
            this.radioB_Sex_X.Location = new System.Drawing.Point(71, 6);
            this.radioB_Sex_X.Name = "radioB_Sex_X";
            this.radioB_Sex_X.Size = new System.Drawing.Size(47, 16);
            this.radioB_Sex_X.TabIndex = 18;
            this.radioB_Sex_X.Text = "여성";
            this.radioB_Sex_X.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(2, 2);
            this.label49.Margin = new System.Windows.Forms.Padding(0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(120, 33);
            this.label49.TabIndex = 0;
            this.label49.Text = "*성별";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_IpinCI
            // 
            this.txt_IpinCI.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_IpinCI.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_IpinCI.Location = new System.Drawing.Point(532, 306);
            this.txt_IpinCI.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txt_IpinCI.MaxLength = 30;
            this.txt_IpinCI.Name = "txt_IpinCI";
            this.txt_IpinCI.Size = new System.Drawing.Size(63, 22);
            this.txt_IpinCI.TabIndex = 1042;
            this.txt_IpinCI.Tag = "-";
            this.txt_IpinCI.Visible = false;
            // 
            // txt_IpinDI
            // 
            this.txt_IpinDI.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_IpinDI.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_IpinDI.Location = new System.Drawing.Point(489, 302);
            this.txt_IpinDI.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txt_IpinDI.MaxLength = 0;
            this.txt_IpinDI.Name = "txt_IpinDI";
            this.txt_IpinDI.Size = new System.Drawing.Size(61, 22);
            this.txt_IpinDI.TabIndex = 1041;
            this.txt_IpinDI.Tag = "-";
            this.txt_IpinDI.Visible = false;
            // 
            // panel67
            // 
            this.panel67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel67.Controls.Add(this.panel68);
            this.panel67.Location = new System.Drawing.Point(301, 221);
            this.panel67.Margin = new System.Windows.Forms.Padding(2);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(297, 37);
            this.panel67.TabIndex = 13;
            // 
            // panel68
            // 
            this.panel68.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel68.BackColor = System.Drawing.Color.White;
            this.panel68.Controls.Add(this.checkB_AgreeMarketing);
            this.panel68.Controls.Add(this.checkB_Third_Person_Agree);
            this.panel68.Location = new System.Drawing.Point(3, 3);
            this.panel68.Margin = new System.Windows.Forms.Padding(2);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(291, 30);
            this.panel68.TabIndex = 16;
            // 
            // checkB_AgreeMarketing
            // 
            this.checkB_AgreeMarketing.Checked = true;
            this.checkB_AgreeMarketing.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkB_AgreeMarketing.Location = new System.Drawing.Point(158, 4);
            this.checkB_AgreeMarketing.Name = "checkB_AgreeMarketing";
            this.checkB_AgreeMarketing.Size = new System.Drawing.Size(110, 20);
            this.checkB_AgreeMarketing.TabIndex = 65;
            this.checkB_AgreeMarketing.Text = "마케팅수신동의";
            this.checkB_AgreeMarketing.UseVisualStyleBackColor = true;
            // 
            // checkB_Third_Person_Agree
            // 
            this.checkB_Third_Person_Agree.Checked = true;
            this.checkB_Third_Person_Agree.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkB_Third_Person_Agree.Location = new System.Drawing.Point(11, 5);
            this.checkB_Third_Person_Agree.Name = "checkB_Third_Person_Agree";
            this.checkB_Third_Person_Agree.Size = new System.Drawing.Size(141, 20);
            this.checkB_Third_Person_Agree.TabIndex = 65;
            this.checkB_Third_Person_Agree.Text = "개인정보사용동의";
            this.checkB_Third_Person_Agree.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel65
            // 
            this.tableLayoutPanel65.ColumnCount = 1;
            this.tableLayoutPanel65.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.Controls.Add(this.Lbl_Certify, 0, 0);
            this.tableLayoutPanel65.Location = new System.Drawing.Point(403, 303);
            this.tableLayoutPanel65.Name = "tableLayoutPanel65";
            this.tableLayoutPanel65.RowCount = 1;
            this.tableLayoutPanel65.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel65.Size = new System.Drawing.Size(80, 18);
            this.tableLayoutPanel65.TabIndex = 1040;
            this.tableLayoutPanel65.Visible = false;
            // 
            // Lbl_Certify
            // 
            this.Lbl_Certify.AutoSize = true;
            this.Lbl_Certify.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_Certify.ForeColor = System.Drawing.Color.Red;
            this.Lbl_Certify.Location = new System.Drawing.Point(3, 0);
            this.Lbl_Certify.Name = "Lbl_Certify";
            this.Lbl_Certify.Size = new System.Drawing.Size(74, 18);
            this.Lbl_Certify.TabIndex = 0;
            this.Lbl_Certify.Text = "인증미확인";
            this.Lbl_Certify.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // butt_Certify
            // 
            this.butt_Certify.BackColor = System.Drawing.Color.White;
            this.butt_Certify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Certify.Location = new System.Drawing.Point(305, 299);
            this.butt_Certify.Name = "butt_Certify";
            this.butt_Certify.Size = new System.Drawing.Size(93, 26);
            this.butt_Certify.TabIndex = 1039;
            this.butt_Certify.TabStop = false;
            this.butt_Certify.Text = "휴대폰 인증";
            this.butt_Certify.UseVisualStyleBackColor = false;
            this.butt_Certify.Visible = false;
            this.butt_Certify.Click += new System.EventHandler(this.butt_Certify_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(658, 442);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(111, 26);
            this.button5.TabIndex = 1024;
            this.button5.TabStop = false;
            this.button5.Text = "매출 재신고";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel39.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel39.Controls.Add(this.panel57, 1, 0);
            this.tableLayoutPanel39.Location = new System.Drawing.Point(674, 649);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 1;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel39.TabIndex = 1021;
            this.tableLayoutPanel39.Visible = false;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(2, 2);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(120, 33);
            this.label44.TabIndex = 0;
            this.label44.Text = "비자_만료일";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.White;
            this.panel57.Controls.Add(this.mtxtVisaDay);
            this.panel57.Controls.Add(this.DTP_VisaDay);
            this.panel57.Location = new System.Drawing.Point(126, 4);
            this.panel57.Margin = new System.Windows.Forms.Padding(2);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(170, 28);
            this.panel57.TabIndex = 15;
            // 
            // mtxtVisaDay
            // 
            this.mtxtVisaDay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtVisaDay.Location = new System.Drawing.Point(3, 3);
            this.mtxtVisaDay.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtVisaDay.Name = "mtxtVisaDay";
            this.mtxtVisaDay.Size = new System.Drawing.Size(143, 21);
            this.mtxtVisaDay.TabIndex = 127;
            this.mtxtVisaDay.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtVisaDay.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtVisaDay.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_VisaDay
            // 
            this.DTP_VisaDay.Location = new System.Drawing.Point(146, 3);
            this.DTP_VisaDay.Name = "DTP_VisaDay";
            this.DTP_VisaDay.Size = new System.Drawing.Size(21, 21);
            this.DTP_VisaDay.TabIndex = 126;
            this.DTP_VisaDay.TabStop = false;
            this.DTP_VisaDay.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // button_Acc_Reg
            // 
            this.button_Acc_Reg.BackColor = System.Drawing.Color.White;
            this.button_Acc_Reg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Acc_Reg.Location = new System.Drawing.Point(427, 485);
            this.button_Acc_Reg.Name = "button_Acc_Reg";
            this.button_Acc_Reg.Size = new System.Drawing.Size(111, 26);
            this.button_Acc_Reg.TabIndex = 1020;
            this.button_Acc_Reg.Text = "계좌_인증";
            this.button_Acc_Reg.UseVisualStyleBackColor = false;
            this.button_Acc_Reg.Visible = false;
            this.button_Acc_Reg.Click += new System.EventHandler(this.button_Acc_Reg_Click);
            // 
            // txtAccount_Reg
            // 
            this.txtAccount_Reg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAccount_Reg.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAccount_Reg.Location = new System.Drawing.Point(542, 396);
            this.txtAccount_Reg.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtAccount_Reg.MaxLength = 30;
            this.txtAccount_Reg.Name = "txtAccount_Reg";
            this.txtAccount_Reg.Size = new System.Drawing.Size(59, 22);
            this.txtAccount_Reg.TabIndex = 1019;
            this.txtAccount_Reg.Tag = "-";
            this.txtAccount_Reg.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(658, 355);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 26);
            this.button1.TabIndex = 1018;
            this.button1.TabStop = false;
            this.button1.Text = "회원 라인 구성";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Location = new System.Drawing.Point(613, 209);
            this.panel12.Margin = new System.Windows.Forms.Padding(2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(190, 33);
            this.panel12.TabIndex = 1002;
            this.panel12.Visible = false;
            // 
            // panel13
            // 
            this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.check_LR);
            this.panel13.Location = new System.Drawing.Point(3, 2);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(184, 29);
            this.panel13.TabIndex = 16;
            // 
            // check_LR
            // 
            this.check_LR.AutoSize = true;
            this.check_LR.Checked = true;
            this.check_LR.CheckState = System.Windows.Forms.CheckState.Checked;
            this.check_LR.Location = new System.Drawing.Point(6, 8);
            this.check_LR.Name = "check_LR";
            this.check_LR.Size = new System.Drawing.Size(100, 16);
            this.check_LR.TabIndex = 0;
            this.check_LR.Text = "좌우좌우 등록";
            this.check_LR.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(658, 392);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel1.TabIndex = 20;
            this.tableLayoutPanel1.Visible = false;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 33);
            this.label6.TabIndex = 0;
            this.label6.Text = "나눔기부(%)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.txtB1);
            this.panel10.Location = new System.Drawing.Point(126, 4);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(170, 28);
            this.panel10.TabIndex = 15;
            // 
            // txtB1
            // 
            this.txtB1.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtB1.Location = new System.Drawing.Point(3, 3);
            this.txtB1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtB1.MaxLength = 4;
            this.txtB1.Name = "txtB1";
            this.txtB1.Size = new System.Drawing.Size(88, 22);
            this.txtB1.TabIndex = 1002;
            this.txtB1.Tag = ".";
            this.txtB1.Text = "0";
            this.txtB1.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtB1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtB1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel63.Controls.Add(this.panel64);
            this.panel63.Location = new System.Drawing.Point(78, 216);
            this.panel63.Margin = new System.Windows.Forms.Padding(2);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(190, 37);
            this.panel63.TabIndex = 1023;
            this.panel63.Visible = false;
            // 
            // panel64
            // 
            this.panel64.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel64.BackColor = System.Drawing.Color.White;
            this.panel64.Controls.Add(this.radioB_G4);
            this.panel64.Controls.Add(this.radioB_G8);
            this.panel64.Location = new System.Drawing.Point(3, 2);
            this.panel64.Margin = new System.Windows.Forms.Padding(2);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(184, 33);
            this.panel64.TabIndex = 16;
            // 
            // radioB_G4
            // 
            this.radioB_G4.AutoSize = true;
            this.radioB_G4.Location = new System.Drawing.Point(6, 15);
            this.radioB_G4.Name = "radioB_G4";
            this.radioB_G4.Size = new System.Drawing.Size(65, 16);
            this.radioB_G4.TabIndex = 55;
            this.radioB_G4.Text = "4주승급";
            this.radioB_G4.UseVisualStyleBackColor = true;
            // 
            // radioB_G8
            // 
            this.radioB_G8.AutoSize = true;
            this.radioB_G8.Checked = true;
            this.radioB_G8.Location = new System.Drawing.Point(6, 1);
            this.radioB_G8.Name = "radioB_G8";
            this.radioB_G8.Size = new System.Drawing.Size(65, 16);
            this.radioB_G8.TabIndex = 54;
            this.radioB_G8.TabStop = true;
            this.radioB_G8.Text = "8주승급";
            this.radioB_G8.UseVisualStyleBackColor = true;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel59.Controls.Add(this.panel60);
            this.panel59.Location = new System.Drawing.Point(78, 290);
            this.panel59.Margin = new System.Windows.Forms.Padding(2);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(101, 37);
            this.panel59.TabIndex = 1022;
            this.panel59.Visible = false;
            // 
            // panel60
            // 
            this.panel60.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel60.BackColor = System.Drawing.Color.White;
            this.panel60.Controls.Add(this.radioB_Begin);
            this.panel60.Controls.Add(this.radioB_RBO);
            this.panel60.Location = new System.Drawing.Point(3, 2);
            this.panel60.Margin = new System.Windows.Forms.Padding(2);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(95, 33);
            this.panel60.TabIndex = 16;
            // 
            // radioB_Begin
            // 
            this.radioB_Begin.AutoSize = true;
            this.radioB_Begin.Location = new System.Drawing.Point(6, 15);
            this.radioB_Begin.Name = "radioB_Begin";
            this.radioB_Begin.Size = new System.Drawing.Size(59, 16);
            this.radioB_Begin.TabIndex = 55;
            this.radioB_Begin.Text = "비긴즈";
            this.radioB_Begin.UseVisualStyleBackColor = true;
            // 
            // radioB_RBO
            // 
            this.radioB_RBO.AutoSize = true;
            this.radioB_RBO.Checked = true;
            this.radioB_RBO.Location = new System.Drawing.Point(6, 1);
            this.radioB_RBO.Name = "radioB_RBO";
            this.radioB_RBO.Size = new System.Drawing.Size(48, 16);
            this.radioB_RBO.TabIndex = 54;
            this.radioB_RBO.TabStop = true;
            this.radioB_RBO.Text = "RBO";
            this.radioB_RBO.UseVisualStyleBackColor = true;
            // 
            // panel_Config
            // 
            this.panel_Config.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.panel_Config.Controls.Add(this.panel9);
            this.panel_Config.Location = new System.Drawing.Point(78, 253);
            this.panel_Config.Margin = new System.Windows.Forms.Padding(2);
            this.panel_Config.Name = "panel_Config";
            this.panel_Config.Size = new System.Drawing.Size(598, 37);
            this.panel_Config.TabIndex = 201;
            // 
            // panel9
            // 
            this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.check_Cpno_Multi);
            this.panel9.Controls.Add(this.check_Cpno);
            this.panel9.Controls.Add(this.check_Cpno_Err);
            this.panel9.Location = new System.Drawing.Point(3, 2);
            this.panel9.Margin = new System.Windows.Forms.Padding(2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(592, 33);
            this.panel9.TabIndex = 16;
            // 
            // tab_Sub
            // 
            this.tab_Sub.Controls.Add(this.tab_Auto);
            this.tab_Sub.Controls.Add(this.tab_C);
            this.tab_Sub.Controls.Add(this.tab_Day);
            this.tab_Sub.Controls.Add(this.tab_Hide);
            this.tab_Sub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Sub.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tab_Sub.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tab_Sub.Location = new System.Drawing.Point(605, 28);
            this.tab_Sub.Name = "tab_Sub";
            this.tab_Sub.SelectedIndex = 0;
            this.tab_Sub.Size = new System.Drawing.Size(1302, 908);
            this.tab_Sub.TabIndex = 9;
            this.tab_Sub.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tab_Sub_DrawItem);
            this.tab_Sub.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tab_Auto
            // 
            this.tab_Auto.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Auto.Controls.Add(this.groupBox4);
            this.tab_Auto.Controls.Add(this.panel43);
            this.tab_Auto.Location = new System.Drawing.Point(4, 22);
            this.tab_Auto.Name = "tab_Auto";
            this.tab_Auto.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Auto.Size = new System.Drawing.Size(1294, 882);
            this.tab_Auto.TabIndex = 0;
            this.tab_Auto.Text = "오토쉽";
            // 
            // groupBox4
            // 
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.Location = new System.Drawing.Point(3, 407);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1288, 472);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            // 
            // panel43
            // 
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(3, 3);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(1288, 404);
            this.panel43.TabIndex = 22;
            // 
            // tab_C
            // 
            this.tab_C.BackColor = System.Drawing.SystemColors.Control;
            this.tab_C.Controls.Add(this.tableLayoutPanel41);
            this.tab_C.Controls.Add(this.tableLayoutPanel40);
            this.tab_C.Controls.Add(this.panel61);
            this.tab_C.Controls.Add(this.check_CC);
            this.tab_C.Controls.Add(this.tableLayoutPanel24);
            this.tab_C.Controls.Add(this.tableLayoutPanel25);
            this.tab_C.Controls.Add(this.tableLayoutPanel26);
            this.tab_C.Controls.Add(this.tableL_Birth_KR_C);
            this.tab_C.Controls.Add(this.tableLayoutPanel38);
            this.tab_C.Location = new System.Drawing.Point(4, 22);
            this.tab_C.Name = "tab_C";
            this.tab_C.Padding = new System.Windows.Forms.Padding(3);
            this.tab_C.Size = new System.Drawing.Size(1294, 882);
            this.tab_C.TabIndex = 2;
            this.tab_C.Text = "부부사업자";
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel41.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel41.ColumnCount = 2;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.Controls.Add(this.label47, 0, 0);
            this.tableLayoutPanel41.Controls.Add(this.panel70, 1, 0);
            this.tableLayoutPanel41.Location = new System.Drawing.Point(2, 132);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 1;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(301, 37);
            this.tableLayoutPanel41.TabIndex = 28;
            // 
            // label47
            // 
            this.label47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(2, 2);
            this.label47.Margin = new System.Windows.Forms.Padding(0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(120, 33);
            this.label47.TabIndex = 0;
            this.label47.Text = "휴대폰";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.Color.White;
            this.panel70.Controls.Add(this.mtxtTel2_C);
            this.panel70.Location = new System.Drawing.Point(126, 4);
            this.panel70.Margin = new System.Windows.Forms.Padding(2);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(170, 28);
            this.panel70.TabIndex = 15;
            // 
            // mtxtTel2_C
            // 
            this.mtxtTel2_C.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtTel2_C.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel2_C.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel2_C.Name = "mtxtTel2_C";
            this.mtxtTel2_C.Size = new System.Drawing.Size(164, 21);
            this.mtxtTel2_C.TabIndex = 11;
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel40.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel40.ColumnCount = 2;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.Controls.Add(this.label45, 0, 0);
            this.tableLayoutPanel40.Controls.Add(this.panel69, 1, 0);
            this.tableLayoutPanel40.Location = new System.Drawing.Point(2, 95);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 1;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(301, 37);
            this.tableLayoutPanel40.TabIndex = 27;
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(2, 2);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 33);
            this.label45.TabIndex = 0;
            this.label45.Text = "E-mail";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel69
            // 
            this.panel69.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel69.BackColor = System.Drawing.Color.White;
            this.panel69.Controls.Add(this.txtEmail_C);
            this.panel69.Location = new System.Drawing.Point(126, 4);
            this.panel69.Margin = new System.Windows.Forms.Padding(2);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(171, 29);
            this.panel69.TabIndex = 15;
            // 
            // txtEmail_C
            // 
            this.txtEmail_C.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail_C.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtEmail_C.Location = new System.Drawing.Point(3, 3);
            this.txtEmail_C.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtEmail_C.MaxLength = 50;
            this.txtEmail_C.Name = "txtEmail_C";
            this.txtEmail_C.Size = new System.Drawing.Size(165, 22);
            this.txtEmail_C.TabIndex = 27;
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.panel61.Controls.Add(this.panel62);
            this.panel61.Location = new System.Drawing.Point(69, 488);
            this.panel61.Margin = new System.Windows.Forms.Padding(2);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(214, 37);
            this.panel61.TabIndex = 1041;
            this.panel61.Visible = false;
            // 
            // panel62
            // 
            this.panel62.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel62.BackColor = System.Drawing.Color.White;
            this.panel62.Controls.Add(this.radioButton7);
            this.panel62.Controls.Add(this.raButt_IN_1_C);
            this.panel62.Controls.Add(this.raButt_IN_2_C);
            this.panel62.Location = new System.Drawing.Point(3, 2);
            this.panel62.Margin = new System.Windows.Forms.Padding(2);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(208, 33);
            this.panel62.TabIndex = 16;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(216, 9);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(59, 16);
            this.radioButton7.TabIndex = 56;
            this.radioButton7.Text = "사업자";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.Visible = false;
            // 
            // raButt_IN_1_C
            // 
            this.raButt_IN_1_C.AutoSize = true;
            this.raButt_IN_1_C.Checked = true;
            this.raButt_IN_1_C.Location = new System.Drawing.Point(1, 9);
            this.raButt_IN_1_C.Name = "raButt_IN_1_C";
            this.raButt_IN_1_C.Size = new System.Drawing.Size(59, 16);
            this.raButt_IN_1_C.TabIndex = 54;
            this.raButt_IN_1_C.TabStop = true;
            this.raButt_IN_1_C.Text = "내국인";
            this.raButt_IN_1_C.UseVisualStyleBackColor = true;
            // 
            // raButt_IN_2_C
            // 
            this.raButt_IN_2_C.AutoSize = true;
            this.raButt_IN_2_C.Location = new System.Drawing.Point(110, 9);
            this.raButt_IN_2_C.Name = "raButt_IN_2_C";
            this.raButt_IN_2_C.Size = new System.Drawing.Size(59, 16);
            this.raButt_IN_2_C.TabIndex = 55;
            this.raButt_IN_2_C.Text = "외국인";
            this.raButt_IN_2_C.UseVisualStyleBackColor = true;
            // 
            // check_CC
            // 
            this.check_CC.AutoSize = true;
            this.check_CC.Location = new System.Drawing.Point(6, 6);
            this.check_CC.Name = "check_CC";
            this.check_CC.Size = new System.Drawing.Size(114, 16);
            this.check_CC.TabIndex = 24;
            this.check_CC.Text = "부부사업자_등록";
            this.check_CC.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.panel47, 1, 0);
            this.tableLayoutPanel24.Location = new System.Drawing.Point(50, 372);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(409, 36);
            this.tableLayoutPanel24.TabIndex = 1038;
            this.tableLayoutPanel24.Visible = false;
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(2, 2);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(120, 32);
            this.label35.TabIndex = 0;
            this.label35.Text = "영문_Last_Name";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel47
            // 
            this.panel47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel47.BackColor = System.Drawing.Color.White;
            this.panel47.Controls.Add(this.txtName_E_2_C);
            this.panel47.Location = new System.Drawing.Point(126, 4);
            this.panel47.Margin = new System.Windows.Forms.Padding(2);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(279, 28);
            this.panel47.TabIndex = 15;
            // 
            // txtName_E_2_C
            // 
            this.txtName_E_2_C.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_E_2_C.Location = new System.Drawing.Point(3, 3);
            this.txtName_E_2_C.MaxLength = 30;
            this.txtName_E_2_C.Name = "txtName_E_2_C";
            this.txtName_E_2_C.Size = new System.Drawing.Size(273, 22);
            this.txtName_E_2_C.TabIndex = 7;
            this.txtName_E_2_C.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_E_2_C.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_E_2_C.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel25.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.panel48, 1, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(46, 334);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(409, 36);
            this.tableLayoutPanel25.TabIndex = 1037;
            this.tableLayoutPanel25.Visible = false;
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(2, 2);
            this.label40.Margin = new System.Windows.Forms.Padding(0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(120, 32);
            this.label40.TabIndex = 0;
            this.label40.Text = "영문_First_Name";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel48
            // 
            this.panel48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.txtName_E_1_C);
            this.panel48.Location = new System.Drawing.Point(126, 4);
            this.panel48.Margin = new System.Windows.Forms.Padding(2);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(279, 28);
            this.panel48.TabIndex = 15;
            // 
            // txtName_E_1_C
            // 
            this.txtName_E_1_C.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_E_1_C.Location = new System.Drawing.Point(3, 3);
            this.txtName_E_1_C.MaxLength = 30;
            this.txtName_E_1_C.Name = "txtName_E_1_C";
            this.txtName_E_1_C.Size = new System.Drawing.Size(273, 22);
            this.txtName_E_1_C.TabIndex = 6;
            this.txtName_E_1_C.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_E_1_C.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_E_1_C.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel26.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.panel50, 1, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(65, 448);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(268, 36);
            this.tableLayoutPanel26.TabIndex = 1036;
            this.tableLayoutPanel26.Visible = false;
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(2, 2);
            this.label41.Margin = new System.Windows.Forms.Padding(0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(120, 32);
            this.label41.TabIndex = 0;
            this.label41.Text = "주민번호";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel50
            // 
            this.panel50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel50.BackColor = System.Drawing.Color.White;
            this.panel50.Controls.Add(this.mtxtSn_C);
            this.panel50.Location = new System.Drawing.Point(126, 4);
            this.panel50.Margin = new System.Windows.Forms.Padding(2);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(138, 28);
            this.panel50.TabIndex = 15;
            // 
            // mtxtSn_C
            // 
            this.mtxtSn_C.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtSn_C.Location = new System.Drawing.Point(3, 3);
            this.mtxtSn_C.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.mtxtSn_C.Name = "mtxtSn_C";
            this.mtxtSn_C.Size = new System.Drawing.Size(132, 21);
            this.mtxtSn_C.TabIndex = 9;
            this.mtxtSn_C.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSn_C.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Sn_KeyPress);
            this.mtxtSn_C.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableL_Birth_KR_C
            // 
            this.tableL_Birth_KR_C.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableL_Birth_KR_C.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableL_Birth_KR_C.ColumnCount = 2;
            this.tableL_Birth_KR_C.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableL_Birth_KR_C.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_Birth_KR_C.Controls.Add(this.label42, 0, 0);
            this.tableL_Birth_KR_C.Controls.Add(this.panel51, 1, 0);
            this.tableL_Birth_KR_C.Location = new System.Drawing.Point(2, 59);
            this.tableL_Birth_KR_C.Name = "tableL_Birth_KR_C";
            this.tableL_Birth_KR_C.RowCount = 1;
            this.tableL_Birth_KR_C.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableL_Birth_KR_C.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableL_Birth_KR_C.Size = new System.Drawing.Size(301, 36);
            this.tableL_Birth_KR_C.TabIndex = 26;
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(2, 2);
            this.label42.Margin = new System.Windows.Forms.Padding(0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(120, 32);
            this.label42.TabIndex = 0;
            this.label42.Text = "생년월일";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel51
            // 
            this.panel51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel51.BackColor = System.Drawing.Color.White;
            this.panel51.Controls.Add(this.radioButton5);
            this.panel51.Controls.Add(this.mtxtBrithDayC);
            this.panel51.Controls.Add(this.DTP_BrithDayC);
            this.panel51.Controls.Add(this.radioButton6);
            this.panel51.Location = new System.Drawing.Point(126, 4);
            this.panel51.Margin = new System.Windows.Forms.Padding(2);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(171, 28);
            this.panel51.TabIndex = 15;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(175, 39);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(47, 16);
            this.radioButton5.TabIndex = 55;
            this.radioButton5.Text = "음력";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.Visible = false;
            // 
            // mtxtBrithDayC
            // 
            this.mtxtBrithDayC.Location = new System.Drawing.Point(3, 3);
            this.mtxtBrithDayC.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtBrithDayC.Name = "mtxtBrithDayC";
            this.mtxtBrithDayC.Size = new System.Drawing.Size(143, 21);
            this.mtxtBrithDayC.TabIndex = 18;
            this.mtxtBrithDayC.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtBrithDayC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtBrithDayC.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_BrithDayC
            // 
            this.DTP_BrithDayC.Location = new System.Drawing.Point(146, 3);
            this.DTP_BrithDayC.Name = "DTP_BrithDayC";
            this.DTP_BrithDayC.Size = new System.Drawing.Size(21, 21);
            this.DTP_BrithDayC.TabIndex = 129;
            this.DTP_BrithDayC.TabStop = false;
            this.DTP_BrithDayC.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(174, 27);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(47, 16);
            this.radioButton6.TabIndex = 54;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "양력";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.Visible = false;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.panel55, 1, 0);
            this.tableLayoutPanel38.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel38.Location = new System.Drawing.Point(2, 23);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(409, 36);
            this.tableLayoutPanel38.TabIndex = 25;
            // 
            // panel55
            // 
            this.panel55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel55.BackColor = System.Drawing.Color.White;
            this.panel55.Controls.Add(this.txtName_C);
            this.panel55.Location = new System.Drawing.Point(126, 4);
            this.panel55.Margin = new System.Windows.Forms.Padding(2);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(279, 28);
            this.panel55.TabIndex = 15;
            // 
            // txtName_C
            // 
            this.txtName_C.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName_C.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_C.Location = new System.Drawing.Point(3, 3);
            this.txtName_C.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtName_C.MaxLength = 30;
            this.txtName_C.Name = "txtName_C";
            this.txtName_C.Size = new System.Drawing.Size(273, 22);
            this.txtName_C.TabIndex = 5;
            this.txtName_C.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_C.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_C.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label43.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(2, 2);
            this.label43.Margin = new System.Windows.Forms.Padding(0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 32);
            this.label43.TabIndex = 0;
            this.label43.Text = "성명";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Day
            // 
            this.tab_Day.Controls.Add(this.dGridView_Base);
            this.tab_Day.Location = new System.Drawing.Point(4, 22);
            this.tab_Day.Name = "tab_Day";
            this.tab_Day.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Day.Size = new System.Drawing.Size(1294, 882);
            this.tab_Day.TabIndex = 1;
            this.tab_Day.Text = "당일_등록";
            this.tab_Day.UseVisualStyleBackColor = true;
            // 
            // tab_Hide
            // 
            this.tab_Hide.Controls.Add(this.tableLayoutPanel29);
            this.tab_Hide.Controls.Add(this.tableLayoutPanel12);
            this.tab_Hide.Controls.Add(this.panel38);
            this.tab_Hide.Controls.Add(this.panel63);
            this.tab_Hide.Controls.Add(this.panel_Config);
            this.tab_Hide.Controls.Add(this.panel59);
            this.tab_Hide.Controls.Add(this.panel20);
            this.tab_Hide.Location = new System.Drawing.Point(4, 22);
            this.tab_Hide.Name = "tab_Hide";
            this.tab_Hide.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Hide.Size = new System.Drawing.Size(1294, 882);
            this.tab_Hide.TabIndex = 3;
            this.tab_Hide.Text = "숨겨진 컨트롤";
            this.tab_Hide.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.tableLayoutPanel29.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(580, 423);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(291, 37);
            this.tableLayoutPanel29.TabIndex = 1024;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(2, 2);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 33);
            this.label22.TabIndex = 0;
            this.label22.Text = "주민번호";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.mtxtSn);
            this.panel19.Location = new System.Drawing.Point(126, 4);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(161, 28);
            this.panel19.TabIndex = 15;
            // 
            // mtxtSn
            // 
            this.mtxtSn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtSn.Location = new System.Drawing.Point(3, 3);
            this.mtxtSn.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.mtxtSn.Name = "mtxtSn";
            this.mtxtSn.Size = new System.Drawing.Size(155, 21);
            this.mtxtSn.TabIndex = 9;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 100);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel15.TabIndex = 2;
            // 
            // panel14
            // 
            this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Location = new System.Drawing.Point(126, 4);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(471, 29);
            this.panel14.TabIndex = 15;
            // 
            // txtAddress2_Auto
            // 
            this.txtAddress2_Auto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress2_Auto.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAddress2_Auto.Location = new System.Drawing.Point(3, 3);
            this.txtAddress2_Auto.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtAddress2_Auto.MaxLength = 100;
            this.txtAddress2_Auto.Name = "txtAddress2_Auto";
            this.txtAddress2_Auto.Size = new System.Drawing.Size(467, 22);
            this.txtAddress2_Auto.TabIndex = 9;
            this.txtAddress2_Auto.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress2_Auto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress2_Auto.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(2, 2);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 33);
            this.label7.TabIndex = 0;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 137);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel11.TabIndex = 3;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Location = new System.Drawing.Point(126, 4);
            this.panel41.Margin = new System.Windows.Forms.Padding(2);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(170, 28);
            this.panel41.TabIndex = 15;
            // 
            // txtName_Auto
            // 
            this.txtName_Auto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName_Auto.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtName_Auto.Location = new System.Drawing.Point(3, 3);
            this.txtName_Auto.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtName_Auto.MaxLength = 30;
            this.txtName_Auto.Name = "txtName_Auto";
            this.txtName_Auto.Size = new System.Drawing.Size(164, 22);
            this.txtName_Auto.TabIndex = 17;
            this.txtName_Auto.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName_Auto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName_Auto.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(2, 2);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 33);
            this.label8.TabIndex = 0;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 62);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel18.TabIndex = 1;
            // 
            // panel40
            // 
            this.panel40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel40.BackColor = System.Drawing.Color.White;
            this.panel40.Location = new System.Drawing.Point(126, 4);
            this.panel40.Margin = new System.Windows.Forms.Padding(2);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(471, 29);
            this.panel40.TabIndex = 15;
            // 
            // txtAddress_Auto
            // 
            this.txtAddress_Auto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress_Auto.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtAddress_Auto.Location = new System.Drawing.Point(3, 3);
            this.txtAddress_Auto.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtAddress_Auto.MaxLength = 100;
            this.txtAddress_Auto.Name = "txtAddress_Auto";
            this.txtAddress_Auto.Size = new System.Drawing.Size(467, 22);
            this.txtAddress_Auto.TabIndex = 8;
            this.txtAddress_Auto.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtAddress_Auto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtAddress_Auto.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 33);
            this.label13.TabIndex = 0;
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Location = new System.Drawing.Point(304, 137);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel14.TabIndex = 4;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.White;
            this.panel42.Location = new System.Drawing.Point(126, 4);
            this.panel42.Margin = new System.Windows.Forms.Padding(2);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(170, 28);
            this.panel42.TabIndex = 15;
            // 
            // mtxtTel_Auto
            // 
            this.mtxtTel_Auto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtTel_Auto.Location = new System.Drawing.Point(3, 3);
            this.mtxtTel_Auto.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtTel_Auto.Name = "mtxtTel_Auto";
            this.mtxtTel_Auto.Size = new System.Drawing.Size(164, 21);
            this.mtxtTel_Auto.TabIndex = 12;
            this.mtxtTel_Auto.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtTel_Auto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtTel_Auto.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 2);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 33);
            this.label10.TabIndex = 0;
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 25);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(378, 37);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Location = new System.Drawing.Point(126, 4);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(248, 29);
            this.panel16.TabIndex = 15;
            // 
            // butt_AddCode2
            // 
            this.butt_AddCode2.BackColor = System.Drawing.Color.White;
            this.butt_AddCode2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_AddCode2.Location = new System.Drawing.Point(93, 1);
            this.butt_AddCode2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_AddCode2.Name = "butt_AddCode2";
            this.butt_AddCode2.Size = new System.Drawing.Size(75, 26);
            this.butt_AddCode2.TabIndex = 95;
            this.butt_AddCode2.TabStop = false;
            this.butt_AddCode2.Text = "우편_번호";
            this.butt_AddCode2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.butt_AddCode2.UseVisualStyleBackColor = false;
            this.butt_AddCode2.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // mtxtZip_Auto
            // 
            this.mtxtZip_Auto.Location = new System.Drawing.Point(3, 3);
            this.mtxtZip_Auto.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtZip_Auto.Name = "mtxtZip_Auto";
            this.mtxtZip_Auto.Size = new System.Drawing.Size(88, 21);
            this.mtxtZip_Auto.TabIndex = 96;
            this.mtxtZip_Auto.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtZip_Auto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtZip_Auto.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // butt_AddCodeT1
            // 
            this.butt_AddCodeT1.BackColor = System.Drawing.Color.White;
            this.butt_AddCodeT1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_AddCodeT1.Location = new System.Drawing.Point(171, 1);
            this.butt_AddCodeT1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_AddCodeT1.Name = "butt_AddCodeT1";
            this.butt_AddCodeT1.Size = new System.Drawing.Size(75, 26);
            this.butt_AddCodeT1.TabIndex = 97;
            this.butt_AddCodeT1.TabStop = false;
            this.butt_AddCodeT1.Text = "좌동";
            this.butt_AddCodeT1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.butt_AddCodeT1.UseVisualStyleBackColor = false;
            this.butt_AddCodeT1.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 33);
            this.label9.TabIndex = 0;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel51.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel51.ColumnCount = 2;
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.Location = new System.Drawing.Point(3, 216);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 1;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(362, 36);
            this.tableLayoutPanel51.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(2, 2);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 32);
            this.label15.TabIndex = 0;
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.White;
            this.panel52.Location = new System.Drawing.Point(126, 4);
            this.panel52.Margin = new System.Windows.Forms.Padding(2);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(232, 28);
            this.panel52.TabIndex = 15;
            // 
            // txt_C_Card_Number
            // 
            this.txt_C_Card_Number.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_Card_Number.Location = new System.Drawing.Point(4, 3);
            this.txt_C_Card_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Number.MaxLength = 30;
            this.txt_C_Card_Number.Name = "txt_C_Card_Number";
            this.txt_C_Card_Number.Size = new System.Drawing.Size(225, 22);
            this.txt_C_Card_Number.TabIndex = 5;
            this.txt_C_Card_Number.Tag = "-";
            this.txt_C_Card_Number.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card_Number.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel53
            // 
            this.tableLayoutPanel53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel53.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel53.ColumnCount = 2;
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel53.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.Location = new System.Drawing.Point(252, 179);
            this.tableLayoutPanel53.Name = "tableLayoutPanel53";
            this.tableLayoutPanel53.RowCount = 1;
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel53.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel53.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel53.TabIndex = 6;
            this.tableLayoutPanel53.Visible = false;
            // 
            // label48
            // 
            this.label48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(2, 2);
            this.label48.Margin = new System.Windows.Forms.Padding(0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(120, 32);
            this.label48.TabIndex = 0;
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.White;
            this.panel54.Location = new System.Drawing.Point(126, 4);
            this.panel54.Margin = new System.Windows.Forms.Padding(2);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(98, 28);
            this.panel54.TabIndex = 15;
            // 
            // txt_C_Name_3
            // 
            this.txt_C_Name_3.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_Name_3.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Name_3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Name_3.MaxLength = 100;
            this.txt_C_Name_3.Name = "txt_C_Name_3";
            this.txt_C_Name_3.Size = new System.Drawing.Size(92, 22);
            this.txt_C_Name_3.TabIndex = 2;
            this.txt_C_Name_3.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Name_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Name_3.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel52.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel52.ColumnCount = 2;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.Location = new System.Drawing.Point(3, 253);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 1;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(249, 36);
            this.tableLayoutPanel52.TabIndex = 8;
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(2, 2);
            this.label46.Margin = new System.Windows.Forms.Padding(0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(120, 32);
            this.label46.TabIndex = 0;
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel53
            // 
            this.panel53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel53.BackColor = System.Drawing.Color.White;
            this.panel53.Location = new System.Drawing.Point(126, 4);
            this.panel53.Margin = new System.Windows.Forms.Padding(2);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(119, 28);
            this.panel53.TabIndex = 15;
            // 
            // combo_C_Card_Month
            // 
            this.combo_C_Card_Month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Month.FormattingEnabled = true;
            this.combo_C_Card_Month.Location = new System.Drawing.Point(72, 4);
            this.combo_C_Card_Month.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Month.Name = "combo_C_Card_Month";
            this.combo_C_Card_Month.Size = new System.Drawing.Size(44, 20);
            this.combo_C_Card_Month.TabIndex = 8;
            // 
            // combo_C_Card_Year
            // 
            this.combo_C_Card_Year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Year.FormattingEnabled = true;
            this.combo_C_Card_Year.Location = new System.Drawing.Point(3, 4);
            this.combo_C_Card_Year.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_C_Card_Year.Name = "combo_C_Card_Year";
            this.combo_C_Card_Year.Size = new System.Drawing.Size(67, 20);
            this.combo_C_Card_Year.TabIndex = 7;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 180);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(249, 36);
            this.tableLayoutPanel20.TabIndex = 5;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.White;
            this.panel49.Location = new System.Drawing.Point(126, 4);
            this.panel49.Margin = new System.Windows.Forms.Padding(2);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(119, 28);
            this.panel49.TabIndex = 15;
            // 
            // txt_C_Card_Code
            // 
            this.txt_C_Card_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(144)))), ((int)(((byte)(176)))));
            this.txt_C_Card_Code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_C_Card_Code.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_Card_Code.ForeColor = System.Drawing.Color.White;
            this.txt_C_Card_Code.Location = new System.Drawing.Point(74, 3);
            this.txt_C_Card_Code.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_Card_Code.MaxLength = 30;
            this.txt_C_Card_Code.Name = "txt_C_Card_Code";
            this.txt_C_Card_Code.ReadOnly = true;
            this.txt_C_Card_Code.Size = new System.Drawing.Size(42, 22);
            this.txt_C_Card_Code.TabIndex = 4;
            this.txt_C_Card_Code.TabStop = false;
            // 
            // txt_C_Card
            // 
            this.txt_C_Card.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_Card.Location = new System.Drawing.Point(3, 3);
            this.txt_C_Card.Margin = new System.Windows.Forms.Padding(0);
            this.txt_C_Card.MaxLength = 30;
            this.txt_C_Card.Name = "txt_C_Card";
            this.txt_C_Card.Size = new System.Drawing.Size(70, 22);
            this.txt_C_Card.TabIndex = 14;
            this.txt_C_Card.Tag = "ncode";
            this.txt_C_Card.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txt_C_Card.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_C_Card.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_C_Card.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(2, 2);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 32);
            this.label14.TabIndex = 0;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Location = new System.Drawing.Point(4, 290);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(248, 37);
            this.tableLayoutPanel21.TabIndex = 9;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.White;
            this.panel44.Location = new System.Drawing.Point(126, 4);
            this.panel44.Margin = new System.Windows.Forms.Padding(2);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(118, 28);
            this.panel44.TabIndex = 15;
            // 
            // cboRegDateA
            // 
            this.cboRegDateA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboRegDateA.FormattingEnabled = true;
            this.cboRegDateA.Location = new System.Drawing.Point(2, 4);
            this.cboRegDateA.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.cboRegDateA.Name = "cboRegDateA";
            this.cboRegDateA.Size = new System.Drawing.Size(112, 20);
            this.cboRegDateA.TabIndex = 57;
            this.cboRegDateA.SelectedIndexChanged += new System.EventHandler(this.cboRegDateA_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(2, 2);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(120, 33);
            this.label26.TabIndex = 0;
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel22.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Location = new System.Drawing.Point(460, 13);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(300, 37);
            this.tableLayoutPanel22.TabIndex = 10;
            this.tableLayoutPanel22.Visible = false;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.White;
            this.panel45.Location = new System.Drawing.Point(126, 4);
            this.panel45.Margin = new System.Windows.Forms.Padding(2);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(170, 28);
            this.panel45.TabIndex = 15;
            // 
            // combo_Auto_Date
            // 
            this.combo_Auto_Date.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Auto_Date.FormattingEnabled = true;
            this.combo_Auto_Date.Location = new System.Drawing.Point(3, 4);
            this.combo_Auto_Date.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Auto_Date.Name = "combo_Auto_Date";
            this.combo_Auto_Date.Size = new System.Drawing.Size(164, 20);
            this.combo_Auto_Date.TabIndex = 9;
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(2, 2);
            this.label30.Margin = new System.Windows.Forms.Padding(0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(120, 33);
            this.label30.TabIndex = 0;
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // check_Auto
            // 
            this.check_Auto.AutoSize = true;
            this.check_Auto.Location = new System.Drawing.Point(3, 7);
            this.check_Auto.Name = "check_Auto";
            this.check_Auto.Size = new System.Drawing.Size(150, 16);
            this.check_Auto.TabIndex = 11;
            this.check_Auto.Text = "오토쉽_등록_수정_해지";
            this.check_Auto.UseVisualStyleBackColor = true;
            this.check_Auto.MouseClick += new System.Windows.Forms.MouseEventHandler(this.check_Auto_MouseClick);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel23.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 327);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(601, 37);
            this.tableLayoutPanel23.TabIndex = 11;
            // 
            // panel46
            // 
            this.panel46.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel46.BackColor = System.Drawing.Color.White;
            this.panel46.Location = new System.Drawing.Point(126, 4);
            this.panel46.Margin = new System.Windows.Forms.Padding(2);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(471, 28);
            this.panel46.TabIndex = 15;
            // 
            // txtRemark_A
            // 
            this.txtRemark_A.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRemark_A.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txtRemark_A.Location = new System.Drawing.Point(3, 3);
            this.txtRemark_A.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txtRemark_A.MaxLength = 50;
            this.txtRemark_A.Name = "txtRemark_A";
            this.txtRemark_A.Size = new System.Drawing.Size(465, 22);
            this.txtRemark_A.TabIndex = 30;
            this.txtRemark_A.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtRemark_A.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtRemark_A.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(2, 2);
            this.label32.Margin = new System.Windows.Forms.Padding(0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(120, 33);
            this.label32.TabIndex = 0;
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel44.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel44.ColumnCount = 2;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.Location = new System.Drawing.Point(4, 364);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 1;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel44.TabIndex = 200;
            // 
            // label50
            // 
            this.label50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(2, 2);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(120, 32);
            this.label50.TabIndex = 0;
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel56
            // 
            this.panel56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel56.BackColor = System.Drawing.Color.White;
            this.panel56.Location = new System.Drawing.Point(126, 4);
            this.panel56.Margin = new System.Windows.Forms.Padding(2);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(98, 28);
            this.panel56.TabIndex = 15;
            // 
            // txt_Auto_PR
            // 
            this.txt_Auto_PR.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Auto_PR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Auto_PR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Auto_PR.Font = new System.Drawing.Font("돋움", 9F);
            this.txt_Auto_PR.ForeColor = System.Drawing.Color.Red;
            this.txt_Auto_PR.Location = new System.Drawing.Point(3, 3);
            this.txt_Auto_PR.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Auto_PR.MaxLength = 30;
            this.txt_Auto_PR.Name = "txt_Auto_PR";
            this.txt_Auto_PR.ReadOnly = true;
            this.txt_Auto_PR.Size = new System.Drawing.Size(92, 21);
            this.txt_Auto_PR.TabIndex = 175;
            this.txt_Auto_PR.TabStop = false;
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel46.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel46.ColumnCount = 2;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.Location = new System.Drawing.Point(232, 364);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 1;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(228, 36);
            this.tableLayoutPanel46.TabIndex = 202;
            // 
            // label52
            // 
            this.label52.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(2, 2);
            this.label52.Margin = new System.Windows.Forms.Padding(0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(120, 32);
            this.label52.TabIndex = 0;
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel58
            // 
            this.panel58.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel58.BackColor = System.Drawing.Color.White;
            this.panel58.Location = new System.Drawing.Point(126, 4);
            this.panel58.Margin = new System.Windows.Forms.Padding(2);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(98, 28);
            this.panel58.TabIndex = 15;
            // 
            // txt_Auto_PR2
            // 
            this.txt_Auto_PR2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Auto_PR2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Auto_PR2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Auto_PR2.Font = new System.Drawing.Font("돋움", 9F);
            this.txt_Auto_PR2.ForeColor = System.Drawing.Color.Red;
            this.txt_Auto_PR2.Location = new System.Drawing.Point(3, 3);
            this.txt_Auto_PR2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Auto_PR2.MaxLength = 30;
            this.txt_Auto_PR2.Name = "txt_Auto_PR2";
            this.txt_Auto_PR2.ReadOnly = true;
            this.txt_Auto_PR2.Size = new System.Drawing.Size(92, 21);
            this.txt_Auto_PR2.TabIndex = 175;
            this.txt_Auto_PR2.TabStop = false;
            // 
            // tableLayoutPanel57
            // 
            this.tableLayoutPanel57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel57.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel57.ColumnCount = 2;
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel57.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel57.Location = new System.Drawing.Point(425, 253);
            this.tableLayoutPanel57.Name = "tableLayoutPanel57";
            this.tableLayoutPanel57.RowCount = 1;
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel57.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel57.Size = new System.Drawing.Size(179, 36);
            this.tableLayoutPanel57.TabIndex = 204;
            this.tableLayoutPanel57.Visible = false;
            // 
            // label56
            // 
            this.label56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(2, 2);
            this.label56.Margin = new System.Windows.Forms.Padding(0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(70, 32);
            this.label56.TabIndex = 0;
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.White;
            this.panel65.Location = new System.Drawing.Point(76, 4);
            this.panel65.Margin = new System.Windows.Forms.Padding(2);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(99, 28);
            this.panel65.TabIndex = 15;
            // 
            // combo_C_Card_Per
            // 
            this.combo_C_Card_Per.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_C_Card_Per.FormattingEnabled = true;
            this.combo_C_Card_Per.Location = new System.Drawing.Point(3, 3);
            this.combo_C_Card_Per.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.combo_C_Card_Per.Name = "combo_C_Card_Per";
            this.combo_C_Card_Per.Size = new System.Drawing.Size(93, 20);
            this.combo_C_Card_Per.TabIndex = 9;
            // 
            // tableLayoutPanel72
            // 
            this.tableLayoutPanel72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel72.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel72.ColumnCount = 2;
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel72.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel72.Location = new System.Drawing.Point(251, 253);
            this.tableLayoutPanel72.Name = "tableLayoutPanel72";
            this.tableLayoutPanel72.RowCount = 1;
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel72.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel72.Size = new System.Drawing.Size(176, 36);
            this.tableLayoutPanel72.TabIndex = 205;
            // 
            // label81
            // 
            this.label81.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label81.ForeColor = System.Drawing.Color.White;
            this.label81.Location = new System.Drawing.Point(2, 2);
            this.label81.Margin = new System.Windows.Forms.Padding(0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(120, 32);
            this.label81.TabIndex = 0;
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel84
            // 
            this.panel84.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel84.BackColor = System.Drawing.Color.White;
            this.panel84.Location = new System.Drawing.Point(126, 4);
            this.panel84.Margin = new System.Windows.Forms.Padding(2);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(46, 28);
            this.panel84.TabIndex = 15;
            // 
            // txt_C_P_Number
            // 
            this.txt_C_P_Number.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_P_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_C_P_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_P_Number.MaxLength = 2;
            this.txt_C_P_Number.Name = "txt_C_P_Number";
            this.txt_C_P_Number.Size = new System.Drawing.Size(42, 22);
            this.txt_C_P_Number.TabIndex = 6;
            this.txt_C_P_Number.Tag = "1";
            // 
            // tableLayoutPanel62
            // 
            this.tableLayoutPanel62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.tableLayoutPanel62.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel62.ColumnCount = 2;
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel62.Location = new System.Drawing.Point(366, 216);
            this.tableLayoutPanel62.Name = "tableLayoutPanel62";
            this.tableLayoutPanel62.RowCount = 1;
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel62.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel62.Size = new System.Drawing.Size(238, 36);
            this.tableLayoutPanel62.TabIndex = 206;
            // 
            // label80
            // 
            this.label80.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(173)))), ((int)(((byte)(142)))));
            this.label80.ForeColor = System.Drawing.Color.White;
            this.label80.Location = new System.Drawing.Point(2, 2);
            this.label80.Margin = new System.Windows.Forms.Padding(0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(120, 32);
            this.label80.TabIndex = 0;
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel83
            // 
            this.panel83.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel83.BackColor = System.Drawing.Color.White;
            this.panel83.Location = new System.Drawing.Point(126, 4);
            this.panel83.Margin = new System.Windows.Forms.Padding(2);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(108, 28);
            this.panel83.TabIndex = 15;
            // 
            // txt_C_B_Number
            // 
            this.txt_C_B_Number.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_C_B_Number.Location = new System.Drawing.Point(3, 3);
            this.txt_C_B_Number.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_C_B_Number.MaxLength = 10;
            this.txt_C_B_Number.Name = "txt_C_B_Number";
            this.txt_C_B_Number.Size = new System.Drawing.Size(102, 22);
            this.txt_C_B_Number.TabIndex = 6;
            this.txt_C_B_Number.Tag = "1";
            // 
            // txt_Auto_Date
            // 
            this.txt_Auto_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Auto_Date.Font = new System.Drawing.Font("돋움", 9.75F);
            this.txt_Auto_Date.Location = new System.Drawing.Point(609, 332);
            this.txt_Auto_Date.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txt_Auto_Date.MaxLength = 2;
            this.txt_Auto_Date.Name = "txt_Auto_Date";
            this.txt_Auto_Date.ReadOnly = true;
            this.txt_Auto_Date.Size = new System.Drawing.Size(773, 22);
            this.txt_Auto_Date.TabIndex = 207;
            this.txt_Auto_Date.Tag = "1";
            this.txt_Auto_Date.Visible = false;
            // 
            // dGridView_Good
            // 
            this.dGridView_Good.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Good.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dGridView_Good.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Good.DefaultCellStyle = dataGridViewCellStyle6;
            this.dGridView_Good.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Good.Location = new System.Drawing.Point(3, 17);
            this.dGridView_Good.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dGridView_Good.Name = "dGridView_Good";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Good.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dGridView_Good.RowTemplate.Height = 23;
            this.dGridView_Good.Size = new System.Drawing.Size(1456, 452);
            this.dGridView_Good.TabIndex = 9;
            this.dGridView_Good.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGridView_Good_CellEndEdit);
            this.dGridView_Good.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dGridView_Good_EditingControlShowing);
            // 
            // frmMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(1400, 936);
            this.ClientSize = new System.Drawing.Size(1924, 915);
            this.Controls.Add(this.tab_Sub);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.KeyPreview = true;
            this.Name = "frmMember";
            this.Text = "회원_등록";
            this.Activated += new System.EventHandler(this.frmMember_Activated);
            this.Load += new System.EventHandler(this.frmBase_From_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            this.Resize += new System.EventHandler(this.frmBase_Resize);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tbl_save.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tbl_nom.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.grB_Line.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Li)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tableLayoutPanel28.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.pnlZipCode_KR.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.tableLayoutPanel36.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pnlSubDistrict_TH.ResumeLayout(false);
            this.panel75.ResumeLayout(false);
            this.pnlDistrict_TH.ResumeLayout(false);
            this.panel74.ResumeLayout(false);
            this.pnlProvince_TH.ResumeLayout(false);
            this.panel73.ResumeLayout(false);
            this.pnlZipCode_TH.ResumeLayout(false);
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.tlpNaCode.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.tableLayoutPanel45.ResumeLayout(false);
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.tableLayoutPanel43.ResumeLayout(false);
            this.tab_Nation.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel42.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel66.PerformLayout();
            this.panel67.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.tableLayoutPanel65.ResumeLayout(false);
            this.tableLayoutPanel65.PerformLayout();
            this.tableLayoutPanel39.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel59.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel60.PerformLayout();
            this.panel_Config.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tab_Sub.ResumeLayout(false);
            this.tab_Auto.ResumeLayout(false);
            this.tab_C.ResumeLayout(false);
            this.tab_C.PerformLayout();
            this.tableLayoutPanel41.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.tableLayoutPanel40.ResumeLayout(false);
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            this.panel61.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.tableL_Birth_KR_C.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.tab_Day.ResumeLayout(false);
            this.tab_Hide.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Good)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button butt_Excel;
        private System.Windows.Forms.Button butt_Delete;
        private System.Windows.Forms.Button butt_Clear;
        private System.Windows.Forms.Button butt_Save;
        private System.Windows.Forms.Button butt_Exit;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.MaskedTextBox mtxtMbid_s;
        private System.Windows.Forms.MaskedTextBox mtxtMbid_n;
        private System.Windows.Forms.DateTimePicker DTP_RegDate;
        private System.Windows.Forms.TextBox txtCenter_Code;
        private System.Windows.Forms.TextBox txtCenter;
        private System.Windows.Forms.Button butt_AddCode;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtBank_Code;
        private System.Windows.Forms.TextBox txtBank;
        private System.Windows.Forms.TextBox txtName_Accnt;
        private System.Windows.Forms.TextBox txtAccount;
        private System.Windows.Forms.TextBox txtName_E_1;
        private System.Windows.Forms.TextBox txtName_E_2;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtWebID;
        private System.Windows.Forms.RadioButton opt_sell_3;
        private System.Windows.Forms.RadioButton opt_sell_2;
        private System.Windows.Forms.TextBox txtLineCnt;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.DateTimePicker DTP_EdDate;
        private System.Windows.Forms.DateTimePicker DTP_BrithDay;
        private System.Windows.Forms.TextBox txtSN_s;
        private System.Windows.Forms.TextBox txtSN_n;
        private System.Windows.Forms.TextBox txtName_n;
        private System.Windows.Forms.TextBox txtName_s;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton opt_Bir_TF_2;
        private System.Windows.Forms.RadioButton opt_Bir_TF_1;
        private System.Windows.Forms.RadioButton raButt_IN_2;
        private System.Windows.Forms.RadioButton raButt_IN_1;
        private System.Windows.Forms.DataGridView dGridView_Base;
        private System.Windows.Forms.GroupBox grB_Line;
        private System.Windows.Forms.DataGridView dGridView_Li;
        private System.Windows.Forms.CheckBox chk_Top_s;
        private System.Windows.Forms.CheckBox chk_Top_n;
        private System.Windows.Forms.TableLayoutPanel tbl_nom;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TableLayoutPanel tbl_save;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox check_CpnoDocument;
        private System.Windows.Forms.CheckBox check_BankDocument;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RadioButton opt_MCode_A;
        private System.Windows.Forms.RadioButton opt_MCode_R;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox check_Cpno_Multi;
        private System.Windows.Forms.CheckBox check_Cpno_Err;
        private System.Windows.Forms.CheckBox check_Cpno;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel pnlZipCode_KR;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.MaskedTextBox mtxtZip1;
        private System.Windows.Forms.MaskedTextBox mtxtRegDate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.MaskedTextBox mtxtTel2;
        private System.Windows.Forms.MaskedTextBox mtxtTel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.MaskedTextBox mtxtEdDate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.MaskedTextBox mtxtBrithDay;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel_Config;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TableLayoutPanel tab_Nation;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox combo_Se;
        private System.Windows.Forms.ComboBox combo_Se_Code;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtB1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.CheckBox check_LR;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tab_Sub;
        private System.Windows.Forms.TabPage tab_Day;
        private System.Windows.Forms.TabPage tab_C;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton raButt_IN_1_C;
        private System.Windows.Forms.RadioButton raButt_IN_2_C;
        private System.Windows.Forms.CheckBox check_CC;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.TextBox txtName_E_2_C;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.TextBox txtName_E_1_C;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.MaskedTextBox mtxtSn_C;
        private System.Windows.Forms.TableLayoutPanel tableL_Birth_KR_C;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.MaskedTextBox mtxtBrithDayC;
        private System.Windows.Forms.DateTimePicker DTP_BrithDayC;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.TextBox txtName_C;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button_Acc_Reg;
        private System.Windows.Forms.TextBox txtAccount_Reg;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.MaskedTextBox mtxtVisaDay;
        private System.Windows.Forms.DateTimePicker DTP_VisaDay;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.RadioButton radioB_Begin;
        private System.Windows.Forms.RadioButton radioB_RBO;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.RadioButton radioB_G4;
        private System.Windows.Forms.RadioButton radioB_G8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel65;
        private System.Windows.Forms.Label Lbl_Certify;
        private System.Windows.Forms.Button butt_Certify;
        private System.Windows.Forms.TabPage tab_Hide;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.RadioButton radioB_Sex_Y;
        private System.Windows.Forms.RadioButton radioB_Sex_X;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.CheckBox checkB_EMail_FLAG;
        private System.Windows.Forms.CheckBox checkB_SMS_FLAG;
        private System.Windows.Forms.TextBox txt_IpinCI;
        private System.Windows.Forms.TextBox txt_IpinDI;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.MaskedTextBox mtxtTel2_C;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.TextBox txtEmail_C;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label lbl_ACC;
        private System.Windows.Forms.RadioButton rdoLineLeft;
        private System.Windows.Forms.RadioButton rdoLineRight;
        private System.Windows.Forms.RadioButton raButt_IN_3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel43;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.CheckBox checkB_Third_Person_Agree;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.MaskedTextBox mtxtSn;
        private System.Windows.Forms.TabPage tab_Auto;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txtAddress2_Auto;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.TextBox txtName_Auto;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.TextBox txtAddress_Auto;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.MaskedTextBox mtxtTel_Auto;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button butt_AddCode2;
        private System.Windows.Forms.MaskedTextBox mtxtZip_Auto;
        private System.Windows.Forms.Button butt_AddCodeT1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.TextBox txt_C_Card_Number;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel53;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.TextBox txt_C_Name_3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.ComboBox combo_C_Card_Month;
        private System.Windows.Forms.ComboBox combo_C_Card_Year;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.TextBox txt_C_Card_Code;
        private System.Windows.Forms.TextBox txt_C_Card;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.ComboBox cboRegDateA;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.ComboBox combo_Auto_Date;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.CheckBox check_Auto;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.TextBox txtRemark_A;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.TextBox txt_Auto_PR;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.TextBox txt_Auto_PR2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.ComboBox combo_C_Card_Per;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel72;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.TextBox txt_C_P_Number;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel62;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.TextBox txt_C_B_Number;
        private System.Windows.Forms.TextBox txt_Auto_Date;
        private System.Windows.Forms.DataGridView dGridView_Good;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.CheckBox checkB_AgreeMarketing;
        private System.Windows.Forms.CheckBox chk_Foreign_s;
        private System.Windows.Forms.CheckBox chk_Foreign_n;
        private System.Windows.Forms.TableLayoutPanel tlpNaCode;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.ComboBox combo_Se_2;
        private System.Windows.Forms.ComboBox combo_Se_Code_2;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TableLayoutPanel pnlDistrict_TH;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.ComboBox cbDistrict_TH;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TableLayoutPanel pnlProvince_TH;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.ComboBox cbProvince_TH;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TableLayoutPanel pnlZipCode_TH;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TableLayoutPanel pnlSubDistrict_TH;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.ComboBox cbSubDistrict_TH;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtZipCode_TH;
    }
}