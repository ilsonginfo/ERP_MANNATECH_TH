﻿namespace MLM_Program
{
    partial class frmClose_2_Select_03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel9 = new System.Windows.Forms.Panel();
            this.butt_Excel_Detail_Down_Sd = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_2 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Detail_2 = new System.Windows.Forms.Button();
            this.tab_Down_N = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_Down_N = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Detail_Down_N = new System.Windows.Forms.Button();
            this.tab_Down_S = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_Down_S = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Detail_Down_S = new System.Windows.Forms.Button();
            this.tab_Down_G = new System.Windows.Forms.TabPage();
            this.dGridView_Down_G = new System.Windows.Forms.DataGridView();
            this.panel37 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel50 = new System.Windows.Forms.TableLayoutPanel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.txt_ETC_S_D_1 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tableLayoutPanel51 = new System.Windows.Forms.TableLayoutPanel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.txt_ETC_S_D_2 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txt_Max_N_LineCnt = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel44 = new System.Windows.Forms.TableLayoutPanel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.butt_G70_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_7_2 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.tableLayoutPanel45 = new System.Windows.Forms.TableLayoutPanel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.butt_G90_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_9_2 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.tableLayoutPanel46 = new System.Windows.Forms.TableLayoutPanel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.butt_G110_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_11_2 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.tableLayoutPanel47 = new System.Windows.Forms.TableLayoutPanel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.butt_G80_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_8_2 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.tableLayoutPanel48 = new System.Windows.Forms.TableLayoutPanel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.butt_G100_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_10_2 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tableLayoutPanel49 = new System.Windows.Forms.TableLayoutPanel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.butt_G120_N2 = new System.Windows.Forms.Button();
            this.txt_ETC_N_12_2 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.butt_G70_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_7 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.butt_G90_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_9 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.butt_G110_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_11 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.butt_G80_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_8 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.butt_G100_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_10 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.tableLayoutPanel43 = new System.Windows.Forms.TableLayoutPanel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.butt_G120_N = new System.Windows.Forms.Button();
            this.txt_ETC_N_12 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.butt_G10_1 = new System.Windows.Forms.Button();
            this.txt_ETC6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.butt_G40_2 = new System.Windows.Forms.Button();
            this.txt_ETC9_2 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.butt_G30_1 = new System.Windows.Forms.Button();
            this.txt_ETC8 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.butt_G10_2 = new System.Windows.Forms.Button();
            this.txt_ETC6_2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.butt_G50_1 = new System.Windows.Forms.Button();
            this.txt_ETC10 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.butt_G60_2 = new System.Windows.Forms.Button();
            this.txt_ETC11_2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.butt_G20_1 = new System.Windows.Forms.Button();
            this.txt_ETC7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.butt_G20_2 = new System.Windows.Forms.Button();
            this.txt_ETC7_2 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.butt_G40_1 = new System.Windows.Forms.Button();
            this.txt_ETC9 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.butt_G50_2 = new System.Windows.Forms.Button();
            this.txt_ETC10_2 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.butt_G60_1 = new System.Windows.Forms.Button();
            this.txt_ETC11 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.butt_G30_2 = new System.Windows.Forms.Button();
            this.txt_ETC8_2 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_1 = new System.Windows.Forms.DataGridView();
            this.tab_save = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_3 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Detail_3 = new System.Windows.Forms.Button();
            this.tab_nom = new System.Windows.Forms.TabPage();
            this.dGridView_Detail_4 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Detail_4 = new System.Windows.Forms.Button();
            this.tab_etc = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txt_ETC12 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txt_ETC5 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txt_ETC4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txt_ETC3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txt_ETC2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txt_ETC1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tab_Detail_01 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_1 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_2 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_2 = new System.Windows.Forms.Button();
            this.tab_Save_D = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_3 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_3 = new System.Windows.Forms.Button();
            this.tab_Up = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_4 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_4 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_SP = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_SP = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_5 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_5 = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_8 = new System.Windows.Forms.DataGridView();
            this.butt_Excel_Pay_8 = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_Cap = new System.Windows.Forms.DataGridView();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.dGridView_Pay_14 = new System.Windows.Forms.DataGridView();
            this.grB_Search = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.mtxtMbid2 = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioB_P = new System.Windows.Forms.RadioButton();
            this.radioB_PM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_PM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_PM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_P_7 = new System.Windows.Forms.RadioButton();
            this.radioB_P_1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioB_S = new System.Windows.Forms.RadioButton();
            this.radioB_SM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_S_7 = new System.Windows.Forms.RadioButton();
            this.radioB_S_1 = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioB_R = new System.Windows.Forms.RadioButton();
            this.radioB_RM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_R_7 = new System.Windows.Forms.RadioButton();
            this.radioB_R_1 = new System.Windows.Forms.RadioButton();
            this.button_base = new System.Windows.Forms.Button();
            this.butt_Exp = new System.Windows.Forms.Button();
            this.txtToEndDate_Code = new System.Windows.Forms.TextBox();
            this.txtToEndDate = new System.Windows.Forms.TextBox();
            this.combo_Grade_Code = new System.Windows.Forms.ComboBox();
            this.combo_Grade = new System.Windows.Forms.ComboBox();
            this.radio_PayTF2 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF1 = new System.Windows.Forms.RadioButton();
            this.txtCenter_Code = new System.Windows.Forms.TextBox();
            this.txtCenter = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.DTP_PayDate1 = new System.Windows.Forms.DateTimePicker();
            this.DTP_PayDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_FromDate1 = new System.Windows.Forms.DateTimePicker();
            this.DTP_FromDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_ToDate1 = new System.Windows.Forms.DateTimePicker();
            this.DTP_ToDate2 = new System.Windows.Forms.DateTimePicker();
            this.pn_Button = new System.Windows.Forms.Panel();
            this.butt_Excel = new System.Windows.Forms.Button();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Select = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.combo_W_Code_2 = new System.Windows.Forms.ComboBox();
            this.combo_W_Code_1 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel52 = new System.Windows.Forms.TableLayoutPanel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.combo_W_2 = new System.Windows.Forms.ComboBox();
            this.combo_W_1 = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.radioB_Su_Not = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioB_Su = new System.Windows.Forms.RadioButton();
            this.label29 = new System.Windows.Forms.Label();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.radioB_Leave = new System.Windows.Forms.RadioButton();
            this.radioB_Leave_Not = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.chk_Leave_Only = new System.Windows.Forms.CheckBox();
            this.chk_Leave = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.checkB_150 = new System.Windows.Forms.CheckBox();
            this.checkB_140 = new System.Windows.Forms.CheckBox();
            this.checkB_10 = new System.Windows.Forms.CheckBox();
            this.checkB_110 = new System.Windows.Forms.CheckBox();
            this.checkB_100 = new System.Windows.Forms.CheckBox();
            this.checkB_130 = new System.Windows.Forms.CheckBox();
            this.checkB_90 = new System.Windows.Forms.CheckBox();
            this.checkB_120 = new System.Windows.Forms.CheckBox();
            this.checkB_80 = new System.Windows.Forms.CheckBox();
            this.checkB_70 = new System.Windows.Forms.CheckBox();
            this.checkB_60 = new System.Windows.Forms.CheckBox();
            this.checkB_50 = new System.Windows.Forms.CheckBox();
            this.checkB_40 = new System.Windows.Forms.CheckBox();
            this.checkB_30 = new System.Windows.Forms.CheckBox();
            this.checkB_Up = new System.Windows.Forms.RadioButton();
            this.combo_Grade2_Code = new System.Windows.Forms.ComboBox();
            this.combo_Grade2 = new System.Windows.Forms.ComboBox();
            this.checkB_Up_60 = new System.Windows.Forms.CheckBox();
            this.checkB_20 = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txt_Us_num = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.mtxtPayDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtPayDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.radio_PayTF_Re_D_2 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_Re_D_1 = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_ALL = new System.Windows.Forms.RadioButton();
            this.radio_PayTF_Not = new System.Windows.Forms.RadioButton();
            this.radio_PayTF3 = new System.Windows.Forms.RadioButton();
            this.label34 = new System.Windows.Forms.Label();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.mtxtToDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtToDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.mtxtFromDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtFromDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dGridCtrl_Base = new DevExpress.XtraGrid.GridControl();
            this.dGridView_Base = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.dGridView_Base_Sum = new System.Windows.Forms.DataGridView();
            this.panel44 = new System.Windows.Forms.Panel();
            this.radioB_Mi_No = new System.Windows.Forms.RadioButton();
            this.radioB_Mi = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.prB = new System.Windows.Forms.ProgressBar();
            this.label32 = new System.Windows.Forms.Label();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.mtxtSellDate = new System.Windows.Forms.MaskedTextBox();
            this.DTP_SellDate = new System.Windows.Forms.DateTimePicker();
            this.label33 = new System.Windows.Forms.Label();
            this.butt_Save = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.chk_Total = new System.Windows.Forms.CheckBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panel9.SuspendLayout();
            this.butt_Excel_Detail_Down_Sd.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_2)).BeginInit();
            this.tab_Down_N.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_Down_N)).BeginInit();
            this.tab_Down_S.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_Down_S)).BeginInit();
            this.tab_Down_G.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Down_G)).BeginInit();
            this.panel37.SuspendLayout();
            this.tableLayoutPanel50.SuspendLayout();
            this.panel58.SuspendLayout();
            this.tableLayoutPanel51.SuspendLayout();
            this.panel59.SuspendLayout();
            this.tableLayoutPanel44.SuspendLayout();
            this.panel52.SuspendLayout();
            this.tableLayoutPanel45.SuspendLayout();
            this.panel53.SuspendLayout();
            this.tableLayoutPanel46.SuspendLayout();
            this.panel54.SuspendLayout();
            this.tableLayoutPanel47.SuspendLayout();
            this.panel55.SuspendLayout();
            this.tableLayoutPanel48.SuspendLayout();
            this.panel56.SuspendLayout();
            this.tableLayoutPanel49.SuspendLayout();
            this.panel57.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.panel46.SuspendLayout();
            this.tableLayoutPanel39.SuspendLayout();
            this.panel47.SuspendLayout();
            this.tableLayoutPanel40.SuspendLayout();
            this.panel48.SuspendLayout();
            this.tableLayoutPanel41.SuspendLayout();
            this.panel49.SuspendLayout();
            this.tableLayoutPanel42.SuspendLayout();
            this.panel50.SuspendLayout();
            this.tableLayoutPanel43.SuspendLayout();
            this.panel51.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.panel41.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.panel23.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.panel32.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel21.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.panel36.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.panel18.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.panel38.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.panel39.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel20.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.panel40.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_1)).BeginInit();
            this.tab_save.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_3)).BeginInit();
            this.tab_nom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_4)).BeginInit();
            this.tab_etc.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.panel24.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tab_Detail_01.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_2)).BeginInit();
            this.tab_Save_D.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_3)).BeginInit();
            this.tab_Up.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_4)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_SP)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_5)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_8)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_Cap)).BeginInit();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_14)).BeginInit();
            this.grB_Search.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pn_Button.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel52.SuspendLayout();
            this.panel60.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.panel43.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.panel42.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.panel31.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.panel27.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.panel28.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.panel29.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.panel33.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridCtrl_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sum)).BeginInit();
            this.panel44.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.panel45.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.butt_Excel_Detail_Down_Sd);
            this.panel9.Controls.Add(this.tab_Detail_01);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(0, 541);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1650, 218);
            this.panel9.TabIndex = 12;
            // 
            // butt_Excel_Detail_Down_Sd
            // 
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tabPage4);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_Down_N);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_Down_S);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_Down_G);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tabPage3);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_save);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_nom);
            this.butt_Excel_Detail_Down_Sd.Controls.Add(this.tab_etc);
            this.butt_Excel_Detail_Down_Sd.Dock = System.Windows.Forms.DockStyle.Fill;
            this.butt_Excel_Detail_Down_Sd.Location = new System.Drawing.Point(752, 0);
            this.butt_Excel_Detail_Down_Sd.Name = "butt_Excel_Detail_Down_Sd";
            this.butt_Excel_Detail_Down_Sd.SelectedIndex = 0;
            this.butt_Excel_Detail_Down_Sd.Size = new System.Drawing.Size(898, 218);
            this.butt_Excel_Detail_Down_Sd.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dGridView_Detail_2);
            this.tabPage4.Controls.Add(this.butt_Excel_Detail_2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(890, 192);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "후원보너스관련_하선";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_2
            // 
            this.dGridView_Detail_2.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dGridView_Detail_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dGridView_Detail_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_2.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_2.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Detail_2.Name = "dGridView_Detail_2";
            this.dGridView_Detail_2.RowTemplate.Height = 23;
            this.dGridView_Detail_2.Size = new System.Drawing.Size(884, 160);
            this.dGridView_Detail_2.TabIndex = 14;
            this.dGridView_Detail_2.DoubleClick += new System.EventHandler(this.dGridView_Base_DoubleClick);
            // 
            // butt_Excel_Detail_2
            // 
            this.butt_Excel_Detail_2.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Detail_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Detail_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Detail_2.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Detail_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Detail_2.Name = "butt_Excel_Detail_2";
            this.butt_Excel_Detail_2.Size = new System.Drawing.Size(884, 26);
            this.butt_Excel_Detail_2.TabIndex = 149;
            this.butt_Excel_Detail_2.TabStop = false;
            this.butt_Excel_Detail_2.Text = "Excel";
            this.butt_Excel_Detail_2.UseVisualStyleBackColor = false;
            this.butt_Excel_Detail_2.Click += new System.EventHandler(this.butt_Excel_Detail_2_Click);
            // 
            // tab_Down_N
            // 
            this.tab_Down_N.Controls.Add(this.dGridView_Detail_Down_N);
            this.tab_Down_N.Controls.Add(this.butt_Excel_Detail_Down_N);
            this.tab_Down_N.Location = new System.Drawing.Point(4, 22);
            this.tab_Down_N.Name = "tab_Down_N";
            this.tab_Down_N.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Down_N.Size = new System.Drawing.Size(890, 192);
            this.tab_Down_N.TabIndex = 6;
            this.tab_Down_N.Text = "직급관련_추천하선";
            this.tab_Down_N.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_Down_N
            // 
            this.dGridView_Detail_Down_N.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_Down_N.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_Down_N.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGridView_Detail_Down_N.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_Down_N.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGridView_Detail_Down_N.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_Down_N.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_Down_N.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Detail_Down_N.Name = "dGridView_Detail_Down_N";
            this.dGridView_Detail_Down_N.RowTemplate.Height = 23;
            this.dGridView_Detail_Down_N.Size = new System.Drawing.Size(884, 160);
            this.dGridView_Detail_Down_N.TabIndex = 15;
            // 
            // butt_Excel_Detail_Down_N
            // 
            this.butt_Excel_Detail_Down_N.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Detail_Down_N.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Detail_Down_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Detail_Down_N.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Detail_Down_N.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Detail_Down_N.Name = "butt_Excel_Detail_Down_N";
            this.butt_Excel_Detail_Down_N.Size = new System.Drawing.Size(884, 26);
            this.butt_Excel_Detail_Down_N.TabIndex = 149;
            this.butt_Excel_Detail_Down_N.TabStop = false;
            this.butt_Excel_Detail_Down_N.Text = "Excel";
            this.butt_Excel_Detail_Down_N.UseVisualStyleBackColor = false;
            this.butt_Excel_Detail_Down_N.Click += new System.EventHandler(this.butt_Excel_Detail_Down_N_Click);
            // 
            // tab_Down_S
            // 
            this.tab_Down_S.Controls.Add(this.dGridView_Detail_Down_S);
            this.tab_Down_S.Controls.Add(this.butt_Excel_Detail_Down_S);
            this.tab_Down_S.Location = new System.Drawing.Point(4, 22);
            this.tab_Down_S.Name = "tab_Down_S";
            this.tab_Down_S.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Down_S.Size = new System.Drawing.Size(890, 192);
            this.tab_Down_S.TabIndex = 7;
            this.tab_Down_S.Text = "직급관련_후원하선";
            this.tab_Down_S.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_Down_S
            // 
            this.dGridView_Detail_Down_S.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_Down_S.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_Down_S.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dGridView_Detail_Down_S.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_Down_S.DefaultCellStyle = dataGridViewCellStyle6;
            this.dGridView_Detail_Down_S.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_Down_S.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_Down_S.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Detail_Down_S.Name = "dGridView_Detail_Down_S";
            this.dGridView_Detail_Down_S.RowTemplate.Height = 23;
            this.dGridView_Detail_Down_S.Size = new System.Drawing.Size(884, 160);
            this.dGridView_Detail_Down_S.TabIndex = 16;
            // 
            // butt_Excel_Detail_Down_S
            // 
            this.butt_Excel_Detail_Down_S.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Detail_Down_S.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Detail_Down_S.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Detail_Down_S.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Detail_Down_S.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Detail_Down_S.Name = "butt_Excel_Detail_Down_S";
            this.butt_Excel_Detail_Down_S.Size = new System.Drawing.Size(884, 26);
            this.butt_Excel_Detail_Down_S.TabIndex = 149;
            this.butt_Excel_Detail_Down_S.TabStop = false;
            this.butt_Excel_Detail_Down_S.Text = "Excel";
            this.butt_Excel_Detail_Down_S.UseVisualStyleBackColor = false;
            this.butt_Excel_Detail_Down_S.Click += new System.EventHandler(this.butt_Excel_Detail_Down_S_Click);
            // 
            // tab_Down_G
            // 
            this.tab_Down_G.BackColor = System.Drawing.SystemColors.Control;
            this.tab_Down_G.Controls.Add(this.dGridView_Down_G);
            this.tab_Down_G.Controls.Add(this.panel37);
            this.tab_Down_G.Location = new System.Drawing.Point(4, 22);
            this.tab_Down_G.Name = "tab_Down_G";
            this.tab_Down_G.Size = new System.Drawing.Size(890, 192);
            this.tab_Down_G.TabIndex = 5;
            this.tab_Down_G.Text = "하선_직급자수(이상)";
            // 
            // dGridView_Down_G
            // 
            this.dGridView_Down_G.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Down_G.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Down_G.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dGridView_Down_G.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Down_G.DefaultCellStyle = dataGridViewCellStyle8;
            this.dGridView_Down_G.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Down_G.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Down_G.Location = new System.Drawing.Point(417, 0);
            this.dGridView_Down_G.Name = "dGridView_Down_G";
            this.dGridView_Down_G.RowTemplate.Height = 23;
            this.dGridView_Down_G.Size = new System.Drawing.Size(473, 192);
            this.dGridView_Down_G.TabIndex = 288;
            // 
            // panel37
            // 
            this.panel37.AutoScroll = true;
            this.panel37.Controls.Add(this.tableLayoutPanel50);
            this.panel37.Controls.Add(this.tableLayoutPanel51);
            this.panel37.Controls.Add(this.txt_Max_N_LineCnt);
            this.panel37.Controls.Add(this.tableLayoutPanel44);
            this.panel37.Controls.Add(this.tableLayoutPanel45);
            this.panel37.Controls.Add(this.tableLayoutPanel46);
            this.panel37.Controls.Add(this.tableLayoutPanel47);
            this.panel37.Controls.Add(this.tableLayoutPanel48);
            this.panel37.Controls.Add(this.tableLayoutPanel49);
            this.panel37.Controls.Add(this.tableLayoutPanel35);
            this.panel37.Controls.Add(this.tableLayoutPanel39);
            this.panel37.Controls.Add(this.tableLayoutPanel40);
            this.panel37.Controls.Add(this.tableLayoutPanel41);
            this.panel37.Controls.Add(this.tableLayoutPanel42);
            this.panel37.Controls.Add(this.tableLayoutPanel43);
            this.panel37.Controls.Add(this.tableLayoutPanel12);
            this.panel37.Controls.Add(this.tableLayoutPanel27);
            this.panel37.Controls.Add(this.tableLayoutPanel17);
            this.panel37.Controls.Add(this.tableLayoutPanel21);
            this.panel37.Controls.Add(this.tableLayoutPanel3);
            this.panel37.Controls.Add(this.tableLayoutPanel22);
            this.panel37.Controls.Add(this.tableLayoutPanel11);
            this.panel37.Controls.Add(this.tableLayoutPanel24);
            this.panel37.Controls.Add(this.tableLayoutPanel15);
            this.panel37.Controls.Add(this.tableLayoutPanel25);
            this.panel37.Controls.Add(this.tableLayoutPanel13);
            this.panel37.Controls.Add(this.tableLayoutPanel26);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel37.Location = new System.Drawing.Point(0, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(417, 192);
            this.panel37.TabIndex = 287;
            // 
            // tableLayoutPanel50
            // 
            this.tableLayoutPanel50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel50.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel50.ColumnCount = 2;
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel50.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel50.Controls.Add(this.panel58, 1, 0);
            this.tableLayoutPanel50.Controls.Add(this.label56, 0, 0);
            this.tableLayoutPanel50.Location = new System.Drawing.Point(1, -1);
            this.tableLayoutPanel50.Name = "tableLayoutPanel50";
            this.tableLayoutPanel50.RowCount = 1;
            this.tableLayoutPanel50.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel50.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel50.TabIndex = 300;
            // 
            // panel58
            // 
            this.panel58.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel58.BackColor = System.Drawing.Color.White;
            this.panel58.Controls.Add(this.txt_ETC_S_D_1);
            this.panel58.Location = new System.Drawing.Point(78, 4);
            this.panel58.Margin = new System.Windows.Forms.Padding(2);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(117, 28);
            this.panel58.TabIndex = 15;
            // 
            // txt_ETC_S_D_1
            // 
            this.txt_ETC_S_D_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_S_D_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_S_D_1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_S_D_1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_S_D_1.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_S_D_1.MaxLength = 30;
            this.txt_ETC_S_D_1.Name = "txt_ETC_S_D_1";
            this.txt_ETC_S_D_1.ReadOnly = true;
            this.txt_ETC_S_D_1.Size = new System.Drawing.Size(112, 22);
            this.txt_ETC_S_D_1.TabIndex = 190;
            this.txt_ETC_S_D_1.TabStop = false;
            this.txt_ETC_S_D_1.Tag = "";
            this.txt_ETC_S_D_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label56
            // 
            this.label56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(2, 2);
            this.label56.Margin = new System.Windows.Forms.Padding(0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(72, 32);
            this.label56.TabIndex = 0;
            this.label56.Text = "후원_1";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel51
            // 
            this.tableLayoutPanel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel51.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel51.ColumnCount = 2;
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel51.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.Controls.Add(this.panel59, 1, 0);
            this.tableLayoutPanel51.Controls.Add(this.label57, 0, 0);
            this.tableLayoutPanel51.Location = new System.Drawing.Point(201, -1);
            this.tableLayoutPanel51.Name = "tableLayoutPanel51";
            this.tableLayoutPanel51.RowCount = 1;
            this.tableLayoutPanel51.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel51.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel51.TabIndex = 301;
            // 
            // panel59
            // 
            this.panel59.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel59.BackColor = System.Drawing.Color.White;
            this.panel59.Controls.Add(this.txt_ETC_S_D_2);
            this.panel59.Location = new System.Drawing.Point(78, 4);
            this.panel59.Margin = new System.Windows.Forms.Padding(2);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(117, 28);
            this.panel59.TabIndex = 15;
            // 
            // txt_ETC_S_D_2
            // 
            this.txt_ETC_S_D_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_S_D_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_S_D_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_S_D_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_S_D_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_S_D_2.MaxLength = 30;
            this.txt_ETC_S_D_2.Name = "txt_ETC_S_D_2";
            this.txt_ETC_S_D_2.ReadOnly = true;
            this.txt_ETC_S_D_2.Size = new System.Drawing.Size(112, 22);
            this.txt_ETC_S_D_2.TabIndex = 190;
            this.txt_ETC_S_D_2.TabStop = false;
            this.txt_ETC_S_D_2.Tag = "";
            this.txt_ETC_S_D_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label57
            // 
            this.label57.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label57.ForeColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(2, 2);
            this.label57.Margin = new System.Windows.Forms.Padding(0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(72, 32);
            this.label57.TabIndex = 0;
            this.label57.Text = "후원_2";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_Max_N_LineCnt
            // 
            this.txt_Max_N_LineCnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Max_N_LineCnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Max_N_LineCnt.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Max_N_LineCnt.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_Max_N_LineCnt.Location = new System.Drawing.Point(406, 16);
            this.txt_Max_N_LineCnt.MaxLength = 30;
            this.txt_Max_N_LineCnt.Name = "txt_Max_N_LineCnt";
            this.txt_Max_N_LineCnt.ReadOnly = true;
            this.txt_Max_N_LineCnt.Size = new System.Drawing.Size(57, 22);
            this.txt_Max_N_LineCnt.TabIndex = 299;
            this.txt_Max_N_LineCnt.TabStop = false;
            this.txt_Max_N_LineCnt.Tag = "";
            this.txt_Max_N_LineCnt.Visible = false;
            // 
            // tableLayoutPanel44
            // 
            this.tableLayoutPanel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel44.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel44.ColumnCount = 2;
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel44.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.Controls.Add(this.panel52, 1, 0);
            this.tableLayoutPanel44.Controls.Add(this.label50, 0, 0);
            this.tableLayoutPanel44.Location = new System.Drawing.Point(201, 251);
            this.tableLayoutPanel44.Name = "tableLayoutPanel44";
            this.tableLayoutPanel44.RowCount = 1;
            this.tableLayoutPanel44.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel44.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel44.TabIndex = 293;
            // 
            // panel52
            // 
            this.panel52.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel52.BackColor = System.Drawing.Color.White;
            this.panel52.Controls.Add(this.butt_G70_N2);
            this.panel52.Controls.Add(this.txt_ETC_N_7_2);
            this.panel52.Location = new System.Drawing.Point(78, 4);
            this.panel52.Margin = new System.Windows.Forms.Padding(2);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(117, 28);
            this.panel52.TabIndex = 15;
            // 
            // butt_G70_N2
            // 
            this.butt_G70_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G70_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G70_N2.Name = "butt_G70_N2";
            this.butt_G70_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G70_N2.TabIndex = 191;
            this.butt_G70_N2.TabStop = false;
            this.butt_G70_N2.Text = "조회";
            this.butt_G70_N2.UseVisualStyleBackColor = true;
            this.butt_G70_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_7_2
            // 
            this.txt_ETC_N_7_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_7_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_7_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_7_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_7_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_7_2.MaxLength = 30;
            this.txt_ETC_N_7_2.Name = "txt_ETC_N_7_2";
            this.txt_ETC_N_7_2.ReadOnly = true;
            this.txt_ETC_N_7_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_7_2.TabIndex = 190;
            this.txt_ETC_N_7_2.TabStop = false;
            this.txt_ETC_N_7_2.Tag = "";
            // 
            // label50
            // 
            this.label50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(2, 2);
            this.label50.Margin = new System.Windows.Forms.Padding(0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(72, 32);
            this.label50.TabIndex = 0;
            this.label50.Text = "트리플윙_우";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel45
            // 
            this.tableLayoutPanel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel45.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel45.ColumnCount = 2;
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel45.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.Controls.Add(this.panel53, 1, 0);
            this.tableLayoutPanel45.Controls.Add(this.label51, 0, 0);
            this.tableLayoutPanel45.Location = new System.Drawing.Point(201, 323);
            this.tableLayoutPanel45.Name = "tableLayoutPanel45";
            this.tableLayoutPanel45.RowCount = 1;
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel45.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel45.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel45.TabIndex = 295;
            // 
            // panel53
            // 
            this.panel53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel53.BackColor = System.Drawing.Color.White;
            this.panel53.Controls.Add(this.butt_G90_N2);
            this.panel53.Controls.Add(this.txt_ETC_N_9_2);
            this.panel53.Location = new System.Drawing.Point(78, 4);
            this.panel53.Margin = new System.Windows.Forms.Padding(2);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(117, 28);
            this.panel53.TabIndex = 15;
            // 
            // butt_G90_N2
            // 
            this.butt_G90_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G90_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G90_N2.Name = "butt_G90_N2";
            this.butt_G90_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G90_N2.TabIndex = 192;
            this.butt_G90_N2.TabStop = false;
            this.butt_G90_N2.Text = "조회";
            this.butt_G90_N2.UseVisualStyleBackColor = true;
            this.butt_G90_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_9_2
            // 
            this.txt_ETC_N_9_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_9_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_9_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_9_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_9_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_9_2.MaxLength = 30;
            this.txt_ETC_N_9_2.Name = "txt_ETC_N_9_2";
            this.txt_ETC_N_9_2.ReadOnly = true;
            this.txt_ETC_N_9_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_9_2.TabIndex = 190;
            this.txt_ETC_N_9_2.TabStop = false;
            this.txt_ETC_N_9_2.Tag = "";
            // 
            // label51
            // 
            this.label51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(2, 2);
            this.label51.Margin = new System.Windows.Forms.Padding(0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(72, 32);
            this.label51.TabIndex = 0;
            this.label51.Text = "스타_우";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel46
            // 
            this.tableLayoutPanel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel46.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel46.ColumnCount = 2;
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel46.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.Controls.Add(this.panel54, 1, 0);
            this.tableLayoutPanel46.Controls.Add(this.label52, 0, 0);
            this.tableLayoutPanel46.Location = new System.Drawing.Point(610, 122);
            this.tableLayoutPanel46.Name = "tableLayoutPanel46";
            this.tableLayoutPanel46.RowCount = 1;
            this.tableLayoutPanel46.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel46.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel46.TabIndex = 297;
            this.tableLayoutPanel46.Visible = false;
            // 
            // panel54
            // 
            this.panel54.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel54.BackColor = System.Drawing.Color.White;
            this.panel54.Controls.Add(this.butt_G110_N2);
            this.panel54.Controls.Add(this.txt_ETC_N_11_2);
            this.panel54.Location = new System.Drawing.Point(78, 4);
            this.panel54.Margin = new System.Windows.Forms.Padding(2);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(117, 28);
            this.panel54.TabIndex = 15;
            // 
            // butt_G110_N2
            // 
            this.butt_G110_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G110_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G110_N2.Name = "butt_G110_N2";
            this.butt_G110_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G110_N2.TabIndex = 192;
            this.butt_G110_N2.TabStop = false;
            this.butt_G110_N2.Text = "조회";
            this.butt_G110_N2.UseVisualStyleBackColor = true;
            this.butt_G110_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_11_2
            // 
            this.txt_ETC_N_11_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_11_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_11_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_11_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_11_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_11_2.MaxLength = 30;
            this.txt_ETC_N_11_2.Name = "txt_ETC_N_11_2";
            this.txt_ETC_N_11_2.ReadOnly = true;
            this.txt_ETC_N_11_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_11_2.TabIndex = 190;
            this.txt_ETC_N_11_2.TabStop = false;
            this.txt_ETC_N_11_2.Tag = "";
            // 
            // label52
            // 
            this.label52.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(2, 2);
            this.label52.Margin = new System.Windows.Forms.Padding(0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(72, 32);
            this.label52.TabIndex = 0;
            this.label52.Text = "CR이상_소";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel47
            // 
            this.tableLayoutPanel47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel47.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel47.ColumnCount = 2;
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel47.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.Controls.Add(this.panel55, 1, 0);
            this.tableLayoutPanel47.Controls.Add(this.label53, 0, 0);
            this.tableLayoutPanel47.Location = new System.Drawing.Point(201, 287);
            this.tableLayoutPanel47.Name = "tableLayoutPanel47";
            this.tableLayoutPanel47.RowCount = 1;
            this.tableLayoutPanel47.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel47.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel47.TabIndex = 294;
            // 
            // panel55
            // 
            this.panel55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel55.BackColor = System.Drawing.Color.White;
            this.panel55.Controls.Add(this.butt_G80_N2);
            this.panel55.Controls.Add(this.txt_ETC_N_8_2);
            this.panel55.Location = new System.Drawing.Point(78, 4);
            this.panel55.Margin = new System.Windows.Forms.Padding(2);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(117, 28);
            this.panel55.TabIndex = 15;
            // 
            // butt_G80_N2
            // 
            this.butt_G80_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G80_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G80_N2.Name = "butt_G80_N2";
            this.butt_G80_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G80_N2.TabIndex = 192;
            this.butt_G80_N2.TabStop = false;
            this.butt_G80_N2.Text = "조회";
            this.butt_G80_N2.UseVisualStyleBackColor = true;
            this.butt_G80_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_8_2
            // 
            this.txt_ETC_N_8_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_8_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_8_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_8_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_8_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_8_2.MaxLength = 30;
            this.txt_ETC_N_8_2.Name = "txt_ETC_N_8_2";
            this.txt_ETC_N_8_2.ReadOnly = true;
            this.txt_ETC_N_8_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_8_2.TabIndex = 190;
            this.txt_ETC_N_8_2.TabStop = false;
            this.txt_ETC_N_8_2.Tag = "";
            // 
            // label53
            // 
            this.label53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(2, 2);
            this.label53.Margin = new System.Windows.Forms.Padding(0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(72, 32);
            this.label53.TabIndex = 0;
            this.label53.Text = "이글윙_우";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel48
            // 
            this.tableLayoutPanel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel48.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel48.ColumnCount = 2;
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel48.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel48.Controls.Add(this.panel56, 1, 0);
            this.tableLayoutPanel48.Controls.Add(this.label54, 0, 0);
            this.tableLayoutPanel48.Location = new System.Drawing.Point(610, 86);
            this.tableLayoutPanel48.Name = "tableLayoutPanel48";
            this.tableLayoutPanel48.RowCount = 1;
            this.tableLayoutPanel48.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel48.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel48.TabIndex = 296;
            this.tableLayoutPanel48.Visible = false;
            // 
            // panel56
            // 
            this.panel56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel56.BackColor = System.Drawing.Color.White;
            this.panel56.Controls.Add(this.butt_G100_N2);
            this.panel56.Controls.Add(this.txt_ETC_N_10_2);
            this.panel56.Location = new System.Drawing.Point(78, 4);
            this.panel56.Margin = new System.Windows.Forms.Padding(2);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(117, 28);
            this.panel56.TabIndex = 15;
            // 
            // butt_G100_N2
            // 
            this.butt_G100_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G100_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G100_N2.Name = "butt_G100_N2";
            this.butt_G100_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G100_N2.TabIndex = 192;
            this.butt_G100_N2.TabStop = false;
            this.butt_G100_N2.Text = "조회";
            this.butt_G100_N2.UseVisualStyleBackColor = true;
            this.butt_G100_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_10_2
            // 
            this.txt_ETC_N_10_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_10_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_10_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_10_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_10_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_10_2.MaxLength = 30;
            this.txt_ETC_N_10_2.Name = "txt_ETC_N_10_2";
            this.txt_ETC_N_10_2.ReadOnly = true;
            this.txt_ETC_N_10_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_10_2.TabIndex = 190;
            this.txt_ETC_N_10_2.TabStop = false;
            this.txt_ETC_N_10_2.Tag = "";
            // 
            // label54
            // 
            this.label54.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(2, 2);
            this.label54.Margin = new System.Windows.Forms.Padding(0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(72, 32);
            this.label54.TabIndex = 0;
            this.label54.Text = "TDM이상_소";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel49
            // 
            this.tableLayoutPanel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel49.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel49.ColumnCount = 2;
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel49.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.Controls.Add(this.panel57, 1, 0);
            this.tableLayoutPanel49.Controls.Add(this.label55, 0, 0);
            this.tableLayoutPanel49.Location = new System.Drawing.Point(610, 158);
            this.tableLayoutPanel49.Name = "tableLayoutPanel49";
            this.tableLayoutPanel49.RowCount = 1;
            this.tableLayoutPanel49.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel49.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel49.TabIndex = 298;
            this.tableLayoutPanel49.Visible = false;
            // 
            // panel57
            // 
            this.panel57.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel57.BackColor = System.Drawing.Color.White;
            this.panel57.Controls.Add(this.butt_G120_N2);
            this.panel57.Controls.Add(this.txt_ETC_N_12_2);
            this.panel57.Location = new System.Drawing.Point(78, 4);
            this.panel57.Margin = new System.Windows.Forms.Padding(2);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(117, 28);
            this.panel57.TabIndex = 15;
            // 
            // butt_G120_N2
            // 
            this.butt_G120_N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G120_N2.Location = new System.Drawing.Point(61, 3);
            this.butt_G120_N2.Name = "butt_G120_N2";
            this.butt_G120_N2.Size = new System.Drawing.Size(53, 22);
            this.butt_G120_N2.TabIndex = 192;
            this.butt_G120_N2.TabStop = false;
            this.butt_G120_N2.Text = "조회";
            this.butt_G120_N2.UseVisualStyleBackColor = true;
            this.butt_G120_N2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_12_2
            // 
            this.txt_ETC_N_12_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_12_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_12_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_12_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_12_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_12_2.MaxLength = 30;
            this.txt_ETC_N_12_2.Name = "txt_ETC_N_12_2";
            this.txt_ETC_N_12_2.ReadOnly = true;
            this.txt_ETC_N_12_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_12_2.TabIndex = 190;
            this.txt_ETC_N_12_2.TabStop = false;
            this.txt_ETC_N_12_2.Tag = "";
            // 
            // label55
            // 
            this.label55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(2, 2);
            this.label55.Margin = new System.Windows.Forms.Padding(0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(72, 32);
            this.label55.TabIndex = 0;
            this.label55.Text = "RCR이상_소";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel35.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel35.ColumnCount = 2;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.panel46, 1, 0);
            this.tableLayoutPanel35.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel35.Location = new System.Drawing.Point(1, 251);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 1;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel35.TabIndex = 287;
            // 
            // panel46
            // 
            this.panel46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel46.BackColor = System.Drawing.Color.White;
            this.panel46.Controls.Add(this.butt_G70_N);
            this.panel46.Controls.Add(this.txt_ETC_N_7);
            this.panel46.Location = new System.Drawing.Point(78, 4);
            this.panel46.Margin = new System.Windows.Forms.Padding(2);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(117, 28);
            this.panel46.TabIndex = 15;
            // 
            // butt_G70_N
            // 
            this.butt_G70_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G70_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G70_N.Name = "butt_G70_N";
            this.butt_G70_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G70_N.TabIndex = 191;
            this.butt_G70_N.TabStop = false;
            this.butt_G70_N.Text = "조회";
            this.butt_G70_N.UseVisualStyleBackColor = true;
            this.butt_G70_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_7
            // 
            this.txt_ETC_N_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_7.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_7.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_7.MaxLength = 30;
            this.txt_ETC_N_7.Name = "txt_ETC_N_7";
            this.txt_ETC_N_7.ReadOnly = true;
            this.txt_ETC_N_7.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_7.TabIndex = 190;
            this.txt_ETC_N_7.TabStop = false;
            this.txt_ETC_N_7.Tag = "";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(2, 2);
            this.label40.Margin = new System.Windows.Forms.Padding(0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 32);
            this.label40.TabIndex = 0;
            this.label40.Text = "트리플윙_좌";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel39
            // 
            this.tableLayoutPanel39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel39.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel39.ColumnCount = 2;
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.Controls.Add(this.panel47, 1, 0);
            this.tableLayoutPanel39.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel39.Location = new System.Drawing.Point(1, 323);
            this.tableLayoutPanel39.Name = "tableLayoutPanel39";
            this.tableLayoutPanel39.RowCount = 1;
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel39.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel39.TabIndex = 289;
            // 
            // panel47
            // 
            this.panel47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel47.BackColor = System.Drawing.Color.White;
            this.panel47.Controls.Add(this.butt_G90_N);
            this.panel47.Controls.Add(this.txt_ETC_N_9);
            this.panel47.Location = new System.Drawing.Point(78, 4);
            this.panel47.Margin = new System.Windows.Forms.Padding(2);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(117, 28);
            this.panel47.TabIndex = 15;
            // 
            // butt_G90_N
            // 
            this.butt_G90_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G90_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G90_N.Name = "butt_G90_N";
            this.butt_G90_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G90_N.TabIndex = 192;
            this.butt_G90_N.TabStop = false;
            this.butt_G90_N.Text = "조회";
            this.butt_G90_N.UseVisualStyleBackColor = true;
            this.butt_G90_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_9
            // 
            this.txt_ETC_N_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_9.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_9.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_9.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_9.MaxLength = 30;
            this.txt_ETC_N_9.Name = "txt_ETC_N_9";
            this.txt_ETC_N_9.ReadOnly = true;
            this.txt_ETC_N_9.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_9.TabIndex = 190;
            this.txt_ETC_N_9.TabStop = false;
            this.txt_ETC_N_9.Tag = "";
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(2, 2);
            this.label41.Margin = new System.Windows.Forms.Padding(0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(72, 32);
            this.label41.TabIndex = 0;
            this.label41.Text = "스타_좌";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel40
            // 
            this.tableLayoutPanel40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel40.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel40.ColumnCount = 2;
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.Controls.Add(this.panel48, 1, 0);
            this.tableLayoutPanel40.Controls.Add(this.label46, 0, 0);
            this.tableLayoutPanel40.Location = new System.Drawing.Point(410, 122);
            this.tableLayoutPanel40.Name = "tableLayoutPanel40";
            this.tableLayoutPanel40.RowCount = 1;
            this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel40.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel40.TabIndex = 291;
            this.tableLayoutPanel40.Visible = false;
            // 
            // panel48
            // 
            this.panel48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel48.BackColor = System.Drawing.Color.White;
            this.panel48.Controls.Add(this.butt_G110_N);
            this.panel48.Controls.Add(this.txt_ETC_N_11);
            this.panel48.Location = new System.Drawing.Point(78, 4);
            this.panel48.Margin = new System.Windows.Forms.Padding(2);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(117, 28);
            this.panel48.TabIndex = 15;
            // 
            // butt_G110_N
            // 
            this.butt_G110_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G110_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G110_N.Name = "butt_G110_N";
            this.butt_G110_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G110_N.TabIndex = 192;
            this.butt_G110_N.TabStop = false;
            this.butt_G110_N.Text = "조회";
            this.butt_G110_N.UseVisualStyleBackColor = true;
            this.butt_G110_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_11
            // 
            this.txt_ETC_N_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_11.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_11.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_11.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_11.MaxLength = 30;
            this.txt_ETC_N_11.Name = "txt_ETC_N_11";
            this.txt_ETC_N_11.ReadOnly = true;
            this.txt_ETC_N_11.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_11.TabIndex = 190;
            this.txt_ETC_N_11.TabStop = false;
            this.txt_ETC_N_11.Tag = "";
            // 
            // label46
            // 
            this.label46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(2, 2);
            this.label46.Margin = new System.Windows.Forms.Padding(0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 32);
            this.label46.TabIndex = 0;
            this.label46.Text = "CR이상_대";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel41
            // 
            this.tableLayoutPanel41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel41.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel41.ColumnCount = 2;
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.Controls.Add(this.panel49, 1, 0);
            this.tableLayoutPanel41.Controls.Add(this.label47, 0, 0);
            this.tableLayoutPanel41.Location = new System.Drawing.Point(1, 287);
            this.tableLayoutPanel41.Name = "tableLayoutPanel41";
            this.tableLayoutPanel41.RowCount = 1;
            this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel41.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel41.TabIndex = 288;
            // 
            // panel49
            // 
            this.panel49.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel49.BackColor = System.Drawing.Color.White;
            this.panel49.Controls.Add(this.butt_G80_N);
            this.panel49.Controls.Add(this.txt_ETC_N_8);
            this.panel49.Location = new System.Drawing.Point(78, 4);
            this.panel49.Margin = new System.Windows.Forms.Padding(2);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(117, 28);
            this.panel49.TabIndex = 15;
            // 
            // butt_G80_N
            // 
            this.butt_G80_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G80_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G80_N.Name = "butt_G80_N";
            this.butt_G80_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G80_N.TabIndex = 192;
            this.butt_G80_N.TabStop = false;
            this.butt_G80_N.Text = "조회";
            this.butt_G80_N.UseVisualStyleBackColor = true;
            this.butt_G80_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_8
            // 
            this.txt_ETC_N_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_8.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_8.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_8.MaxLength = 30;
            this.txt_ETC_N_8.Name = "txt_ETC_N_8";
            this.txt_ETC_N_8.ReadOnly = true;
            this.txt_ETC_N_8.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_8.TabIndex = 190;
            this.txt_ETC_N_8.TabStop = false;
            this.txt_ETC_N_8.Tag = "";
            // 
            // label47
            // 
            this.label47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(2, 2);
            this.label47.Margin = new System.Windows.Forms.Padding(0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(72, 32);
            this.label47.TabIndex = 0;
            this.label47.Text = "이글윙_좌";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel42
            // 
            this.tableLayoutPanel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel42.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel42.ColumnCount = 2;
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.Controls.Add(this.panel50, 1, 0);
            this.tableLayoutPanel42.Controls.Add(this.label48, 0, 0);
            this.tableLayoutPanel42.Location = new System.Drawing.Point(410, 86);
            this.tableLayoutPanel42.Name = "tableLayoutPanel42";
            this.tableLayoutPanel42.RowCount = 1;
            this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel42.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel42.TabIndex = 290;
            this.tableLayoutPanel42.Visible = false;
            // 
            // panel50
            // 
            this.panel50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel50.BackColor = System.Drawing.Color.White;
            this.panel50.Controls.Add(this.butt_G100_N);
            this.panel50.Controls.Add(this.txt_ETC_N_10);
            this.panel50.Location = new System.Drawing.Point(78, 4);
            this.panel50.Margin = new System.Windows.Forms.Padding(2);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(117, 28);
            this.panel50.TabIndex = 15;
            // 
            // butt_G100_N
            // 
            this.butt_G100_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G100_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G100_N.Name = "butt_G100_N";
            this.butt_G100_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G100_N.TabIndex = 192;
            this.butt_G100_N.TabStop = false;
            this.butt_G100_N.Text = "조회";
            this.butt_G100_N.UseVisualStyleBackColor = true;
            this.butt_G100_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_10
            // 
            this.txt_ETC_N_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_10.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_10.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_10.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_10.MaxLength = 30;
            this.txt_ETC_N_10.Name = "txt_ETC_N_10";
            this.txt_ETC_N_10.ReadOnly = true;
            this.txt_ETC_N_10.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_10.TabIndex = 190;
            this.txt_ETC_N_10.TabStop = false;
            this.txt_ETC_N_10.Tag = "";
            // 
            // label48
            // 
            this.label48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(2, 2);
            this.label48.Margin = new System.Windows.Forms.Padding(0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(72, 32);
            this.label48.TabIndex = 0;
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel43
            // 
            this.tableLayoutPanel43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel43.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel43.ColumnCount = 2;
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel43.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.Controls.Add(this.panel51, 1, 0);
            this.tableLayoutPanel43.Controls.Add(this.label49, 0, 0);
            this.tableLayoutPanel43.Location = new System.Drawing.Point(410, 158);
            this.tableLayoutPanel43.Name = "tableLayoutPanel43";
            this.tableLayoutPanel43.RowCount = 1;
            this.tableLayoutPanel43.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel43.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel43.TabIndex = 292;
            this.tableLayoutPanel43.Visible = false;
            // 
            // panel51
            // 
            this.panel51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel51.BackColor = System.Drawing.Color.White;
            this.panel51.Controls.Add(this.butt_G120_N);
            this.panel51.Controls.Add(this.txt_ETC_N_12);
            this.panel51.Location = new System.Drawing.Point(78, 4);
            this.panel51.Margin = new System.Windows.Forms.Padding(2);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(117, 28);
            this.panel51.TabIndex = 15;
            // 
            // butt_G120_N
            // 
            this.butt_G120_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G120_N.Location = new System.Drawing.Point(61, 3);
            this.butt_G120_N.Name = "butt_G120_N";
            this.butt_G120_N.Size = new System.Drawing.Size(53, 22);
            this.butt_G120_N.TabIndex = 192;
            this.butt_G120_N.TabStop = false;
            this.butt_G120_N.Text = "조회";
            this.butt_G120_N.UseVisualStyleBackColor = true;
            this.butt_G120_N.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC_N_12
            // 
            this.txt_ETC_N_12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC_N_12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC_N_12.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC_N_12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC_N_12.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC_N_12.MaxLength = 30;
            this.txt_ETC_N_12.Name = "txt_ETC_N_12";
            this.txt_ETC_N_12.ReadOnly = true;
            this.txt_ETC_N_12.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC_N_12.TabIndex = 190;
            this.txt_ETC_N_12.TabStop = false;
            this.txt_ETC_N_12.Tag = "";
            // 
            // label49
            // 
            this.label49.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(2, 2);
            this.label49.Margin = new System.Windows.Forms.Padding(0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(72, 32);
            this.label49.TabIndex = 0;
            this.label49.Text = "RCR이상_대";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel12.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(1, 35);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel12.TabIndex = 274;
            // 
            // panel19
            // 
            this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.butt_G10_1);
            this.panel19.Controls.Add(this.txt_ETC6);
            this.panel19.Location = new System.Drawing.Point(78, 4);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(117, 28);
            this.panel19.TabIndex = 15;
            // 
            // butt_G10_1
            // 
            this.butt_G10_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G10_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G10_1.Name = "butt_G10_1";
            this.butt_G10_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G10_1.TabIndex = 191;
            this.butt_G10_1.TabStop = false;
            this.butt_G10_1.Text = "조회";
            this.butt_G10_1.UseVisualStyleBackColor = true;
            this.butt_G10_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC6
            // 
            this.txt_ETC6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC6.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC6.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC6.MaxLength = 30;
            this.txt_ETC6.Name = "txt_ETC6";
            this.txt_ETC6.ReadOnly = true;
            this.txt_ETC6.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC6.TabIndex = 190;
            this.txt_ETC6.TabStop = false;
            this.txt_ETC6.Tag = "";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 2);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 32);
            this.label11.TabIndex = 0;
            this.label11.Text = "싱글_좌";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel27.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel27.ColumnCount = 2;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.panel41, 1, 0);
            this.tableLayoutPanel27.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel27.Location = new System.Drawing.Point(201, 143);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 1;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel27.TabIndex = 286;
            // 
            // panel41
            // 
            this.panel41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Controls.Add(this.butt_G40_2);
            this.panel41.Controls.Add(this.txt_ETC9_2);
            this.panel41.Location = new System.Drawing.Point(78, 4);
            this.panel41.Margin = new System.Windows.Forms.Padding(2);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(117, 28);
            this.panel41.TabIndex = 15;
            // 
            // butt_G40_2
            // 
            this.butt_G40_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G40_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G40_2.Name = "butt_G40_2";
            this.butt_G40_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G40_2.TabIndex = 192;
            this.butt_G40_2.TabStop = false;
            this.butt_G40_2.Text = "조회";
            this.butt_G40_2.UseVisualStyleBackColor = true;
            this.butt_G40_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC9_2
            // 
            this.txt_ETC9_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC9_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC9_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC9_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC9_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC9_2.MaxLength = 30;
            this.txt_ETC9_2.Name = "txt_ETC9_2";
            this.txt_ETC9_2.ReadOnly = true;
            this.txt_ETC9_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC9_2.TabIndex = 190;
            this.txt_ETC9_2.TabStop = false;
            this.txt_ETC9_2.Tag = "";
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(2, 2);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 32);
            this.label28.TabIndex = 0;
            this.label28.Text = "풀_우";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel17.ColumnCount = 2;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.panel23, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(1, 107);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 1;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel17.TabIndex = 276;
            // 
            // panel23
            // 
            this.panel23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.butt_G30_1);
            this.panel23.Controls.Add(this.txt_ETC8);
            this.panel23.Location = new System.Drawing.Point(78, 4);
            this.panel23.Margin = new System.Windows.Forms.Padding(2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(117, 28);
            this.panel23.TabIndex = 15;
            // 
            // butt_G30_1
            // 
            this.butt_G30_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G30_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G30_1.Name = "butt_G30_1";
            this.butt_G30_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G30_1.TabIndex = 192;
            this.butt_G30_1.TabStop = false;
            this.butt_G30_1.Text = "조회";
            this.butt_G30_1.UseVisualStyleBackColor = true;
            this.butt_G30_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC8
            // 
            this.txt_ETC8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC8.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC8.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC8.MaxLength = 30;
            this.txt_ETC8.Name = "txt_ETC8";
            this.txt_ETC8.ReadOnly = true;
            this.txt_ETC8.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC8.TabIndex = 190;
            this.txt_ETC8.TabStop = false;
            this.txt_ETC8.Tag = "";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(2, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 32);
            this.label18.TabIndex = 0;
            this.label18.Text = "트리플_좌";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel21.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel21.ColumnCount = 2;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.panel32, 1, 0);
            this.tableLayoutPanel21.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel21.Location = new System.Drawing.Point(201, 35);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel21.TabIndex = 280;
            // 
            // panel32
            // 
            this.panel32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Controls.Add(this.butt_G10_2);
            this.panel32.Controls.Add(this.txt_ETC6_2);
            this.panel32.Location = new System.Drawing.Point(78, 4);
            this.panel32.Margin = new System.Windows.Forms.Padding(2);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(117, 28);
            this.panel32.TabIndex = 15;
            // 
            // butt_G10_2
            // 
            this.butt_G10_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G10_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G10_2.Name = "butt_G10_2";
            this.butt_G10_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G10_2.TabIndex = 192;
            this.butt_G10_2.TabStop = false;
            this.butt_G10_2.Text = "조회";
            this.butt_G10_2.UseVisualStyleBackColor = true;
            this.butt_G10_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC6_2
            // 
            this.txt_ETC6_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC6_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC6_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC6_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC6_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC6_2.MaxLength = 30;
            this.txt_ETC6_2.Name = "txt_ETC6_2";
            this.txt_ETC6_2.ReadOnly = true;
            this.txt_ETC6_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC6_2.TabIndex = 190;
            this.txt_ETC6_2.TabStop = false;
            this.txt_ETC6_2.Tag = "";
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(2, 2);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 32);
            this.label22.TabIndex = 0;
            this.label22.Text = "싱글_우";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel21, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(1, 179);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel3.TabIndex = 278;
            // 
            // panel21
            // 
            this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Controls.Add(this.butt_G50_1);
            this.panel21.Controls.Add(this.txt_ETC10);
            this.panel21.Location = new System.Drawing.Point(78, 4);
            this.panel21.Margin = new System.Windows.Forms.Padding(2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(117, 28);
            this.panel21.TabIndex = 15;
            // 
            // butt_G50_1
            // 
            this.butt_G50_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G50_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G50_1.Name = "butt_G50_1";
            this.butt_G50_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G50_1.TabIndex = 192;
            this.butt_G50_1.TabStop = false;
            this.butt_G50_1.Text = "조회";
            this.butt_G50_1.UseVisualStyleBackColor = true;
            this.butt_G50_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC10
            // 
            this.txt_ETC10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC10.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC10.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC10.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC10.MaxLength = 30;
            this.txt_ETC10.Name = "txt_ETC10";
            this.txt_ETC10.ReadOnly = true;
            this.txt_ETC10.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC10.TabIndex = 190;
            this.txt_ETC10.TabStop = false;
            this.txt_ETC10.Tag = "";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(2, 2);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 32);
            this.label15.TabIndex = 0;
            this.label15.Text = "싱글윙_좌";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel22.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel22.ColumnCount = 2;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.panel36, 1, 0);
            this.tableLayoutPanel22.Controls.Add(this.label23, 0, 0);
            this.tableLayoutPanel22.Location = new System.Drawing.Point(201, 215);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel22.TabIndex = 285;
            // 
            // panel36
            // 
            this.panel36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel36.BackColor = System.Drawing.Color.White;
            this.panel36.Controls.Add(this.butt_G60_2);
            this.panel36.Controls.Add(this.txt_ETC11_2);
            this.panel36.Location = new System.Drawing.Point(78, 4);
            this.panel36.Margin = new System.Windows.Forms.Padding(2);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(117, 28);
            this.panel36.TabIndex = 15;
            // 
            // butt_G60_2
            // 
            this.butt_G60_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G60_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G60_2.Name = "butt_G60_2";
            this.butt_G60_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G60_2.TabIndex = 192;
            this.butt_G60_2.TabStop = false;
            this.butt_G60_2.Text = "조회";
            this.butt_G60_2.UseVisualStyleBackColor = true;
            this.butt_G60_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC11_2
            // 
            this.txt_ETC11_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC11_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC11_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC11_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC11_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC11_2.MaxLength = 30;
            this.txt_ETC11_2.Name = "txt_ETC11_2";
            this.txt_ETC11_2.ReadOnly = true;
            this.txt_ETC11_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC11_2.TabIndex = 190;
            this.txt_ETC11_2.TabStop = false;
            this.txt_ETC11_2.Tag = "";
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(2, 2);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 32);
            this.label23.TabIndex = 0;
            this.label23.Text = "더블윙_우";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel11.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.panel18, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(1, 71);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel11.TabIndex = 275;
            // 
            // panel18
            // 
            this.panel18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Controls.Add(this.butt_G20_1);
            this.panel18.Controls.Add(this.txt_ETC7);
            this.panel18.Location = new System.Drawing.Point(78, 4);
            this.panel18.Margin = new System.Windows.Forms.Padding(2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(117, 28);
            this.panel18.TabIndex = 15;
            // 
            // butt_G20_1
            // 
            this.butt_G20_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G20_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G20_1.Name = "butt_G20_1";
            this.butt_G20_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G20_1.TabIndex = 192;
            this.butt_G20_1.TabStop = false;
            this.butt_G20_1.Text = "조회";
            this.butt_G20_1.UseVisualStyleBackColor = true;
            this.butt_G20_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC7
            // 
            this.txt_ETC7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC7.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC7.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC7.MaxLength = 30;
            this.txt_ETC7.Name = "txt_ETC7";
            this.txt_ETC7.ReadOnly = true;
            this.txt_ETC7.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC7.TabIndex = 190;
            this.txt_ETC7.TabStop = false;
            this.txt_ETC7.Tag = "";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 2);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 32);
            this.label10.TabIndex = 0;
            this.label10.Text = "더블_좌";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel24.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.panel38, 1, 0);
            this.tableLayoutPanel24.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel24.Location = new System.Drawing.Point(201, 71);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel24.TabIndex = 281;
            // 
            // panel38
            // 
            this.panel38.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel38.BackColor = System.Drawing.Color.White;
            this.panel38.Controls.Add(this.butt_G20_2);
            this.panel38.Controls.Add(this.txt_ETC7_2);
            this.panel38.Location = new System.Drawing.Point(78, 4);
            this.panel38.Margin = new System.Windows.Forms.Padding(2);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(117, 28);
            this.panel38.TabIndex = 15;
            // 
            // butt_G20_2
            // 
            this.butt_G20_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G20_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G20_2.Name = "butt_G20_2";
            this.butt_G20_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G20_2.TabIndex = 192;
            this.butt_G20_2.TabStop = false;
            this.butt_G20_2.Text = "조회";
            this.butt_G20_2.UseVisualStyleBackColor = true;
            this.butt_G20_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC7_2
            // 
            this.txt_ETC7_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC7_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC7_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC7_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC7_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC7_2.MaxLength = 30;
            this.txt_ETC7_2.Name = "txt_ETC7_2";
            this.txt_ETC7_2.ReadOnly = true;
            this.txt_ETC7_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC7_2.TabIndex = 190;
            this.txt_ETC7_2.TabStop = false;
            this.txt_ETC7_2.Tag = "";
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(2, 2);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 32);
            this.label25.TabIndex = 0;
            this.label25.Text = "더블_우";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.panel22, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(1, 143);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel15.TabIndex = 277;
            // 
            // panel22
            // 
            this.panel22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Controls.Add(this.butt_G40_1);
            this.panel22.Controls.Add(this.txt_ETC9);
            this.panel22.Location = new System.Drawing.Point(78, 4);
            this.panel22.Margin = new System.Windows.Forms.Padding(2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(117, 28);
            this.panel22.TabIndex = 15;
            // 
            // butt_G40_1
            // 
            this.butt_G40_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G40_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G40_1.Name = "butt_G40_1";
            this.butt_G40_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G40_1.TabIndex = 192;
            this.butt_G40_1.TabStop = false;
            this.butt_G40_1.Text = "조회";
            this.butt_G40_1.UseVisualStyleBackColor = true;
            this.butt_G40_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC9
            // 
            this.txt_ETC9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC9.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC9.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC9.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC9.MaxLength = 30;
            this.txt_ETC9.Name = "txt_ETC9";
            this.txt_ETC9.ReadOnly = true;
            this.txt_ETC9.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC9.TabIndex = 190;
            this.txt_ETC9.TabStop = false;
            this.txt_ETC9.Tag = "";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(2, 2);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 32);
            this.label17.TabIndex = 0;
            this.label17.Text = "풀_좌";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel25.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel25.ColumnCount = 2;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.panel39, 1, 0);
            this.tableLayoutPanel25.Controls.Add(this.label26, 0, 0);
            this.tableLayoutPanel25.Location = new System.Drawing.Point(201, 179);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel25.TabIndex = 284;
            // 
            // panel39
            // 
            this.panel39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel39.BackColor = System.Drawing.Color.White;
            this.panel39.Controls.Add(this.butt_G50_2);
            this.panel39.Controls.Add(this.txt_ETC10_2);
            this.panel39.Location = new System.Drawing.Point(78, 4);
            this.panel39.Margin = new System.Windows.Forms.Padding(2);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(117, 28);
            this.panel39.TabIndex = 15;
            // 
            // butt_G50_2
            // 
            this.butt_G50_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G50_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G50_2.Name = "butt_G50_2";
            this.butt_G50_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G50_2.TabIndex = 192;
            this.butt_G50_2.TabStop = false;
            this.butt_G50_2.Text = "조회";
            this.butt_G50_2.UseVisualStyleBackColor = true;
            this.butt_G50_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC10_2
            // 
            this.txt_ETC10_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC10_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC10_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC10_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC10_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC10_2.MaxLength = 30;
            this.txt_ETC10_2.Name = "txt_ETC10_2";
            this.txt_ETC10_2.ReadOnly = true;
            this.txt_ETC10_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC10_2.TabIndex = 190;
            this.txt_ETC10_2.TabStop = false;
            this.txt_ETC10_2.Tag = "";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(2, 2);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 32);
            this.label26.TabIndex = 0;
            this.label26.Text = "싱글윙_우";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.panel20, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(1, 215);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel13.TabIndex = 279;
            // 
            // panel20
            // 
            this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Controls.Add(this.butt_G60_1);
            this.panel20.Controls.Add(this.txt_ETC11);
            this.panel20.Location = new System.Drawing.Point(78, 4);
            this.panel20.Margin = new System.Windows.Forms.Padding(2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(117, 28);
            this.panel20.TabIndex = 15;
            // 
            // butt_G60_1
            // 
            this.butt_G60_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G60_1.Location = new System.Drawing.Point(61, 3);
            this.butt_G60_1.Name = "butt_G60_1";
            this.butt_G60_1.Size = new System.Drawing.Size(53, 22);
            this.butt_G60_1.TabIndex = 192;
            this.butt_G60_1.TabStop = false;
            this.butt_G60_1.Text = "조회";
            this.butt_G60_1.UseVisualStyleBackColor = true;
            this.butt_G60_1.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC11
            // 
            this.txt_ETC11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC11.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC11.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC11.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC11.MaxLength = 30;
            this.txt_ETC11.Name = "txt_ETC11";
            this.txt_ETC11.ReadOnly = true;
            this.txt_ETC11.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC11.TabIndex = 190;
            this.txt_ETC11.TabStop = false;
            this.txt_ETC11.Tag = "";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "더블윙_좌";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel26.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.panel40, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.label27, 0, 0);
            this.tableLayoutPanel26.Location = new System.Drawing.Point(201, 107);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 1;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(199, 36);
            this.tableLayoutPanel26.TabIndex = 282;
            // 
            // panel40
            // 
            this.panel40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel40.BackColor = System.Drawing.Color.White;
            this.panel40.Controls.Add(this.butt_G30_2);
            this.panel40.Controls.Add(this.txt_ETC8_2);
            this.panel40.Location = new System.Drawing.Point(78, 4);
            this.panel40.Margin = new System.Windows.Forms.Padding(2);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(117, 28);
            this.panel40.TabIndex = 15;
            // 
            // butt_G30_2
            // 
            this.butt_G30_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_G30_2.Location = new System.Drawing.Point(61, 3);
            this.butt_G30_2.Name = "butt_G30_2";
            this.butt_G30_2.Size = new System.Drawing.Size(53, 22);
            this.butt_G30_2.TabIndex = 192;
            this.butt_G30_2.TabStop = false;
            this.butt_G30_2.Text = "조회";
            this.butt_G30_2.UseVisualStyleBackColor = true;
            this.butt_G30_2.Click += new System.EventHandler(this.butt_G60_1_Click);
            // 
            // txt_ETC8_2
            // 
            this.txt_ETC8_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC8_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC8_2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC8_2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC8_2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC8_2.MaxLength = 30;
            this.txt_ETC8_2.Name = "txt_ETC8_2";
            this.txt_ETC8_2.ReadOnly = true;
            this.txt_ETC8_2.Size = new System.Drawing.Size(57, 22);
            this.txt_ETC8_2.TabIndex = 190;
            this.txt_ETC8_2.TabStop = false;
            this.txt_ETC8_2.Tag = "";
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(2, 2);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(72, 32);
            this.label27.TabIndex = 0;
            this.label27.Text = "트리플_우";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dGridView_Detail_1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(890, 192);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "본인매출";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_1
            // 
            this.dGridView_Detail_1.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dGridView_Detail_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_1.DefaultCellStyle = dataGridViewCellStyle10;
            this.dGridView_Detail_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_1.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Detail_1.Name = "dGridView_Detail_1";
            this.dGridView_Detail_1.RowTemplate.Height = 23;
            this.dGridView_Detail_1.Size = new System.Drawing.Size(884, 186);
            this.dGridView_Detail_1.TabIndex = 13;
            // 
            // tab_save
            // 
            this.tab_save.Controls.Add(this.dGridView_Detail_3);
            this.tab_save.Controls.Add(this.butt_Excel_Detail_3);
            this.tab_save.Location = new System.Drawing.Point(4, 22);
            this.tab_save.Name = "tab_save";
            this.tab_save.Padding = new System.Windows.Forms.Padding(3);
            this.tab_save.Size = new System.Drawing.Size(890, 192);
            this.tab_save.TabIndex = 2;
            this.tab_save.Text = "후원역추적";
            this.tab_save.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_3
            // 
            this.dGridView_Detail_3.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dGridView_Detail_3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_3.DefaultCellStyle = dataGridViewCellStyle12;
            this.dGridView_Detail_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_3.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_3.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Detail_3.Name = "dGridView_Detail_3";
            this.dGridView_Detail_3.RowTemplate.Height = 23;
            this.dGridView_Detail_3.Size = new System.Drawing.Size(884, 160);
            this.dGridView_Detail_3.TabIndex = 14;
            // 
            // butt_Excel_Detail_3
            // 
            this.butt_Excel_Detail_3.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Detail_3.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Detail_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Detail_3.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Detail_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Detail_3.Name = "butt_Excel_Detail_3";
            this.butt_Excel_Detail_3.Size = new System.Drawing.Size(884, 26);
            this.butt_Excel_Detail_3.TabIndex = 149;
            this.butt_Excel_Detail_3.TabStop = false;
            this.butt_Excel_Detail_3.Text = "Excel";
            this.butt_Excel_Detail_3.UseVisualStyleBackColor = false;
            this.butt_Excel_Detail_3.Click += new System.EventHandler(this.butt_Excel_Detail_3_Click);
            // 
            // tab_nom
            // 
            this.tab_nom.Controls.Add(this.dGridView_Detail_4);
            this.tab_nom.Controls.Add(this.butt_Excel_Detail_4);
            this.tab_nom.Location = new System.Drawing.Point(4, 22);
            this.tab_nom.Name = "tab_nom";
            this.tab_nom.Padding = new System.Windows.Forms.Padding(3);
            this.tab_nom.Size = new System.Drawing.Size(890, 192);
            this.tab_nom.TabIndex = 3;
            this.tab_nom.Text = "추천역추적";
            this.tab_nom.UseVisualStyleBackColor = true;
            // 
            // dGridView_Detail_4
            // 
            this.dGridView_Detail_4.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Detail_4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Detail_4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dGridView_Detail_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Detail_4.DefaultCellStyle = dataGridViewCellStyle14;
            this.dGridView_Detail_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Detail_4.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Detail_4.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Detail_4.Name = "dGridView_Detail_4";
            this.dGridView_Detail_4.RowTemplate.Height = 23;
            this.dGridView_Detail_4.Size = new System.Drawing.Size(884, 160);
            this.dGridView_Detail_4.TabIndex = 14;
            // 
            // butt_Excel_Detail_4
            // 
            this.butt_Excel_Detail_4.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Detail_4.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Detail_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Detail_4.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Detail_4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Detail_4.Name = "butt_Excel_Detail_4";
            this.butt_Excel_Detail_4.Size = new System.Drawing.Size(884, 26);
            this.butt_Excel_Detail_4.TabIndex = 149;
            this.butt_Excel_Detail_4.TabStop = false;
            this.butt_Excel_Detail_4.Text = "Excel";
            this.butt_Excel_Detail_4.UseVisualStyleBackColor = false;
            this.butt_Excel_Detail_4.Click += new System.EventHandler(this.butt_Excel_Detail_4_Click);
            // 
            // tab_etc
            // 
            this.tab_etc.BackColor = System.Drawing.SystemColors.Control;
            this.tab_etc.Controls.Add(this.tableLayoutPanel18);
            this.tab_etc.Controls.Add(this.tableLayoutPanel10);
            this.tab_etc.Controls.Add(this.tableLayoutPanel9);
            this.tab_etc.Controls.Add(this.tableLayoutPanel5);
            this.tab_etc.Controls.Add(this.tableLayoutPanel16);
            this.tab_etc.Controls.Add(this.tableLayoutPanel19);
            this.tab_etc.Location = new System.Drawing.Point(4, 22);
            this.tab_etc.Name = "tab_etc";
            this.tab_etc.Size = new System.Drawing.Size(890, 192);
            this.tab_etc.TabIndex = 4;
            this.tab_etc.Text = "기타";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel18.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.panel24, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel18.Location = new System.Drawing.Point(284, 176);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel18.TabIndex = 280;
            this.tableLayoutPanel18.Visible = false;
            // 
            // panel24
            // 
            this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Controls.Add(this.txt_ETC12);
            this.panel24.Location = new System.Drawing.Point(126, 4);
            this.panel24.Margin = new System.Windows.Forms.Padding(2);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(117, 28);
            this.panel24.TabIndex = 15;
            // 
            // txt_ETC12
            // 
            this.txt_ETC12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC12.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC12.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC12.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC12.MaxLength = 30;
            this.txt_ETC12.Name = "txt_ETC12";
            this.txt_ETC12.ReadOnly = true;
            this.txt_ETC12.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC12.TabIndex = 190;
            this.txt_ETC12.TabStop = false;
            this.txt_ETC12.Tag = "";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Down_CD_Count";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.panel13, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(13, 176);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel10.TabIndex = 273;
            this.tableLayoutPanel10.Visible = false;
            // 
            // panel13
            // 
            this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.txt_ETC5);
            this.panel13.Location = new System.Drawing.Point(126, 4);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(117, 28);
            this.panel13.TabIndex = 15;
            // 
            // txt_ETC5
            // 
            this.txt_ETC5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC5.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC5.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC5.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC5.MaxLength = 30;
            this.txt_ETC5.Name = "txt_ETC5";
            this.txt_ETC5.ReadOnly = true;
            this.txt_ETC5.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC5.TabIndex = 190;
            this.txt_ETC5.TabStop = false;
            this.txt_ETC5.Tag = "";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 32);
            this.label9.TabIndex = 0;
            this.label9.Text = "Down_PT_Count";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 38);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel9.TabIndex = 272;
            // 
            // panel16
            // 
            this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.txt_ETC4);
            this.panel16.Location = new System.Drawing.Point(126, 4);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(117, 28);
            this.panel16.TabIndex = 15;
            // 
            // txt_ETC4
            // 
            this.txt_ETC4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC4.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC4.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC4.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC4.MaxLength = 30;
            this.txt_ETC4.Name = "txt_ETC4";
            this.txt_ETC4.ReadOnly = true;
            this.txt_ETC4.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC4.TabIndex = 190;
            this.txt_ETC4.TabStop = false;
            this.txt_ETC4.Tag = "";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 32);
            this.label6.TabIndex = 0;
            this.label6.Text = "4주누적_우측BV";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 115);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel5.TabIndex = 271;
            // 
            // panel15
            // 
            this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.txt_ETC3);
            this.panel15.Location = new System.Drawing.Point(126, 4);
            this.panel15.Margin = new System.Windows.Forms.Padding(2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(117, 28);
            this.panel15.TabIndex = 15;
            // 
            // txt_ETC3
            // 
            this.txt_ETC3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC3.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC3.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC3.MaxLength = 30;
            this.txt_ETC3.Name = "txt_ETC3";
            this.txt_ETC3.ReadOnly = true;
            this.txt_ETC3.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC3.TabIndex = 190;
            this.txt_ETC3.TabStop = false;
            this.txt_ETC3.Tag = "";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "누적_우측BV";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel16.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 79);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel16.TabIndex = 270;
            // 
            // panel14
            // 
            this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.txt_ETC2);
            this.panel14.Location = new System.Drawing.Point(126, 4);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(117, 28);
            this.panel14.TabIndex = 15;
            // 
            // txt_ETC2
            // 
            this.txt_ETC2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC2.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC2.MaxLength = 30;
            this.txt_ETC2.Name = "txt_ETC2";
            this.txt_ETC2.ReadOnly = true;
            this.txt_ETC2.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC2.TabIndex = 190;
            this.txt_ETC2.TabStop = false;
            this.txt_ETC2.Tag = "";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(2, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 32);
            this.label16.TabIndex = 0;
            this.label16.Text = "누적_좌측BV";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.tableLayoutPanel19.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel19.ColumnCount = 2;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.panel25, 1, 0);
            this.tableLayoutPanel19.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 1;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(247, 36);
            this.tableLayoutPanel19.TabIndex = 269;
            // 
            // panel25
            // 
            this.panel25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Controls.Add(this.txt_ETC1);
            this.panel25.Location = new System.Drawing.Point(126, 4);
            this.panel25.Margin = new System.Windows.Forms.Padding(2);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(117, 28);
            this.panel25.TabIndex = 15;
            // 
            // txt_ETC1
            // 
            this.txt_ETC1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_ETC1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_ETC1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ETC1.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_ETC1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.txt_ETC1.Location = new System.Drawing.Point(3, 3);
            this.txt_ETC1.MaxLength = 30;
            this.txt_ETC1.Name = "txt_ETC1";
            this.txt_ETC1.ReadOnly = true;
            this.txt_ETC1.Size = new System.Drawing.Size(111, 22);
            this.txt_ETC1.TabIndex = 190;
            this.txt_ETC1.TabStop = false;
            this.txt_ETC1.Tag = "";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(117)))), ((int)(((byte)(140)))));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(2, 2);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 32);
            this.label20.TabIndex = 0;
            this.label20.Text = "4주누적_좌측BV";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tab_Detail_01
            // 
            this.tab_Detail_01.Controls.Add(this.tabPage1);
            this.tab_Detail_01.Controls.Add(this.tabPage2);
            this.tab_Detail_01.Controls.Add(this.tab_Save_D);
            this.tab_Detail_01.Controls.Add(this.tab_Up);
            this.tab_Detail_01.Controls.Add(this.tabPage6);
            this.tab_Detail_01.Controls.Add(this.tabPage5);
            this.tab_Detail_01.Controls.Add(this.tabPage8);
            this.tab_Detail_01.Controls.Add(this.tabPage7);
            this.tab_Detail_01.Controls.Add(this.tabPage14);
            this.tab_Detail_01.Dock = System.Windows.Forms.DockStyle.Left;
            this.tab_Detail_01.Location = new System.Drawing.Point(0, 0);
            this.tab_Detail_01.Name = "tab_Detail_01";
            this.tab_Detail_01.SelectedIndex = 0;
            this.tab_Detail_01.Size = new System.Drawing.Size(752, 218);
            this.tab_Detail_01.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dGridView_Pay_1);
            this.tabPage1.Controls.Add(this.butt_Excel_Pay_1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(744, 192);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "추천매칭보너스";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_1
            // 
            this.dGridView_Pay_1.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dGridView_Pay_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_1.DefaultCellStyle = dataGridViewCellStyle16;
            this.dGridView_Pay_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_1.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_1.Name = "dGridView_Pay_1";
            this.dGridView_Pay_1.RowTemplate.Height = 23;
            this.dGridView_Pay_1.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_1.TabIndex = 12;
            // 
            // butt_Excel_Pay_1
            // 
            this.butt_Excel_Pay_1.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_1.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_1.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_1.Name = "butt_Excel_Pay_1";
            this.butt_Excel_Pay_1.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_1.TabIndex = 149;
            this.butt_Excel_Pay_1.TabStop = false;
            this.butt_Excel_Pay_1.Text = "Excel";
            this.butt_Excel_Pay_1.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_1.Click += new System.EventHandler(this.butt_Excel_Pay_1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dGridView_Pay_2);
            this.tabPage2.Controls.Add(this.butt_Excel_Pay_2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(744, 192);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "추천보너스";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_2
            // 
            this.dGridView_Pay_2.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_2.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dGridView_Pay_2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_2.DefaultCellStyle = dataGridViewCellStyle18;
            this.dGridView_Pay_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_2.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_2.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_2.Name = "dGridView_Pay_2";
            this.dGridView_Pay_2.RowTemplate.Height = 23;
            this.dGridView_Pay_2.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_2.TabIndex = 12;
            // 
            // butt_Excel_Pay_2
            // 
            this.butt_Excel_Pay_2.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_2.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_2.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_2.Name = "butt_Excel_Pay_2";
            this.butt_Excel_Pay_2.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_2.TabIndex = 149;
            this.butt_Excel_Pay_2.TabStop = false;
            this.butt_Excel_Pay_2.Text = "Excel";
            this.butt_Excel_Pay_2.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_2.Click += new System.EventHandler(this.butt_Excel_Pay_2_Click);
            // 
            // tab_Save_D
            // 
            this.tab_Save_D.Controls.Add(this.dGridView_Pay_3);
            this.tab_Save_D.Controls.Add(this.butt_Excel_Pay_3);
            this.tab_Save_D.Location = new System.Drawing.Point(4, 22);
            this.tab_Save_D.Name = "tab_Save_D";
            this.tab_Save_D.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Save_D.Size = new System.Drawing.Size(744, 192);
            this.tab_Save_D.TabIndex = 2;
            this.tab_Save_D.Text = "기간하선판매";
            this.tab_Save_D.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_3
            // 
            this.dGridView_Pay_3.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_3.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dGridView_Pay_3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_3.DefaultCellStyle = dataGridViewCellStyle20;
            this.dGridView_Pay_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_3.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_3.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_3.Name = "dGridView_Pay_3";
            this.dGridView_Pay_3.RowTemplate.Height = 23;
            this.dGridView_Pay_3.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_3.TabIndex = 13;
            // 
            // butt_Excel_Pay_3
            // 
            this.butt_Excel_Pay_3.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_3.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_3.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_3.Name = "butt_Excel_Pay_3";
            this.butt_Excel_Pay_3.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_3.TabIndex = 149;
            this.butt_Excel_Pay_3.TabStop = false;
            this.butt_Excel_Pay_3.Text = "Excel";
            this.butt_Excel_Pay_3.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_3.Click += new System.EventHandler(this.butt_Excel_Pay_3_Click);
            // 
            // tab_Up
            // 
            this.tab_Up.Controls.Add(this.dGridView_Pay_4);
            this.tab_Up.Controls.Add(this.butt_Excel_Pay_4);
            this.tab_Up.Location = new System.Drawing.Point(4, 22);
            this.tab_Up.Name = "tab_Up";
            this.tab_Up.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Up.Size = new System.Drawing.Size(744, 192);
            this.tab_Up.TabIndex = 3;
            this.tab_Up.Text = "판매_역추적";
            this.tab_Up.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_4
            // 
            this.dGridView_Pay_4.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_4.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dGridView_Pay_4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_4.DefaultCellStyle = dataGridViewCellStyle22;
            this.dGridView_Pay_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_4.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_4.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_4.Name = "dGridView_Pay_4";
            this.dGridView_Pay_4.RowTemplate.Height = 23;
            this.dGridView_Pay_4.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_4.TabIndex = 13;
            // 
            // butt_Excel_Pay_4
            // 
            this.butt_Excel_Pay_4.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_4.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_4.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_4.Name = "butt_Excel_Pay_4";
            this.butt_Excel_Pay_4.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_4.TabIndex = 149;
            this.butt_Excel_Pay_4.TabStop = false;
            this.butt_Excel_Pay_4.Text = "Excel";
            this.butt_Excel_Pay_4.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_4.Click += new System.EventHandler(this.butt_Excel_Pay_4_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dGridView_Pay_SP);
            this.tabPage6.Controls.Add(this.butt_Excel_Pay_SP);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(744, 192);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "미지급관련";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_SP
            // 
            this.dGridView_Pay_SP.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_SP.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_SP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dGridView_Pay_SP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_SP.DefaultCellStyle = dataGridViewCellStyle24;
            this.dGridView_Pay_SP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_SP.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_SP.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_SP.Name = "dGridView_Pay_SP";
            this.dGridView_Pay_SP.RowTemplate.Height = 23;
            this.dGridView_Pay_SP.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_SP.TabIndex = 13;
            // 
            // butt_Excel_Pay_SP
            // 
            this.butt_Excel_Pay_SP.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_SP.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_SP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_SP.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_SP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_SP.Name = "butt_Excel_Pay_SP";
            this.butt_Excel_Pay_SP.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_SP.TabIndex = 149;
            this.butt_Excel_Pay_SP.TabStop = false;
            this.butt_Excel_Pay_SP.Text = "Excel";
            this.butt_Excel_Pay_SP.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_SP.Click += new System.EventHandler(this.butt_Excel_Pay_SP_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dGridView_Pay_5);
            this.tabPage5.Controls.Add(this.butt_Excel_Pay_5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(744, 192);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "추천역추적";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_5
            // 
            this.dGridView_Pay_5.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_5.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dGridView_Pay_5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_5.DefaultCellStyle = dataGridViewCellStyle26;
            this.dGridView_Pay_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_5.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_5.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_5.Name = "dGridView_Pay_5";
            this.dGridView_Pay_5.RowTemplate.Height = 23;
            this.dGridView_Pay_5.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_5.TabIndex = 13;
            // 
            // butt_Excel_Pay_5
            // 
            this.butt_Excel_Pay_5.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_5.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_5.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_5.Name = "butt_Excel_Pay_5";
            this.butt_Excel_Pay_5.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_5.TabIndex = 149;
            this.butt_Excel_Pay_5.TabStop = false;
            this.butt_Excel_Pay_5.Text = "Excel";
            this.butt_Excel_Pay_5.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_5.Click += new System.EventHandler(this.butt_Excel_Pay_5_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dGridView_Pay_8);
            this.tabPage8.Controls.Add(this.butt_Excel_Pay_8);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(744, 192);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "추천매칭역추적";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_8
            // 
            this.dGridView_Pay_8.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_8.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_8.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dGridView_Pay_8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_8.DefaultCellStyle = dataGridViewCellStyle28;
            this.dGridView_Pay_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_8.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_8.Location = new System.Drawing.Point(3, 29);
            this.dGridView_Pay_8.Name = "dGridView_Pay_8";
            this.dGridView_Pay_8.RowTemplate.Height = 23;
            this.dGridView_Pay_8.Size = new System.Drawing.Size(738, 160);
            this.dGridView_Pay_8.TabIndex = 14;
            // 
            // butt_Excel_Pay_8
            // 
            this.butt_Excel_Pay_8.BackColor = System.Drawing.Color.White;
            this.butt_Excel_Pay_8.Dock = System.Windows.Forms.DockStyle.Top;
            this.butt_Excel_Pay_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel_Pay_8.Location = new System.Drawing.Point(3, 3);
            this.butt_Excel_Pay_8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel_Pay_8.Name = "butt_Excel_Pay_8";
            this.butt_Excel_Pay_8.Size = new System.Drawing.Size(738, 26);
            this.butt_Excel_Pay_8.TabIndex = 149;
            this.butt_Excel_Pay_8.TabStop = false;
            this.butt_Excel_Pay_8.Text = "Excel";
            this.butt_Excel_Pay_8.UseVisualStyleBackColor = false;
            this.butt_Excel_Pay_8.Click += new System.EventHandler(this.butt_Excel_Pay_8_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage7.Controls.Add(this.dGridView_Pay_Cap);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(744, 192);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "캡적용_관련";
            // 
            // dGridView_Pay_Cap
            // 
            this.dGridView_Pay_Cap.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_Cap.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_Cap.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dGridView_Pay_Cap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_Cap.DefaultCellStyle = dataGridViewCellStyle30;
            this.dGridView_Pay_Cap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_Cap.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_Cap.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Pay_Cap.Name = "dGridView_Pay_Cap";
            this.dGridView_Pay_Cap.RowTemplate.Height = 23;
            this.dGridView_Pay_Cap.Size = new System.Drawing.Size(738, 186);
            this.dGridView_Pay_Cap.TabIndex = 14;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dGridView_Pay_14);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(744, 192);
            this.tabPage14.TabIndex = 8;
            this.tabPage14.Text = "패키지보너스";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // dGridView_Pay_14
            // 
            this.dGridView_Pay_14.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Pay_14.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Pay_14.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dGridView_Pay_14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Pay_14.DefaultCellStyle = dataGridViewCellStyle32;
            this.dGridView_Pay_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Pay_14.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Pay_14.Location = new System.Drawing.Point(3, 3);
            this.dGridView_Pay_14.Name = "dGridView_Pay_14";
            this.dGridView_Pay_14.RowTemplate.Height = 23;
            this.dGridView_Pay_14.Size = new System.Drawing.Size(738, 186);
            this.dGridView_Pay_14.TabIndex = 15;
            // 
            // grB_Search
            // 
            this.grB_Search.Controls.Add(this.panel4);
            this.grB_Search.Controls.Add(this.panel2);
            this.grB_Search.Controls.Add(this.button_base);
            this.grB_Search.Controls.Add(this.butt_Exp);
            this.grB_Search.Location = new System.Drawing.Point(1444, 158);
            this.grB_Search.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grB_Search.Name = "grB_Search";
            this.grB_Search.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grB_Search.Size = new System.Drawing.Size(158, 195);
            this.grB_Search.TabIndex = 13;
            this.grB_Search.TabStop = false;
            this.grB_Search.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 482);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(152, 0);
            this.panel4.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel8);
            this.panel2.Controls.Add(this.tableLayoutPanel6);
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Controls.Add(this.tableLayoutPanel4);
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 464);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel8.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 39);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(312, 55);
            this.tableLayoutPanel8.TabIndex = 120;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(5, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 51);
            this.label4.TabIndex = 12;
            this.label4.Text = "구분";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Location = new System.Drawing.Point(112, 6);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(195, 43);
            this.panel5.TabIndex = 90;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel6.Controls.Add(this.label31, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel11, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 92);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(312, 36);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Location = new System.Drawing.Point(5, 2);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(99, 32);
            this.label31.TabIndex = 12;
            this.label31.Text = "회원_번호";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel11
            // 
            this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel11.Controls.Add(this.mtxtMbid2);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Location = new System.Drawing.Point(112, 6);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(195, 24);
            this.panel11.TabIndex = 90;
            // 
            // mtxtMbid2
            // 
            this.mtxtMbid2.Location = new System.Drawing.Point(99, 0);
            this.mtxtMbid2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtMbid2.Name = "mtxtMbid2";
            this.mtxtMbid2.Size = new System.Drawing.Size(87, 21);
            this.mtxtMbid2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(90, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(9, 15);
            this.label3.TabIndex = 17;
            this.label3.Text = "-";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 329);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(5, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 98);
            this.label1.TabIndex = 58;
            this.label1.Text = "지급_일자";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.radioB_P);
            this.panel1.Controls.Add(this.radioB_PM_3);
            this.panel1.Controls.Add(this.radioB_PM_2);
            this.panel1.Controls.Add(this.radioB_PM_1);
            this.panel1.Controls.Add(this.radioB_P_7);
            this.panel1.Controls.Add(this.radioB_P_1);
            this.panel1.Location = new System.Drawing.Point(112, 6);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 90);
            this.panel1.TabIndex = 90;
            // 
            // radioB_P
            // 
            this.radioB_P.AutoSize = true;
            this.radioB_P.Location = new System.Drawing.Point(111, 67);
            this.radioB_P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P.Name = "radioB_P";
            this.radioB_P.Size = new System.Drawing.Size(47, 16);
            this.radioB_P.TabIndex = 69;
            this.radioB_P.Tag = "T_1";
            this.radioB_P.Text = "전체";
            this.radioB_P.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_3
            // 
            this.radioB_PM_3.AutoSize = true;
            this.radioB_PM_3.Location = new System.Drawing.Point(10, 66);
            this.radioB_PM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_3.Name = "radioB_PM_3";
            this.radioB_PM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_PM_3.TabIndex = 68;
            this.radioB_PM_3.Tag = "M_3";
            this.radioB_PM_3.Text = "최근3개월";
            this.radioB_PM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_2
            // 
            this.radioB_PM_2.AutoSize = true;
            this.radioB_PM_2.Location = new System.Drawing.Point(111, 46);
            this.radioB_PM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_2.Name = "radioB_PM_2";
            this.radioB_PM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_PM_2.TabIndex = 67;
            this.radioB_PM_2.Tag = "M_2";
            this.radioB_PM_2.Text = "전월";
            this.radioB_PM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_PM_1
            // 
            this.radioB_PM_1.AutoSize = true;
            this.radioB_PM_1.Location = new System.Drawing.Point(10, 46);
            this.radioB_PM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_PM_1.Name = "radioB_PM_1";
            this.radioB_PM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_PM_1.TabIndex = 66;
            this.radioB_PM_1.Tag = "M_1";
            this.radioB_PM_1.Text = "당월";
            this.radioB_PM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_P_7
            // 
            this.radioB_P_7.AutoSize = true;
            this.radioB_P_7.Location = new System.Drawing.Point(111, 26);
            this.radioB_P_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P_7.Name = "radioB_P_7";
            this.radioB_P_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_P_7.TabIndex = 65;
            this.radioB_P_7.Tag = "D_7";
            this.radioB_P_7.Text = "최근7일";
            this.radioB_P_7.UseVisualStyleBackColor = true;
            // 
            // radioB_P_1
            // 
            this.radioB_P_1.AutoSize = true;
            this.radioB_P_1.Location = new System.Drawing.Point(10, 26);
            this.radioB_P_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_P_1.Name = "radioB_P_1";
            this.radioB_P_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_P_1.TabIndex = 64;
            this.radioB_P_1.Tag = "D_1";
            this.radioB_P_1.Text = "당일";
            this.radioB_P_1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel4.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 130);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.radioB_S);
            this.panel3.Controls.Add(this.radioB_SM_3);
            this.panel3.Controls.Add(this.radioB_SM_2);
            this.panel3.Controls.Add(this.radioB_SM_1);
            this.panel3.Controls.Add(this.radioB_S_7);
            this.panel3.Controls.Add(this.radioB_S_1);
            this.panel3.Location = new System.Drawing.Point(112, 6);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(195, 90);
            this.panel3.TabIndex = 90;
            // 
            // radioB_S
            // 
            this.radioB_S.AutoSize = true;
            this.radioB_S.Location = new System.Drawing.Point(111, 68);
            this.radioB_S.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S.Name = "radioB_S";
            this.radioB_S.Size = new System.Drawing.Size(47, 16);
            this.radioB_S.TabIndex = 63;
            this.radioB_S.Tag = "T_1";
            this.radioB_S.Text = "전체";
            this.radioB_S.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_3
            // 
            this.radioB_SM_3.AutoSize = true;
            this.radioB_SM_3.Location = new System.Drawing.Point(10, 67);
            this.radioB_SM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_3.Name = "radioB_SM_3";
            this.radioB_SM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_SM_3.TabIndex = 62;
            this.radioB_SM_3.Tag = "M_3";
            this.radioB_SM_3.Text = "최근3개월";
            this.radioB_SM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_2
            // 
            this.radioB_SM_2.AutoSize = true;
            this.radioB_SM_2.Location = new System.Drawing.Point(111, 47);
            this.radioB_SM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_2.Name = "radioB_SM_2";
            this.radioB_SM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_2.TabIndex = 61;
            this.radioB_SM_2.Tag = "M_2";
            this.radioB_SM_2.Text = "전월";
            this.radioB_SM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_1
            // 
            this.radioB_SM_1.AutoSize = true;
            this.radioB_SM_1.Location = new System.Drawing.Point(10, 47);
            this.radioB_SM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_1.Name = "radioB_SM_1";
            this.radioB_SM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_1.TabIndex = 60;
            this.radioB_SM_1.Tag = "M_1";
            this.radioB_SM_1.Text = "당월";
            this.radioB_SM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_S_7
            // 
            this.radioB_S_7.AutoSize = true;
            this.radioB_S_7.Location = new System.Drawing.Point(111, 27);
            this.radioB_S_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_7.Name = "radioB_S_7";
            this.radioB_S_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_S_7.TabIndex = 59;
            this.radioB_S_7.Tag = "D_7";
            this.radioB_S_7.Text = "최근7일";
            this.radioB_S_7.UseVisualStyleBackColor = true;
            // 
            // radioB_S_1
            // 
            this.radioB_S_1.AutoSize = true;
            this.radioB_S_1.Location = new System.Drawing.Point(10, 27);
            this.radioB_S_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_1.Name = "radioB_S_1";
            this.radioB_S_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_S_1.TabIndex = 58;
            this.radioB_S_1.Tag = "D_1";
            this.radioB_S_1.Text = "당일";
            this.radioB_S_1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(5, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 98);
            this.label14.TabIndex = 52;
            this.label14.Text = "마감_시작일";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.58213F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.41787F));
            this.tableLayoutPanel7.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.panel7, 1, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 230);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(312, 102);
            this.tableLayoutPanel7.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(5, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 98);
            this.label7.TabIndex = 58;
            this.label7.Text = "마감_종료일";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.Controls.Add(this.radioB_R);
            this.panel7.Controls.Add(this.radioB_RM_3);
            this.panel7.Controls.Add(this.radioB_RM_2);
            this.panel7.Controls.Add(this.radioB_RM_1);
            this.panel7.Controls.Add(this.radioB_R_7);
            this.panel7.Controls.Add(this.radioB_R_1);
            this.panel7.Location = new System.Drawing.Point(112, 6);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(195, 90);
            this.panel7.TabIndex = 90;
            // 
            // radioB_R
            // 
            this.radioB_R.AutoSize = true;
            this.radioB_R.Location = new System.Drawing.Point(111, 67);
            this.radioB_R.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R.Name = "radioB_R";
            this.radioB_R.Size = new System.Drawing.Size(47, 16);
            this.radioB_R.TabIndex = 69;
            this.radioB_R.Tag = "T_1";
            this.radioB_R.Text = "전체";
            this.radioB_R.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_3
            // 
            this.radioB_RM_3.AutoSize = true;
            this.radioB_RM_3.Location = new System.Drawing.Point(10, 66);
            this.radioB_RM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_3.Name = "radioB_RM_3";
            this.radioB_RM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_RM_3.TabIndex = 68;
            this.radioB_RM_3.Tag = "M_3";
            this.radioB_RM_3.Text = "최근3개월";
            this.radioB_RM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_2
            // 
            this.radioB_RM_2.AutoSize = true;
            this.radioB_RM_2.Location = new System.Drawing.Point(111, 46);
            this.radioB_RM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_2.Name = "radioB_RM_2";
            this.radioB_RM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_2.TabIndex = 67;
            this.radioB_RM_2.Tag = "M_2";
            this.radioB_RM_2.Text = "전월";
            this.radioB_RM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_1
            // 
            this.radioB_RM_1.AutoSize = true;
            this.radioB_RM_1.Location = new System.Drawing.Point(10, 46);
            this.radioB_RM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_1.Name = "radioB_RM_1";
            this.radioB_RM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_1.TabIndex = 66;
            this.radioB_RM_1.Tag = "M_1";
            this.radioB_RM_1.Text = "당월";
            this.radioB_RM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_R_7
            // 
            this.radioB_R_7.AutoSize = true;
            this.radioB_R_7.Location = new System.Drawing.Point(111, 26);
            this.radioB_R_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_7.Name = "radioB_R_7";
            this.radioB_R_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_R_7.TabIndex = 65;
            this.radioB_R_7.Tag = "D_7";
            this.radioB_R_7.Text = "최근7일";
            this.radioB_R_7.UseVisualStyleBackColor = true;
            // 
            // radioB_R_1
            // 
            this.radioB_R_1.AutoSize = true;
            this.radioB_R_1.Location = new System.Drawing.Point(10, 26);
            this.radioB_R_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_1.Name = "radioB_R_1";
            this.radioB_R_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_R_1.TabIndex = 64;
            this.radioB_R_1.Tag = "D_1";
            this.radioB_R_1.Text = "당일";
            this.radioB_R_1.UseVisualStyleBackColor = true;
            // 
            // button_base
            // 
            this.button_base.Location = new System.Drawing.Point(848, 108);
            this.button_base.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_base.Name = "button_base";
            this.button_base.Size = new System.Drawing.Size(25, 28);
            this.button_base.TabIndex = 86;
            this.button_base.Text = "...";
            this.button_base.UseVisualStyleBackColor = true;
            this.button_base.Visible = false;
            // 
            // butt_Exp
            // 
            this.butt_Exp.Location = new System.Drawing.Point(848, 14);
            this.butt_Exp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exp.Name = "butt_Exp";
            this.butt_Exp.Size = new System.Drawing.Size(25, 25);
            this.butt_Exp.TabIndex = 83;
            this.butt_Exp.Text = ".";
            this.butt_Exp.UseVisualStyleBackColor = true;
            // 
            // txtToEndDate_Code
            // 
            this.txtToEndDate_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtToEndDate_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtToEndDate_Code.ForeColor = System.Drawing.Color.White;
            this.txtToEndDate_Code.Location = new System.Drawing.Point(107, 3);
            this.txtToEndDate_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToEndDate_Code.MaxLength = 30;
            this.txtToEndDate_Code.Name = "txtToEndDate_Code";
            this.txtToEndDate_Code.Size = new System.Drawing.Size(84, 22);
            this.txtToEndDate_Code.TabIndex = 78;
            this.txtToEndDate_Code.TabStop = false;
            // 
            // txtToEndDate
            // 
            this.txtToEndDate.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtToEndDate.Location = new System.Drawing.Point(3, 3);
            this.txtToEndDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtToEndDate.MaxLength = 8;
            this.txtToEndDate.Name = "txtToEndDate";
            this.txtToEndDate.Size = new System.Drawing.Size(104, 22);
            this.txtToEndDate.TabIndex = 5;
            this.txtToEndDate.Tag = "ncode1";
            this.txtToEndDate.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtToEndDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtToEndDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtToEndDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // combo_Grade_Code
            // 
            this.combo_Grade_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade_Code.FormattingEnabled = true;
            this.combo_Grade_Code.Location = new System.Drawing.Point(154, 3);
            this.combo_Grade_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade_Code.Name = "combo_Grade_Code";
            this.combo_Grade_Code.Size = new System.Drawing.Size(38, 20);
            this.combo_Grade_Code.TabIndex = 202;
            this.combo_Grade_Code.TabStop = false;
            this.combo_Grade_Code.Visible = false;
            // 
            // combo_Grade
            // 
            this.combo_Grade.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade.FormattingEnabled = true;
            this.combo_Grade.Location = new System.Drawing.Point(3, 3);
            this.combo_Grade.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade.Name = "combo_Grade";
            this.combo_Grade.Size = new System.Drawing.Size(150, 20);
            this.combo_Grade.TabIndex = 193;
            // 
            // radio_PayTF2
            // 
            this.radio_PayTF2.AutoSize = true;
            this.radio_PayTF2.Location = new System.Drawing.Point(3, 2);
            this.radio_PayTF2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF2.Name = "radio_PayTF2";
            this.radio_PayTF2.Size = new System.Drawing.Size(47, 16);
            this.radio_PayTF2.TabIndex = 66;
            this.radio_PayTF2.Tag = "D_1";
            this.radio_PayTF2.Text = "전체";
            this.radio_PayTF2.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF1
            // 
            this.radio_PayTF1.AutoSize = true;
            this.radio_PayTF1.Checked = true;
            this.radio_PayTF1.Location = new System.Drawing.Point(3, 22);
            this.radio_PayTF1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF1.Name = "radio_PayTF1";
            this.radio_PayTF1.Size = new System.Drawing.Size(47, 16);
            this.radio_PayTF1.TabIndex = 65;
            this.radio_PayTF1.TabStop = true;
            this.radio_PayTF1.Tag = "D_1";
            this.radio_PayTF1.Text = "지급";
            this.radio_PayTF1.UseVisualStyleBackColor = true;
            // 
            // txtCenter_Code
            // 
            this.txtCenter_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtCenter_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter_Code.ForeColor = System.Drawing.Color.White;
            this.txtCenter_Code.Location = new System.Drawing.Point(146, 3);
            this.txtCenter_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter_Code.MaxLength = 30;
            this.txtCenter_Code.Name = "txtCenter_Code";
            this.txtCenter_Code.Size = new System.Drawing.Size(46, 22);
            this.txtCenter_Code.TabIndex = 78;
            this.txtCenter_Code.TabStop = false;
            // 
            // txtCenter
            // 
            this.txtCenter.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtCenter.Location = new System.Drawing.Point(3, 3);
            this.txtCenter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCenter.MaxLength = 30;
            this.txtCenter.Name = "txtCenter";
            this.txtCenter.Size = new System.Drawing.Size(142, 22);
            this.txtCenter.TabIndex = 5;
            this.txtCenter.Tag = "ncode";
            this.txtCenter.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtCenter.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtCenter.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtCenter.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName.Location = new System.Drawing.Point(3, 3);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(189, 22);
            this.txtName.TabIndex = 2;
            this.txtName.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtMbid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.Size = new System.Drawing.Size(189, 21);
            this.mtxtMbid.TabIndex = 0;
            this.mtxtMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_MtxtData_KeyPress);
            this.mtxtMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_PayDate1
            // 
            this.DTP_PayDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_PayDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PayDate1.Name = "DTP_PayDate1";
            this.DTP_PayDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_PayDate1.TabIndex = 59;
            this.DTP_PayDate1.TabStop = false;
            this.DTP_PayDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_PayDate2
            // 
            this.DTP_PayDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_PayDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_PayDate2.Name = "DTP_PayDate2";
            this.DTP_PayDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_PayDate2.TabIndex = 62;
            this.DTP_PayDate2.TabStop = false;
            this.DTP_PayDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_FromDate1
            // 
            this.DTP_FromDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_FromDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_FromDate1.Name = "DTP_FromDate1";
            this.DTP_FromDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_FromDate1.TabIndex = 53;
            this.DTP_FromDate1.TabStop = false;
            this.DTP_FromDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_FromDate2
            // 
            this.DTP_FromDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_FromDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_FromDate2.Name = "DTP_FromDate2";
            this.DTP_FromDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_FromDate2.TabIndex = 56;
            this.DTP_FromDate2.TabStop = false;
            this.DTP_FromDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_ToDate1
            // 
            this.DTP_ToDate1.Location = new System.Drawing.Point(70, 3);
            this.DTP_ToDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_ToDate1.Name = "DTP_ToDate1";
            this.DTP_ToDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_ToDate1.TabIndex = 59;
            this.DTP_ToDate1.TabStop = false;
            this.DTP_ToDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_ToDate2
            // 
            this.DTP_ToDate2.Location = new System.Drawing.Point(171, 3);
            this.DTP_ToDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_ToDate2.Name = "DTP_ToDate2";
            this.DTP_ToDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_ToDate2.TabIndex = 62;
            this.DTP_ToDate2.TabStop = false;
            this.DTP_ToDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // pn_Button
            // 
            this.pn_Button.Controls.Add(this.butt_Excel);
            this.pn_Button.Controls.Add(this.butt_Delete);
            this.pn_Button.Controls.Add(this.butt_Clear);
            this.pn_Button.Controls.Add(this.butt_Select);
            this.pn_Button.Controls.Add(this.butt_Exit);
            this.pn_Button.Dock = System.Windows.Forms.DockStyle.Top;
            this.pn_Button.Location = new System.Drawing.Point(0, 0);
            this.pn_Button.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pn_Button.Name = "pn_Button";
            this.pn_Button.Size = new System.Drawing.Size(1650, 28);
            this.pn_Button.TabIndex = 14;
            // 
            // butt_Excel
            // 
            this.butt_Excel.BackColor = System.Drawing.Color.White;
            this.butt_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel.Location = new System.Drawing.Point(528, 1);
            this.butt_Excel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel.Name = "butt_Excel";
            this.butt_Excel.Size = new System.Drawing.Size(111, 26);
            this.butt_Excel.TabIndex = 4;
            this.butt_Excel.TabStop = false;
            this.butt_Excel.Text = "엑셀";
            this.butt_Excel.UseVisualStyleBackColor = false;
            this.butt_Excel.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(125, 1);
            this.butt_Delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(111, 26);
            this.butt_Delete.TabIndex = 3;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "삭제";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Visible = false;
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.Location = new System.Drawing.Point(266, 1);
            this.butt_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(111, 26);
            this.butt_Clear.TabIndex = 2;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            this.butt_Clear.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Select
            // 
            this.butt_Select.BackColor = System.Drawing.Color.White;
            this.butt_Select.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Select.Location = new System.Drawing.Point(411, 1);
            this.butt_Select.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Select.Name = "butt_Select";
            this.butt_Select.Size = new System.Drawing.Size(111, 26);
            this.butt_Select.TabIndex = 2;
            this.butt_Select.Text = "검색";
            this.butt_Select.UseVisualStyleBackColor = false;
            this.butt_Select.Click += new System.EventHandler(this.Select_Button_Click);
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(658, 1);
            this.butt_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(111, 26);
            this.butt_Exit.TabIndex = 0;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            this.butt_Exit.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.combo_W_Code_2);
            this.panel12.Controls.Add(this.combo_W_Code_1);
            this.panel12.Controls.Add(this.tableLayoutPanel52);
            this.panel12.Controls.Add(this.tableLayoutPanel28);
            this.panel12.Controls.Add(this.tableLayoutPanel23);
            this.panel12.Controls.Add(this.tableLayoutPanel20);
            this.panel12.Controls.Add(this.tableLayoutPanel14);
            this.panel12.Controls.Add(this.tableLayoutPanel2);
            this.panel12.Controls.Add(this.tableLayoutPanel29);
            this.panel12.Controls.Add(this.tableLayoutPanel30);
            this.panel12.Controls.Add(this.tableLayoutPanel31);
            this.panel12.Controls.Add(this.tableLayoutPanel32);
            this.panel12.Controls.Add(this.tableLayoutPanel33);
            this.panel12.Controls.Add(this.tableLayoutPanel36);
            this.panel12.Controls.Add(this.grB_Search);
            this.panel12.Controls.Add(this.tableLayoutPanel37);
            this.panel12.Controls.Add(this.tableLayoutPanel38);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 28);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1650, 114);
            this.panel12.TabIndex = 0;
            // 
            // combo_W_Code_2
            // 
            this.combo_W_Code_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_W_Code_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_W_Code_2.FormattingEnabled = true;
            this.combo_W_Code_2.Location = new System.Drawing.Point(1087, 174);
            this.combo_W_Code_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_W_Code_2.Name = "combo_W_Code_2";
            this.combo_W_Code_2.Size = new System.Drawing.Size(36, 20);
            this.combo_W_Code_2.TabIndex = 208;
            this.combo_W_Code_2.TabStop = false;
            this.combo_W_Code_2.Visible = false;
            // 
            // combo_W_Code_1
            // 
            this.combo_W_Code_1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_W_Code_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_W_Code_1.FormattingEnabled = true;
            this.combo_W_Code_1.Location = new System.Drawing.Point(1045, 174);
            this.combo_W_Code_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_W_Code_1.Name = "combo_W_Code_1";
            this.combo_W_Code_1.Size = new System.Drawing.Size(36, 20);
            this.combo_W_Code_1.TabIndex = 207;
            this.combo_W_Code_1.TabStop = false;
            this.combo_W_Code_1.Visible = false;
            // 
            // tableLayoutPanel52
            // 
            this.tableLayoutPanel52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel52.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel52.ColumnCount = 2;
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel52.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.Controls.Add(this.panel60, 1, 0);
            this.tableLayoutPanel52.Controls.Add(this.label59, 0, 0);
            this.tableLayoutPanel52.Location = new System.Drawing.Point(379, 147);
            this.tableLayoutPanel52.Name = "tableLayoutPanel52";
            this.tableLayoutPanel52.RowCount = 1;
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel52.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel52.Size = new System.Drawing.Size(660, 36);
            this.tableLayoutPanel52.TabIndex = 206;
            this.tableLayoutPanel52.Visible = false;
            // 
            // panel60
            // 
            this.panel60.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel60.BackColor = System.Drawing.Color.White;
            this.panel60.Controls.Add(this.combo_W_2);
            this.panel60.Controls.Add(this.combo_W_1);
            this.panel60.Controls.Add(this.label58);
            this.panel60.Location = new System.Drawing.Point(126, 4);
            this.panel60.Margin = new System.Windows.Forms.Padding(2);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(530, 28);
            this.panel60.TabIndex = 15;
            // 
            // combo_W_2
            // 
            this.combo_W_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.combo_W_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_W_2.FormattingEnabled = true;
            this.combo_W_2.Location = new System.Drawing.Point(273, 4);
            this.combo_W_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_W_2.Name = "combo_W_2";
            this.combo_W_2.Size = new System.Drawing.Size(254, 20);
            this.combo_W_2.TabIndex = 204;
            // 
            // combo_W_1
            // 
            this.combo_W_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.combo_W_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_W_1.FormattingEnabled = true;
            this.combo_W_1.Location = new System.Drawing.Point(3, 4);
            this.combo_W_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_W_1.Name = "combo_W_1";
            this.combo_W_1.Size = new System.Drawing.Size(254, 20);
            this.combo_W_1.TabIndex = 203;
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(261, 7);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(9, 15);
            this.label58.TabIndex = 60;
            this.label58.Text = "~";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(2, 2);
            this.label59.Margin = new System.Windows.Forms.Padding(0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(120, 32);
            this.label59.TabIndex = 0;
            this.label59.Text = "마감_주차";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel28.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Controls.Add(this.panel43, 1, 0);
            this.tableLayoutPanel28.Controls.Add(this.label29, 0, 0);
            this.tableLayoutPanel28.Location = new System.Drawing.Point(1281, 1);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel28.TabIndex = 38;
            // 
            // panel43
            // 
            this.panel43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel43.BackColor = System.Drawing.Color.White;
            this.panel43.Controls.Add(this.radioB_Su_Not);
            this.panel43.Controls.Add(this.radioButton2);
            this.panel43.Controls.Add(this.radioB_Su);
            this.panel43.Location = new System.Drawing.Point(126, 4);
            this.panel43.Margin = new System.Windows.Forms.Padding(2);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(195, 28);
            this.panel43.TabIndex = 15;
            // 
            // radioB_Su_Not
            // 
            this.radioB_Su_Not.AutoSize = true;
            this.radioB_Su_Not.Location = new System.Drawing.Point(137, 4);
            this.radioB_Su_Not.Name = "radioB_Su_Not";
            this.radioB_Su_Not.Size = new System.Drawing.Size(59, 16);
            this.radioB_Su_Not.TabIndex = 55;
            this.radioB_Su_Not.Text = "미수집";
            this.radioB_Su_Not.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(47, 16);
            this.radioButton2.TabIndex = 53;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "전체";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioB_Su
            // 
            this.radioB_Su.AutoSize = true;
            this.radioB_Su.Location = new System.Drawing.Point(73, 4);
            this.radioB_Su.Name = "radioB_Su";
            this.radioB_Su.Size = new System.Drawing.Size(47, 16);
            this.radioB_Su.TabIndex = 54;
            this.radioB_Su.Text = "수집";
            this.radioB_Su.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(2, 2);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(120, 32);
            this.label29.TabIndex = 0;
            this.label29.Text = "주민번호 수집 구분";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel23.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.panel42, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel23.Location = new System.Drawing.Point(1281, 39);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 1;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(425, 36);
            this.tableLayoutPanel23.TabIndex = 16;
            // 
            // panel42
            // 
            this.panel42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel42.BackColor = System.Drawing.Color.White;
            this.panel42.Controls.Add(this.radioB_Leave);
            this.panel42.Controls.Add(this.radioB_Leave_Not);
            this.panel42.Controls.Add(this.radioButton1);
            this.panel42.Controls.Add(this.chk_Leave_Only);
            this.panel42.Controls.Add(this.chk_Leave);
            this.panel42.Location = new System.Drawing.Point(126, 4);
            this.panel42.Margin = new System.Windows.Forms.Padding(2);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(295, 28);
            this.panel42.TabIndex = 15;
            // 
            // radioB_Leave
            // 
            this.radioB_Leave.AutoSize = true;
            this.radioB_Leave.Location = new System.Drawing.Point(181, 6);
            this.radioB_Leave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_Leave.Name = "radioB_Leave";
            this.radioB_Leave.Size = new System.Drawing.Size(71, 16);
            this.radioB_Leave.TabIndex = 69;
            this.radioB_Leave.Tag = "D_1";
            this.radioB_Leave.Text = "탈퇴자만";
            this.radioB_Leave.UseVisualStyleBackColor = true;
            // 
            // radioB_Leave_Not
            // 
            this.radioB_Leave_Not.AutoSize = true;
            this.radioB_Leave_Not.Location = new System.Drawing.Point(78, 6);
            this.radioB_Leave_Not.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_Leave_Not.Name = "radioB_Leave_Not";
            this.radioB_Leave_Not.Size = new System.Drawing.Size(83, 16);
            this.radioB_Leave_Not.TabIndex = 68;
            this.radioB_Leave_Not.Tag = "D_1";
            this.radioB_Leave_Not.Text = "미탈퇴자만";
            this.radioB_Leave_Not.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(4, 6);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 16);
            this.radioButton1.TabIndex = 67;
            this.radioButton1.Tag = "D_1";
            this.radioButton1.Text = "전체";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // chk_Leave_Only
            // 
            this.chk_Leave_Only.AutoSize = true;
            this.chk_Leave_Only.Location = new System.Drawing.Point(95, 33);
            this.chk_Leave_Only.Name = "chk_Leave_Only";
            this.chk_Leave_Only.Size = new System.Drawing.Size(72, 16);
            this.chk_Leave_Only.TabIndex = 19;
            this.chk_Leave_Only.Text = "탈퇴자만";
            this.chk_Leave_Only.UseVisualStyleBackColor = true;
            this.chk_Leave_Only.Visible = false;
            // 
            // chk_Leave
            // 
            this.chk_Leave.AutoSize = true;
            this.chk_Leave.Location = new System.Drawing.Point(4, 34);
            this.chk_Leave.Name = "chk_Leave";
            this.chk_Leave.Size = new System.Drawing.Size(84, 16);
            this.chk_Leave.TabIndex = 17;
            this.chk_Leave.Text = "탈퇴자포함";
            this.chk_Leave.UseVisualStyleBackColor = true;
            this.chk_Leave.Visible = false;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(2, 2);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(120, 32);
            this.label24.TabIndex = 0;
            this.label24.Text = "구분";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel20.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.panel31, 1, 0);
            this.tableLayoutPanel20.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel20.Location = new System.Drawing.Point(304, 76);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(1126, 36);
            this.tableLayoutPanel20.TabIndex = 15;
            // 
            // panel31
            // 
            this.panel31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.checkB_150);
            this.panel31.Controls.Add(this.checkB_140);
            this.panel31.Controls.Add(this.checkB_10);
            this.panel31.Controls.Add(this.checkB_110);
            this.panel31.Controls.Add(this.checkB_100);
            this.panel31.Controls.Add(this.checkB_130);
            this.panel31.Controls.Add(this.checkB_90);
            this.panel31.Controls.Add(this.checkB_120);
            this.panel31.Controls.Add(this.checkB_80);
            this.panel31.Controls.Add(this.checkB_70);
            this.panel31.Controls.Add(this.checkB_60);
            this.panel31.Controls.Add(this.checkB_50);
            this.panel31.Controls.Add(this.checkB_40);
            this.panel31.Controls.Add(this.checkB_30);
            this.panel31.Controls.Add(this.checkB_Up);
            this.panel31.Controls.Add(this.combo_Grade2_Code);
            this.panel31.Controls.Add(this.combo_Grade2);
            this.panel31.Controls.Add(this.checkB_Up_60);
            this.panel31.Controls.Add(this.checkB_20);
            this.panel31.Location = new System.Drawing.Point(91, 4);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(1031, 28);
            this.panel31.TabIndex = 15;
            // 
            // checkB_150
            // 
            this.checkB_150.AutoSize = true;
            this.checkB_150.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_150.ForeColor = System.Drawing.Color.Black;
            this.checkB_150.Location = new System.Drawing.Point(957, 6);
            this.checkB_150.Name = "checkB_150";
            this.checkB_150.Size = new System.Drawing.Size(72, 16);
            this.checkB_150.TabIndex = 218;
            this.checkB_150.Text = "임페리얼";
            this.checkB_150.UseVisualStyleBackColor = true;
            // 
            // checkB_140
            // 
            this.checkB_140.AutoSize = true;
            this.checkB_140.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_140.ForeColor = System.Drawing.Color.Black;
            this.checkB_140.Location = new System.Drawing.Point(897, 6);
            this.checkB_140.Name = "checkB_140";
            this.checkB_140.Size = new System.Drawing.Size(60, 16);
            this.checkB_140.TabIndex = 217;
            this.checkB_140.Text = "크라운";
            this.checkB_140.UseVisualStyleBackColor = true;
            // 
            // checkB_10
            // 
            this.checkB_10.AutoSize = true;
            this.checkB_10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_10.ForeColor = System.Drawing.Color.Black;
            this.checkB_10.Location = new System.Drawing.Point(99, 6);
            this.checkB_10.Name = "checkB_10";
            this.checkB_10.Size = new System.Drawing.Size(54, 16);
            this.checkB_10.TabIndex = 216;
            this.checkB_10.Text = "1스타";
            this.checkB_10.UseVisualStyleBackColor = true;
            // 
            // checkB_110
            // 
            this.checkB_110.AutoSize = true;
            this.checkB_110.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_110.ForeColor = System.Drawing.Color.Black;
            this.checkB_110.Location = new System.Drawing.Point(669, 6);
            this.checkB_110.Name = "checkB_110";
            this.checkB_110.Size = new System.Drawing.Size(60, 16);
            this.checkB_110.TabIndex = 214;
            this.checkB_110.Text = "다이아";
            this.checkB_110.UseVisualStyleBackColor = true;
            // 
            // checkB_100
            // 
            this.checkB_100.AutoSize = true;
            this.checkB_100.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_100.ForeColor = System.Drawing.Color.Black;
            this.checkB_100.Location = new System.Drawing.Point(597, 6);
            this.checkB_100.Name = "checkB_100";
            this.checkB_100.Size = new System.Drawing.Size(72, 16);
            this.checkB_100.TabIndex = 213;
            this.checkB_100.Text = "에메랄드";
            this.checkB_100.UseVisualStyleBackColor = true;
            // 
            // checkB_130
            // 
            this.checkB_130.AutoSize = true;
            this.checkB_130.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_130.ForeColor = System.Drawing.Color.Black;
            this.checkB_130.Location = new System.Drawing.Point(813, 6);
            this.checkB_130.Name = "checkB_130";
            this.checkB_130.Size = new System.Drawing.Size(84, 16);
            this.checkB_130.TabIndex = 216;
            this.checkB_130.Text = "레드다이아";
            this.checkB_130.UseVisualStyleBackColor = true;
            // 
            // checkB_90
            // 
            this.checkB_90.AutoSize = true;
            this.checkB_90.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_90.ForeColor = System.Drawing.Color.Black;
            this.checkB_90.Location = new System.Drawing.Point(525, 6);
            this.checkB_90.Name = "checkB_90";
            this.checkB_90.Size = new System.Drawing.Size(72, 16);
            this.checkB_90.TabIndex = 212;
            this.checkB_90.Text = "사파이어";
            this.checkB_90.UseVisualStyleBackColor = true;
            // 
            // checkB_120
            // 
            this.checkB_120.AutoSize = true;
            this.checkB_120.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_120.ForeColor = System.Drawing.Color.Black;
            this.checkB_120.Location = new System.Drawing.Point(729, 6);
            this.checkB_120.Name = "checkB_120";
            this.checkB_120.Size = new System.Drawing.Size(84, 16);
            this.checkB_120.TabIndex = 215;
            this.checkB_120.Text = "블루다이아";
            this.checkB_120.UseVisualStyleBackColor = true;
            // 
            // checkB_80
            // 
            this.checkB_80.AutoSize = true;
            this.checkB_80.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_80.ForeColor = System.Drawing.Color.Black;
            this.checkB_80.Location = new System.Drawing.Point(477, 6);
            this.checkB_80.Name = "checkB_80";
            this.checkB_80.Size = new System.Drawing.Size(48, 16);
            this.checkB_80.TabIndex = 211;
            this.checkB_80.Text = "루비";
            this.checkB_80.UseVisualStyleBackColor = true;
            // 
            // checkB_70
            // 
            this.checkB_70.AutoSize = true;
            this.checkB_70.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_70.ForeColor = System.Drawing.Color.Black;
            this.checkB_70.Location = new System.Drawing.Point(429, 6);
            this.checkB_70.Name = "checkB_70";
            this.checkB_70.Size = new System.Drawing.Size(48, 16);
            this.checkB_70.TabIndex = 210;
            this.checkB_70.Text = "골드";
            this.checkB_70.UseVisualStyleBackColor = true;
            // 
            // checkB_60
            // 
            this.checkB_60.AutoSize = true;
            this.checkB_60.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_60.ForeColor = System.Drawing.Color.Black;
            this.checkB_60.Location = new System.Drawing.Point(381, 6);
            this.checkB_60.Name = "checkB_60";
            this.checkB_60.Size = new System.Drawing.Size(48, 16);
            this.checkB_60.TabIndex = 209;
            this.checkB_60.Text = "실버";
            this.checkB_60.UseVisualStyleBackColor = true;
            // 
            // checkB_50
            // 
            this.checkB_50.AutoSize = true;
            this.checkB_50.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_50.ForeColor = System.Drawing.Color.Black;
            this.checkB_50.Location = new System.Drawing.Point(321, 6);
            this.checkB_50.Name = "checkB_50";
            this.checkB_50.Size = new System.Drawing.Size(60, 16);
            this.checkB_50.TabIndex = 208;
            this.checkB_50.Text = "브론즈";
            this.checkB_50.UseVisualStyleBackColor = true;
            // 
            // checkB_40
            // 
            this.checkB_40.AutoSize = true;
            this.checkB_40.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_40.ForeColor = System.Drawing.Color.Black;
            this.checkB_40.Location = new System.Drawing.Point(261, 6);
            this.checkB_40.Name = "checkB_40";
            this.checkB_40.Size = new System.Drawing.Size(60, 16);
            this.checkB_40.TabIndex = 207;
            this.checkB_40.Text = "매니저";
            this.checkB_40.UseVisualStyleBackColor = true;
            // 
            // checkB_30
            // 
            this.checkB_30.AutoSize = true;
            this.checkB_30.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_30.ForeColor = System.Drawing.Color.Black;
            this.checkB_30.Location = new System.Drawing.Point(207, 6);
            this.checkB_30.Name = "checkB_30";
            this.checkB_30.Size = new System.Drawing.Size(54, 16);
            this.checkB_30.TabIndex = 206;
            this.checkB_30.Text = "3스타";
            this.checkB_30.UseVisualStyleBackColor = true;
            // 
            // checkB_Up
            // 
            this.checkB_Up.AutoSize = true;
            this.checkB_Up.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_Up.ForeColor = System.Drawing.Color.Blue;
            this.checkB_Up.Location = new System.Drawing.Point(4, 6);
            this.checkB_Up.Name = "checkB_Up";
            this.checkB_Up.Size = new System.Drawing.Size(95, 16);
            this.checkB_Up.TabIndex = 205;
            this.checkB_Up.TabStop = true;
            this.checkB_Up.Text = "직급_승급자";
            this.checkB_Up.UseVisualStyleBackColor = true;
            // 
            // combo_Grade2_Code
            // 
            this.combo_Grade2_Code.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade2_Code.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade2_Code.FormattingEnabled = true;
            this.combo_Grade2_Code.Location = new System.Drawing.Point(233, 30);
            this.combo_Grade2_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade2_Code.Name = "combo_Grade2_Code";
            this.combo_Grade2_Code.Size = new System.Drawing.Size(346, 20);
            this.combo_Grade2_Code.TabIndex = 204;
            this.combo_Grade2_Code.TabStop = false;
            this.combo_Grade2_Code.Visible = false;
            // 
            // combo_Grade2
            // 
            this.combo_Grade2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Grade2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Grade2.FormattingEnabled = true;
            this.combo_Grade2.Location = new System.Drawing.Point(101, 30);
            this.combo_Grade2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Grade2.Name = "combo_Grade2";
            this.combo_Grade2.Size = new System.Drawing.Size(346, 20);
            this.combo_Grade2.TabIndex = 203;
            // 
            // checkB_Up_60
            // 
            this.checkB_Up_60.AutoSize = true;
            this.checkB_Up_60.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_Up_60.ForeColor = System.Drawing.Color.Blue;
            this.checkB_Up_60.Location = new System.Drawing.Point(143, 30);
            this.checkB_Up_60.Name = "checkB_Up_60";
            this.checkB_Up_60.Size = new System.Drawing.Size(114, 16);
            this.checkB_Up_60.TabIndex = 1;
            this.checkB_Up_60.Text = "PD이상_승급자";
            this.checkB_Up_60.UseVisualStyleBackColor = true;
            // 
            // checkB_20
            // 
            this.checkB_20.AutoSize = true;
            this.checkB_20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.checkB_20.ForeColor = System.Drawing.Color.Black;
            this.checkB_20.Location = new System.Drawing.Point(153, 6);
            this.checkB_20.Name = "checkB_20";
            this.checkB_20.Size = new System.Drawing.Size(54, 16);
            this.checkB_20.TabIndex = 0;
            this.checkB_20.Text = "2스타";
            this.checkB_20.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(2, 2);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 32);
            this.label21.TabIndex = 0;
            this.label21.Text = "신규_승급";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.panel17, 1, 0);
            this.tableLayoutPanel14.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(25, 192);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel14.TabIndex = 14;
            this.tableLayoutPanel14.Visible = false;
            // 
            // panel17
            // 
            this.panel17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.txt_Us_num);
            this.panel17.Location = new System.Drawing.Point(126, 4);
            this.panel17.Margin = new System.Windows.Forms.Padding(2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(195, 28);
            this.panel17.TabIndex = 15;
            // 
            // txt_Us_num
            // 
            this.txt_Us_num.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Us_num.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Us_num.Location = new System.Drawing.Point(3, 3);
            this.txt_Us_num.Margin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.txt_Us_num.MaxLength = 7;
            this.txt_Us_num.Name = "txt_Us_num";
            this.txt_Us_num.Size = new System.Drawing.Size(189, 22);
            this.txt_Us_num.TabIndex = 7;
            this.txt_Us_num.Tag = "1";
            this.txt_Us_num.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Us_num.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Us_num.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 32);
            this.label19.TabIndex = 0;
            this.label19.Text = "미국회원_번호";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel10, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(956, 40);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.mtxtPayDate2);
            this.panel10.Controls.Add(this.mtxtPayDate1);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Controls.Add(this.DTP_PayDate2);
            this.panel10.Controls.Add(this.DTP_PayDate1);
            this.panel10.Location = new System.Drawing.Point(126, 4);
            this.panel10.Margin = new System.Windows.Forms.Padding(2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(195, 28);
            this.panel10.TabIndex = 15;
            // 
            // mtxtPayDate2
            // 
            this.mtxtPayDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtPayDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPayDate2.Name = "mtxtPayDate2";
            this.mtxtPayDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtPayDate2.TabIndex = 64;
            this.mtxtPayDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPayDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPayDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtPayDate1
            // 
            this.mtxtPayDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtPayDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtPayDate1.Name = "mtxtPayDate1";
            this.mtxtPayDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtPayDate1.TabIndex = 0;
            this.mtxtPayDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtPayDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtPayDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(94, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(9, 15);
            this.label8.TabIndex = 60;
            this.label8.Text = "~";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 32);
            this.label13.TabIndex = 0;
            this.label13.Text = "지급_일자";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel29.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel29.ColumnCount = 2;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Controls.Add(this.panel26, 1, 0);
            this.tableLayoutPanel29.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel29.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 1;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 107F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(300, 109);
            this.tableLayoutPanel29.TabIndex = 9;
            // 
            // panel26
            // 
            this.panel26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.radio_PayTF_Re_D_2);
            this.panel26.Controls.Add(this.radio_PayTF_Re_D_1);
            this.panel26.Controls.Add(this.radio_PayTF_ALL);
            this.panel26.Controls.Add(this.radio_PayTF_Not);
            this.panel26.Controls.Add(this.radio_PayTF3);
            this.panel26.Controls.Add(this.radio_PayTF2);
            this.panel26.Controls.Add(this.radio_PayTF1);
            this.panel26.Location = new System.Drawing.Point(126, 4);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(170, 101);
            this.panel26.TabIndex = 15;
            // 
            // radio_PayTF_Re_D_2
            // 
            this.radio_PayTF_Re_D_2.AutoSize = true;
            this.radio_PayTF_Re_D_2.Location = new System.Drawing.Point(3, 84);
            this.radio_PayTF_Re_D_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Re_D_2.Name = "radio_PayTF_Re_D_2";
            this.radio_PayTF_Re_D_2.Size = new System.Drawing.Size(165, 16);
            this.radio_PayTF_Re_D_2.TabIndex = 71;
            this.radio_PayTF_Re_D_2.Tag = "D_1";
            this.radio_PayTF_Re_D_2.Text = "이월된+이월한 반품공제액";
            this.radio_PayTF_Re_D_2.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_Re_D_1
            // 
            this.radio_PayTF_Re_D_1.AutoSize = true;
            this.radio_PayTF_Re_D_1.Location = new System.Drawing.Point(3, 63);
            this.radio_PayTF_Re_D_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Re_D_1.Name = "radio_PayTF_Re_D_1";
            this.radio_PayTF_Re_D_1.Size = new System.Drawing.Size(129, 16);
            this.radio_PayTF_Re_D_1.TabIndex = 70;
            this.radio_PayTF_Re_D_1.Tag = "D_1";
            this.radio_PayTF_Re_D_1.Text = "이월한반품공제액 +";
            this.radio_PayTF_Re_D_1.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_ALL
            // 
            this.radio_PayTF_ALL.AutoSize = true;
            this.radio_PayTF_ALL.Location = new System.Drawing.Point(74, 2);
            this.radio_PayTF_ALL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_ALL.Name = "radio_PayTF_ALL";
            this.radio_PayTF_ALL.Size = new System.Drawing.Size(89, 16);
            this.radio_PayTF_ALL.TabIndex = 69;
            this.radio_PayTF_ALL.Tag = "D_1";
            this.radio_PayTF_ALL.Text = "지급+미지급";
            this.radio_PayTF_ALL.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF_Not
            // 
            this.radio_PayTF_Not.AutoSize = true;
            this.radio_PayTF_Not.Location = new System.Drawing.Point(3, 43);
            this.radio_PayTF_Not.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF_Not.Name = "radio_PayTF_Not";
            this.radio_PayTF_Not.Size = new System.Drawing.Size(59, 16);
            this.radio_PayTF_Not.TabIndex = 68;
            this.radio_PayTF_Not.Tag = "D_1";
            this.radio_PayTF_Not.Text = "미지급";
            this.radio_PayTF_Not.UseVisualStyleBackColor = true;
            // 
            // radio_PayTF3
            // 
            this.radio_PayTF3.AutoSize = true;
            this.radio_PayTF3.Location = new System.Drawing.Point(74, 22);
            this.radio_PayTF3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radio_PayTF3.Name = "radio_PayTF3";
            this.radio_PayTF3.Size = new System.Drawing.Size(71, 16);
            this.radio_PayTF3.TabIndex = 67;
            this.radio_PayTF3.Tag = "D_1";
            this.radio_PayTF3.Text = "미발생자";
            this.radio_PayTF3.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(2, 2);
            this.label34.Margin = new System.Windows.Forms.Padding(0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(120, 105);
            this.label34.TabIndex = 0;
            this.label34.Text = "구분";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel30.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel30.ColumnCount = 2;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.panel27, 1, 0);
            this.tableLayoutPanel30.Controls.Add(this.label35, 0, 0);
            this.tableLayoutPanel30.Location = new System.Drawing.Point(1013, 140);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 1;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel30.TabIndex = 3;
            // 
            // panel27
            // 
            this.panel27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Controls.Add(this.txtCenter_Code);
            this.panel27.Controls.Add(this.txtCenter);
            this.panel27.Location = new System.Drawing.Point(126, 4);
            this.panel27.Margin = new System.Windows.Forms.Padding(2);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(195, 28);
            this.panel27.TabIndex = 15;
            // 
            // label35
            // 
            this.label35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(2, 2);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(120, 32);
            this.label35.TabIndex = 0;
            this.label35.Text = "센타";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel31.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel31.ColumnCount = 2;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.panel28, 1, 0);
            this.tableLayoutPanel31.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel31.Location = new System.Drawing.Point(358, 188);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 1;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(324, 36);
            this.tableLayoutPanel31.TabIndex = 2;
            // 
            // panel28
            // 
            this.panel28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Controls.Add(this.txtToEndDate_Code);
            this.panel28.Controls.Add(this.txtToEndDate);
            this.panel28.Location = new System.Drawing.Point(126, 4);
            this.panel28.Margin = new System.Windows.Forms.Padding(2);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(194, 28);
            this.panel28.TabIndex = 15;
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(2, 2);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 32);
            this.label36.TabIndex = 0;
            this.label36.Text = "마감일";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel32.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel32.ColumnCount = 2;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.panel29, 1, 0);
            this.tableLayoutPanel32.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel32.Location = new System.Drawing.Point(956, 2);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 1;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel32.TabIndex = 8;
            // 
            // panel29
            // 
            this.panel29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.combo_Grade_Code);
            this.panel29.Controls.Add(this.combo_Grade);
            this.panel29.Location = new System.Drawing.Point(126, 4);
            this.panel29.Margin = new System.Windows.Forms.Padding(2);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(195, 28);
            this.panel29.TabIndex = 15;
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(2, 2);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(120, 32);
            this.label37.TabIndex = 0;
            this.label37.Text = "직급";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.panel30, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(630, 40);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel33.TabIndex = 5;
            // 
            // panel30
            // 
            this.panel30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.mtxtToDate2);
            this.panel30.Controls.Add(this.mtxtToDate1);
            this.panel30.Controls.Add(this.label38);
            this.panel30.Controls.Add(this.DTP_ToDate2);
            this.panel30.Controls.Add(this.DTP_ToDate1);
            this.panel30.Location = new System.Drawing.Point(126, 4);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(195, 28);
            this.panel30.TabIndex = 15;
            // 
            // mtxtToDate2
            // 
            this.mtxtToDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtToDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtToDate2.Name = "mtxtToDate2";
            this.mtxtToDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtToDate2.TabIndex = 64;
            this.mtxtToDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtToDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtToDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtToDate1
            // 
            this.mtxtToDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtToDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtToDate1.Name = "mtxtToDate1";
            this.mtxtToDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtToDate1.TabIndex = 0;
            this.mtxtToDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtToDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtToDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(94, 7);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(9, 15);
            this.label38.TabIndex = 60;
            this.label38.Text = "~";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(2, 2);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 32);
            this.label39.TabIndex = 0;
            this.label39.Text = "마감_종료일";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel36.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel36.ColumnCount = 2;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.panel33, 1, 0);
            this.tableLayoutPanel36.Controls.Add(this.label43, 0, 0);
            this.tableLayoutPanel36.Location = new System.Drawing.Point(304, 40);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 1;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel36.TabIndex = 4;
            // 
            // panel33
            // 
            this.panel33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Controls.Add(this.mtxtFromDate2);
            this.panel33.Controls.Add(this.mtxtFromDate1);
            this.panel33.Controls.Add(this.label42);
            this.panel33.Controls.Add(this.DTP_FromDate2);
            this.panel33.Controls.Add(this.DTP_FromDate1);
            this.panel33.Location = new System.Drawing.Point(126, 4);
            this.panel33.Margin = new System.Windows.Forms.Padding(2);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(195, 28);
            this.panel33.TabIndex = 15;
            // 
            // mtxtFromDate2
            // 
            this.mtxtFromDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtFromDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtFromDate2.Name = "mtxtFromDate2";
            this.mtxtFromDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtFromDate2.TabIndex = 64;
            this.mtxtFromDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtFromDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtFromDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtFromDate1
            // 
            this.mtxtFromDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtFromDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtFromDate1.Name = "mtxtFromDate1";
            this.mtxtFromDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtFromDate1.TabIndex = 0;
            this.mtxtFromDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtFromDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtFromDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(94, 7);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(9, 15);
            this.label42.TabIndex = 60;
            this.label42.Text = "~";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(2, 2);
            this.label43.Margin = new System.Windows.Forms.Padding(0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 32);
            this.label43.TabIndex = 0;
            this.label43.Text = "마감_시작일";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel37.ColumnCount = 2;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.panel34, 1, 0);
            this.tableLayoutPanel37.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel37.Location = new System.Drawing.Point(630, 3);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel37.TabIndex = 1;
            // 
            // panel34
            // 
            this.panel34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Controls.Add(this.txtName);
            this.panel34.Location = new System.Drawing.Point(126, 4);
            this.panel34.Margin = new System.Windows.Forms.Padding(2);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(195, 28);
            this.panel34.TabIndex = 15;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(2, 2);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(120, 32);
            this.label44.TabIndex = 0;
            this.label44.Text = "성명";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.panel35, 1, 0);
            this.tableLayoutPanel38.Controls.Add(this.label45, 0, 0);
            this.tableLayoutPanel38.Location = new System.Drawing.Point(304, 3);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel38.TabIndex = 0;
            // 
            // panel35
            // 
            this.panel35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.mtxtMbid);
            this.panel35.Location = new System.Drawing.Point(126, 4);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(195, 28);
            this.panel35.TabIndex = 15;
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(2, 2);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 32);
            this.label45.TabIndex = 0;
            this.label45.Text = "회원_번호";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel44);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 142);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1650, 759);
            this.panel6.TabIndex = 16;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dGridCtrl_Base);
            this.panel8.Controls.Add(this.dGridView_Base_Sum);
            this.panel8.Location = new System.Drawing.Point(12, 37);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1386, 374);
            this.panel8.TabIndex = 28;
            // 
            // dGridCtrl_Base
            // 
            this.dGridCtrl_Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridCtrl_Base.Location = new System.Drawing.Point(177, 0);
            this.dGridCtrl_Base.MainView = this.dGridView_Base;
            this.dGridCtrl_Base.Name = "dGridCtrl_Base";
            this.dGridCtrl_Base.Size = new System.Drawing.Size(1209, 374);
            this.dGridCtrl_Base.TabIndex = 12;
            this.dGridCtrl_Base.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.dGridView_Base});
            // 
            // dGridView_Base
            // 
            this.dGridView_Base.GridControl = this.dGridCtrl_Base;
            this.dGridView_Base.IndicatorWidth = 35;
            this.dGridView_Base.Name = "dGridView_Base";
            this.dGridView_Base.OptionsBehavior.AutoSelectAllInEditor = false;
            this.dGridView_Base.OptionsBehavior.Editable = false;
            this.dGridView_Base.OptionsBehavior.ReadOnly = true;
            this.dGridView_Base.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.dGridView_Base_RowCellClick);
            this.dGridView_Base.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.dGridView_Base_CustomDrawRowIndicator_1);
            this.dGridView_Base.DoubleClick += new System.EventHandler(this.dGridView_Base_DoubleClick_2);
            // 
            // dGridView_Base_Sum
            // 
            this.dGridView_Base_Sum.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Sum.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Sum.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.dGridView_Base_Sum.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Sum.DefaultCellStyle = dataGridViewCellStyle34;
            this.dGridView_Base_Sum.Dock = System.Windows.Forms.DockStyle.Left;
            this.dGridView_Base_Sum.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Sum.Location = new System.Drawing.Point(0, 0);
            this.dGridView_Base_Sum.Name = "dGridView_Base_Sum";
            this.dGridView_Base_Sum.RowTemplate.Height = 23;
            this.dGridView_Base_Sum.Size = new System.Drawing.Size(177, 374);
            this.dGridView_Base_Sum.TabIndex = 11;
            // 
            // panel44
            // 
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.radioB_Mi_No);
            this.panel44.Controls.Add(this.radioB_Mi);
            this.panel44.Controls.Add(this.button2);
            this.panel44.Controls.Add(this.label30);
            this.panel44.Controls.Add(this.prB);
            this.panel44.Controls.Add(this.label32);
            this.panel44.Controls.Add(this.tableLayoutPanel34);
            this.panel44.Controls.Add(this.butt_Save);
            this.panel44.Controls.Add(this.button1);
            this.panel44.Controls.Add(this.chk_Total);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(1650, 30);
            this.panel44.TabIndex = 27;
            this.panel44.Visible = false;
            // 
            // radioB_Mi_No
            // 
            this.radioB_Mi_No.AutoSize = true;
            this.radioB_Mi_No.Checked = true;
            this.radioB_Mi_No.Location = new System.Drawing.Point(5, 6);
            this.radioB_Mi_No.Name = "radioB_Mi_No";
            this.radioB_Mi_No.Size = new System.Drawing.Size(113, 16);
            this.radioB_Mi_No.TabIndex = 180;
            this.radioB_Mi_No.TabStop = true;
            this.radioB_Mi_No.Text = "미지급으로_적용";
            this.radioB_Mi_No.UseVisualStyleBackColor = true;
            // 
            // radioB_Mi
            // 
            this.radioB_Mi.AutoSize = true;
            this.radioB_Mi.Location = new System.Drawing.Point(1008, 4);
            this.radioB_Mi.Name = "radioB_Mi";
            this.radioB_Mi.Size = new System.Drawing.Size(59, 16);
            this.radioB_Mi.TabIndex = 179;
            this.radioB_Mi.TabStop = true;
            this.radioB_Mi.Text = "미지급";
            this.radioB_Mi.UseVisualStyleBackColor = true;
            this.radioB_Mi.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(590, 41);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 34);
            this.button2.TabIndex = 178;
            this.button2.Text = "현금_영수증_발행";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.ForeColor = System.Drawing.Color.IndianRed;
            this.label30.Location = new System.Drawing.Point(577, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(233, 12);
            this.label30.TabIndex = 88;
            this.label30.Text = "승인일자 미입력시 결제일자 변경 없음";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // prB
            // 
            this.prB.Location = new System.Drawing.Point(325, 15);
            this.prB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.prB.Name = "prB";
            this.prB.Size = new System.Drawing.Size(200, 14);
            this.prB.TabIndex = 177;
            this.prB.Visible = false;
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.ForeColor = System.Drawing.Color.IndianRed;
            this.label32.Location = new System.Drawing.Point(576, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(290, 12);
            this.label32.TabIndex = 87;
            this.label32.Text = "승인일자 입력시 결제일자가 입력된 날짜로 변경";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel34.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel34.ColumnCount = 2;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Controls.Add(this.panel45, 1, 0);
            this.tableLayoutPanel34.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel34.Location = new System.Drawing.Point(227, 50);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 1;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(223, 36);
            this.tableLayoutPanel34.TabIndex = 88;
            this.tableLayoutPanel34.Visible = false;
            // 
            // panel45
            // 
            this.panel45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel45.BackColor = System.Drawing.Color.White;
            this.panel45.Controls.Add(this.mtxtSellDate);
            this.panel45.Controls.Add(this.DTP_SellDate);
            this.panel45.Location = new System.Drawing.Point(126, 4);
            this.panel45.Margin = new System.Windows.Forms.Padding(2);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(93, 28);
            this.panel45.TabIndex = 15;
            // 
            // mtxtSellDate
            // 
            this.mtxtSellDate.Location = new System.Drawing.Point(3, 3);
            this.mtxtSellDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate.Name = "mtxtSellDate";
            this.mtxtSellDate.Size = new System.Drawing.Size(67, 21);
            this.mtxtSellDate.TabIndex = 106;
            // 
            // DTP_SellDate
            // 
            this.DTP_SellDate.Location = new System.Drawing.Point(69, 3);
            this.DTP_SellDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate.Name = "DTP_SellDate";
            this.DTP_SellDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate.TabIndex = 105;
            this.DTP_SellDate.TabStop = false;
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(2, 2);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 32);
            this.label33.TabIndex = 0;
            this.label33.Text = "승인_일자";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.White;
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.Location = new System.Drawing.Point(129, 1);
            this.butt_Save.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(198, 26);
            this.butt_Save.TabIndex = 3;
            this.butt_Save.Text = "선택내역_미지급으로_적용";
            this.butt_Save.UseVisualStyleBackColor = false;
            this.butt_Save.Click += new System.EventHandler(this.butt_Save_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(27, 110);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 26);
            this.button1.TabIndex = 85;
            this.button1.Text = "선택_내역_체크";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // chk_Total
            // 
            this.chk_Total.AutoSize = true;
            this.chk_Total.Location = new System.Drawing.Point(150, 120);
            this.chk_Total.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chk_Total.Name = "chk_Total";
            this.chk_Total.Size = new System.Drawing.Size(78, 16);
            this.chk_Total.TabIndex = 82;
            this.chk_Total.Text = "전체_체크";
            this.chk_Total.UseVisualStyleBackColor = true;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "xlsx";
            this.saveFileDialog1.Filter = "Excel File (*.xlsx)|*.xlsx";
            // 
            // gridView1
            // 
            this.gridView1.IndicatorWidth = 35;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AutoSelectAllInEditor = false;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.ReadOnly = true;
            // 
            // gridView2
            // 
            this.gridView2.IndicatorWidth = 35;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsBehavior.AutoSelectAllInEditor = false;
            this.gridView2.OptionsBehavior.Editable = false;
            this.gridView2.OptionsBehavior.ReadOnly = true;
            // 
            // gridView3
            // 
            this.gridView3.IndicatorWidth = 35;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsBehavior.AutoSelectAllInEditor = false;
            this.gridView3.OptionsBehavior.Editable = false;
            this.gridView3.OptionsBehavior.ReadOnly = true;
            // 
            // frmClose_2_Select_03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(1650, 765);
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1408, 918);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.pn_Button);
            this.KeyPreview = true;
            this.Name = "frmClose_2_Select_03";
            this.Text = "주간_마감_회원별";
            this.Activated += new System.EventHandler(this.frm_Base_Activated);
            this.Load += new System.EventHandler(this.frmBase_From_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            this.Resize += new System.EventHandler(this.frmBase_Resize);
            this.panel9.ResumeLayout(false);
            this.butt_Excel_Detail_Down_Sd.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_2)).EndInit();
            this.tab_Down_N.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_Down_N)).EndInit();
            this.tab_Down_S.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_Down_S)).EndInit();
            this.tab_Down_G.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Down_G)).EndInit();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.tableLayoutPanel50.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel58.PerformLayout();
            this.tableLayoutPanel51.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.tableLayoutPanel44.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.tableLayoutPanel45.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.tableLayoutPanel46.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.tableLayoutPanel47.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.tableLayoutPanel48.ResumeLayout(false);
            this.panel56.ResumeLayout(false);
            this.panel56.PerformLayout();
            this.tableLayoutPanel49.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.tableLayoutPanel35.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.tableLayoutPanel39.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.tableLayoutPanel40.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.tableLayoutPanel41.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.tableLayoutPanel42.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.tableLayoutPanel43.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tableLayoutPanel27.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.tableLayoutPanel17.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.tableLayoutPanel21.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.tableLayoutPanel22.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.tableLayoutPanel24.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.tableLayoutPanel25.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.tableLayoutPanel26.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_1)).EndInit();
            this.tab_save.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_3)).EndInit();
            this.tab_nom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Detail_4)).EndInit();
            this.tab_etc.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.tab_Detail_01.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_2)).EndInit();
            this.tab_Save_D.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_3)).EndInit();
            this.tab_Up.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_4)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_SP)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_5)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_8)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_Cap)).EndInit();
            this.tabPage14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Pay_14)).EndInit();
            this.grB_Search.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pn_Button.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel52.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.tableLayoutPanel23.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.tableLayoutPanel20.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tableLayoutPanel30.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.tableLayoutPanel31.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.tableLayoutPanel32.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tableLayoutPanel36.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridCtrl_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sum)).EndInit();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.tableLayoutPanel34.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TabControl butt_Excel_Detail_Down_Sd;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dGridView_Detail_1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dGridView_Detail_2;
        private System.Windows.Forms.TabPage tab_save;
        private System.Windows.Forms.DataGridView dGridView_Detail_3;
        private System.Windows.Forms.TabPage tab_nom;
        private System.Windows.Forms.DataGridView dGridView_Detail_4;
        private System.Windows.Forms.TabPage tab_etc;
        private System.Windows.Forms.TabControl tab_Detail_01;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dGridView_Pay_1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dGridView_Pay_2;
        private System.Windows.Forms.TabPage tab_Save_D;
        private System.Windows.Forms.DataGridView dGridView_Pay_3;
        private System.Windows.Forms.TabPage tab_Up;
        private System.Windows.Forms.DataGridView dGridView_Pay_4;
        private System.Windows.Forms.GroupBox grB_Search;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtToEndDate_Code;
        private System.Windows.Forms.TextBox txtToEndDate;
        private System.Windows.Forms.ComboBox combo_Grade_Code;
        private System.Windows.Forms.ComboBox combo_Grade;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radio_PayTF2;
        private System.Windows.Forms.RadioButton radio_PayTF1;
        private System.Windows.Forms.TextBox txtCenter_Code;
        private System.Windows.Forms.TextBox txtCenter;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.MaskedTextBox mtxtMbid2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioB_P;
        private System.Windows.Forms.RadioButton radioB_PM_3;
        private System.Windows.Forms.RadioButton radioB_PM_2;
        private System.Windows.Forms.RadioButton radioB_PM_1;
        private System.Windows.Forms.RadioButton radioB_P_7;
        private System.Windows.Forms.RadioButton radioB_P_1;
        private System.Windows.Forms.DateTimePicker DTP_PayDate1;
        private System.Windows.Forms.DateTimePicker DTP_PayDate2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioB_S;
        private System.Windows.Forms.RadioButton radioB_SM_3;
        private System.Windows.Forms.RadioButton radioB_SM_2;
        private System.Windows.Forms.RadioButton radioB_SM_1;
        private System.Windows.Forms.RadioButton radioB_S_7;
        private System.Windows.Forms.RadioButton radioB_S_1;
        private System.Windows.Forms.DateTimePicker DTP_FromDate1;
        private System.Windows.Forms.DateTimePicker DTP_FromDate2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioB_R;
        private System.Windows.Forms.RadioButton radioB_RM_3;
        private System.Windows.Forms.RadioButton radioB_RM_2;
        private System.Windows.Forms.RadioButton radioB_RM_1;
        private System.Windows.Forms.RadioButton radioB_R_7;
        private System.Windows.Forms.RadioButton radioB_R_1;
        private System.Windows.Forms.DateTimePicker DTP_ToDate1;
        private System.Windows.Forms.DateTimePicker DTP_ToDate2;
        private System.Windows.Forms.Button button_base;
        private System.Windows.Forms.Button butt_Exp;
        private System.Windows.Forms.Panel pn_Button;
        private System.Windows.Forms.Button butt_Excel;
        private System.Windows.Forms.Button butt_Delete;
        private System.Windows.Forms.Button butt_Clear;
        private System.Windows.Forms.Button butt_Select;
        private System.Windows.Forms.Button butt_Exit;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.MaskedTextBox mtxtToDate2;
        private System.Windows.Forms.MaskedTextBox mtxtToDate1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.MaskedTextBox mtxtFromDate2;
        private System.Windows.Forms.MaskedTextBox mtxtFromDate1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.MaskedTextBox mtxtPayDate2;
        private System.Windows.Forms.MaskedTextBox mtxtPayDate1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dGridView_Pay_5;
        private System.Windows.Forms.RadioButton radio_PayTF3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txt_Us_num;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dGridView_Pay_SP;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txt_ETC12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox txt_ETC11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox txt_ETC10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox txt_ETC9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txt_ETC8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox txt_ETC7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txt_ETC6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txt_ETC5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txt_ETC4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txt_ETC3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txt_ETC2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txt_ETC1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.CheckBox checkB_20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkB_Up_60;
        private System.Windows.Forms.ComboBox combo_Grade2_Code;
        private System.Windows.Forms.ComboBox combo_Grade2;
        private System.Windows.Forms.TabPage tab_Down_G;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.TextBox txt_ETC9_2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txt_ETC6_2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox txt_ETC11_2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.TextBox txt_ETC7_2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txt_ETC10_2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.TextBox txt_ETC8_2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button butt_G10_1;
        private System.Windows.Forms.Button butt_G40_2;
        private System.Windows.Forms.Button butt_G30_1;
        private System.Windows.Forms.Button butt_G10_2;
        private System.Windows.Forms.Button butt_G50_1;
        private System.Windows.Forms.Button butt_G60_2;
        private System.Windows.Forms.Button butt_G20_1;
        private System.Windows.Forms.Button butt_G20_2;
        private System.Windows.Forms.Button butt_G40_1;
        private System.Windows.Forms.Button butt_G50_2;
        private System.Windows.Forms.Button butt_G60_1;
        private System.Windows.Forms.Button butt_G30_2;
        private System.Windows.Forms.DataGridView dGridView_Down_G;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.CheckBox chk_Leave;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox chk_Leave_Only;
        private System.Windows.Forms.RadioButton checkB_Up;
        private System.Windows.Forms.CheckBox checkB_120;
        private System.Windows.Forms.CheckBox checkB_110;
        private System.Windows.Forms.CheckBox checkB_100;
        private System.Windows.Forms.CheckBox checkB_90;
        private System.Windows.Forms.CheckBox checkB_80;
        private System.Windows.Forms.CheckBox checkB_70;
        private System.Windows.Forms.CheckBox checkB_60;
        private System.Windows.Forms.CheckBox checkB_50;
        private System.Windows.Forms.CheckBox checkB_40;
        private System.Windows.Forms.CheckBox checkB_30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.RadioButton radioB_Su_Not;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioB_Su;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ProgressBar prB;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate;
        private System.Windows.Forms.DateTimePicker DTP_SellDate;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button butt_Save;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chk_Total;
        private System.Windows.Forms.RadioButton radioB_Mi_No;
        private System.Windows.Forms.RadioButton radioB_Mi;
        private System.Windows.Forms.CheckBox checkB_10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Button butt_G70_N;
        private System.Windows.Forms.TextBox txt_ETC_N_7;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Button butt_G90_N;
        private System.Windows.Forms.TextBox txt_ETC_N_9;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Button butt_G110_N;
        private System.Windows.Forms.TextBox txt_ETC_N_11;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Button butt_G80_N;
        private System.Windows.Forms.TextBox txt_ETC_N_8;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Button butt_G100_N;
        private System.Windows.Forms.TextBox txt_ETC_N_10;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel43;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Button butt_G120_N;
        private System.Windows.Forms.TextBox txt_ETC_N_12;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TabPage tab_Down_N;
        private System.Windows.Forms.DataGridView dGridView_Detail_Down_N;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel44;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Button butt_G70_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_7_2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel45;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Button butt_G90_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_9_2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel46;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Button butt_G110_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_11_2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel47;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Button butt_G80_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_8_2;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel48;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Button butt_G100_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_10_2;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel49;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Button butt_G120_N2;
        private System.Windows.Forms.TextBox txt_ETC_N_12_2;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txt_Max_N_LineCnt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel50;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.TextBox txt_ETC_S_D_1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel51;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.TextBox txt_ETC_S_D_2;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.RadioButton radio_PayTF_Not;
        private System.Windows.Forms.TabPage tab_Down_S;
        private System.Windows.Forms.DataGridView dGridView_Detail_Down_S;
        private System.Windows.Forms.ComboBox combo_W_Code_2;
        private System.Windows.Forms.ComboBox combo_W_Code_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel52;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.ComboBox combo_W_2;
        private System.Windows.Forms.ComboBox combo_W_1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dGridView_Pay_Cap;
        private System.Windows.Forms.RadioButton radioB_Leave;
        private System.Windows.Forms.RadioButton radioB_Leave_Not;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.CheckBox checkB_150;
        private System.Windows.Forms.CheckBox checkB_140;
        private System.Windows.Forms.CheckBox checkB_130;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView dGridView_Pay_8;
        private System.Windows.Forms.RadioButton radio_PayTF_ALL;
        private System.Windows.Forms.RadioButton radio_PayTF_Re_D_2;
        private System.Windows.Forms.RadioButton radio_PayTF_Re_D_1;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.DataGridView dGridView_Pay_14;
        //private DevExpress.XtraGrid.GridControl dGridCtrl_Base;
        //private DevExpress.XtraGrid.Views.Grid.GridView dGridView_Base;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private System.Windows.Forms.Panel panel8;
        private DevExpress.XtraGrid.GridControl dGridCtrl_Base;
        private DevExpress.XtraGrid.Views.Grid.GridView dGridView_Base;
        private System.Windows.Forms.DataGridView dGridView_Base_Sum;
        private System.Windows.Forms.Button butt_Excel_Detail_2;
        private System.Windows.Forms.Button butt_Excel_Detail_Down_N;
        private System.Windows.Forms.Button butt_Excel_Detail_Down_S;
        private System.Windows.Forms.Button butt_Excel_Detail_3;
        private System.Windows.Forms.Button butt_Excel_Detail_4;
        private System.Windows.Forms.Button butt_Excel_Pay_1;
        private System.Windows.Forms.Button butt_Excel_Pay_2;
        private System.Windows.Forms.Button butt_Excel_Pay_3;
        private System.Windows.Forms.Button butt_Excel_Pay_4;
        private System.Windows.Forms.Button butt_Excel_Pay_SP;
        private System.Windows.Forms.Button butt_Excel_Pay_5;
        private System.Windows.Forms.Button butt_Excel_Pay_8;
    }
}