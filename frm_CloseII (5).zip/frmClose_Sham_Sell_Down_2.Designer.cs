﻿namespace MLM_Program
{
    partial class frmClose_Sham_Sell_Down_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dGridView_Base_Sub = new System.Windows.Forms.DataGridView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.mtxtMakeDate2 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtMakeDate1 = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DTP_MakeDate2 = new System.Windows.Forms.DateTimePicker();
            this.DTP_MakeDate1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.mtxtSMbid = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.combo_Se_Code2 = new System.Windows.Forms.ComboBox();
            this.combo_Se2 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.mtxtSMbid2 = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioB_S = new System.Windows.Forms.RadioButton();
            this.radioB_SM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_SM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_S_7 = new System.Windows.Forms.RadioButton();
            this.radioB_S_1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioB_R = new System.Windows.Forms.RadioButton();
            this.radioB_RM_3 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_2 = new System.Windows.Forms.RadioButton();
            this.radioB_RM_1 = new System.Windows.Forms.RadioButton();
            this.radioB_R_7 = new System.Windows.Forms.RadioButton();
            this.radioB_R_1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txtR_Id_Code = new System.Windows.Forms.TextBox();
            this.txtR_Id = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.txtName2 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.butt_Excel = new System.Windows.Forms.Button();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.mtxtSellDate3 = new System.Windows.Forms.MaskedTextBox();
            this.mtxtSellDate2 = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.DTP_SellDate3 = new System.Windows.Forms.DateTimePicker();
            this.DTP_SellDate2 = new System.Windows.Forms.DateTimePicker();
            this.label45 = new System.Windows.Forms.Label();
            this.butt_Search = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioB_SellTF1 = new System.Windows.Forms.RadioButton();
            this.radioB_SellTF2 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_Pv = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.mtxtMbid = new System.Windows.Forms.MaskedTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtSellCode_Code = new System.Windows.Forms.TextBox();
            this.txtSellCode = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.mtxtSellDate = new System.Windows.Forms.MaskedTextBox();
            this.DTP_SellDate = new System.Windows.Forms.DateTimePicker();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.txtName = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.butt_Delete = new System.Windows.Forms.Button();
            this.butt_Clear = new System.Windows.Forms.Button();
            this.butt_Save = new System.Windows.Forms.Button();
            this.butt_Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sub)).BeginInit();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.panel30.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel13.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel19.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dGridView_Base_Sub
            // 
            this.dGridView_Base_Sub.BackgroundColor = System.Drawing.Color.White;
            this.dGridView_Base_Sub.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dGridView_Base_Sub.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGridView_Base_Sub.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGridView_Base_Sub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("굴림", 9F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGridView_Base_Sub.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGridView_Base_Sub.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGridView_Base_Sub.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dGridView_Base_Sub.Location = new System.Drawing.Point(286, 144);
            this.dGridView_Base_Sub.Margin = new System.Windows.Forms.Padding(3, 0, 3, 4);
            this.dGridView_Base_Sub.Name = "dGridView_Base_Sub";
            this.dGridView_Base_Sub.RowHeadersWidth = 30;
            this.dGridView_Base_Sub.RowTemplate.Height = 23;
            this.dGridView_Base_Sub.Size = new System.Drawing.Size(1014, 656);
            this.dGridView_Base_Sub.TabIndex = 35;
            this.dGridView_Base_Sub.DoubleClick += new System.EventHandler(this.dGridView_Base_Sub_DoubleClick);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.tableLayoutPanel10);
            this.panel10.Controls.Add(this.tableLayoutPanel4);
            this.panel10.Controls.Add(this.tableLayoutPanel3);
            this.panel10.Controls.Add(this.panel2);
            this.panel10.Controls.Add(this.tableLayoutPanel33);
            this.panel10.Controls.Add(this.tableLayoutPanel37);
            this.panel10.Controls.Add(this.butt_Excel);
            this.panel10.Controls.Add(this.tableLayoutPanel38);
            this.panel10.Controls.Add(this.butt_Search);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(286, 28);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1014, 116);
            this.panel10.TabIndex = 36;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel10.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.panel15, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 77);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel10.TabIndex = 17;
            // 
            // panel15
            // 
            this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.mtxtMakeDate2);
            this.panel15.Controls.Add(this.mtxtMakeDate1);
            this.panel15.Controls.Add(this.label4);
            this.panel15.Controls.Add(this.DTP_MakeDate2);
            this.panel15.Controls.Add(this.DTP_MakeDate1);
            this.panel15.Location = new System.Drawing.Point(126, 4);
            this.panel15.Margin = new System.Windows.Forms.Padding(2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(195, 28);
            this.panel15.TabIndex = 15;
            // 
            // mtxtMakeDate2
            // 
            this.mtxtMakeDate2.Location = new System.Drawing.Point(104, 3);
            this.mtxtMakeDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtMakeDate2.Name = "mtxtMakeDate2";
            this.mtxtMakeDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtMakeDate2.TabIndex = 145;
            this.mtxtMakeDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMakeDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtMakeDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtMakeDate1
            // 
            this.mtxtMakeDate1.Location = new System.Drawing.Point(3, 3);
            this.mtxtMakeDate1.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtMakeDate1.Name = "mtxtMakeDate1";
            this.mtxtMakeDate1.Size = new System.Drawing.Size(67, 21);
            this.mtxtMakeDate1.TabIndex = 0;
            this.mtxtMakeDate1.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMakeDate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtMakeDate1.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(94, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(9, 15);
            this.label4.TabIndex = 60;
            this.label4.Text = "~";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DTP_MakeDate2
            // 
            this.DTP_MakeDate2.Location = new System.Drawing.Point(170, 3);
            this.DTP_MakeDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_MakeDate2.Name = "DTP_MakeDate2";
            this.DTP_MakeDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_MakeDate2.TabIndex = 144;
            this.DTP_MakeDate2.TabStop = false;
            this.DTP_MakeDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_MakeDate1
            // 
            this.DTP_MakeDate1.Location = new System.Drawing.Point(69, 3);
            this.DTP_MakeDate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_MakeDate1.Name = "DTP_MakeDate1";
            this.DTP_MakeDate1.Size = new System.Drawing.Size(21, 21);
            this.DTP_MakeDate1.TabIndex = 62;
            this.DTP_MakeDate1.TabStop = false;
            this.DTP_MakeDate1.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "기록일";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel7, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.mtxtSMbid);
            this.panel7.Location = new System.Drawing.Point(126, 4);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(195, 28);
            this.panel7.TabIndex = 15;
            // 
            // mtxtSMbid
            // 
            this.mtxtSMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtSMbid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtSMbid.Name = "mtxtSMbid";
            this.mtxtSMbid.Size = new System.Drawing.Size(188, 21);
            this.mtxtSMbid.TabIndex = 0;
            this.mtxtSMbid.TextChanged += new System.EventHandler(this.S_MtxtMbid_TextChanged);
            this.mtxtSMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.S_MtxtData_KeyPress);
            this.mtxtSMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 32);
            this.label3.TabIndex = 0;
            this.label3.Text = "회원번호";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel16, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 107);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel3.TabIndex = 2;
            this.tableLayoutPanel3.Visible = false;
            // 
            // panel16
            // 
            this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.combo_Se_Code2);
            this.panel16.Controls.Add(this.combo_Se2);
            this.panel16.Location = new System.Drawing.Point(126, 4);
            this.panel16.Margin = new System.Windows.Forms.Padding(2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(195, 28);
            this.panel16.TabIndex = 15;
            // 
            // combo_Se_Code2
            // 
            this.combo_Se_Code2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se_Code2.Enabled = false;
            this.combo_Se_Code2.FormattingEnabled = true;
            this.combo_Se_Code2.Location = new System.Drawing.Point(148, 3);
            this.combo_Se_Code2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Se_Code2.Name = "combo_Se_Code2";
            this.combo_Se_Code2.Size = new System.Drawing.Size(46, 20);
            this.combo_Se_Code2.TabIndex = 203;
            this.combo_Se_Code2.TabStop = false;
            // 
            // combo_Se2
            // 
            this.combo_Se2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.combo_Se2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Se2.FormattingEnabled = true;
            this.combo_Se2.Location = new System.Drawing.Point(3, 3);
            this.combo_Se2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.combo_Se2.Name = "combo_Se2";
            this.combo_Se2.Size = new System.Drawing.Size(144, 20);
            this.combo_Se2.TabIndex = 203;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(2, 2);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 32);
            this.label13.TabIndex = 0;
            this.label13.Text = "구매종류";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel9);
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Location = new System.Drawing.Point(729, 89);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(84, 66);
            this.panel2.TabIndex = 6;
            this.panel2.Visible = false;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(5, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(224, 36);
            this.tableLayoutPanel9.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Location = new System.Drawing.Point(5, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 32);
            this.label10.TabIndex = 13;
            this.label10.Text = "회원_번호";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.mtxtSMbid2);
            this.panel3.Location = new System.Drawing.Point(114, 5);
            this.panel3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.panel3.Size = new System.Drawing.Size(108, 26);
            this.panel3.TabIndex = 90;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(5, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(9, 15);
            this.label14.TabIndex = 17;
            this.label14.Text = "-";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Visible = false;
            // 
            // mtxtSMbid2
            // 
            this.mtxtSMbid2.Location = new System.Drawing.Point(1, 37);
            this.mtxtSMbid2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mtxtSMbid2.Name = "mtxtSMbid2";
            this.mtxtSMbid2.Size = new System.Drawing.Size(100, 21);
            this.mtxtSMbid2.TabIndex = 1;
            this.mtxtSMbid2.Visible = false;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 268);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(224, 198);
            this.tableLayoutPanel7.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(5, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 194);
            this.label5.TabIndex = 12;
            this.label5.Text = "기록일";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.radioB_S);
            this.panel4.Controls.Add(this.radioB_SM_3);
            this.panel4.Controls.Add(this.radioB_SM_2);
            this.panel4.Controls.Add(this.radioB_SM_1);
            this.panel4.Controls.Add(this.radioB_S_7);
            this.panel4.Controls.Add(this.radioB_S_1);
            this.panel4.Location = new System.Drawing.Point(117, 6);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(102, 186);
            this.panel4.TabIndex = 90;
            // 
            // radioB_S
            // 
            this.radioB_S.AutoSize = true;
            this.radioB_S.Location = new System.Drawing.Point(3, 166);
            this.radioB_S.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S.Name = "radioB_S";
            this.radioB_S.Size = new System.Drawing.Size(47, 16);
            this.radioB_S.TabIndex = 147;
            this.radioB_S.Tag = "T_1";
            this.radioB_S.Text = "전체";
            this.radioB_S.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_3
            // 
            this.radioB_SM_3.AutoSize = true;
            this.radioB_SM_3.Location = new System.Drawing.Point(3, 144);
            this.radioB_SM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_3.Name = "radioB_SM_3";
            this.radioB_SM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_SM_3.TabIndex = 146;
            this.radioB_SM_3.Tag = "M_3";
            this.radioB_SM_3.Text = "최근3개월";
            this.radioB_SM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_2
            // 
            this.radioB_SM_2.AutoSize = true;
            this.radioB_SM_2.Location = new System.Drawing.Point(3, 124);
            this.radioB_SM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_2.Name = "radioB_SM_2";
            this.radioB_SM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_2.TabIndex = 145;
            this.radioB_SM_2.Tag = "M_2";
            this.radioB_SM_2.Text = "전월";
            this.radioB_SM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_SM_1
            // 
            this.radioB_SM_1.AutoSize = true;
            this.radioB_SM_1.Location = new System.Drawing.Point(3, 104);
            this.radioB_SM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_SM_1.Name = "radioB_SM_1";
            this.radioB_SM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_SM_1.TabIndex = 144;
            this.radioB_SM_1.Tag = "M_1";
            this.radioB_SM_1.Text = "당월";
            this.radioB_SM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_S_7
            // 
            this.radioB_S_7.AutoSize = true;
            this.radioB_S_7.Location = new System.Drawing.Point(3, 84);
            this.radioB_S_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_7.Name = "radioB_S_7";
            this.radioB_S_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_S_7.TabIndex = 143;
            this.radioB_S_7.Tag = "D_7";
            this.radioB_S_7.Text = "최근7일";
            this.radioB_S_7.UseVisualStyleBackColor = true;
            // 
            // radioB_S_1
            // 
            this.radioB_S_1.AutoSize = true;
            this.radioB_S_1.Location = new System.Drawing.Point(3, 64);
            this.radioB_S_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_S_1.Name = "radioB_S_1";
            this.radioB_S_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_S_1.TabIndex = 142;
            this.radioB_S_1.Tag = "D_1";
            this.radioB_S_1.Text = "당일";
            this.radioB_S_1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel8, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 39);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(224, 198);
            this.tableLayoutPanel2.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(5, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 194);
            this.label8.TabIndex = 12;
            this.label8.Text = "적용_일자";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.Controls.Add(this.radioB_R);
            this.panel8.Controls.Add(this.radioB_RM_3);
            this.panel8.Controls.Add(this.radioB_RM_2);
            this.panel8.Controls.Add(this.radioB_RM_1);
            this.panel8.Controls.Add(this.radioB_R_7);
            this.panel8.Controls.Add(this.radioB_R_1);
            this.panel8.Location = new System.Drawing.Point(117, 6);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(102, 186);
            this.panel8.TabIndex = 90;
            // 
            // radioB_R
            // 
            this.radioB_R.AutoSize = true;
            this.radioB_R.Location = new System.Drawing.Point(3, 166);
            this.radioB_R.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R.Name = "radioB_R";
            this.radioB_R.Size = new System.Drawing.Size(47, 16);
            this.radioB_R.TabIndex = 147;
            this.radioB_R.Tag = "T_1";
            this.radioB_R.Text = "전체";
            this.radioB_R.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_3
            // 
            this.radioB_RM_3.AutoSize = true;
            this.radioB_RM_3.Location = new System.Drawing.Point(3, 144);
            this.radioB_RM_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_3.Name = "radioB_RM_3";
            this.radioB_RM_3.Size = new System.Drawing.Size(77, 16);
            this.radioB_RM_3.TabIndex = 146;
            this.radioB_RM_3.Tag = "M_3";
            this.radioB_RM_3.Text = "최근3개월";
            this.radioB_RM_3.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_2
            // 
            this.radioB_RM_2.AutoSize = true;
            this.radioB_RM_2.Location = new System.Drawing.Point(3, 124);
            this.radioB_RM_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_2.Name = "radioB_RM_2";
            this.radioB_RM_2.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_2.TabIndex = 145;
            this.radioB_RM_2.Tag = "M_2";
            this.radioB_RM_2.Text = "전월";
            this.radioB_RM_2.UseVisualStyleBackColor = true;
            // 
            // radioB_RM_1
            // 
            this.radioB_RM_1.AutoSize = true;
            this.radioB_RM_1.Location = new System.Drawing.Point(3, 104);
            this.radioB_RM_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_RM_1.Name = "radioB_RM_1";
            this.radioB_RM_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_RM_1.TabIndex = 144;
            this.radioB_RM_1.Tag = "M_1";
            this.radioB_RM_1.Text = "당월";
            this.radioB_RM_1.UseVisualStyleBackColor = true;
            // 
            // radioB_R_7
            // 
            this.radioB_R_7.AutoSize = true;
            this.radioB_R_7.Location = new System.Drawing.Point(3, 84);
            this.radioB_R_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_7.Name = "radioB_R_7";
            this.radioB_R_7.Size = new System.Drawing.Size(65, 16);
            this.radioB_R_7.TabIndex = 143;
            this.radioB_R_7.Tag = "D_7";
            this.radioB_R_7.Text = "최근7일";
            this.radioB_R_7.UseVisualStyleBackColor = true;
            // 
            // radioB_R_1
            // 
            this.radioB_R_1.AutoSize = true;
            this.radioB_R_1.Location = new System.Drawing.Point(3, 64);
            this.radioB_R_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioB_R_1.Name = "radioB_R_1";
            this.radioB_R_1.Size = new System.Drawing.Size(47, 16);
            this.radioB_R_1.TabIndex = 142;
            this.radioB_R_1.Tag = "D_1";
            this.radioB_R_1.Text = "당일";
            this.radioB_R_1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel33.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel33.ColumnCount = 2;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.panel26, 1, 0);
            this.tableLayoutPanel33.Controls.Add(this.label39, 0, 0);
            this.tableLayoutPanel33.Location = new System.Drawing.Point(329, 40);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 1;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel33.TabIndex = 3;
            // 
            // panel26
            // 
            this.panel26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.txtR_Id_Code);
            this.panel26.Controls.Add(this.txtR_Id);
            this.panel26.Location = new System.Drawing.Point(126, 4);
            this.panel26.Margin = new System.Windows.Forms.Padding(2);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(195, 28);
            this.panel26.TabIndex = 15;
            // 
            // txtR_Id_Code
            // 
            this.txtR_Id_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtR_Id_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtR_Id_Code.ForeColor = System.Drawing.Color.White;
            this.txtR_Id_Code.Location = new System.Drawing.Point(147, 3);
            this.txtR_Id_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtR_Id_Code.MaxLength = 30;
            this.txtR_Id_Code.Name = "txtR_Id_Code";
            this.txtR_Id_Code.Size = new System.Drawing.Size(46, 22);
            this.txtR_Id_Code.TabIndex = 81;
            this.txtR_Id_Code.TabStop = false;
            // 
            // txtR_Id
            // 
            this.txtR_Id.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtR_Id.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtR_Id.Location = new System.Drawing.Point(3, 3);
            this.txtR_Id.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtR_Id.MaxLength = 30;
            this.txtR_Id.Name = "txtR_Id";
            this.txtR_Id.Size = new System.Drawing.Size(144, 22);
            this.txtR_Id.TabIndex = 6;
            this.txtR_Id.Tag = "ncode";
            this.txtR_Id.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            this.txtR_Id.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtR_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtR_Id.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label39
            // 
            this.label39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(2, 2);
            this.label39.Margin = new System.Windows.Forms.Padding(0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(120, 32);
            this.label39.TabIndex = 0;
            this.label39.Text = "기록자";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel37.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel37.ColumnCount = 2;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.panel30, 1, 0);
            this.tableLayoutPanel37.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel37.Location = new System.Drawing.Point(329, 3);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 1;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel37.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel30.BackColor = System.Drawing.Color.White;
            this.panel30.Controls.Add(this.txtName2);
            this.panel30.Location = new System.Drawing.Point(126, 4);
            this.panel30.Margin = new System.Windows.Forms.Padding(2);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(195, 28);
            this.panel30.TabIndex = 15;
            // 
            // txtName2
            // 
            this.txtName2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName2.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName2.Location = new System.Drawing.Point(3, 3);
            this.txtName2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtName2.MaxLength = 30;
            this.txtName2.Name = "txtName2";
            this.txtName2.Size = new System.Drawing.Size(188, 22);
            this.txtName2.TabIndex = 2;
            this.txtName2.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(2, 2);
            this.label44.Margin = new System.Windows.Forms.Padding(0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(120, 32);
            this.label44.TabIndex = 0;
            this.label44.Text = "성명";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Excel
            // 
            this.butt_Excel.BackColor = System.Drawing.Color.White;
            this.butt_Excel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Excel.Location = new System.Drawing.Point(655, 41);
            this.butt_Excel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Excel.Name = "butt_Excel";
            this.butt_Excel.Size = new System.Drawing.Size(146, 36);
            this.butt_Excel.TabIndex = 4;
            this.butt_Excel.TabStop = false;
            this.butt_Excel.Text = "엑셀";
            this.butt_Excel.UseVisualStyleBackColor = false;
            this.butt_Excel.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel38.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel38.ColumnCount = 2;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.panel31, 1, 0);
            this.tableLayoutPanel38.Controls.Add(this.label45, 0, 0);
            this.tableLayoutPanel38.Location = new System.Drawing.Point(3, 40);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 1;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(325, 36);
            this.tableLayoutPanel38.TabIndex = 4;
            // 
            // panel31
            // 
            this.panel31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel31.BackColor = System.Drawing.Color.White;
            this.panel31.Controls.Add(this.mtxtSellDate3);
            this.panel31.Controls.Add(this.mtxtSellDate2);
            this.panel31.Controls.Add(this.label38);
            this.panel31.Controls.Add(this.DTP_SellDate3);
            this.panel31.Controls.Add(this.DTP_SellDate2);
            this.panel31.Location = new System.Drawing.Point(126, 4);
            this.panel31.Margin = new System.Windows.Forms.Padding(2);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(195, 28);
            this.panel31.TabIndex = 15;
            // 
            // mtxtSellDate3
            // 
            this.mtxtSellDate3.Location = new System.Drawing.Point(104, 3);
            this.mtxtSellDate3.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate3.Name = "mtxtSellDate3";
            this.mtxtSellDate3.Size = new System.Drawing.Size(67, 21);
            this.mtxtSellDate3.TabIndex = 145;
            this.mtxtSellDate3.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSellDate3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtSellDate3.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // mtxtSellDate2
            // 
            this.mtxtSellDate2.Location = new System.Drawing.Point(3, 3);
            this.mtxtSellDate2.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate2.Name = "mtxtSellDate2";
            this.mtxtSellDate2.Size = new System.Drawing.Size(67, 21);
            this.mtxtSellDate2.TabIndex = 0;
            this.mtxtSellDate2.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSellDate2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtSellDate2.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(94, 8);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(9, 15);
            this.label38.TabIndex = 60;
            this.label38.Text = "~";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DTP_SellDate3
            // 
            this.DTP_SellDate3.Location = new System.Drawing.Point(170, 3);
            this.DTP_SellDate3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate3.Name = "DTP_SellDate3";
            this.DTP_SellDate3.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate3.TabIndex = 144;
            this.DTP_SellDate3.TabStop = false;
            this.DTP_SellDate3.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // DTP_SellDate2
            // 
            this.DTP_SellDate2.Location = new System.Drawing.Point(69, 3);
            this.DTP_SellDate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate2.Name = "DTP_SellDate2";
            this.DTP_SellDate2.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate2.TabIndex = 62;
            this.DTP_SellDate2.TabStop = false;
            this.DTP_SellDate2.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(2, 2);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 32);
            this.label45.TabIndex = 0;
            this.label45.Text = "적용_일자";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // butt_Search
            // 
            this.butt_Search.BackColor = System.Drawing.Color.White;
            this.butt_Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Search.Location = new System.Drawing.Point(655, 4);
            this.butt_Search.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Search.Name = "butt_Search";
            this.butt_Search.Size = new System.Drawing.Size(146, 36);
            this.butt_Search.TabIndex = 16;
            this.butt_Search.TabStop = false;
            this.butt_Search.Text = "조회";
            this.butt_Search.UseVisualStyleBackColor = false;
            this.butt_Search.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tableLayoutPanel1);
            this.panel9.Controls.Add(this.tableLayoutPanel16);
            this.panel9.Controls.Add(this.tableLayoutPanel14);
            this.panel9.Controls.Add(this.groupBox3);
            this.panel9.Controls.Add(this.tableLayoutPanel6);
            this.panel9.Controls.Add(this.groupBox1);
            this.panel9.Controls.Add(this.tableLayoutPanel13);
            this.panel9.Controls.Add(this.tableLayoutPanel5);
            this.panel9.Controls.Add(this.tableLayoutPanel15);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 28);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(286, 772);
            this.panel9.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 153);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel1.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "적용_라인";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.radioB_SellTF1);
            this.panel5.Controls.Add(this.radioB_SellTF2);
            this.panel5.Location = new System.Drawing.Point(126, 4);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(151, 28);
            this.panel5.TabIndex = 15;
            // 
            // radioB_SellTF1
            // 
            this.radioB_SellTF1.AutoSize = true;
            this.radioB_SellTF1.Checked = true;
            this.radioB_SellTF1.Location = new System.Drawing.Point(6, 5);
            this.radioB_SellTF1.Name = "radioB_SellTF1";
            this.radioB_SellTF1.Size = new System.Drawing.Size(47, 16);
            this.radioB_SellTF1.TabIndex = 55;
            this.radioB_SellTF1.TabStop = true;
            this.radioB_SellTF1.Text = "좌측";
            this.radioB_SellTF1.UseVisualStyleBackColor = true;
            // 
            // radioB_SellTF2
            // 
            this.radioB_SellTF2.AutoSize = true;
            this.radioB_SellTF2.Location = new System.Drawing.Point(72, 5);
            this.radioB_SellTF2.Name = "radioB_SellTF2";
            this.radioB_SellTF2.Size = new System.Drawing.Size(47, 16);
            this.radioB_SellTF2.TabIndex = 56;
            this.radioB_SellTF2.Text = "우측";
            this.radioB_SellTF2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel16.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel16.ColumnCount = 2;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 191);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 1;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel16.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 2);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 33);
            this.label19.TabIndex = 0;
            this.label19.Text = "비고";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel14
            // 
            this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.txtRemark);
            this.panel14.Location = new System.Drawing.Point(126, 4);
            this.panel14.Margin = new System.Windows.Forms.Padding(2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(151, 28);
            this.panel14.TabIndex = 15;
            // 
            // txtRemark
            // 
            this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRemark.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtRemark.Location = new System.Drawing.Point(3, 3);
            this.txtRemark.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtRemark.MaxLength = 50;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(145, 22);
            this.txtRemark.TabIndex = 4;
            this.txtRemark.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtRemark.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtRemark.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel14.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.panel12, 1, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 115);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel14.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(2, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 33);
            this.label16.TabIndex = 0;
            this.label16.Text = "적용_BV";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel12
            // 
            this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.txt_Pv);
            this.panel12.Location = new System.Drawing.Point(126, 4);
            this.panel12.Margin = new System.Windows.Forms.Padding(2);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(151, 28);
            this.panel12.TabIndex = 15;
            // 
            // txt_Pv
            // 
            this.txt_Pv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Pv.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txt_Pv.Location = new System.Drawing.Point(3, 3);
            this.txt_Pv.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txt_Pv.MaxLength = 8;
            this.txt_Pv.Name = "txt_Pv";
            this.txt_Pv.Size = new System.Drawing.Size(145, 22);
            this.txt_Pv.TabIndex = 0;
            this.txt_Pv.Tag = "-1";
            this.txt_Pv.Enter += new System.EventHandler(this.txtData_Enter);
            this.txt_Pv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txt_Pv.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(86, 450);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(79, 55);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            this.groupBox3.Visible = false;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel6.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.panel11, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(2, 2);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 33);
            this.label12.TabIndex = 0;
            this.label12.Text = "회원번호";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel11
            // 
            this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.mtxtMbid);
            this.panel11.Location = new System.Drawing.Point(126, 4);
            this.panel11.Margin = new System.Windows.Forms.Padding(2);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(151, 28);
            this.panel11.TabIndex = 15;
            // 
            // mtxtMbid
            // 
            this.mtxtMbid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mtxtMbid.AsciiOnly = true;
            this.mtxtMbid.Location = new System.Drawing.Point(3, 3);
            this.mtxtMbid.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtMbid.Name = "mtxtMbid";
            this.mtxtMbid.Size = new System.Drawing.Size(145, 21);
            this.mtxtMbid.TabIndex = 0;
            this.mtxtMbid.Click += new System.EventHandler(this.mtxtMbid_Click);
            this.mtxtMbid.TextChanged += new System.EventHandler(this.mtxtMbid_TextChanged);
            this.mtxtMbid.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtMbid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_KeyPress);
            this.mtxtMbid.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(76, 315);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(132, 87);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel13.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.label7, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.panel13, 1, 0);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(7, 300);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel13.TabIndex = 3;
            this.tableLayoutPanel13.Visible = false;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(2, 2);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 33);
            this.label7.TabIndex = 0;
            this.label7.Text = "구매_종류";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel13
            // 
            this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.txtSellCode_Code);
            this.panel13.Controls.Add(this.txtSellCode);
            this.panel13.Location = new System.Drawing.Point(126, 4);
            this.panel13.Margin = new System.Windows.Forms.Padding(2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(151, 28);
            this.panel13.TabIndex = 15;
            // 
            // txtSellCode_Code
            // 
            this.txtSellCode_Code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.txtSellCode_Code.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode_Code.ForeColor = System.Drawing.Color.White;
            this.txtSellCode_Code.Location = new System.Drawing.Point(98, 3);
            this.txtSellCode_Code.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode_Code.MaxLength = 30;
            this.txtSellCode_Code.Name = "txtSellCode_Code";
            this.txtSellCode_Code.Size = new System.Drawing.Size(51, 22);
            this.txtSellCode_Code.TabIndex = 103;
            // 
            // txtSellCode
            // 
            this.txtSellCode.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtSellCode.Location = new System.Drawing.Point(3, 3);
            this.txtSellCode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSellCode.MaxLength = 30;
            this.txtSellCode.Name = "txtSellCode";
            this.txtSellCode.Size = new System.Drawing.Size(95, 22);
            this.txtSellCode.TabIndex = 1;
            this.txtSellCode.Tag = "ncode";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.panel19, 1, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 77);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(2, 2);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 33);
            this.label17.TabIndex = 0;
            this.label17.Text = "적용_일자";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Controls.Add(this.mtxtSellDate);
            this.panel19.Controls.Add(this.DTP_SellDate);
            this.panel19.Location = new System.Drawing.Point(126, 4);
            this.panel19.Margin = new System.Windows.Forms.Padding(2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(151, 28);
            this.panel19.TabIndex = 15;
            // 
            // mtxtSellDate
            // 
            this.mtxtSellDate.Location = new System.Drawing.Point(3, 3);
            this.mtxtSellDate.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.mtxtSellDate.Name = "mtxtSellDate";
            this.mtxtSellDate.Size = new System.Drawing.Size(80, 21);
            this.mtxtSellDate.TabIndex = 1;
            this.mtxtSellDate.Enter += new System.EventHandler(this.txtData_Enter);
            this.mtxtSellDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MtxtData_Temp_KeyPress);
            this.mtxtSellDate.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // DTP_SellDate
            // 
            this.DTP_SellDate.Location = new System.Drawing.Point(82, 3);
            this.DTP_SellDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DTP_SellDate.Name = "DTP_SellDate";
            this.DTP_SellDate.Size = new System.Drawing.Size(21, 21);
            this.DTP_SellDate.TabIndex = 105;
            this.DTP_SellDate.TabStop = false;
            this.DTP_SellDate.CloseUp += new System.EventHandler(this.DTP_Base_CloseUp);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.tableLayoutPanel15.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.panel35, 1, 0);
            this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 39);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(281, 37);
            this.tableLayoutPanel15.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(117)))), ((int)(((byte)(159)))));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(2, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 33);
            this.label18.TabIndex = 0;
            this.label18.Text = "성명";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel35
            // 
            this.panel35.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.txtName);
            this.panel35.Location = new System.Drawing.Point(126, 4);
            this.panel35.Margin = new System.Windows.Forms.Padding(2);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(151, 28);
            this.panel35.TabIndex = 15;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtName.Location = new System.Drawing.Point(3, 3);
            this.txtName.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(145, 22);
            this.txtName.TabIndex = 1;
            this.txtName.Tag = "name";
            this.txtName.Enter += new System.EventHandler(this.txtData_Enter);
            this.txtName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtData_KeyPress);
            this.txtName.Leave += new System.EventHandler(this.txtData_Base_Leave);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtKey);
            this.panel1.Controls.Add(this.butt_Delete);
            this.panel1.Controls.Add(this.butt_Clear);
            this.panel1.Controls.Add(this.butt_Save);
            this.panel1.Controls.Add(this.butt_Exit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 28);
            this.panel1.TabIndex = 1;
            // 
            // txtKey
            // 
            this.txtKey.Font = new System.Drawing.Font("굴림", 9.75F);
            this.txtKey.Location = new System.Drawing.Point(18, 0);
            this.txtKey.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtKey.MaxLength = 50;
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(76, 22);
            this.txtKey.TabIndex = 10;
            this.txtKey.TabStop = false;
            this.txtKey.Visible = false;
            // 
            // butt_Delete
            // 
            this.butt_Delete.BackColor = System.Drawing.Color.White;
            this.butt_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Delete.Location = new System.Drawing.Point(125, 1);
            this.butt_Delete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Delete.Name = "butt_Delete";
            this.butt_Delete.Size = new System.Drawing.Size(111, 26);
            this.butt_Delete.TabIndex = 3;
            this.butt_Delete.TabStop = false;
            this.butt_Delete.Text = "삭제";
            this.butt_Delete.UseVisualStyleBackColor = false;
            this.butt_Delete.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Clear
            // 
            this.butt_Clear.BackColor = System.Drawing.Color.White;
            this.butt_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Clear.Location = new System.Drawing.Point(266, 1);
            this.butt_Clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Clear.Name = "butt_Clear";
            this.butt_Clear.Size = new System.Drawing.Size(111, 26);
            this.butt_Clear.TabIndex = 2;
            this.butt_Clear.TabStop = false;
            this.butt_Clear.Text = "새로입력";
            this.butt_Clear.UseVisualStyleBackColor = false;
            this.butt_Clear.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Save
            // 
            this.butt_Save.BackColor = System.Drawing.Color.White;
            this.butt_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Save.Location = new System.Drawing.Point(411, 1);
            this.butt_Save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Save.Name = "butt_Save";
            this.butt_Save.Size = new System.Drawing.Size(111, 26);
            this.butt_Save.TabIndex = 5;
            this.butt_Save.Text = "저장";
            this.butt_Save.UseVisualStyleBackColor = false;
            this.butt_Save.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // butt_Exit
            // 
            this.butt_Exit.BackColor = System.Drawing.Color.White;
            this.butt_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butt_Exit.Location = new System.Drawing.Point(658, 1);
            this.butt_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butt_Exit.Name = "butt_Exit";
            this.butt_Exit.Size = new System.Drawing.Size(111, 26);
            this.butt_Exit.TabIndex = 0;
            this.butt_Exit.TabStop = false;
            this.butt_Exit.Text = "닫기";
            this.butt_Exit.UseVisualStyleBackColor = false;
            this.butt_Exit.Click += new System.EventHandler(this.Base_Button_Click);
            // 
            // frmClose_Sham_Sell_Down_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(1300, 800);
            this.ClientSize = new System.Drawing.Size(1096, 746);
            this.Controls.Add(this.dGridView_Base_Sub);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.Name = "frmClose_Sham_Sell_Down_2";
            this.Text = "주간_정산_하선_누적Bv_조정";
            this.Activated += new System.EventHandler(this.frm_Base_Activated);
            this.Load += new System.EventHandler(this.frmBase_From_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmBase_From_KeyDown);
            this.Resize += new System.EventHandler(this.frmBase_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dGridView_Base_Sub)).EndInit();
            this.panel10.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tableLayoutPanel33.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tableLayoutPanel37.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.tableLayoutPanel38.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dGridView_Base_Sub;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.MaskedTextBox mtxtMakeDate2;
        private System.Windows.Forms.MaskedTextBox mtxtMakeDate1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker DTP_MakeDate2;
        private System.Windows.Forms.DateTimePicker DTP_MakeDate1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.MaskedTextBox mtxtSMbid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ComboBox combo_Se_Code2;
        private System.Windows.Forms.ComboBox combo_Se2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox mtxtSMbid2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioB_S;
        private System.Windows.Forms.RadioButton radioB_SM_3;
        private System.Windows.Forms.RadioButton radioB_SM_2;
        private System.Windows.Forms.RadioButton radioB_SM_1;
        private System.Windows.Forms.RadioButton radioB_S_7;
        private System.Windows.Forms.RadioButton radioB_S_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioB_R;
        private System.Windows.Forms.RadioButton radioB_RM_3;
        private System.Windows.Forms.RadioButton radioB_RM_2;
        private System.Windows.Forms.RadioButton radioB_RM_1;
        private System.Windows.Forms.RadioButton radioB_R_7;
        private System.Windows.Forms.RadioButton radioB_R_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txtR_Id_Code;
        private System.Windows.Forms.TextBox txtR_Id;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.TextBox txtName2;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button butt_Excel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate3;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DateTimePicker DTP_SellDate3;
        private System.Windows.Forms.DateTimePicker DTP_SellDate2;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button butt_Search;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txt_Pv;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.MaskedTextBox mtxtMbid;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtSellCode_Code;
        private System.Windows.Forms.TextBox txtSellCode;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.MaskedTextBox mtxtSellDate;
        private System.Windows.Forms.DateTimePicker DTP_SellDate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.Button butt_Delete;
        private System.Windows.Forms.Button butt_Clear;
        private System.Windows.Forms.Button butt_Save;
        private System.Windows.Forms.Button butt_Exit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioB_SellTF1;
        private System.Windows.Forms.RadioButton radioB_SellTF2;
    }
}